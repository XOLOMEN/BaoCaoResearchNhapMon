'use client';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

const COLORS = ['#60B5FF', '#FF9149', '#80D8C3', '#A19AD3', '#FF90BB'];

export default function ClassUtilChart({ data }: { data: any[] }) {
  const chartData = (data ?? [])?.map?.((d: any) => ({
    name: d?.code ?? d?.name ?? '',
    'Tỷ lệ (%)': d?.rate ?? 0,
  })) ?? [];

  if (chartData.length === 0) {
    return <div className="h-full flex items-center justify-center text-sm text-muted-foreground">Chưa có dữ liệu</div>;
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 20 }}>
        <XAxis dataKey="name" tickLine={false} tick={{ fontSize: 10 }} interval="preserveStartEnd" />
        <YAxis tickLine={false} tick={{ fontSize: 10 }} domain={[0, 100]} />
        <Tooltip contentStyle={{ fontSize: 11 }} />
        <Bar dataKey="Tỷ lệ (%)" radius={[4, 4, 0, 0]}>
          {chartData?.map?.((_: any, i: number) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
