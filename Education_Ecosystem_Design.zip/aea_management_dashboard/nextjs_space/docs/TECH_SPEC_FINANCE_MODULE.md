# AEA Finance Module – Technical Specification

> **Version:** 1.0  
> **Author:** AEA Architecture Team  
> **Status:** Draft – Pending Review  
> **Date:** June 2026  
> **Scope:** Revenue tracking, Academic↔Finance synchronization, Dashboard revenue charts  
> **Related Documents:** `aea_system_design.md`, `aea_database_ddl.sql`, `prisma/schema.prisma`

---

## Mục lục

1. [Tổng quan & Mục tiêu](#1-tổng-quan--mục-tiêu)
2. [Phần 1: Cấu trúc dữ liệu Finance Module](#2-phần-1-cấu-trúc-dữ-liệu-finance-module)
3. [Phần 2: Quy trình đồng bộ Học vụ ↔ Tài chính](#3-phần-2-quy-trình-đồng-bộ-học-vụ--tài-chính)
4. [Phần 3: Tích hợp biểu đồ doanh thu vào Dashboard](#4-phần-3-tích-hợp-biểu-đồ-doanh-thu-vào-dashboard)
5. [Phụ lục: Migration & Rollback Strategy](#5-phụ-lục-migration--rollback-strategy)

---

## 1. Tổng quan & Mục tiêu

### 1.1 Business Context

Hệ thống AEA hiện đã có Academic Module hoạt động đầy đủ với các chức năng: quản lý học viên, giáo viên, khóa học, lớp học, ghi danh, và chấm điểm. Finance Module là pha tiếp theo, tập trung vào:

- **Theo dõi doanh thu học phí** theo chi nhánh và theo tháng/quý/năm
- **Tự động hóa quy trình tạo hóa đơn** khi học viên đăng ký khóa học
- **Hiển thị biểu đồ tài chính** trực tiếp trên trang Dashboard tổng quan

### 1.2 Hiện trạng hệ thống

| Thành phần | Trạng thái | Ghi chú |
|---|---|---|
| Prisma Schema (Finance tables) | ✅ Đã có | Invoice, InvoiceItem, Payment, PaymentPlan, Discount, Expense |
| SQL DDL (finance schema) | ✅ Đã có | Đầy đủ FK, indexes, JSONB comments, RLS |
| API Routes (Finance) | ❌ Chưa có | Cần xây dựng |
| UI Pages (Finance) | ❌ Chưa có | Sidebar đang hiển thị "Sắp ra mắt" |
| Dashboard Stats API | ✅ Đã có | Chỉ có Academic metrics, cần mở rộng |
| Dashboard Charts | ✅ Đã có | 3 charts Academic, cần thêm Revenue chart |

### 1.3 Mục tiêu kỹ thuật

```
┌────────────────────────────────────────────────────────────────────┐
│                    FINANCE MODULE GOALS                            │
│                                                                    │
│  G1. Revenue by Branch by Month tracking                          │
│  G2. Auto-invoice on enrollment (Academic ↔ Finance sync)         │
│  G3. Revenue chart on Dashboard                                    │
│  G4. Zero breaking changes to existing Academic module             │
│  G5. AI-ready data structure (metadata JSONB preserved)            │
│  G6. Multi-branch RLS compliance                                   │
└────────────────────────────────────────────────────────────────────┘
```

---

## 2. Phần 1: Cấu trúc dữ liệu Finance Module

### 2.1 Entity Relationship – Finance Context

```
                            ┌─────────────────┐
                            │   core.branches  │
                            │   (branch_id)    │
                            └────────┬─────────┘
                                     │ 1:N
              ┌──────────────┬───────┼───────┬──────────────┐
              │              │       │       │              │
              ▼              ▼       ▼       ▼              ▼
    ┌─────────────┐  ┌────────────┐  │  ┌──────────┐  ┌──────────┐
    │  discounts   │  │  expenses   │  │  │ payments │  │ invoices │
    └──────┬──────┘  └────────────┘  │  └────┬─────┘  └────┬─────┘
           │                         │       │             │
           │         ┌───────────────┘       │             │
           │         │                       │             │
           └────────►│◄──────────────────────┘             │
                     │                                     │
                     ▼                                     ▼
              ┌─────────────┐                    ┌──────────────┐
              │   invoices   │◄───────────────────│invoice_items │
              │              │    1:N              └──────────────┘
              │              │
              │              │◄──── payment_plans (1:N)
              │              │
              │ student_id ──┼──► academic.students
              │ enrollment_id┼──► academic.enrollments
              └──────────────┘
```

### 2.2 Mô hình dữ liệu theo dõi doanh thu

Để theo dõi doanh thu học phí **theo chi nhánh và theo tháng**, dữ liệu được trích xuất từ 2 bảng chính:

#### 2.2.1 Bảng `invoices` – Nguồn doanh thu gốc

```
finance.invoices
├── branch_id        → Phân loại theo chi nhánh
├── type              → Loại doanh thu: 'tuition' | 'materials' | 'registration' | 'exam_fee'
├── total_amount      → Tổng giá trị hóa đơn (VND)
├── paid_amount       → Số tiền đã thu thực tế
├── status            → Trạng thái: draft → issued → partially_paid → paid
├── issued_at         → Thời điểm phát hành (dùng cho báo cáo theo tháng)
├── due_date          → Hạn thanh toán
└── currency          → VND (mặc định)
```

#### 2.2.2 Bảng `payments` – Dòng tiền thực tế

```
finance.payments
├── branch_id        → Chi nhánh thu tiền
├── amount           → Số tiền thanh toán
├── payment_method   → 'cash' | 'bank_transfer' | 'momo' | 'vnpay' | 'zalopay'
├── payment_date     → Ngày thanh toán thực tế (dùng cho báo cáo theo tháng)
├── status           → 'completed' | 'pending' | 'refunded'
└── invoice_id       → Liên kết ngược về hóa đơn
```

### 2.3 Chiến lược truy vấn doanh thu

#### Revenue by Branch by Month (Core Query)

Doanh thu được tính theo **2 góc nhìn** khác nhau:

```
┌──────────────────────────────────────────────────────────────────────┐
│                    REVENUE CALCULATION MODELS                        │
│                                                                      │
│  MODEL A: Accrual Basis (Doanh thu phát sinh)                       │
│  ─────────────────────────────────────────────                       │
│  SELECT branch_id,                                                   │
│         DATE_TRUNC('month', issued_at) AS month,                     │
│         SUM(total_amount) AS accrued_revenue                         │
│  FROM finance.invoices                                               │
│  WHERE status NOT IN ('draft', 'cancelled')                          │
│  GROUP BY branch_id, month                                           │
│                                                                      │
│  → Phản ánh tổng doanh thu phát sinh (kể cả chưa thu)              │
│  → Dùng cho: Báo cáo doanh thu kế toán                             │
│                                                                      │
│  MODEL B: Cash Basis (Doanh thu thực thu)                           │
│  ────────────────────────────────────────                            │
│  SELECT branch_id,                                                   │
│         DATE_TRUNC('month', payment_date) AS month,                  │
│         SUM(amount) AS collected_revenue                              │
│  FROM finance.payments                                               │
│  WHERE status = 'completed'                                          │
│  GROUP BY branch_id, month                                           │
│                                                                      │
│  → Phản ánh tiền thực tế đã vào tài khoản                          │
│  → Dùng cho: Dashboard overview, cash flow management               │
│                                                                      │
│  ★ KHUYẾN NGHỊ: Dashboard mặc định dùng MODEL B (Cash Basis)       │
│    vì phản ánh đúng dòng tiền thực. MODEL A hiển thị trong          │
│    trang Finance Reports chi tiết.                                   │
└──────────────────────────────────────────────────────────────────────┘
```

### 2.4 Prisma Query tương ứng (Application Layer)

```typescript
// === MODEL B: Cash Basis Revenue by Branch by Month ===

// Option 1: Prisma groupBy (khuyến nghị cho đơn giản)
const revenueByMonth = await prisma.payment.groupBy({
  by: ['branchId'],
  where: {
    status: 'completed',
    paymentDate: { gte: startDate, lte: endDate },
    ...(branchId ? { branchId } : {}),
  },
  _sum: { amount: true },
});

// Option 2: Raw SQL (khuyến nghị cho báo cáo phức tạp)
const revenueTrend = await prisma.$queryRaw`
  SELECT
    b.name AS branch_name,
    b.code AS branch_code,
    TO_CHAR(p.payment_date, 'YYYY-MM') AS month,
    COUNT(p.id) AS transaction_count,
    SUM(p.amount) AS total_collected,
    SUM(CASE WHEN p.payment_method = 'cash' THEN p.amount ELSE 0 END) AS cash_amount,
    SUM(CASE WHEN p.payment_method != 'cash' THEN p.amount ELSE 0 END) AS transfer_amount
  FROM payments p
  INNER JOIN branches b ON b.id = p.branch_id
  WHERE p.status = 'completed'
    AND p.payment_date >= ${startDate}
    AND p.payment_date <= ${endDate}
  GROUP BY b.name, b.code, TO_CHAR(p.payment_date, 'YYYY-MM')
  ORDER BY month ASC, branch_name ASC
`;
```

### 2.5 Data Aggregation Views (Đề xuất)

Để tối ưu hiệu suất cho Dashboard queries, đề xuất tạo **Materialized View** hoặc **denormalized aggregation table**:

```sql
-- Materialized View cho revenue summary (refresh nightly hoặc on-demand)
CREATE MATERIALIZED VIEW finance.mv_monthly_revenue AS
SELECT
    p.branch_id,
    b.name AS branch_name,
    b.code AS branch_code,
    DATE_TRUNC('month', p.payment_date)::DATE AS month,
    COUNT(DISTINCT p.invoice_id) AS invoice_count,
    COUNT(p.id) AS payment_count,
    SUM(p.amount) AS total_collected,
    SUM(CASE WHEN p.payment_method = 'cash' THEN p.amount ELSE 0 END) AS cash_collected,
    SUM(CASE WHEN p.payment_method IN ('bank_transfer','momo','vnpay','zalopay') THEN p.amount ELSE 0 END) AS digital_collected
FROM payments p
INNER JOIN branches b ON b.id = p.branch_id
WHERE p.status = 'completed'
GROUP BY p.branch_id, b.name, b.code, DATE_TRUNC('month', p.payment_date)
ORDER BY month DESC;

-- Index cho fast lookups
CREATE UNIQUE INDEX idx_mv_revenue_branch_month
    ON finance.mv_monthly_revenue (branch_id, month);

-- Refresh command (chạy via scheduled task hoặc after payment creation)
REFRESH MATERIALIZED VIEW CONCURRENTLY finance.mv_monthly_revenue;
```

> **Lưu ý:** Trong giai đoạn đầu (< 10,000 payments), query trực tiếp từ bảng `payments` là đủ nhanh. Materialized View nên áp dụng khi hệ thống scale lên.

### 2.6 Cấu trúc dữ liệu cho AI-Ready Analytics

Mỗi payment và invoice đều có trường `metadata JSONB` dùng cho AI pipeline sau này:

```jsonc
// invoice.metadata – AI sẽ ghi vào _ai namespace
{
  "_ai": {
    "payment_prediction": {
      "probability_on_time": 0.82,
      "expected_date": "2026-07-15",
      "risk_level": "low"         // low | medium | high
    },
    "anomaly_flags": [],           // ["duplicate_suspected", "amount_exceeds_2sigma"]
    "revenue_category": "tuition", // classification by AI
    "student_ltv_impact": 15000000 // Lifetime value impact
  }
}

// payment.metadata – AI sẽ ghi vào _ai namespace  
{
  "_ai": {
    "duplicate_risk": 0.02,
    "anomaly_score": 0.05,
    "anomaly_type": null,
    "verified_automatically": true
  }
}
```

---

## 3. Phần 2: Quy trình đồng bộ Học vụ ↔ Tài chính

### 3.1 Business Rule

```
┌─────────────────────────────────────────────────────────────────────────┐
│  RULE: Khi học viên đăng ký khóa học (enrollment created),             │
│        hệ thống TỰ ĐỘNG tạo hóa đơn nháp (draft invoice)              │
│        với thông tin học phí từ khóa học.                               │
│                                                                         │
│  Trigger: POST /api/enrollments (enrollment.create)                     │
│  Action:  Auto-create Invoice with status = 'draft'                     │
│  Scope:   Same branch_id as enrollment                                  │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Sequence Diagram

```
  Staff/Admin              API Server              Database
      │                        │                       │
      │  POST /api/enrollments │                       │
      │  {studentId, classId,  │                       │
      │   branchId}            │                       │
      │───────────────────────►│                       │
      │                        │                       │
      │                        │ 1. Validate capacity  │
      │                        │──────────────────────►│
      │                        │◄──────────────────────│
      │                        │                       │
      │                        │ 2. BEGIN TRANSACTION  │
      │                        │──────────────────────►│
      │                        │                       │
      │                        │ 2a. Create Enrollment │
      │                        │──────────────────────►│
      │                        │◄─── enrollment record │
      │                        │                       │
      │                        │ 2b. Fetch Course fees │
      │                        │──────────────────────►│
      │                        │◄─── course.tuition_fee│
      │                        │     course.materials_ │
      │                        │     fee               │
      │                        │                       │
      │                        │ 2c. Generate invoice  │
      │                        │     number            │
      │                        │──────────────────────►│
      │                        │◄─── next invoice seq  │
      │                        │                       │
      │                        │ 2d. Create Invoice    │
      │                        │     (status='draft')  │
      │                        │──────────────────────►│
      │                        │◄─── invoice record    │
      │                        │                       │
      │                        │ 2e. Create Invoice    │
      │                        │     Items             │
      │                        │──────────────────────►│
      │                        │◄─── items created     │
      │                        │                       │
      │                        │ 2f. COMMIT            │
      │                        │──────────────────────►│
      │                        │                       │
      │  201 Created           │                       │
      │  {enrollment, invoice} │                       │
      │◄───────────────────────│                       │
      │                        │                       │
```

### 3.3 Thiết kế API – Enrollment + Auto-Invoice

#### Cập nhật `POST /api/enrollments`

```typescript
// File: app/api/enrollments/route.ts
// MODIFIED: Add auto-invoice creation inside a transaction

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await request.json();
  const { studentId, classId, branchId } = body;

  // Validate inputs
  if (!studentId || !classId || !branchId) {
    return NextResponse.json({ error: 'Thiếu thông tin bắt buộc' }, { status: 400 });
  }

  // Capacity check
  const cls = await prisma.class.findUnique({
    where: { id: classId },
    include: {
      _count: { select: { enrollments: true } },
      course: { select: { id: true, name: true, code: true, tuitionFee: true, materialsFee: true } },
    },
  });
  if (!cls) return NextResponse.json({ error: 'Lớp không tồn tại' }, { status: 404 });
  if (cls._count.enrollments >= cls.capacity) {
    return NextResponse.json({ error: 'Lớp đã đầy' }, { status: 400 });
  }

  // === TRANSACTION: Enrollment + Auto-Invoice ===
  const result = await prisma.$transaction(async (tx) => {
    // Step 1: Create enrollment
    const enrollment = await tx.enrollment.create({
      data: {
        studentId,
        classId,
        branchId,
        status: 'active',
        enrolledAt: new Date(),
      },
    });

    // Step 2: Generate invoice number
    // Format: INV-{BRANCH_CODE}-{YYYYMM}-{SEQUENCE}
    const branch = await tx.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const now = new Date();
    const monthStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const prefix = `INV-${branch?.code ?? 'XX'}-${monthStr}`;

    // Count existing invoices this month for this branch to get next sequence
    const existingCount = await tx.invoice.count({
      where: {
        branchId,
        invoiceNumber: { startsWith: prefix },
      },
    });
    const invoiceNumber = `${prefix}-${String(existingCount + 1).padStart(4, '0')}`;

    // Step 3: Calculate amounts
    const tuitionFee = cls.course?.tuitionFee ?? 0;
    const materialsFee = cls.course?.materialsFee ?? 0;
    const subtotal = tuitionFee + materialsFee;
    const taxAmount = 0; // Education services exempt from VAT in Vietnam
    const totalAmount = subtotal - 0 + taxAmount; // No discount by default

    // Step 4: Create draft invoice
    const invoice = await tx.invoice.create({
      data: {
        branchId,
        invoiceNumber,
        studentId,
        enrollmentId: enrollment.id,
        type: 'tuition',
        subtotal,
        discountAmount: 0,
        taxAmount,
        totalAmount,
        paidAmount: 0,
        currency: 'VND',
        dueDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000), // +30 days
        status: 'draft',
        issuedBy: (session.user as any)?.id ?? null,
        metadata: {
          auto_generated: true,
          source: 'enrollment_sync',
          enrollment_id: enrollment.id,
          course_id: cls.course?.id,
          course_name: cls.course?.name,
        },
      },
    });

    // Step 5: Create invoice line items
    const items = [];
    if (tuitionFee > 0) {
      items.push({
        invoiceId: invoice.id,
        description: `Học phí khóa ${cls.course?.name ?? ''} (${cls.course?.code ?? ''})`,
        quantity: 1,
        unitPrice: tuitionFee,
        amount: tuitionFee,
      });
    }
    if (materialsFee > 0) {
      items.push({
        invoiceId: invoice.id,
        description: `Phí tài liệu khóa ${cls.course?.name ?? ''} (${cls.course?.code ?? ''})`,
        quantity: 1,
        unitPrice: materialsFee,
        amount: materialsFee,
      });
    }
    if (items.length > 0) {
      await tx.invoiceItem.createMany({ data: items });
    }

    return { enrollment, invoice };
  });

  return NextResponse.json(result, { status: 201 });
}
```

### 3.4 Invoice Number Convention

```
Format: INV-{BRANCH_CODE}-{YYYYMM}-{SEQUENCE}

Examples:
  INV-HCM-Q1-202607-0001   → Hóa đơn #1, chi nhánh Q1, tháng 07/2026
  INV-HCM-Q7-202607-0042   → Hóa đơn #42, chi nhánh Q7, tháng 07/2026
  INV-HN-CG-202608-0001    → Hóa đơn #1, chi nhánh Cầu Giấy, tháng 08/2026

Properties:
  • Unique per branch per month
  • Sortable chronologically
  • Human-readable branch identifier
  • Sequential within each month-branch partition
```

### 3.5 Data Integrity Rules

```
┌─────────────────────────────────────────────────────────────────────────┐
│  INTEGRITY RULES (enforced at application + database level)            │
│                                                                         │
│  R1. Mỗi Enrollment chỉ có TỐI ĐA 1 Invoice với type='tuition'        │
│      → Enforced by: UNIQUE(enrollment_id) WHERE type='tuition'         │
│        hoặc application-level check trước khi tạo                      │
│                                                                         │
│  R2. Invoice.total_amount = SUM(invoice_items.amount)                   │
│      - discount_amount + tax_amount                                     │
│      → Enforced by: Application recalculation on item changes          │
│                                                                         │
│  R3. Invoice.paid_amount = SUM(payments.amount)                         │
│      WHERE payments.status = 'completed'                                │
│      → Enforced by: Trigger/application update after each payment      │
│                                                                         │
│  R4. Invoice.status auto-transitions:                                   │
│      draft → issued (when issued_at is set)                             │
│      issued → partially_paid (when 0 < paid_amount < total_amount)     │
│      partially_paid → paid (when paid_amount >= total_amount)          │
│      issued/partially_paid → overdue (when NOW() > due_date)           │
│      → Enforced by: Application logic after payment/date check         │
│                                                                         │
│  R5. Xóa Enrollment → Invoice chuyển status='cancelled'                │
│      (KHÔNG xóa invoice – giữ cho audit trail)                         │
│      → Enforced by: Application soft-delete pattern                    │
│                                                                         │
│  R6. Tất cả financial operations cùng branch_id với enrollment          │
│      → Enforced by: FK + application validation + RLS policy           │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.6 Error Handling & Edge Cases

| Scenario | Handling | HTTP Code |
|---|---|---|
| Student already enrolled in class | Return `P2002` duplicate error | `409 Conflict` |
| Class at full capacity | Reject enrollment | `400 Bad Request` |
| Course has tuitionFee = 0 | Create enrollment WITHOUT invoice (free course) | `201 Created` |
| Transaction fails mid-way | Prisma `$transaction` auto-rollback (both enrollment AND invoice) | `500 Internal` |
| Invoice number collision | Retry with incremented sequence | Transparent |
| Enrollment deleted/dropped | Set invoice status → `cancelled`, paid_amount refund logic | `200 OK` |

### 3.7 Event Store Integration (AI Pipeline)

Khi enrollment+invoice được tạo, ghi event vào `system.event_store`:

```typescript
// After successful transaction
await tx.eventStore.create({
  data: {
    branchId,
    aggregateType: 'enrollment',
    aggregateId: enrollment.id,
    eventType: 'enrollment.created_with_invoice',
    payload: {
      student_id: studentId,
      class_id: classId,
      invoice_id: invoice.id,
      invoice_amount: totalAmount,
      course_id: cls.course?.id,
      auto_generated: true,
    },
    sequenceNumber: 0, // auto-increment in production
  },
});
```

---

## 4. Phần 3: Tích hợp biểu đồ doanh thu vào Dashboard

### 4.1 Hiện trạng Dashboard

Trang Dashboard hiện tại (`/dashboard`) bao gồm:

```
┌─────────────────────────────────────────────────────────────────────┐
│  DASHBOARD LAYOUT HIỆN TẠI                                          │
│                                                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐              │
│  │Tổng HV   │ │Lớp đang  │ │Giáo viên │ │Khóa học  │   ← KPI Row │
│  │(Students)│ │học       │ │(Teachers)│ │(Courses) │              │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘              │
│                                                                     │
│  ┌─────────────────────┐ ┌─────────────────────┐                   │
│  │ Xu hướng ghi danh   │ │ Sử dụng lớp học     │   ← Charts Row 1│
│  │ (Area Chart)        │ │ (Bar Chart)         │                   │
│  └─────────────────────┘ └─────────────────────┘                   │
│                                                                     │
│  ┌─────────────────────┐ ┌─────────────────────┐                   │
│  │ Tổng quan chi nhánh │ │ Ghi danh gần đây    │   ← Charts Row 2│
│  │ (Bar Chart)         │ │ (List)              │                   │
│  └─────────────────────┘ └─────────────────────┘                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 4.2 Layout sau khi tích hợp Finance

```
┌─────────────────────────────────────────────────────────────────────┐
│  DASHBOARD LAYOUT SAU TÍCH HỢP                                      │
│                                                                     │
│  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐│
│  │Tổng HV │ │Lớp đang│ │Giáo    │ │Khóa    │ │Doanh   │ │Công nợ ││
│  │        │ │học     │ │viên    │ │học     │ │thu     │ │        ││
│  │ 245    │ │ 12     │ │ 18     │ │ 8      │ │ 1.2B   │ │ 350M   ││
│  └────────┘ └────────┘ └────────┘ └────────┘ └────────┘ └────────┘│
│  ← Academic KPIs (existing) →  ← Finance KPIs (NEW) →             │
│                                                                     │
│  ┌─────────────────────┐ ┌─────────────────────────────┐           │
│  │ Xu hướng ghi danh   │ │ ★ DOANH THU THEO THÁNG      │           │
│  │ (Area Chart)        │ │   (Stacked Bar Chart)       │  ← NEW   │
│  │                     │ │   - Theo chi nhánh           │           │
│  │                     │ │   - 6 tháng gần nhất         │           │
│  └─────────────────────┘ └─────────────────────────────┘           │
│                                                                     │
│  ┌─────────────────────┐ ┌─────────────────────┐                   │
│  │ Sử dụng lớp học     │ │ Tổng quan chi nhánh │                   │
│  │ (Bar Chart)         │ │ (Bar Chart)         │                   │
│  └─────────────────────┘ └─────────────────────┘                   │
│                                                                     │
│  ┌─────────────────────┐ ┌─────────────────────┐                   │
│  │ Ghi danh gần đây    │ │ ★ HOÁ ĐƠN CHỜ THU  │                   │
│  │ (List)              │ │   (Table - NEW)     │  ← NEW            │
│  └─────────────────────┘ └─────────────────────┘                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 4.3 Yêu cầu kỹ thuật chi tiết

#### 4.3.1 API Endpoint mới: `GET /api/dashboard/finance-stats`

```typescript
// File: app/api/dashboard/finance-stats/route.ts
// Purpose: Provide finance KPIs and chart data for Dashboard

// Request
GET /api/dashboard/finance-stats?branchId={optional}

// Response Schema
interface FinanceStatsResponse {
  // === KPI Cards ===
  totalRevenue: number;           // Tổng doanh thu tháng hiện tại (VND)
  totalRevenueLastMonth: number;  // Doanh thu tháng trước (để tính % change)
  revenueGrowthPercent: number;   // % tăng/giảm so với tháng trước
  totalOutstanding: number;       // Tổng công nợ (chưa thu)
  overdueAmount: number;          // Số tiền quá hạn
  overdueInvoiceCount: number;    // Số hóa đơn quá hạn
  collectionRate: number;         // Tỷ lệ thu (paid_amount / total_amount) %

  // === Revenue by Month Chart ===
  revenueByMonth: Array<{
    month: string;                // "2026-01", "2026-02", ...
    total: number;                // Tổng doanh thu tất cả chi nhánh
    branches: Array<{
      branchId: string;
      branchName: string;
      branchCode: string;
      amount: number;             // Doanh thu chi nhánh trong tháng
    }>;
  }>;

  // === Outstanding Invoices (Top 5) ===
  outstandingInvoices: Array<{
    id: string;
    invoiceNumber: string;
    studentName: string;
    totalAmount: number;
    paidAmount: number;
    balance: number;              // totalAmount - paidAmount
    dueDate: string;              // ISO date
    isOverdue: boolean;
    branchName: string;
  }>;

  // === Revenue by Payment Method (current month) ===
  revenueByMethod: Array<{
    method: string;               // 'cash', 'bank_transfer', 'momo', etc.
    amount: number;
    count: number;
  }>;
}
```

#### 4.3.2 Implementation Logic

```typescript
// Pseudocode cho /api/dashboard/finance-stats

async function GET(request) {
  // Auth check
  const session = await getServerSession(authOptions);
  const branchId = url.searchParams.get('branchId');
  const branchFilter = branchId ? { branchId } : {};

  const now = new Date();
  const currentMonthStart = startOfMonth(now);
  const lastMonthStart = startOfMonth(subMonths(now, 1));
  const sixMonthsAgo = startOfMonth(subMonths(now, 5));

  const [
    currentMonthRevenue,
    lastMonthRevenue,
    outstandingTotal,
    overdueInvoices,
    revenueByMonthRaw,
    topOutstanding,
    methodBreakdown,
  ] = await Promise.all([
    // KPI: Current month revenue (Cash Basis)
    prisma.payment.aggregate({
      where: { status: 'completed', paymentDate: { gte: currentMonthStart }, ...branchFilter },
      _sum: { amount: true },
    }),

    // KPI: Last month revenue
    prisma.payment.aggregate({
      where: {
        status: 'completed',
        paymentDate: { gte: lastMonthStart, lt: currentMonthStart },
        ...branchFilter,
      },
      _sum: { amount: true },
    }),

    // KPI: Total outstanding (unpaid invoices)
    prisma.invoice.aggregate({
      where: { status: { in: ['issued', 'partially_paid', 'overdue'] }, ...branchFilter },
      _sum: { totalAmount: true, paidAmount: true },
    }),

    // KPI: Overdue invoices
    prisma.invoice.aggregate({
      where: {
        status: { in: ['issued', 'partially_paid'] },
        dueDate: { lt: now },
        ...branchFilter,
      },
      _count: true,
      _sum: { totalAmount: true, paidAmount: true },
    }),

    // Chart: Revenue by month (last 6 months, grouped by branch)
    prisma.payment.findMany({
      where: {
        status: 'completed',
        paymentDate: { gte: sixMonthsAgo },
        ...branchFilter,
      },
      select: { amount: true, paymentDate: true, branchId: true, branch: { select: { name: true, code: true } } },
    }),

    // Table: Top outstanding invoices
    prisma.invoice.findMany({
      where: { status: { in: ['issued', 'partially_paid', 'overdue'] }, ...branchFilter },
      orderBy: [{ dueDate: 'asc' }],
      take: 5,
      include: {
        student: { select: { fullName: true } },
        branch: { select: { name: true } },
      },
    }),

    // Chart: Revenue by payment method (current month)
    prisma.payment.groupBy({
      by: ['paymentMethod'],
      where: { status: 'completed', paymentDate: { gte: currentMonthStart }, ...branchFilter },
      _sum: { amount: true },
      _count: true,
    }),
  ]);

  // Aggregate revenue by month-branch for chart
  // ... (aggregate revenueByMonthRaw into structured response)

  return NextResponse.json(/* response */);
}
```

#### 4.3.3 New Chart Component: `RevenueChart`

```typescript
// File: app/dashboard/charts/revenue-chart.tsx
// Type: Stacked Bar Chart (recharts)
// Purpose: Display revenue by branch by month

import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

interface RevenueChartProps {
  data: Array<{
    month: string;        // "2026-01" → display as "T1/2026"
    [branchCode: string]: number | string; // dynamic branch keys
  }>;
  branches: Array<{
    code: string;
    name: string;
    color: string;
  }>;
}

// Chart configuration:
// - Stacked bars: mỗi segment = 1 chi nhánh
// - X-axis: Tháng (T1, T2, T3, ...)
// - Y-axis: VND (formatted: 1.2B, 350M, etc.)
// - Colors: mỗi chi nhánh 1 màu khác nhau
// - Tooltip: hiển thị chi tiết từng chi nhánh + tổng
// - Dynamic import với ssr: false (như các chart hiện tại)

// Color palette for branches:
const BRANCH_COLORS = [
  '#3b82f6', // blue (Q1)
  '#10b981', // green (Q7)
  '#f59e0b', // amber (Cầu Giấy)
  '#8b5cf6', // purple (future branch 4)
  '#ef4444', // red (future branch 5)
];

// VND formatter:
const formatVND = (value: number) => {
  if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(1)}B`;
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(0)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(0)}K`;
  return value.toString();
};
```

#### 4.3.4 Dashboard Content Modifications

```typescript
// File: app/dashboard/dashboard-content.tsx
// MODIFICATIONS:

// 1. Import new chart
const RevenueChart = dynamic(() => import('./charts/revenue-chart'), {
  ssr: false,
  loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải biểu đồ...</div>,
});

// 2. Add finance stats state
const [financeStats, setFinanceStats] = useState<FinanceStats | null>(null);

// 3. Fetch finance stats in useEffect
useEffect(() => {
  const q = branchId ? `?branchId=${branchId}` : '';
  Promise.all([
    fetch(`/api/dashboard/stats${q}`).then(r => r.json()),
    fetch(`/api/dashboard/finance-stats${q}`).then(r => r.json()),
  ]).then(([academic, finance]) => {
    setStats(academic);
    setFinanceStats(finance);
  });
}, [branchId]);

// 4. Add 2 new KPI cards to the grid
const kpis = [
  // ... existing 4 KPIs ...
  {
    label: 'Doanh thu tháng này',
    value: formatVND(financeStats?.totalRevenue ?? 0),
    icon: DollarSign,
    color: 'text-green-600',
    bg: 'bg-green-50',
    trend: financeStats?.revenueGrowthPercent,  // Show ▲ +12% or ▼ -5%
  },
  {
    label: 'Công nợ chờ thu',
    value: formatVND(financeStats?.totalOutstanding ?? 0),
    icon: CreditCard,
    color: 'text-red-600',
    bg: 'bg-red-50',
    badge: financeStats?.overdueInvoiceCount > 0
      ? `${financeStats.overdueInvoiceCount} quá hạn`
      : null,
  },
];

// 5. Change KPI grid from grid-cols-4 to grid-cols-3 lg:grid-cols-6
// to accommodate 6 KPI cards

// 6. Add Revenue Chart in Charts Row 1 (right side)
// Replace the current layout:
//   Row 1: [Enrollment Trend] [Revenue Chart]  ← Revenue replaces Class Util
//   Row 2: [Class Utilization] [Branch Overview]
//   Row 3: [Recent Enrollments] [Outstanding Invoices]  ← NEW
```

### 4.4 Component Specification Summary

| Component | File | Type | Data Source | Dependencies |
|---|---|---|---|---|
| `RevenueChart` | `charts/revenue-chart.tsx` | Stacked Bar Chart | `financeStats.revenueByMonth` | `recharts` |
| `OutstandingTable` | `charts/outstanding-table.tsx` | Table/List | `financeStats.outstandingInvoices` | `shadcn/ui` |
| Finance KPI Cards | inline in `dashboard-content.tsx` | Card | `financeStats.totalRevenue`, etc. | `lucide-react` |

### 4.5 Performance Considerations

```
┌─────────────────────────────────────────────────────────────────────────┐
│  PERFORMANCE BUDGET                                                     │
│                                                                         │
│  Target: Dashboard load < 2 seconds (including finance data)            │
│                                                                         │
│  Strategy:                                                              │
│  1. Parallel fetch: Academic stats + Finance stats in Promise.all()     │
│  2. Database indexes already created:                                   │
│     - idx_payments_date (payment_date)                                  │
│     - idx_payments_branch (branch_id)                                   │
│     - idx_invoices_status (branch_id, status)                           │
│     - idx_invoices_due (due_date) WHERE status NOT IN (paid,cancelled)  │
│  3. Limit data window: 6 months for charts, 5 items for lists          │
│  4. Dynamic import for chart components (code splitting)                │
│  5. Future: Materialized View when payments > 10,000 records            │
│                                                                         │
│  Estimated query times (< 1,000 records):                               │
│  - Payment aggregation: < 50ms                                          │
│  - Invoice aggregation: < 50ms                                          │
│  - Combined response:   < 200ms                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 4.6 Branch Selector Integration

Biểu đồ doanh thu tuân theo **Global Branch Context** hiện tại:

```
• Chọn "Tất cả chi nhánh" → Stacked bar (mỗi segment = 1 branch)
• Chọn 1 chi nhánh cụ thể → Single bar (chỉ branch đó)

Branch context được đọc từ useBranch() hook,
truyền qua query parameter ?branchId={id} đến API.
```

---

## 5. Phụ lục: Migration & Rollback Strategy

### 5.1 Implementation Phases

```
 Phase 1 (Backend):     Phase 2 (Frontend):     Phase 3 (Polish):
 ┌─────────────────┐   ┌─────────────────┐    ┌─────────────────┐
 │ • Update POST   │   │ • RevenueChart  │    │ • Finance pages │
 │   /enrollments  │   │   component     │    │   (Invoices,    │
 │   with auto-    │   │ • Finance KPIs  │    │    Payments)    │
 │   invoice logic │   │   on dashboard  │    │ • Payment flow  │
 │ • Create GET    │   │ • Outstanding   │    │ • Reports       │
 │   /finance-stats│   │   invoices list │    │ • Discount mgmt │
 │ • Seed sample   │   │ • Layout update │    │ • Expense mgmt  │
 │   finance data  │   │                 │    │                 │
 └─────────────────┘   └─────────────────┘    └─────────────────┘
    ~4 hours              ~3 hours                ~6 hours
```

### 5.2 Database Migration

```
Không cần migration! 

Các bảng Finance (invoices, payments, invoice_items, payment_plans, 
discounts, expenses) đã tồn tại trong Prisma schema từ Phase 1.

Chỉ cần:
1. Seed dữ liệu mẫu (sample invoices + payments) cho testing
2. Cập nhật logic tại enrollment API
3. Tạo mới finance-stats API endpoint
```

### 5.3 Rollback Plan

```
Nếu cần rollback:
1. Revert POST /api/enrollments → bỏ invoice creation logic
   (enrollment vẫn tạo bình thường, chỉ không tạo invoice)
2. Remove /api/dashboard/finance-stats endpoint
3. Revert dashboard-content.tsx → bỏ finance KPIs + chart
4. Invoices đã tạo → giữ nguyên trong DB (status='draft', harmless)

Impact: ZERO impact on existing Academic module functionality.
```

---

## Ghi chú cuối

- Tất cả code backend viết bằng **TypeScript/English**, UI labels bằng **tiếng Việt**
- Tuân thủ RLS: mọi query đều filter theo `branchId` từ session/context
- JSONB metadata fields dự phòng cho AI pipeline trong tương lai
- Financial amounts luôn dùng `DECIMAL(12,2)` (Prisma `Float`), đơn vị VND
- Không sử dụng floating-point arithmetic cho financial calculations ở client-side

---

*Document generated based on current codebase analysis of AEA Management Dashboard.*
