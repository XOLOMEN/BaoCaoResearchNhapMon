export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getStudentSession } from '@/lib/portal/helpers';

export async function GET(_req: NextRequest, { params }: { params: { courseId: string } }) {
  const { error, session } = await getStudentSession();
  if (error) return error;
  const studentId = session!.user.studentId!;
  const { courseId } = params;

  try {
    // Verify enrollment
    const enrollment = await prisma.lmsEnrollment.findUnique({
      where: { lmsCourseId_studentId: { lmsCourseId: courseId, studentId } },
    });
    if (!enrollment) return NextResponse.json({ error: 'Not enrolled' }, { status: 403 });

    const course = await prisma.lmsCourse.findUnique({
      where: { id: courseId },
      include: {
        instructorUser: { select: { fullName: true, avatarUrl: true } },
        modules: {
          orderBy: { sortOrder: 'asc' },
          include: {
            lessons: {
              where: { isPublished: true },
              orderBy: { sortOrder: 'asc' },
              select: { id: true, title: true, type: true, sortOrder: true, durationMin: true, isFree: true },
            },
          },
        },
        lessons: {
          where: { isPublished: true, lmsModuleId: null },
          orderBy: { sortOrder: 'asc' },
          select: { id: true, title: true, type: true, sortOrder: true, durationMin: true, isFree: true },
        },
      },
    });
    if (!course) return NextResponse.json({ error: 'Course not found' }, { status: 404 });

    // Get progress for all lessons
    const progressRecords = await prisma.lmsProgress.findMany({
      where: { lmsEnrollmentId: enrollment.id },
      select: { lessonId: true, status: true, progressPct: true, completedAt: true, timeSpentSec: true },
    });
    const progressMap = Object.fromEntries(progressRecords.map((p: any) => [p.lessonId, p]));

    return NextResponse.json({
      course,
      enrollment,
      progressMap,
    });
  } catch (err: any) {
    console.error('Portal course detail error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
