export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getStudentSession } from '@/lib/portal/helpers';

export async function GET() {
  const { error, session } = await getStudentSession();
  if (error) return error;
  const studentId = session!.user.studentId!;

  try {
    const [enrollments, recentProgress, totalTimeSpent] = await Promise.all([
      prisma.lmsEnrollment.findMany({
        where: { studentId },
        include: {
          lmsCourse: { select: { id: true, title: true, thumbnail: true, totalLessons: true, level: true, category: true } },
        },
        orderBy: { lastAccessedAt: 'desc' },
      }),
      prisma.lmsProgress.findMany({
        where: { enrollment: { studentId } },
        include: {
          lesson: { select: { id: true, title: true, type: true, lmsCourseId: true } },
          enrollment: { select: { lmsCourse: { select: { title: true } } } },
        },
        orderBy: { updatedAt: 'desc' },
        take: 5,
      }),
      prisma.lmsProgress.aggregate({
        where: { enrollment: { studentId } },
        _sum: { timeSpentSec: true },
      }),
    ]);

    const activeCourses = enrollments.filter((e: any) => e.status === 'active').length;
    const completedCourses = enrollments.filter((e: any) => e.status === 'completed').length;
    const avgProgress = enrollments.length > 0
      ? Math.round(enrollments.reduce((sum: number, e: any) => sum + e.progressPct, 0) / enrollments.length)
      : 0;

    return NextResponse.json({
      stats: {
        totalCourses: enrollments.length,
        activeCourses,
        completedCourses,
        avgProgress,
        totalTimeSpentMin: Math.round((totalTimeSpent._sum.timeSpentSec ?? 0) / 60),
      },
      enrollments: enrollments.slice(0, 4),
      recentActivity: recentProgress,
    });
  } catch (err: any) {
    console.error('Portal dashboard error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
