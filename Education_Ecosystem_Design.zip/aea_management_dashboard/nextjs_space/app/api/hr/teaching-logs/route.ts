export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const employeeId = url.searchParams.get('employeeId');
    const status = url.searchParams.get('status');
    const month = url.searchParams.get('month'); // YYYY-MM

    const where: any = {};
    if (session.user.role !== 'super_admin') {
      where.branchId = session.user.primaryBranchId;
    } else if (branchId) {
      where.branchId = branchId;
    }
    if (employeeId) where.employeeId = employeeId;
    if (status) where.status = status;
    if (month) {
      const [y, m] = month.split('-').map(Number);
      where.sessionDate = { gte: new Date(y, m - 1, 1), lt: new Date(y, m, 1) };
    }

    const logs = await prisma.hrTeachingLog.findMany({
      where,
      include: {
        employee: { select: { fullName: true, employeeCode: true } },
        classSession: {
          select: {
            sessionNumber: true, topic: true, startTime: true, endTime: true,
            class: { select: { name: true, classCode: true, course: { select: { name: true } } } },
          },
        },
        branch: { select: { name: true } },
        approver: { select: { fullName: true } },
      },
      orderBy: { sessionDate: 'desc' },
      take: 200,
    });

    return NextResponse.json({
      teachingLogs: logs.map((l: any) => ({
        ...l,
        sessionDate: l.sessionDate?.toISOString(),
        approvedAt: l.approvedAt?.toISOString(),
        createdAt: l.createdAt?.toISOString(),
        updatedAt: l.updatedAt?.toISOString(),
      })),
    });
  } catch (error: any) {
    console.error('[HR/TeachingLogs GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// POST: Sync teaching log from a completed class session
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
    }

    const body = await request.json();
    const { classSessionId } = body ?? {};

    if (!classSessionId) {
      return NextResponse.json({ error: 'Thiếu classSessionId' }, { status: 400 });
    }

    // Get class session with teacher info
    const classSession = await prisma.classSession.findUnique({
      where: { id: classSessionId },
      include: {
        class: {
          include: {
            teacher: true,
            branch: { select: { id: true } },
          },
        },
      },
    });

    if (!classSession) {
      return NextResponse.json({ error: 'Không tìm thấy buổi học' }, { status: 404 });
    }

    const teacher = classSession.class.teacher;
    if (!teacher) {
      return NextResponse.json({ error: 'Lớp chưa được phân công giáo viên' }, { status: 400 });
    }

    // Find linked HrEmployee via teacherId
    const hrEmployee = await prisma.hrEmployee.findUnique({
      where: { teacherId: teacher.id },
    });

    if (!hrEmployee) {
      return NextResponse.json({
        error: 'Giáo viên chưa có hồ sơ nhân sự. Vui lòng tạo hồ sơ nhân viên và liên kết với giáo viên.',
      }, { status: 400 });
    }

    // Calculate teaching hours from start/end time
    let teachingHours = 1.5; // default
    if (classSession.startTime && classSession.endTime) {
      const [sh, sm] = classSession.startTime.split(':').map(Number);
      const [eh, em] = classSession.endTime.split(':').map(Number);
      teachingHours = ((eh * 60 + em) - (sh * 60 + sm)) / 60;
      if (teachingHours <= 0) teachingHours = 1.5;
    }

    const hourlyRate = teacher.hourlyRate ?? 0;
    const totalAmount = Math.round(teachingHours * hourlyRate);

    const teachingLog = await prisma.hrTeachingLog.upsert({
      where: {
        employeeId_classSessionId: {
          employeeId: hrEmployee.id,
          classSessionId: classSession.id,
        },
      },
      create: {
        employeeId: hrEmployee.id,
        classSessionId: classSession.id,
        classId: classSession.classId,
        branchId: classSession.class.branch.id,
        sessionDate: classSession.sessionDate,
        teachingHours,
        hourlyRate,
        totalAmount,
        status: 'pending_review',
      },
      update: {},
    });

    // Event store
    await prisma.eventStore.create({
      data: {
        branchId: classSession.class.branch.id,
        aggregateType: 'HrTeachingLog',
        aggregateId: teachingLog.id,
        eventType: 'TEACHING_LOG_CREATED',
        payload: {
          employeeId: hrEmployee.id,
          classSessionId,
          teachingHours,
          hourlyRate,
          totalAmount,
        },
        sequenceNumber: 1,
      },
    });

    return NextResponse.json({ teachingLog }, { status: 201 });
  } catch (error: any) {
    console.error('[HR/TeachingLogs POST]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// PUT: Approve or reject teaching log
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
    }

    const body = await request.json();
    const { teachingLogId, action } = body ?? {}; // action: 'approved' | 'rejected'

    if (!teachingLogId || !['approved', 'rejected'].includes(action)) {
      return NextResponse.json({ error: 'Thiếu teachingLogId hoặc action không hợp lệ' }, { status: 400 });
    }

    const log = await prisma.hrTeachingLog.findUnique({ where: { id: teachingLogId } });
    if (!log) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 });
    if (log.status !== 'pending_review') {
      return NextResponse.json({ error: 'Chỉ có thể duyệt log ở trạng thái chờ duyệt' }, { status: 400 });
    }

    const updated = await prisma.hrTeachingLog.update({
      where: { id: teachingLogId },
      data: {
        status: action,
        approvedBy: session.user.id,
        approvedAt: new Date(),
      },
    });

    return NextResponse.json({ teachingLog: updated });
  } catch (error: any) {
    console.error('[HR/TeachingLogs PUT]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
