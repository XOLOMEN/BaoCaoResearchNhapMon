'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { FadeIn } from '@/components/ui/animate';
import {
  ArrowLeft, BookOpen, Clock, CheckCircle2, PlayCircle, FileText, HelpCircle,
  ChevronDown, ChevronRight, Lock
} from 'lucide-react';

const typeIcons: Record<string, any> = { video: PlayCircle, text: FileText, pdf: FileText, quiz: HelpCircle };
const levelLabels: Record<string, string> = { beginner: 'Sơ cấp', intermediate: 'Trung cấp', advanced: 'Nâng cao', all: 'Tất cả' };

export default function CourseDetailContent({ courseId }: { courseId: string }) {
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [expandedModules, setExpandedModules] = useState<Record<string, boolean>>({});

  useEffect(() => {
    fetch(`/api/portal/my-courses/${courseId}`)
      .then(r => r.json())
      .then(d => {
        setData(d);
        // Auto-expand all modules
        const expanded: Record<string, boolean> = {};
        d?.course?.modules?.forEach((m: any) => { expanded[m.id] = true; });
        setExpandedModules(expanded);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [courseId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="h-48 bg-muted animate-pulse rounded-xl" />
        <div className="space-y-3">
          {[1,2,3,4].map(i => <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />)}
        </div>
      </div>
    );
  }

  if (!data?.course) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground">Không tìm thấy khóa học hoặc bạn chưa ghi danh.</p>
        <Button variant="outline" className="mt-4" onClick={() => router.push('/dashboard/portal/courses')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Quay lại
        </Button>
      </div>
    );
  }

  const { course, enrollment, progressMap } = data;
  const modules = course.modules ?? [];
  const ungroupedLessons = course.lessons ?? [];

  const toggleModule = (id: string) => {
    setExpandedModules(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getLessonStatus = (lessonId: string) => progressMap?.[lessonId]?.status || 'not_started';

  const renderLesson = (lesson: any) => {
    const status = getLessonStatus(lesson.id);
    const Icon = typeIcons[lesson.type] || BookOpen;
    const isCompleted = status === 'completed';
    const isInProgress = status === 'in_progress';

    return (
      <Link
        key={lesson.id}
        href={`/dashboard/portal/courses/${courseId}/lessons/${lesson.id}`}
        className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent/50 transition-colors group"
      >
        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
          isCompleted ? 'bg-emerald-100 text-emerald-600' :
          isInProgress ? 'bg-blue-100 text-blue-600' :
          'bg-muted text-muted-foreground'
        }`}>
          {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium truncate ${
            isCompleted ? 'text-muted-foreground line-through' : ''
          }`}>{lesson.title}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <Badge variant="outline" className="text-[10px] px-1.5 py-0">
              {lesson.type === 'video' ? 'Video' : lesson.type === 'text' ? 'Bài đọc' : lesson.type === 'quiz' ? 'Quiz' : lesson.type.toUpperCase()}
            </Badge>
            {lesson.durationMin && (
              <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                <Clock className="w-3 h-3" /> {lesson.durationMin} phút
              </span>
            )}
          </div>
        </div>
        {isInProgress && progressMap?.[lesson.id] && (
          <span className="text-xs text-primary font-medium">{Math.round(progressMap[lesson.id].progressPct)}%</span>
        )}
      </Link>
    );
  };

  return (
    <FadeIn>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard/portal/courses')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h2 className="text-2xl font-bold tracking-tight">{course.title}</h2>
            <p className="text-muted-foreground text-sm">{course.description}</p>
          </div>
        </div>

        {/* Course Info Card */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex flex-wrap items-center gap-4 mb-4">
              {course.level && <Badge variant="outline">{levelLabels[course.level] || course.level}</Badge>}
              {course.category && <Badge variant="secondary">{course.category}</Badge>}
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <BookOpen className="w-4 h-4" /> {course.totalLessons} bài học
              </span>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Clock className="w-4 h-4" /> {course.totalDuration} phút
              </span>
            </div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Tiến độ khóa học</span>
              <span className="text-sm font-bold text-primary">{Math.round(enrollment.progressPct)}%</span>
            </div>
            <Progress value={enrollment.progressPct} className="h-2.5" />
          </CardContent>
        </Card>

        {/* Modules & Lessons */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Nội dung khóa học</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {modules.map((mod: any) => {
              const isExpanded = expandedModules[mod.id] ?? false;
              const modLessons = mod.lessons ?? [];
              const completedCount = modLessons.filter((l: any) => getLessonStatus(l.id) === 'completed').length;

              return (
                <div key={mod.id} className="border rounded-lg overflow-hidden">
                  <button
                    onClick={() => toggleModule(mod.id)}
                    className="w-full flex items-center gap-3 p-4 hover:bg-accent/30 transition-colors"
                  >
                    {isExpanded ? <ChevronDown className="w-4 h-4 shrink-0" /> : <ChevronRight className="w-4 h-4 shrink-0" />}
                    <div className="flex-1 text-left">
                      <p className="text-sm font-semibold">{mod.title}</p>
                      <p className="text-xs text-muted-foreground">{completedCount}/{modLessons.length} bài hoàn thành</p>
                    </div>
                    <Progress value={modLessons.length > 0 ? (completedCount / modLessons.length) * 100 : 0} className="w-24 h-1.5" />
                  </button>
                  {isExpanded && modLessons.length > 0 && (
                    <div className="px-4 pb-3 space-y-1 border-t bg-accent/5">
                      {modLessons.map(renderLesson)}
                    </div>
                  )}
                </div>
              );
            })}

            {/* Ungrouped lessons */}
            {ungroupedLessons.length > 0 && (
              <div className="space-y-1 pt-2">
                {modules.length > 0 && <p className="text-xs text-muted-foreground font-medium px-1">Bài học khác</p>}
                {ungroupedLessons.map(renderLesson)}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </FadeIn>
  );
}
