export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

function buildBranchWhere(session: any, queryBranchId?: string | null) {
  const where: any = {};
  if (session.user.role !== 'super_admin') {
    where.branchId = session.user.primaryBranchId;
  } else if (queryBranchId) {
    where.branchId = queryBranchId;
  }
  return where;
}

const VALID_STATUSES = ['draft', 'active', 'paused', 'completed', 'cancelled'];
const VALID_TYPES = ['email', 'social_media', 'event', 'referral', 'ads', 'content', 'outbound', 'other'];

// ── GET ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const status = url.searchParams.get('status');
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'));
    const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get('limit') || '50')));

    const where: any = buildBranchWhere(session, branchId);
    if (status) where.status = status;

    const [campaigns, total] = await Promise.all([
      prisma.crmCampaign.findMany({
        where,
        include: {
          branch: { select: { name: true, code: true } },
          creator: { select: { id: true, fullName: true } },
          _count: { select: { leads: true } },
        },
        orderBy: [{ createdAt: 'desc' }],
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.crmCampaign.count({ where }),
    ]);

    // Enrich with conversion stats
    const enrichedCampaigns = await Promise.all(
      campaigns.map(async (c: any) => {
        const leadStats = await prisma.crmLead.groupBy({
          by: ['status'],
          where: { campaignId: c.id },
          _count: { id: true },
        });
        const totalLeads = leadStats.reduce((s, r) => s + r._count.id, 0);
        const converted = leadStats.find(r => r.status === 'converted')?._count.id || 0;
        return {
          ...c,
          startDate: c.startDate?.toISOString() || null,
          endDate: c.endDate?.toISOString() || null,
          createdAt: c.createdAt?.toISOString(),
          updatedAt: c.updatedAt?.toISOString(),
          stats: {
            totalLeads,
            converted,
            conversionRate: totalLeads > 0 ? Math.round((converted / totalLeads) * 100) : 0,
          },
        };
      })
    );

    return NextResponse.json({
      campaigns: enrichedCampaigns,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch (error: any) {
    console.error('[CRM/Campaigns GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền tạo chiến dịch' }, { status: 403 });
    }

    const body = await request.json();
    const { branchId, name, type, description, startDate, endDate, budget, channels } = body ?? {};

    if (!branchId || !name) {
      return NextResponse.json({ error: 'Thiếu thông tin bắt buộc (branchId, name)' }, { status: 400 });
    }
    if (type && !VALID_TYPES.includes(type)) {
      return NextResponse.json({ error: 'Loại chiến dịch không hợp lệ' }, { status: 400 });
    }

    const campaign = await prisma.crmCampaign.create({
      data: {
        branchId,
        name,
        type: type || 'other',
        description: description || null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        budget: budget ? parseFloat(budget) : null,
        channels: channels || [],
        createdBy: session.user.id,
        status: 'draft',
      },
      include: {
        branch: { select: { name: true } },
        creator: { select: { fullName: true } },
      },
    });

    return NextResponse.json({ campaign }, { status: 201 });
  } catch (error: any) {
    console.error('[CRM/Campaigns POST]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── PUT ──
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền cập nhật chiến dịch' }, { status: 403 });
    }

    const body = await request.json();
    const { id, ...updateFields } = body ?? {};
    if (!id) return NextResponse.json({ error: 'Thiếu campaign ID' }, { status: 400 });

    const existing = await prisma.crmCampaign.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Không tìm thấy chiến dịch' }, { status: 404 });

    if (session.user.role !== 'super_admin' && existing.branchId !== session.user.primaryBranchId) {
      return NextResponse.json({ error: 'Không có quyền cập nhật chiến dịch chi nhánh khác' }, { status: 403 });
    }

    const data: any = {};
    if (updateFields.name) data.name = updateFields.name;
    if (updateFields.type && VALID_TYPES.includes(updateFields.type)) data.type = updateFields.type;
    if (updateFields.description !== undefined) data.description = updateFields.description;
    if (updateFields.startDate !== undefined) data.startDate = updateFields.startDate ? new Date(updateFields.startDate) : null;
    if (updateFields.endDate !== undefined) data.endDate = updateFields.endDate ? new Date(updateFields.endDate) : null;
    if (updateFields.budget !== undefined) data.budget = updateFields.budget ? parseFloat(updateFields.budget) : null;
    if (updateFields.spent !== undefined) data.spent = parseFloat(updateFields.spent);
    if (updateFields.channels !== undefined) data.channels = updateFields.channels;
    if (updateFields.status && VALID_STATUSES.includes(updateFields.status)) data.status = updateFields.status;

    const campaign = await prisma.crmCampaign.update({
      where: { id },
      data,
      include: {
        branch: { select: { name: true } },
        creator: { select: { fullName: true } },
        _count: { select: { leads: true } },
      },
    });

    return NextResponse.json({ campaign });
  } catch (error: any) {
    console.error('[CRM/Campaigns PUT]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── DELETE ──
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Chỉ Super Admin có quyền xóa chiến dịch' }, { status: 403 });
    }

    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Thiếu campaign ID' }, { status: 400 });

    // Check if campaign has leads
    const leadCount = await prisma.crmLead.count({ where: { campaignId: id } });
    if (leadCount > 0) {
      return NextResponse.json({ error: `Không thể xóa chiến dịch có ${leadCount} leads liên kết` }, { status: 400 });
    }

    await prisma.crmCampaign.delete({ where: { id } });
    return NextResponse.json({ success: true, message: 'Đã xóa chiến dịch' });
  } catch (error: any) {
    console.error('[CRM/Campaigns DELETE]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
