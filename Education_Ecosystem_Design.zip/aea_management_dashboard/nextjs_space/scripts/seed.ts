import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Organization
  const org = await prisma.organization.upsert({
    where: { slug: 'aea-education' },
    update: {},
    create: {
      name: 'AEA Education',
      slug: 'aea-education',
      settings: { timezone: 'Asia/Ho_Chi_Minh', locale: 'vi-VN', currency: 'VND' },
    },
  });

  // Branches
  const branch1 = await prisma.branch.upsert({
    where: { orgId_code: { orgId: org.id, code: 'HCM-Q1' } },
    update: {},
    create: {
      orgId: org.id,
      name: 'Chi nhánh Quận 1',
      code: 'HCM-Q1',
      address: '123 Nguyễn Huệ, Quận 1, TP.HCM',
      city: 'Hồ Chí Minh',
      phone: '028-1234-5678',
      email: 'q1@aea.edu.vn',
      isHeadquarters: true,
      isActive: true,
    },
  });

  const branch2 = await prisma.branch.upsert({
    where: { orgId_code: { orgId: org.id, code: 'HCM-Q7' } },
    update: {},
    create: {
      orgId: org.id,
      name: 'Chi nhánh Quận 7',
      code: 'HCM-Q7',
      address: '456 Nguyễn Thị Thập, Quận 7, TP.HCM',
      city: 'Hồ Chí Minh',
      phone: '028-8765-4321',
      email: 'q7@aea.edu.vn',
      isActive: true,
    },
  });

  const branch3 = await prisma.branch.upsert({
    where: { orgId_code: { orgId: org.id, code: 'HN-CG' } },
    update: {},
    create: {
      orgId: org.id,
      name: 'Chi nhánh Cầu Giấy',
      code: 'HN-CG',
      address: '789 Cầu Giấy, Hà Nội',
      city: 'Hà Nội',
      phone: '024-1234-5678',
      email: 'cg@aea.edu.vn',
      isActive: true,
    },
  });

  // Users
  const hashedPw = await bcrypt.hash('johndoe123', 10);
  const staffPw = await bcrypt.hash('staff123', 10);
  const teacherPw = await bcrypt.hash('teacher123', 10);

  const superAdmin = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      passwordHash: hashedPw,
      fullName: 'Quản Trị Viên',
      role: 'super_admin',
      primaryBranchId: branch1.id,
      isActive: true,
      emailVerified: true,
    },
  });

  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@aea.edu.vn' },
    update: {},
    create: {
      email: 'admin@aea.edu.vn',
      passwordHash: await bcrypt.hash('admin@aea2024', 10),
      fullName: 'Nguyễn Văn Admin',
      role: 'super_admin',
      primaryBranchId: branch1.id,
      isActive: true,
      emailVerified: true,
    },
  });

  const staffUser = await prisma.user.upsert({
    where: { email: 'staff@aea.edu.vn' },
    update: {},
    create: {
      email: 'staff@aea.edu.vn',
      passwordHash: staffPw,
      fullName: 'Trần Thị Nhân Viên',
      role: 'staff',
      primaryBranchId: branch1.id,
      isActive: true,
      emailVerified: true,
    },
  });

  const teacherUser1 = await prisma.user.upsert({
    where: { email: 'teacher1@aea.edu.vn' },
    update: {},
    create: {
      email: 'teacher1@aea.edu.vn',
      passwordHash: teacherPw,
      fullName: 'Lê Minh Giáo Viên',
      role: 'teacher',
      primaryBranchId: branch1.id,
      isActive: true,
      emailVerified: true,
    },
  });

  const teacherUser2 = await prisma.user.upsert({
    where: { email: 'teacher2@aea.edu.vn' },
    update: {},
    create: {
      email: 'teacher2@aea.edu.vn',
      passwordHash: teacherPw,
      fullName: 'Phạm Hồng Lan',
      role: 'teacher',
      primaryBranchId: branch2.id,
      isActive: true,
      emailVerified: true,
    },
  });

  // User-Branch associations
  for (const u of [superAdmin, adminUser]) {
    for (const b of [branch1, branch2, branch3]) {
      await prisma.userBranch.upsert({
        where: { userId_branchId: { userId: u.id, branchId: b.id } },
        update: {},
        create: { userId: u.id, branchId: b.id },
      });
    }
  }
  await prisma.userBranch.upsert({
    where: { userId_branchId: { userId: staffUser.id, branchId: branch1.id } },
    update: {},
    create: { userId: staffUser.id, branchId: branch1.id },
  });
  await prisma.userBranch.upsert({
    where: { userId_branchId: { userId: teacherUser1.id, branchId: branch1.id } },
    update: {},
    create: { userId: teacherUser1.id, branchId: branch1.id },
  });
  await prisma.userBranch.upsert({
    where: { userId_branchId: { userId: teacherUser2.id, branchId: branch2.id } },
    update: {},
    create: { userId: teacherUser2.id, branchId: branch2.id },
  });

  // Teachers
  const teacher1 = await prisma.teacher.upsert({
    where: { branchId_employeeCode: { branchId: branch1.id, employeeCode: 'GV-001' } },
    update: {},
    create: {
      userId: teacherUser1.id,
      branchId: branch1.id,
      employeeCode: 'GV-001',
      fullName: 'Lê Minh Giáo Viên',
      phone: '0901234567',
      email: 'teacher1@aea.edu.vn',
      specializations: ['Tiếng Anh giao tiếp', 'IELTS'],
      hireDate: new Date('2023-01-15'),
      hourlyRate: 250000,
      status: 'active',
    },
  });

  const teacher2 = await prisma.teacher.upsert({
    where: { branchId_employeeCode: { branchId: branch2.id, employeeCode: 'GV-002' } },
    update: {},
    create: {
      userId: teacherUser2.id,
      branchId: branch2.id,
      employeeCode: 'GV-002',
      fullName: 'Phạm Hồng Lan',
      phone: '0907654321',
      email: 'teacher2@aea.edu.vn',
      specializations: ['TOEIC', 'Business English'],
      hireDate: new Date('2023-06-01'),
      hourlyRate: 280000,
      status: 'active',
    },
  });

  // Courses
  const course1 = await prisma.course.upsert({
    where: { branchId_code: { branchId: branch1.id, code: 'ENG-GEN-01' } },
    update: {},
    create: {
      branchId: branch1.id,
      name: 'Tiếng Anh Giao Tiếp Cơ Bản',
      code: 'ENG-GEN-01',
      description: 'Khóa học tiếng Anh giao tiếp dành cho người mới bắt đầu',
      level: 'beginner',
      category: 'General English',
      durationHours: 60,
      totalSessions: 30,
      maxStudents: 15,
      tuitionFee: 5500000,
      materialsFee: 350000,
      isActive: true,
    },
  });

  const course2 = await prisma.course.upsert({
    where: { branchId_code: { branchId: branch1.id, code: 'IELTS-01' } },
    update: {},
    create: {
      branchId: branch1.id,
      name: 'Luyện Thi IELTS 6.5+',
      code: 'IELTS-01',
      description: 'Khóa luyện thi IELTS mục tiêu 6.5 trở lên',
      level: 'intermediate',
      category: 'IELTS',
      durationHours: 90,
      totalSessions: 45,
      maxStudents: 12,
      tuitionFee: 12000000,
      materialsFee: 500000,
      isActive: true,
    },
  });

  const course3 = await prisma.course.upsert({
    where: { branchId_code: { branchId: branch2.id, code: 'TOEIC-01' } },
    update: {},
    create: {
      branchId: branch2.id,
      name: 'Luyện Thi TOEIC 700+',
      code: 'TOEIC-01',
      description: 'Khóa luyện thi TOEIC cho người đi làm',
      level: 'intermediate',
      category: 'TOEIC',
      durationHours: 72,
      totalSessions: 36,
      maxStudents: 18,
      tuitionFee: 8000000,
      materialsFee: 400000,
      isActive: true,
    },
  });

  // Classes
  const class1 = await prisma.class.upsert({
    where: { branchId_classCode: { branchId: branch1.id, classCode: 'ENG-GEN-01-A' } },
    update: {},
    create: {
      courseId: course1.id,
      branchId: branch1.id,
      teacherId: teacher1.id,
      name: 'Tiếng Anh Giao Tiếp - Lớp A',
      classCode: 'ENG-GEN-01-A',
      room: 'Phòng 101',
      schedule: { days: ['Thứ 2', 'Thứ 4', 'Thứ 6'], time: '18:00 - 20:00' },
      startDate: new Date('2026-05-01'),
      endDate: new Date('2026-07-30'),
      capacity: 15,
      status: 'in_progress',
    },
  });

  const class2 = await prisma.class.upsert({
    where: { branchId_classCode: { branchId: branch1.id, classCode: 'IELTS-01-B' } },
    update: {},
    create: {
      courseId: course2.id,
      branchId: branch1.id,
      teacherId: teacher1.id,
      name: 'IELTS 6.5+ - Lớp B',
      classCode: 'IELTS-01-B',
      room: 'Phòng 202',
      schedule: { days: ['Thứ 3', 'Thứ 5', 'Thứ 7'], time: '09:00 - 11:00' },
      startDate: new Date('2026-04-15'),
      endDate: new Date('2026-08-15'),
      capacity: 12,
      status: 'in_progress',
    },
  });

  const class3 = await prisma.class.upsert({
    where: { branchId_classCode: { branchId: branch2.id, classCode: 'TOEIC-01-A' } },
    update: {},
    create: {
      courseId: course3.id,
      branchId: branch2.id,
      teacherId: teacher2.id,
      name: 'TOEIC 700+ - Lớp A',
      classCode: 'TOEIC-01-A',
      room: 'Phòng 301',
      schedule: { days: ['Thứ 2', 'Thứ 4'], time: '19:00 - 21:00' },
      startDate: new Date('2026-05-10'),
      endDate: new Date('2026-08-30'),
      capacity: 18,
      status: 'in_progress',
    },
  });

  // Students
  const studentNames = [
    { name: 'Nguyễn Văn An', code: 'SV-001', branch: branch1.id, gender: 'male', level: 'beginner', dob: '2005-03-15' },
    { name: 'Trần Thị Bình', code: 'SV-002', branch: branch1.id, gender: 'female', level: 'intermediate', dob: '2004-07-22' },
    { name: 'Lê Hoàng Cường', code: 'SV-003', branch: branch1.id, gender: 'male', level: 'beginner', dob: '2006-01-10' },
    { name: 'Phạm Minh Duy', code: 'SV-004', branch: branch1.id, gender: 'male', level: 'intermediate', dob: '2003-11-05' },
    { name: 'Võ Thị Hoa', code: 'SV-005', branch: branch1.id, gender: 'female', level: 'advanced', dob: '2004-09-18' },
    { name: 'Đặng Quốc Hùng', code: 'SV-006', branch: branch1.id, gender: 'male', level: 'beginner', dob: '2005-05-30' },
    { name: 'Ngô Thị Kim', code: 'SV-007', branch: branch1.id, gender: 'female', level: 'intermediate', dob: '2004-12-01' },
    { name: 'Bùi Thanh Long', code: 'SV-008', branch: branch1.id, gender: 'male', level: 'beginner', dob: '2006-04-14' },
    { name: 'Huỳnh Thị Mai', code: 'SV-009', branch: branch2.id, gender: 'female', level: 'intermediate', dob: '2003-08-25' },
    { name: 'Đỗ Văn Nam', code: 'SV-010', branch: branch2.id, gender: 'male', level: 'beginner', dob: '2005-02-07' },
    { name: 'Lý Thị Oanh', code: 'SV-011', branch: branch2.id, gender: 'female', level: 'advanced', dob: '2004-06-19' },
    { name: 'Trương Minh Phúc', code: 'SV-012', branch: branch2.id, gender: 'male', level: 'intermediate', dob: '2003-10-11' },
  ];

  const students: any[] = [];
  for (const s of studentNames) {
    const student = await prisma.student.upsert({
      where: { branchId_studentCode: { branchId: s.branch, studentCode: s.code } },
      update: {},
      create: {
        branchId: s.branch,
        studentCode: s.code,
        fullName: s.name,
        dateOfBirth: new Date(s.dob),
        gender: s.gender,
        phone: `090${Math.floor(1000000 + Math.random() * 9000000)}`,
        email: `${s.code.toLowerCase().replace('-', '')}@email.com`,
        enrollmentDate: new Date('2026-04-01'),
        status: 'active',
        level: s.level,
        source: 'website',
      },
    });
    students.push(student);
  }

  // Enrollments
  const b1Students = students.filter((s: any) => s.branchId === branch1.id);
  const b2Students = students.filter((s: any) => s.branchId === branch2.id);

  // Enroll b1 students in class1 and class2
  for (let i = 0; i < Math.min(b1Students.length, 6); i++) {
    await prisma.enrollment.upsert({
      where: { studentId_classId: { studentId: b1Students[i].id, classId: class1.id } },
      update: {},
      create: {
        studentId: b1Students[i].id,
        classId: class1.id,
        branchId: branch1.id,
        status: 'active',
        enrolledAt: new Date('2026-04-28'),
      },
    });
  }
  for (let i = 2; i < Math.min(b1Students.length, 7); i++) {
    await prisma.enrollment.upsert({
      where: { studentId_classId: { studentId: b1Students[i].id, classId: class2.id } },
      update: {},
      create: {
        studentId: b1Students[i].id,
        classId: class2.id,
        branchId: branch1.id,
        status: 'active',
        enrolledAt: new Date('2026-04-10'),
      },
    });
  }
  for (const s of b2Students) {
    await prisma.enrollment.upsert({
      where: { studentId_classId: { studentId: s.id, classId: class3.id } },
      update: {},
      create: {
        studentId: s.id,
        classId: class3.id,
        branchId: branch2.id,
        status: 'active',
        enrolledAt: new Date('2026-05-05'),
      },
    });
  }

  // Grade Records for enrollments
  const enrollments = await prisma.enrollment.findMany({ take: 20 });
  const assessmentTypes = ['quiz', 'midterm', 'homework', 'speaking'];
  for (const enr of enrollments) {
    for (const aType of assessmentTypes) {
      const score = Math.floor(50 + Math.random() * 50);
      await prisma.gradeRecord.upsert({
        where: { id: `grade-${enr.id}-${aType}` },
        update: {},
        create: {
          id: `grade-${enr.id}-${aType}`,
          enrollmentId: enr.id,
          assessmentType: aType,
          assessmentName: aType === 'quiz' ? 'Quiz 1' : aType === 'midterm' ? 'Giữa kỳ' : aType === 'homework' ? 'Bài tập 1' : 'Nói 1',
          score: score,
          maxScore: 100,
          weight: aType === 'midterm' ? 2.0 : 1.0,
          gradedAt: new Date(),
        },
      });
    }
  }

  // ========================================
  // Student & Parent User Accounts for Portal
  // ========================================
  const studentPasswordHash = await bcrypt.hash('student123', 10);
  const parentPasswordHash = await bcrypt.hash('parent123', 10);

  // Create a student user linked to first student (Nguyễn Văn An)
  const firstStudent = await prisma.student.findFirst({ where: { studentCode: 'SV-001' } });
  if (firstStudent) {
    const studentUser = await prisma.user.upsert({
      where: { email: 'student@aea.edu.vn' },
      update: {},
      create: {
        email: 'student@aea.edu.vn',
        passwordHash: studentPasswordHash,
        fullName: firstStudent.fullName,
        role: 'student',
        primaryBranchId: firstStudent.branchId,
        isActive: true,
        emailVerified: true,
      },
    });
    // Link student record to user
    await prisma.student.update({
      where: { id: firstStudent.id },
      data: { userId: studentUser.id },
    });
    // Create parent user
    const parentUser = await prisma.user.upsert({
      where: { email: 'parent@aea.edu.vn' },
      update: {},
      create: {
        email: 'parent@aea.edu.vn',
        passwordHash: parentPasswordHash,
        fullName: 'Nguyễn Văn Bảo (Phụ huynh)',
        role: 'parent',
        primaryBranchId: firstStudent.branchId,
        isActive: true,
        emailVerified: true,
      },
    });
    // Create parent record
    const parentRecord = await prisma.parent.upsert({
      where: { userId: parentUser.id },
      update: {},
      create: {
        userId: parentUser.id,
        branchId: firstStudent.branchId,
        fullName: 'Nguyễn Văn Bảo',
        phone: '0901234567',
        email: 'parent@aea.edu.vn',
        occupation: 'Doanh nhân',
      },
    });
    // Link parent to student
    await prisma.studentParent.upsert({
      where: { studentId_parentId: { studentId: firstStudent.id, parentId: parentRecord.id } },
      update: {},
      create: {
        studentId: firstStudent.id,
        parentId: parentRecord.id,
        relationship: 'father',
        isPrimary: true,
      },
    });

    // Create LMS sample data for the student portal
    const sampleCourse1 = await prisma.lmsCourse.upsert({
      where: { slug: 'english-beginner-a1' },
      update: {},
      create: {
        branchId: firstStudent.branchId,
        title: 'Tiếng Anh Sơ Cấp A1',
        slug: 'english-beginner-a1',
        description: 'Khóa học tiếng Anh dành cho người mới bắt đầu, từ cơ bản đến A1.',
        level: 'beginner',
        category: 'English',
        tags: JSON.stringify(['english', 'beginner', 'a1']),
        totalLessons: 3,
        totalDuration: 90,
        isPublished: true,
        publishedAt: new Date(),
      },
    });
    const sampleCourse2 = await prisma.lmsCourse.upsert({
      where: { slug: 'english-intermediate-b1' },
      update: {},
      create: {
        branchId: firstStudent.branchId,
        title: 'Tiếng Anh Trung Cấp B1',
        slug: 'english-intermediate-b1',
        description: 'Khóa học nâng cao kỹ năng giao tiếp và ngữ pháp cấp độ B1.',
        level: 'intermediate',
        category: 'English',
        tags: JSON.stringify(['english', 'intermediate', 'b1']),
        totalLessons: 4,
        totalDuration: 120,
        isPublished: true,
        publishedAt: new Date(),
      },
    });

    // Create modules and lessons for course 1
    const mod1 = await prisma.lmsModule.upsert({
      where: { id: 'mod-c1-m1' },
      update: {},
      create: { id: 'mod-c1-m1', lmsCourseId: sampleCourse1.id, title: 'Chào hỏi & Giới thiệu', sortOrder: 1 },
    });
    const mod2 = await prisma.lmsModule.upsert({
      where: { id: 'mod-c1-m2' },
      update: {},
      create: { id: 'mod-c1-m2', lmsCourseId: sampleCourse1.id, title: 'Số đếm & Ngày tháng', sortOrder: 2 },
    });

    const lesson1 = await prisma.lmsLesson.upsert({
      where: { id: 'les-c1-l1' },
      update: {},
      create: { id: 'les-c1-l1', lmsCourseId: sampleCourse1.id, lmsModuleId: mod1.id, title: 'Hello & Greetings', type: 'video', sortOrder: 1, durationMin: 30 },
    });
    const lesson2 = await prisma.lmsLesson.upsert({
      where: { id: 'les-c1-l2' },
      update: {},
      create: { id: 'les-c1-l2', lmsCourseId: sampleCourse1.id, lmsModuleId: mod1.id, title: 'Introduce Yourself', type: 'text', sortOrder: 2, durationMin: 20 },
    });
    const lesson3 = await prisma.lmsLesson.upsert({
      where: { id: 'les-c1-l3' },
      update: {},
      create: { id: 'les-c1-l3', lmsCourseId: sampleCourse1.id, lmsModuleId: mod2.id, title: 'Numbers 1-100', type: 'video', sortOrder: 3, durationMin: 40 },
    });

    // Add content to lessons
    await prisma.lmsContent.upsert({
      where: { id: 'cnt-l1-1' },
      update: {},
      create: { id: 'cnt-l1-1', lessonId: lesson1.id, type: 'video', title: 'Video bài giảng', body: 'https://example.com/video1.mp4', sortOrder: 1 },
    });
    await prisma.lmsContent.upsert({
      where: { id: 'cnt-l2-1' },
      update: {},
      create: { id: 'cnt-l2-1', lessonId: lesson2.id, type: 'text', title: 'Nội dung bài học', body: '## Introduce Yourself\n\nHello! My name is ... I am from Vietnam. Nice to meet you!\n\n### Vocabulary\n- **Hello** - Xin chào\n- **My name is** - Tên tôi là\n- **Nice to meet you** - Rất vui được gặp bạn\n- **Where are you from?** - Bạn đến từ đâu?\n\n### Practice Dialog\nA: Hello! My name is An. What is your name?\nB: Hi An! My name is Binh. Nice to meet you!\nA: Nice to meet you too! Where are you from?\nB: I am from Ho Chi Minh City.', sortOrder: 1 },
    });
    await prisma.lmsContent.upsert({
      where: { id: 'cnt-l3-1' },
      update: {},
      create: { id: 'cnt-l3-1', lessonId: lesson3.id, type: 'video', title: 'Video số đếm', body: 'https://example.com/video3.mp4', sortOrder: 1 },
    });

    // Enroll student in courses
    const enrollment1 = await prisma.lmsEnrollment.upsert({
      where: { lmsCourseId_studentId: { lmsCourseId: sampleCourse1.id, studentId: firstStudent.id } },
      update: {},
      create: { lmsCourseId: sampleCourse1.id, studentId: firstStudent.id, branchId: firstStudent.branchId, status: 'active', progressPct: 66.7 },
    });
    const enrollment2 = await prisma.lmsEnrollment.upsert({
      where: { lmsCourseId_studentId: { lmsCourseId: sampleCourse2.id, studentId: firstStudent.id } },
      update: {},
      create: { lmsCourseId: sampleCourse2.id, studentId: firstStudent.id, branchId: firstStudent.branchId, status: 'active', progressPct: 0 },
    });

    // Add progress for lessons
    await prisma.lmsProgress.upsert({
      where: { lmsEnrollmentId_lessonId: { lmsEnrollmentId: enrollment1.id, lessonId: lesson1.id } },
      update: {},
      create: { lmsEnrollmentId: enrollment1.id, lessonId: lesson1.id, status: 'completed', progressPct: 100, completedAt: new Date('2026-06-10'), timeSpentSec: 1800 },
    });
    await prisma.lmsProgress.upsert({
      where: { lmsEnrollmentId_lessonId: { lmsEnrollmentId: enrollment1.id, lessonId: lesson2.id } },
      update: {},
      create: { lmsEnrollmentId: enrollment1.id, lessonId: lesson2.id, status: 'completed', progressPct: 100, completedAt: new Date('2026-06-12'), timeSpentSec: 1200 },
    });
    await prisma.lmsProgress.upsert({
      where: { lmsEnrollmentId_lessonId: { lmsEnrollmentId: enrollment1.id, lessonId: lesson3.id } },
      update: {},
      create: { lmsEnrollmentId: enrollment1.id, lessonId: lesson3.id, status: 'in_progress', progressPct: 40, timeSpentSec: 600 },
    });

    console.log('Student/Parent accounts and LMS data seeded.');
  }

  console.log('Seed completed successfully!');
}

main()
  .catch((e: any) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
