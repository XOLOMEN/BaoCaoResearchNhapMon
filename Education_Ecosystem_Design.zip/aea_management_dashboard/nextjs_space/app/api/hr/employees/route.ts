export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const status = url.searchParams.get('status');
    const search = url.searchParams.get('search');

    const where: any = {};
    if (session.user.role !== 'super_admin') {
      where.branchId = session.user.primaryBranchId;
    } else if (branchId) {
      where.branchId = branchId;
    }
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { employeeCode: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const employees = await prisma.hrEmployee.findMany({
      where,
      include: {
        branch: { select: { name: true, code: true } },
        teacher: { select: { id: true, fullName: true, hourlyRate: true, specializations: true } },
        contracts: { where: { status: 'active' }, take: 1, orderBy: { startDate: 'desc' } },
        _count: { select: { teachingLogs: true, payroll: true } },
      },
      orderBy: { fullName: 'asc' },
    });

    return NextResponse.json({
      employees: employees.map((e: any) => ({
        ...e,
        dateOfBirth: e.dateOfBirth?.toISOString(),
        hireDate: e.hireDate?.toISOString(),
        terminationDate: e.terminationDate?.toISOString(),
        createdAt: e.createdAt?.toISOString(),
        updatedAt: e.updatedAt?.toISOString(),
        contracts: e.contracts?.map((c: any) => ({
          ...c,
          startDate: c.startDate?.toISOString(),
          endDate: c.endDate?.toISOString(),
        })),
      })),
    });
  } catch (error: any) {
    console.error('[HR/Employees GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
    }

    const body = await request.json();
    const { branchId, employeeCode, fullName, email, phone, department, position,
            employmentType, hireDate, gender, dateOfBirth, address, bankAccount,
            bankName, taxCode, teacherId } = body ?? {};

    if (!branchId || !employeeCode || !fullName || !department || !position) {
      return NextResponse.json({ error: 'Thiếu thông tin bắt buộc' }, { status: 400 });
    }

    const employee = await prisma.hrEmployee.create({
      data: {
        branchId,
        employeeCode,
        fullName,
        email: email || null,
        phone: phone || null,
        department,
        position,
        employmentType: employmentType || 'full_time',
        hireDate: new Date(hireDate || Date.now()),
        gender: gender || null,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
        address: address || null,
        bankAccount: bankAccount || null,
        bankName: bankName || null,
        taxCode: taxCode || null,
        teacherId: teacherId || null,
      },
      include: {
        branch: { select: { name: true } },
        teacher: { select: { fullName: true } },
      },
    });

    return NextResponse.json({ employee }, { status: 201 });
  } catch (error: any) {
    console.error('[HR/Employees POST]', error);
    if (error?.code === 'P2002') {
      return NextResponse.json({ error: 'Mã nhân viên đã tồn tại' }, { status: 400 });
    }
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
