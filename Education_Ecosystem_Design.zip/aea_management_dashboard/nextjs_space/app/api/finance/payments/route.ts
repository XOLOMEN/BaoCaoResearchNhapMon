export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const invoiceId = url.searchParams.get('invoiceId');

    const where: any = {};
    if (branchId) where.branchId = branchId;
    if (invoiceId) where.invoiceId = invoiceId;

    const payments = await prisma.payment.findMany({
      where,
      include: {
        invoice: {
          select: {
            invoiceNumber: true, totalAmount: true, paidAmount: true, status: true,
            student: { select: { fullName: true, studentCode: true } },
          },
        },
        branch: { select: { name: true } },
      },
      orderBy: { paymentDate: 'desc' },
    });

    return NextResponse.json({
      payments: payments.map((p: any) => ({
        ...p,
        paymentDate: p.paymentDate?.toISOString(),
        createdAt: p.createdAt?.toISOString(),
        updatedAt: p.updatedAt?.toISOString(),
      })),
    });
  } catch (error: any) {
    console.error('[Finance/Payments GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const role = session.user.role;
    if (role !== 'super_admin' && role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
    }

    const body = await request.json();
    const invoiceId = body?.invoiceId;
    const amount = body?.amount;
    const paymentMethod = body?.paymentMethod || body?.method;
    const notes = body?.notes || body?.note;

    if (!invoiceId || !amount || amount <= 0 || !paymentMethod) {
      return NextResponse.json({ error: 'Thiếu thông tin' }, { status: 400 });
    }

    // Get invoice
    const invoice = await prisma.invoice.findUnique({
      where: { id: invoiceId },
      select: { id: true, branchId: true, totalAmount: true, paidAmount: true, status: true, studentId: true },
    });

    if (!invoice) return NextResponse.json({ error: 'Hóa đơn không tồn tại' }, { status: 404 });

    if (invoice.status === 'cancelled' || invoice.status === 'paid') {
      return NextResponse.json({ error: `Hóa đơn đã ${invoice.status === 'paid' ? 'thanh toán xong' : 'bị hủy'}` }, { status: 400 });
    }

    const remaining = invoice.totalAmount - invoice.paidAmount;
    if (amount > remaining) {
      return NextResponse.json({ error: `Số tiền vượt quá còn lại (${remaining} VND)` }, { status: 400 });
    }

    // Generate receipt number
    const now = new Date();
    const receiptCount = await prisma.payment.count({ where: { branchId: invoice.branchId } });
    const receiptNumber = `RCP-${String(receiptCount + 1).padStart(6, '0')}`;

    // Transaction: create payment + update invoice
    const newPaidAmount = invoice.paidAmount + amount;
    const newStatus = newPaidAmount >= invoice.totalAmount ? 'paid' : 'partially_paid';

    const [payment] = await prisma.$transaction([
      prisma.payment.create({
        data: {
          invoiceId,
          branchId: invoice.branchId,
          amount,
          paymentMethod,
          paymentDate: now,
          receiptNumber,
          status: 'completed',
          receivedBy: session.user.id,
          notes,
        },
      }),
      prisma.invoice.update({
        where: { id: invoiceId },
        data: {
          paidAmount: newPaidAmount,
          status: newStatus,
        },
      }),
      prisma.eventStore.create({
        data: {
          branchId: invoice.branchId,
          aggregateType: 'payment',
          aggregateId: invoiceId,
          eventType: 'payment.completed',
          payload: {
            amount,
            paymentMethod,
            invoiceId,
            studentId: invoice.studentId,
            newPaidAmount,
            newStatus,
          },
          sequenceNumber: receiptCount + 1,
        },
      }),
    ]);

    return NextResponse.json({ payment, invoiceStatus: newStatus }, { status: 201 });
  } catch (error: any) {
    console.error('[Finance/Payments POST]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}
