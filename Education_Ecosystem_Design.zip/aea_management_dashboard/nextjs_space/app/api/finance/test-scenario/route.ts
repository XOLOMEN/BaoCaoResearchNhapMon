export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

/**
 * POST /api/finance/test-scenario
 * Simulates a full partial-payment test scenario:
 *   Step 1: Pick (or create) a test student
 *   Step 2: Pick a class with tuition > 0
 *   Step 3: Create enrollment → auto-generate draft invoice
 *   Step 4: Issue the invoice (draft → issued)
 *   Step 5: Record partial payment (50% of total)
 *   Step 6: Snapshot finance stats (before vs after)
 * Returns all intermediate results so UI can display step-by-step.
 */
export async function POST(request: NextRequest) {
  const steps: any[] = [];
  const log = (step: number, title: string, status: 'success' | 'error' | 'info', data: any) => {
    steps.push({ step, title, status, data, timestamp: new Date().toISOString() });
  };

  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // ── Step 0: Snapshot stats BEFORE ──
    const statsBefore = await getFinanceSnapshot();
    log(0, 'Snapshot tài chính TRƯỚC test', 'info', statsBefore);

    // ── Step 1: Find or create a test student ──
    const branch = await prisma.branch.findFirst({ where: { isActive: true }, select: { id: true, name: true, code: true } });
    if (!branch) return NextResponse.json({ error: 'Không có chi nhánh', steps }, { status: 400 });

    let student = await prisma.student.findFirst({
      where: { studentCode: 'TEST-FIN-001', branchId: branch.id },
      select: { id: true, fullName: true, studentCode: true },
    });
    if (!student) {
      student = await prisma.student.create({
        data: {
          branchId: branch.id,
          studentCode: 'TEST-FIN-001',
          fullName: 'Nguyễn Văn Test (Tài chính)',
          status: 'active',
        },
        select: { id: true, fullName: true, studentCode: true },
      });
    }
    log(1, 'Xác định học viên test', 'success', { student, branch: branch.name });

    // ── Step 2: Find a class with tuition fee > 0 ──
    const cls = await prisma.class.findFirst({
      where: {
        branchId: branch.id,
        status: { in: ['scheduled', 'in_progress'] },
        course: { tuitionFee: { gt: 0 } },
      },
      include: {
        course: { select: { id: true, name: true, tuitionFee: true, materialsFee: true } },
        _count: { select: { enrollments: true } },
      },
    });
    if (!cls) {
      return NextResponse.json({
        error: 'Không tìm thấy lớp nào có học phí > 0. Vui lòng tạo khóa học & lớp với tuitionFee trước.',
        steps,
      }, { status: 400 });
    }
    const tuition = (cls.course?.tuitionFee || 0) + (cls.course?.materialsFee || 0);
    log(2, 'Chọn lớp học có học phí', 'success', {
      class: cls.name,
      classCode: cls.classCode,
      course: cls.course?.name,
      tuitionFee: cls.course?.tuitionFee,
      materialsFee: cls.course?.materialsFee,
      totalFee: tuition,
    });

    // ── Step 3: Check if already enrolled, if so clean up ──
    const existingEnrollment = await prisma.enrollment.findFirst({
      where: { studentId: student.id, classId: cls.id },
    });
    if (existingEnrollment) {
      // Clean up: delete related invoices and the enrollment
      const relatedInvoices = await prisma.invoice.findMany({
        where: { enrollmentId: existingEnrollment.id },
        select: { id: true },
      });
      for (const inv of relatedInvoices) {
        await prisma.payment.deleteMany({ where: { invoiceId: inv.id } });
        await prisma.invoiceItem.deleteMany({ where: { invoiceId: inv.id } });
        await prisma.invoice.delete({ where: { id: inv.id } });
      }
      await prisma.enrollment.delete({ where: { id: existingEnrollment.id } });
      log(3, 'Dọn dẹp ghi danh cũ', 'info', { deletedEnrollmentId: existingEnrollment.id });
    }

    // ── Step 3b: Create enrollment (triggers auto-invoice) ──
    // We replicate the enrollment API logic here for atomicity
    const now = new Date();
    const branchCode = branch.code || 'XX';
    const yyMM = `${String(now.getFullYear()).slice(-2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const invoiceCount = await prisma.invoice.count({
      where: { branchId: branch.id, createdAt: { gte: monthStart, lt: monthEnd } },
    });
    const seq = String(invoiceCount + 1).padStart(4, '0');
    const invoiceNumber = `INV-${branchCode}-${yyMM}-${seq}`;
    const dueDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    const [enrollment, invoice] = await prisma.$transaction([
      prisma.enrollment.create({
        data: { studentId: student.id, classId: cls.id, branchId: branch.id, status: 'active', enrolledAt: now },
      }),
      prisma.invoice.create({
        data: {
          branchId: branch.id,
          invoiceNumber,
          studentId: student.id,
          type: 'tuition',
          subtotal: tuition,
          discountAmount: 0,
          taxAmount: 0,
          totalAmount: tuition,
          paidAmount: 0,
          currency: 'VND',
          dueDate,
          status: 'draft',
          notes: `[TEST] Tự động tạo khi ghi danh khóa ${cls.course?.name || ''}`,
          items: {
            create: [
              ...(cls.course?.tuitionFee ? [{ description: `Học phí - ${cls.course.name}`, quantity: 1, unitPrice: cls.course.tuitionFee, amount: cls.course.tuitionFee }] : []),
              ...(cls.course?.materialsFee ? [{ description: 'Phí tài liệu', quantity: 1, unitPrice: cls.course.materialsFee, amount: cls.course.materialsFee }] : []),
            ],
          },
        },
      }),
    ]);
    await prisma.invoice.update({ where: { id: invoice.id }, data: { enrollmentId: enrollment.id } });

    log(3, 'Tạo ghi danh + hóa đơn nháp tự động', 'success', {
      enrollmentId: enrollment.id,
      invoiceNumber: invoice.invoiceNumber,
      invoiceStatus: invoice.status,
      totalAmount: invoice.totalAmount,
      paidAmount: invoice.paidAmount,
    });

    // ── Step 4: Issue the invoice (draft → issued) ──
    const issuedInvoice = await prisma.invoice.update({
      where: { id: invoice.id },
      data: { status: 'issued', issuedAt: now, issuedBy: session.user.id },
    });
    log(4, 'Phát hành hóa đơn (draft → issued)', 'success', {
      invoiceNumber: issuedInvoice.invoiceNumber,
      status: issuedInvoice.status,
      totalAmount: issuedInvoice.totalAmount,
    });

    // Snapshot stats after issuing (revenue should increase, outstanding should increase)
    const statsAfterIssue = await getFinanceSnapshot();
    log(4, 'Snapshot sau phát hành hóa đơn', 'info', statsAfterIssue);

    // ── Step 5: Record partial payment (50%) ──
    const partialAmount = Math.floor(tuition * 0.5);
    const receiptCount = await prisma.payment.count({ where: { branchId: branch.id } });
    const receiptNumber = `RCP-${String(receiptCount + 1).padStart(6, '0')}`;

    const newPaidAmount = partialAmount;
    const newStatus = newPaidAmount >= tuition ? 'paid' : 'partially_paid';

    const [payment] = await prisma.$transaction([
      prisma.payment.create({
        data: {
          invoiceId: invoice.id,
          branchId: branch.id,
          amount: partialAmount,
          paymentMethod: 'bank_transfer',
          paymentDate: now,
          receiptNumber,
          status: 'completed',
          receivedBy: session.user.id,
          notes: '[TEST] Thanh toán 50% học phí',
        },
      }),
      prisma.invoice.update({
        where: { id: invoice.id },
        data: { paidAmount: newPaidAmount, status: newStatus },
      }),
      prisma.eventStore.create({
        data: {
          branchId: branch.id,
          aggregateType: 'payment',
          aggregateId: invoice.id,
          eventType: 'payment.completed',
          payload: { amount: partialAmount, paymentMethod: 'bank_transfer', invoiceId: invoice.id, studentId: student.id, newPaidAmount, newStatus },
          sequenceNumber: receiptCount + 1,
        },
      }),
    ]);

    log(5, `Ghi nhận thanh toán 50% (${partialAmount.toLocaleString('vi-VN')} VNĐ)`, 'success', {
      receiptNumber: payment.receiptNumber,
      paymentAmount: payment.amount,
      paymentMethod: 'bank_transfer',
      invoiceNewStatus: newStatus,
      invoicePaidAmount: newPaidAmount,
      invoiceRemaining: tuition - newPaidAmount,
    });

    // ── Step 6: Snapshot stats AFTER partial payment ──
    const statsAfter = await getFinanceSnapshot();
    log(6, 'Snapshot tài chính SAU test', 'info', statsAfter);

    // ── Step 7: Compute deltas ──
    const delta = {
      totalRevenue: statsAfter.totalRevenue - statsBefore.totalRevenue,
      totalCollected: statsAfter.totalCollected - statsBefore.totalCollected,
      totalOutstanding: statsAfter.totalOutstanding - statsBefore.totalOutstanding,
      partialCount: statsAfter.partialCount - statsBefore.partialCount,
    };
    log(7, 'So sánh thay đổi (Delta)', 'success', {
      description: 'Chênh lệch giữa TRƯỚC và SAU test',
      delta,
      expected: {
        totalRevenue_increase: tuition,
        totalCollected_increase: partialAmount,
        totalOutstanding_increase: tuition - partialAmount,
        partialCount_increase: 1,
      },
      match: {
        revenue: delta.totalRevenue === tuition,
        collected: delta.totalCollected === partialAmount,
        outstanding: delta.totalOutstanding === (tuition - partialAmount),
        partialCount: delta.partialCount === 1,
      },
    });

    const allMatch = delta.totalRevenue === tuition
      && delta.totalCollected === partialAmount
      && delta.totalOutstanding === (tuition - partialAmount)
      && delta.partialCount === 1;

    return NextResponse.json({
      success: allMatch,
      summary: allMatch
        ? '✅ TẤT CẢ KIỂM TRA ĐỀU ĐÚNG — Hệ thống tài chính hoạt động chính xác'
        : '⚠️ Một số giá trị không khớp — cần kiểm tra thêm',
      testStudent: student,
      invoiceNumber: invoice.invoiceNumber,
      totalFee: tuition,
      partialPayment: partialAmount,
      remaining: tuition - partialAmount,
      steps,
    });
  } catch (error: any) {
    console.error('[Test Scenario]', error);
    log(99, 'Lỗi hệ thống', 'error', { message: error?.message });
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống', steps }, { status: 500 });
  }
}

async function getFinanceSnapshot() {
  const agg = await prisma.invoice.aggregate({
    where: { status: { notIn: ['cancelled', 'draft'] } },
    _sum: { totalAmount: true, paidAmount: true },
    _count: true,
  });
  const totalRevenue = agg._sum.totalAmount || 0;
  const totalCollected = agg._sum.paidAmount || 0;
  const [draftCount, issuedCount, paidCount, overdueCount, partialCount] = await Promise.all([
    prisma.invoice.count({ where: { status: 'draft' } }),
    prisma.invoice.count({ where: { status: 'issued' } }),
    prisma.invoice.count({ where: { status: 'paid' } }),
    prisma.invoice.count({ where: { status: 'overdue' } }),
    prisma.invoice.count({ where: { status: 'partially_paid' } }),
  ]);
  return {
    totalRevenue,
    totalCollected,
    totalOutstanding: totalRevenue - totalCollected,
    invoiceCount: agg._count,
    draftCount,
    issuedCount,
    paidCount,
    overdueCount,
    partialCount,
  };
}
