'use client';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FadeIn } from '@/components/ui/animate';
import { Trophy, Clock, CheckCircle2, BookOpen, Target, Award } from 'lucide-react';

export default function ProgressContent() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/portal/progress')
      .then(r => r.json())
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-28 bg-muted animate-pulse rounded-lg" />)}
        </div>
      </div>
    );
  }

  const summary = data?.summary;
  const enrollments = data?.enrollments ?? [];
  const quizAttempts = data?.quizAttempts ?? [];
  const certificates = data?.certificates ?? [];

  const kpis = [
    { label: 'Bài học hoàn thành', value: summary?.completedLessons ?? 0, icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'Tỉ lệ hoàn thành', value: `${summary?.completionRate ?? 0}%`, icon: Target, color: 'text-blue-600 bg-blue-50' },
    { label: 'Thời gian học', value: `${summary?.totalTimeSpentMin ?? 0} phút`, icon: Clock, color: 'text-purple-600 bg-purple-50' },
    { label: 'Chứng chỉ', value: certificates.length, icon: Award, color: 'text-amber-600 bg-amber-50' },
  ];

  return (
    <FadeIn>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Tiến độ học tập</h2>
          <p className="text-muted-foreground">Theo dõi chi tiết kết quả học tập của bạn.</p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((kpi, idx) => (
            <Card key={idx} className="border-0 shadow-sm">
              <CardContent className="flex items-center gap-4 p-5">
                <div className={`p-3 rounded-xl ${kpi.color}`}>
                  <kpi.icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{kpi.label}</p>
                  <p className="text-2xl font-bold">{kpi.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Course Progress */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Tiến độ theo khóa học</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {enrollments.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">Chưa ghi danh khóa học nào</p>
            ) : (
              enrollments.map((e: any) => {
                const course = e.lmsCourse;
                const completed = e.progress?.filter((p: any) => p.status === 'completed').length ?? 0;
                const total = e.progress?.length ?? 0;

                return (
                  <div key={e.id} className="p-4 border rounded-lg space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold">{course?.title}</p>
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <span>{completed}/{total} bài hoàn thành</span>
                          <span>•</span>
                          <span>{course?.totalLessons} tổng bài học</span>
                        </div>
                      </div>
                      <Badge variant={e.status === 'completed' ? 'default' : 'secondary'}>
                        {e.status === 'completed' ? 'Hoàn thành' : 'Đang học'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3">
                      <Progress value={e.progressPct} className="h-2 flex-1" />
                      <span className="text-sm font-medium text-primary w-12 text-right">{Math.round(e.progressPct)}%</span>
                    </div>
                    {/* Lesson breakdown */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {e.progress?.slice(0, 6).map((p: any) => (
                        <div key={p.id} className="flex items-center gap-2 text-xs">
                          {p.status === 'completed' ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          ) : (
                            <div className="w-3.5 h-3.5 rounded-full border-2 border-muted-foreground/30 shrink-0" />
                          )}
                          <span className="truncate">{p.lesson?.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        {/* Quiz Results */}
        {quizAttempts.length > 0 && (
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Kết quả kiểm tra</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {quizAttempts.map((a: any) => (
                  <div key={a.id} className="flex items-center gap-3 p-3 rounded-lg border">
                    <div className={`p-2 rounded-lg ${a.passed ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                      {a.passed ? <Trophy className="w-4 h-4" /> : <Target className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{a.quiz?.title || a.quiz?.lesson?.title}</p>
                      <p className="text-xs text-muted-foreground">Lần {a.attemptNumber}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold">{a.percentage != null ? `${Math.round(a.percentage)}%` : '-'}</p>
                      <Badge variant={a.passed ? 'default' : 'destructive'} className="text-[10px]">
                        {a.passed ? 'Đạt' : 'Chưa đạt'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Certificates */}
        {certificates.length > 0 && (
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Chứng chỉ</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {certificates.map((cert: any) => (
                  <div key={cert.id} className="flex items-center gap-4 p-4 rounded-lg border bg-gradient-to-r from-amber-50/50 to-yellow-50/50">
                    <Award className="w-10 h-10 text-amber-500" />
                    <div>
                      <p className="font-semibold">{cert.lmsCourse?.title}</p>
                      <p className="text-xs text-muted-foreground">Mã: {cert.certificateNo}</p>
                      <p className="text-xs text-muted-foreground">Ngày cấp: {new Date(cert.issuedAt).toLocaleDateString('vi-VN')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </FadeIn>
  );
}
