import { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;
        try {
          const user = await prisma.user.findUnique({
            where: { email: credentials.email },
            include: {
              primaryBranch: true,
              student: { select: { id: true } },
              parent: { select: { id: true, studentLinks: { select: { studentId: true } } } },
            },
          });
          if (!user || !user?.isActive) return null;
          const isValid = await bcrypt.compare(credentials.password, user.passwordHash);
          if (!isValid) return null;
          await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
          return {
            id: user.id,
            email: user.email,
            name: user.fullName,
            role: user.role,
            primaryBranchId: user.primaryBranchId,
            primaryBranchName: user.primaryBranch?.name ?? null,
            studentId: user.student?.id ?? null,
            parentId: user.parent?.id ?? null,
            childStudentIds: user.parent?.studentLinks?.map((l: any) => l.studentId) ?? [],
          };
        } catch {
          return null;
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }: any) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
        token.primaryBranchId = user.primaryBranchId;
        token.primaryBranchName = user.primaryBranchName;
        token.studentId = user.studentId;
        token.parentId = user.parentId;
        token.childStudentIds = user.childStudentIds;
      }
      return token;
    },
    async session({ session, token }: any) {
      if (session?.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as string;
        session.user.primaryBranchId = token.primaryBranchId as string;
        session.user.primaryBranchName = token.primaryBranchName as string;
        session.user.studentId = token.studentId as string | null;
        session.user.parentId = token.parentId as string | null;
        session.user.childStudentIds = (token.childStudentIds as string[]) ?? [];
      }
      return session;
    },
  },
  pages: {
    signIn: '/login',
  },
  session: { strategy: 'jwt' },
  secret: process.env.NEXTAUTH_SECRET,
};
