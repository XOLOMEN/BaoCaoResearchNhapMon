export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const search = url.searchParams.get('search') ?? '';
    const status = url.searchParams.get('status') ?? '';
    const level = url.searchParams.get('level') ?? '';
    const page = parseInt(url.searchParams.get('page') ?? '1');
    const limit = parseInt(url.searchParams.get('limit') ?? '20');

    const where: any = {};
    if (branchId) where.branchId = branchId;
    if (status) where.status = status;
    if (level) where.level = level;
    if (search) {
      where.OR = [
        { fullName: { contains: search } },
        { studentCode: { contains: search } },
        { phone: { contains: search } },
        { email: { contains: search } },
      ];
    }

    const [students, total] = await Promise.all([
      prisma.student.findMany({
        where,
        include: { branch: { select: { name: true, code: true } } },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.student.count({ where }),
    ]);

    return NextResponse.json({
      students: students?.map?.((s: any) => ({
        ...s,
        dateOfBirth: s?.dateOfBirth?.toISOString?.() ?? null,
        enrollmentDate: s?.enrollmentDate?.toISOString?.() ?? null,
        createdAt: s?.createdAt?.toISOString?.() ?? null,
        updatedAt: s?.updatedAt?.toISOString?.() ?? null,
      })) ?? [],
      total,
      page,
      totalPages: Math.ceil((total ?? 0) / limit),
    });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!['super_admin', 'staff'].includes(session.user.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { branchId, studentCode, fullName, dateOfBirth, gender, phone, email, address, level, source, notes } = body ?? {};
    if (!branchId || !studentCode || !fullName) {
      return NextResponse.json({ error: 'Thiếu thông tin bắt buộc' }, { status: 400 });
    }

    const student = await prisma.student.create({
      data: {
        branchId,
        studentCode,
        fullName,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : undefined,
        gender,
        phone,
        email,
        address,
        level,
        source,
        notes,
        status: 'active',
        enrollmentDate: new Date(),
      },
    });
    return NextResponse.json({ student }, { status: 201 });
  } catch (error: any) {
    console.error(error);
    if (error?.code === 'P2002') {
      return NextResponse.json({ error: 'Mã học viên đã tồn tại' }, { status: 409 });
    }
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
