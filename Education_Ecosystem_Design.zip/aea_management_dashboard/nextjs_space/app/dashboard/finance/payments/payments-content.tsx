'use client';
import { useState, useEffect, useCallback } from 'react';
import { CreditCard, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBranch } from '@/hooks/use-branch';
import { formatCurrency, formatDate } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

const METHOD_LABELS: Record<string, string> = {
  cash: 'Tiền mặt',
  bank_transfer: 'Chuyển khoản',
  card: 'Thẻ',
  e_wallet: 'Ví điện tử',
  other: 'Khác',
};

export function PaymentsContent() {
  const { branchId } = useBranch();
  const [payments, setPayments] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [filterMethod, setFilterMethod] = useState('');
  const [loading, setLoading] = useState(true);
  const perPage = 20;

  const loadPayments = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (branchId) params.set('branchId', branchId);
    if (search) params.set('search', search);
    if (filterMethod) params.set('method', filterMethod);
    params.set('page', String(page));
    params.set('limit', String(perPage));
    fetch(`/api/finance/payments?${params}`)
      .then((r: any) => r?.json?.())
      .then((d: any) => { setPayments(d?.payments ?? []); setTotal(d?.total ?? 0); })
      .catch(() => toast.error('Không thể tải dữ liệu'))
      .finally(() => setLoading(false));
  }, [branchId, search, filterMethod, page]);

  useEffect(() => { loadPayments(); }, [loadPayments]);

  const totalPages = Math.ceil(total / perPage);

  return (
    <div className="space-y-6">
      <FadeIn>
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-primary" /> Lịch sử Thanh toán
          </h1>
          <p className="text-muted-foreground text-sm">Danh sách các khoản thu đã ghi nhận</p>
        </div>
      </FadeIn>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Tìm theo số biên lai, hóa đơn..."
                value={search}
                onChange={(e: any) => { setSearch(e?.target?.value ?? ''); setPage(1); }}
                className="pl-10 h-9 text-sm"
              />
            </div>
            <Select value={filterMethod || 'all'} onValueChange={(v: string) => { setFilterMethod(v === 'all' ? '' : v); setPage(1); }}>
              <SelectTrigger className="w-40 h-9 text-xs"><SelectValue placeholder="Phương thức" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả</SelectItem>
                <SelectItem value="cash">Tiền mặt</SelectItem>
                <SelectItem value="bank_transfer">Chuyển khoản</SelectItem>
                <SelectItem value="card">Thẻ</SelectItem>
                <SelectItem value="e_wallet">Ví điện tử</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="secondary" className="text-xs">{total} giao dịch</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Số biên lai</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Hóa đơn</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Học viên</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">Số tiền</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Phương thức</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Ngày TT</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Ghi chú</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr><td colSpan={7} className="text-center py-12 text-muted-foreground">Đang tải...</td></tr>
                ) : payments.length === 0 ? (
                  <tr><td colSpan={7} className="text-center py-12 text-muted-foreground">Chưa có giao dịch nào</td></tr>
                ) : (
                  payments.map((p: any) => (
                    <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs font-medium">{p.receiptNumber}</td>
                      <td className="px-4 py-3 font-mono text-xs">{p.invoice?.invoiceNumber ?? '—'}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-sm">{p.invoice?.student?.fullName ?? '—'}</p>
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-sm font-medium text-emerald-600">{formatCurrency(p.amount)}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className="text-[10px]">{METHOD_LABELS[p.paymentMethod || p.method] ?? p.paymentMethod ?? p.method}</Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(p.paymentDate)}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground max-w-[150px] truncate">{p.note ?? '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t">
              <p className="text-xs text-muted-foreground">Trang {page}/{totalPages} ({total} kết quả)</p>
              <div className="flex gap-1">
                <Button variant="outline" size="icon" className="h-7 w-7" disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronLeft className="w-3.5 h-3.5" /></Button>
                <Button variant="outline" size="icon" className="h-7 w-7" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}><ChevronRight className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
