export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const where: any = {};
    if (branchId) where.branchId = branchId;

    const teachers = await prisma.teacher.findMany({
      where,
      include: {
        branch: { select: { name: true, code: true } },
        _count: { select: { classes: true } },
      },
      orderBy: { fullName: 'asc' },
    });
    return NextResponse.json({ teachers });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const teacher = await prisma.teacher.create({ data: {
      branchId: body.branchId,
      employeeCode: body.employeeCode,
      fullName: body.fullName,
      phone: body.phone,
      email: body.email,
      specializations: body.specializations ?? [],
      hireDate: new Date(body.hireDate ?? Date.now()),
      hourlyRate: body.hourlyRate,
      status: 'active',
    }});
    return NextResponse.json({ teacher }, { status: 201 });
  } catch (error: any) {
    console.error(error);
    if (error?.code === 'P2002') return NextResponse.json({ error: 'Mã giáo viên đã tồn tại' }, { status: 409 });
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
