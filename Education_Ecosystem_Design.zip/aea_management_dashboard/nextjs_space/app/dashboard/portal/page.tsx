import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import StudentDashboardContent from './student-dashboard-content';

export default async function PortalPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/login');
  if (session.user.role === 'parent') redirect('/dashboard/portal/parent');
  if (session.user.role !== 'student') redirect('/dashboard');
  return <StudentDashboardContent />;
}
