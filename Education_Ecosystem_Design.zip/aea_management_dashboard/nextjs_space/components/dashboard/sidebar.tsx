'use client';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import {
  LayoutDashboard, GraduationCap, Users, BookOpen, School,
  ClipboardList, BarChart3, FileText, DollarSign, UserCog,
  Megaphone, ChevronDown, ChevronRight,
  BookOpenCheck, Award, CalendarCheck, Mail, CheckSquare, Target,
  MonitorPlay, PlayCircle, TrendingUp, Trophy
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

interface NavItem {
  label: string;
  href?: string;
  icon: any;
  children?: NavItem[];
  roles?: string[];
  disabled?: boolean;
}

const adminNavItems: NavItem[] = [
  { label: 'Tổng quan', href: '/dashboard', icon: LayoutDashboard },
  {
    label: 'Học vụ', icon: GraduationCap,
    children: [
      { label: 'Học viên', href: '/dashboard/students', icon: Users },
      { label: 'Giáo viên', href: '/dashboard/teachers', icon: UserCog },
      { label: 'Khóa học', href: '/dashboard/courses', icon: BookOpen },
      { label: 'Lớp học', href: '/dashboard/classes', icon: School },
      { label: 'Ghi danh', href: '/dashboard/enrollments', icon: ClipboardList },
      { label: 'Chương trình', href: '/dashboard/curriculum', icon: BookOpenCheck },
      { label: 'Điểm số', href: '/dashboard/grades', icon: Award },
      { label: 'Phân tích', href: '/dashboard/analytics', icon: BarChart3 },
      { label: 'Báo cáo', href: '/dashboard/reports', icon: FileText },
    ],
  },
  {
    label: 'Tài chính', icon: DollarSign,
    children: [
      { label: 'Hóa đơn', href: '/dashboard/finance/invoices', icon: FileText },
      { label: 'Thanh toán', href: '/dashboard/finance/payments', icon: DollarSign },
      { label: 'Test Scenario', href: '/dashboard/finance/test-scenario', icon: FileText },
    ],
  },
  {
    label: 'Nhân sự', icon: UserCog,
    children: [
      { label: 'Nhân viên', href: '/dashboard/hr/employees', icon: Users },
      { label: 'Chấm công', href: '/dashboard/hr/attendance', icon: CalendarCheck },
      { label: 'Bảng lương', href: '/dashboard/hr/payroll', icon: DollarSign, roles: ['super_admin'] },
    ],
  },
  {
    label: 'LMS', icon: MonitorPlay,
    children: [
      { label: 'Khóa học', href: '/dashboard/lms/courses', icon: BookOpen },
    ],
  },
  {
    label: 'CRM', icon: Megaphone,
    children: [
      { label: 'Leads', href: '/dashboard/crm/leads', icon: Users },
      { label: 'Tasks', href: '/dashboard/crm/tasks', icon: CheckSquare },
      { label: 'Chiến dịch', href: '/dashboard/crm/campaigns', icon: Target },
      { label: 'Phân tích', href: '/dashboard/crm/analytics', icon: BarChart3 },
    ],
  },
  { label: 'Liên hệ', href: '/dashboard/contact', icon: Mail },
];

const studentNavItems: NavItem[] = [
  { label: 'Bảng điều khiển', href: '/dashboard/portal', icon: LayoutDashboard },
  { label: 'Khóa học của tôi', href: '/dashboard/portal/courses', icon: BookOpen },
  { label: 'Tiến độ học tập', href: '/dashboard/portal/progress', icon: TrendingUp },
];

const parentNavItems: NavItem[] = [
  { label: 'Bảng điều khiển', href: '/dashboard/portal/parent', icon: LayoutDashboard },
];

export function Sidebar() {
  const pathname = usePathname();
  const { data: session } = useSession() || {};
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ 'Học vụ': true });

  const toggleExpand = (label: string) => {
    setExpanded((prev: any) => ({ ...(prev ?? {}), [label]: !prev?.[label] }));
  };

  const role = session?.user?.role ?? 'staff';
  const isStudent = role === 'student';
  const isParent = role === 'parent';
  const navItems = isStudent ? studentNavItems : isParent ? parentNavItems : adminNavItems;
  const portalLabel = isStudent ? 'Cổng học viên' : isParent ? 'Cổng phụ huynh' : 'Quản lý giáo dục';

  return (
    <aside className="w-64 bg-card border-r border-border min-h-screen flex flex-col">
      {/* Logo */}
      <div className="p-4 border-b border-border">
        <Link href={isStudent ? '/dashboard/portal' : isParent ? '/dashboard/portal/parent' : '/dashboard'} className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display font-bold text-sm tracking-tight">AEA Education</h1>
            <p className="text-[10px] text-muted-foreground">{portalLabel}</p>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems?.map((item: NavItem) => {
          const isActive = item.href ? pathname === item.href : item.children?.some((c: NavItem) => pathname === c.href);
          const isExpanded = expanded?.[item.label] ?? false;
          const hasChildren = (item.children?.length ?? 0) > 0;

          if (item.disabled) {
            return (
              <div key={item.label}>
                <button
                  onClick={() => hasChildren && toggleExpand(item.label)}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm text-muted-foreground/50 cursor-not-allowed"
                >
                  <item.icon className="w-4 h-4" />
                  <span className="flex-1 text-left">{item.label}</span>
                  <span className="text-[9px] bg-muted px-1.5 py-0.5 rounded">Sắp ra mắt</span>
                </button>
              </div>
            );
          }

          if (hasChildren) {
            return (
              <div key={item.label}>
                <button
                  onClick={() => toggleExpand(item.label)}
                  className={cn(
                    'w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors',
                    isActive ? 'text-primary font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
                  )}
                >
                  <item.icon className="w-4 h-4" />
                  <span className="flex-1 text-left">{item.label}</span>
                  {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                </button>
                {isExpanded && (
                  <div className="ml-4 mt-1 space-y-0.5">
                    {item.children?.map((child: NavItem) => {
                      const childActive = pathname === child.href;
                      if (child.disabled) {
                        return (
                          <span key={child.label} className="flex items-center gap-2 px-3 py-1.5 rounded-md text-xs text-muted-foreground/40 cursor-not-allowed">
                            <child.icon className="w-3.5 h-3.5" />
                            {child.label}
                          </span>
                        );
                      }
                      return (
                        <Link
                          key={child.label}
                          href={child.href ?? '#'}
                          className={cn(
                            'flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-colors',
                            childActive
                              ? 'bg-primary/10 text-primary font-medium'
                              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
                          )}
                        >
                          <child.icon className="w-3.5 h-3.5" />
                          {child.label}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          }

          return (
            <Link
              key={item.label}
              href={item.href ?? '#'}
              className={cn(
                'flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors',
                isActive
                  ? 'bg-primary/10 text-primary font-medium'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
              )}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
