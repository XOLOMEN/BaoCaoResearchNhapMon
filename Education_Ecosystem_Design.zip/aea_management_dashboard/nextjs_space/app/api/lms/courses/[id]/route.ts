export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { canModifyLms, slugify } from '@/lib/lms/helpers';

// ── GET: Single course with lessons ──
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const course = await prisma.lmsCourse.findUnique({
      where: { id: params.id },
      include: {
        branch: { select: { id: true, name: true, code: true } },
        course: { select: { id: true, name: true, code: true } },
        instructorUser: { select: { id: true, fullName: true } },
        lessons: {
          orderBy: { sortOrder: 'asc' },
          include: {
            contents: { orderBy: { sortOrder: 'asc' } },
            quiz: { select: { id: true, title: true, passingScore: true, maxAttempts: true } },
            _count: { select: { progress: true } },
          },
        },
        _count: { select: { enrollments: true, lessons: true, certificates: true } },
      },
    });
    if (!course) return NextResponse.json({ error: 'Không tìm thấy khóa học' }, { status: 404 });

    return NextResponse.json(course);
  } catch (error: any) {
    console.error('LMS course GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── PUT: Update course ──
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLms(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const body = await request.json();
    const data: any = {};

    const fields = ['title', 'description', 'level', 'category', 'thumbnail', 'price', 'currency', 'courseId', 'instructor', 'sortOrder'];
    for (const f of fields) {
      if (body[f] !== undefined) data[f] = body[f];
    }
    if (body.tags !== undefined) data.tags = body.tags;
    if (body.isPublished !== undefined) {
      data.isPublished = body.isPublished;
      if (body.isPublished) data.publishedAt = new Date();
    }
    if (body.title && body.updateSlug) {
      data.slug = slugify(body.title) + '-' + Date.now().toString(36);
    }

    const course = await prisma.lmsCourse.update({
      where: { id: params.id },
      data,
      include: {
        branch: { select: { id: true, name: true, code: true } },
        _count: { select: { enrollments: true, lessons: true } },
      },
    });

    return NextResponse.json(course);
  } catch (error: any) {
    console.error('LMS course PUT error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── DELETE: Delete course (super_admin only) ──
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin') return NextResponse.json({ error: 'Chỉ super_admin mới được xóa' }, { status: 403 });

    await prisma.lmsCourse.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('LMS course DELETE error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
