export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const where: any = {};
    if (branchId) where.branchId = branchId;

    const courses = await prisma.course.findMany({
      where,
      include: {
        branch: { select: { name: true, code: true } },
        _count: { select: { classes: true } },
      },
      orderBy: { name: 'asc' },
    });
    return NextResponse.json({ courses });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const course = await prisma.course.create({ data: {
      branchId: body.branchId,
      name: body.name,
      code: body.code,
      description: body.description,
      level: body.level,
      category: body.category,
      durationHours: parseInt(body.durationHours ?? '0'),
      totalSessions: parseInt(body.totalSessions ?? '0'),
      maxStudents: parseInt(body.maxStudents ?? '20'),
      tuitionFee: parseFloat(body.tuitionFee ?? '0'),
      materialsFee: parseFloat(body.materialsFee ?? '0'),
      isActive: true,
    }});
    return NextResponse.json({ course }, { status: 201 });
  } catch (error: any) {
    console.error(error);
    if (error?.code === 'P2002') return NextResponse.json({ error: 'Mã khóa học đã tồn tại' }, { status: 409 });
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
