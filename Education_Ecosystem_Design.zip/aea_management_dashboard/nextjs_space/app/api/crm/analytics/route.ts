export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { calculateConversionAnalytics } from '@/lib/crm/analytics';

// ── GET: CRM Conversion Analytics ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const role = session.user.role;
    if (role !== 'super_admin' && role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền xem phân tích CRM' }, { status: 403 });
    }

    const url = new URL(request.url);
    const branchId = role !== 'super_admin'
      ? session.user.primaryBranchId
      : url.searchParams.get('branchId') || undefined;
    const dateFrom = url.searchParams.get('dateFrom');
    const dateTo = url.searchParams.get('dateTo');

    const analytics = await calculateConversionAnalytics(
      branchId || undefined,
      dateFrom ? new Date(dateFrom) : undefined,
      dateTo ? new Date(dateTo) : undefined,
    );

    return NextResponse.json({ analytics });
  } catch (error: any) {
    console.error('[CRM/Analytics GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
