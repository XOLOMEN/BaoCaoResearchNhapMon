export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { buildBranchWhere, canModifyLms } from '@/lib/lms/helpers';

// ── GET: List LMS enrollments ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const lmsCourseId = url.searchParams.get('lmsCourseId');
    const studentId = url.searchParams.get('studentId');
    const status = url.searchParams.get('status');

    const where: any = buildBranchWhere(session, branchId);
    if (lmsCourseId) where.lmsCourseId = lmsCourseId;
    if (studentId) where.studentId = studentId;
    if (status) where.status = status;

    const enrollments = await prisma.lmsEnrollment.findMany({
      where,
      include: {
        lmsCourse: { select: { id: true, title: true, slug: true, totalLessons: true } },
        student: { select: { id: true, fullName: true, studentCode: true } },
        branch: { select: { id: true, name: true, code: true } },
        _count: { select: { progress: true } },
      },
      orderBy: { enrolledAt: 'desc' },
      take: 200,
    });

    return NextResponse.json(enrollments);
  } catch (error: any) {
    console.error('LMS enrollments GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Enroll student in LMS course ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLms(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const body = await request.json();
    const { lmsCourseId, studentId, branchId } = body;
    if (!lmsCourseId || !studentId || !branchId) {
      return NextResponse.json({ error: 'lmsCourseId, studentId, branchId bắt buộc' }, { status: 400 });
    }

    // Verify course exists and is published
    const course = await prisma.lmsCourse.findUnique({ where: { id: lmsCourseId } });
    if (!course) return NextResponse.json({ error: 'Khóa học không tồn tại' }, { status: 404 });

    const enrollment = await prisma.lmsEnrollment.create({
      data: { lmsCourseId, studentId, branchId },
      include: {
        lmsCourse: { select: { id: true, title: true } },
        student: { select: { id: true, fullName: true } },
      },
    });

    // Log to EventStore
    await prisma.eventStore.create({
      data: {
        branchId,
        aggregateType: 'LmsEnrollment',
        aggregateId: enrollment.id,
        eventType: 'LMS_ENROLLMENT_CREATED',
        payload: { lmsCourseId, studentId, courseTitle: course.title, createdBy: session.user.id },
        sequenceNumber: 1,
      },
    });

    return NextResponse.json(enrollment, { status: 201 });
  } catch (error: any) {
    console.error('LMS enrollments POST error:', error);
    if (error.code === 'P2002') return NextResponse.json({ error: 'Học viên đã đăng ký khóa học này' }, { status: 409 });
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
