export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const branchFilter = branchId ? { branchId } : {};

    // Total revenue metrics
    const invoiceAgg = await prisma.invoice.aggregate({
      where: { ...branchFilter, status: { notIn: ['cancelled', 'draft'] } },
      _sum: { totalAmount: true, paidAmount: true },
      _count: true,
    });

    const totalRevenue = invoiceAgg._sum.totalAmount || 0;
    const totalCollected = invoiceAgg._sum.paidAmount || 0;
    const totalOutstanding = totalRevenue - totalCollected;

    // Status counts
    const [draftCount, issuedCount, paidCount, overdueCount, partialCount] = await Promise.all([
      prisma.invoice.count({ where: { ...branchFilter, status: 'draft' } }),
      prisma.invoice.count({ where: { ...branchFilter, status: 'issued' } }),
      prisma.invoice.count({ where: { ...branchFilter, status: 'paid' } }),
      prisma.invoice.count({ where: { ...branchFilter, status: 'overdue' } }),
      prisma.invoice.count({ where: { ...branchFilter, status: 'partially_paid' } }),
    ]);

    // Monthly revenue (last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const payments = await prisma.payment.findMany({
      where: {
        ...branchFilter,
        status: 'completed',
        paymentDate: { gte: sixMonthsAgo },
      },
      select: { amount: true, paymentDate: true, branchId: true },
    });

    // Aggregate payments by month (collected)
    const monthlyCollected: Record<string, number> = {};
    for (const p of payments) {
      const d = new Date(p.paymentDate);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthlyCollected[key] = (monthlyCollected[key] || 0) + p.amount;
    }

    // Aggregate invoices by month (revenue = totalAmount of issued invoices)
    const invoicesInRange = await prisma.invoice.findMany({
      where: { ...branchFilter, status: { notIn: ['cancelled', 'draft'] }, createdAt: { gte: sixMonthsAgo } },
      select: { totalAmount: true, paidAmount: true, createdAt: true },
    });
    const monthlyInvoiced: Record<string, number> = {};
    for (const inv of invoicesInRange) {
      const d = new Date(inv.createdAt);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthlyInvoiced[key] = (monthlyInvoiced[key] || 0) + inv.totalAmount;
    }

    // Merge into monthly data
    const allMonths = new Set([...Object.keys(monthlyCollected), ...Object.keys(monthlyInvoiced)]);
    const monthlyRevenueData = Array.from(allMonths)
      .sort()
      .map((month) => ({
        month,
        revenue: monthlyInvoiced[month] || 0,
        collected: monthlyCollected[month] || 0,
      }));

    // Revenue by branch
    const branchPayments = await prisma.payment.groupBy({
      by: ['branchId'],
      where: { status: 'completed' },
      _sum: { amount: true },
    });

    const branches = await prisma.branch.findMany({
      where: { isActive: true },
      select: { id: true, name: true, code: true },
    });

    const branchRevenue = branches.map((b) => {
      const bp = branchPayments.find((bp) => bp.branchId === b.id);
      return {
        name: b.name,
        code: b.code,
        revenue: bp?._sum.amount || 0,
      };
    });

    // Recent payments
    const recentPayments = await prisma.payment.findMany({
      where: branchFilter,
      include: {
        invoice: {
          select: {
            invoiceNumber: true,
            student: { select: { fullName: true } },
          },
        },
        branch: { select: { name: true } },
      },
      orderBy: { paymentDate: 'desc' },
      take: 5,
    });

    // Payment method distribution
    const methodAgg = await prisma.payment.groupBy({
      by: ['paymentMethod'],
      where: { ...branchFilter, status: 'completed' },
      _sum: { amount: true },
      _count: true,
    });

    const paymentMethods = methodAgg.map((m) => ({
      method: m.paymentMethod,
      count: m._count,
      total: m._sum.amount || 0,
    }));

    return NextResponse.json({
      totalRevenue,
      totalCollected,
      totalOutstanding,
      invoiceCount: invoiceAgg._count,
      draftCount,
      issuedCount,
      paidCount,
      overdueCount,
      partialCount,
      monthlyRevenue: monthlyRevenueData,
      branchRevenue,
      recentPayments: recentPayments.map((p: any) => ({
        id: p.id,
        amount: p.amount,
        method: p.paymentMethod,
        date: p.paymentDate?.toISOString(),
        receiptNumber: p.receiptNumber,
        studentName: p.invoice?.student?.fullName || '',
        invoiceNumber: p.invoice?.invoiceNumber || '',
        branchName: p.branch?.name || '',
      })),
      paymentMethods,
    });
  } catch (error: any) {
    console.error('[Finance/Stats]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
