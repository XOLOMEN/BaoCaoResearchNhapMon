// lib/lms/helpers.ts — LMS utility functions

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

export function generateCertificateNo(branchCode: string): string {
  const now = new Date();
  const ym = `${String(now.getFullYear()).slice(-2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
  const rand = String(Math.floor(Math.random() * 9999)).padStart(4, '0');
  return `CERT-${branchCode}-${ym}-${rand}`;
}

export function buildBranchWhere(session: any, queryBranchId?: string | null) {
  const where: any = {};
  if (session.user.role !== 'super_admin') {
    where.branchId = session.user.primaryBranchId;
  } else if (queryBranchId) {
    where.branchId = queryBranchId;
  }
  return where;
}

export function canModifyLms(role: string): boolean {
  return role === 'super_admin' || role === 'staff';
}

export const LMS_COURSE_LEVELS = ['all', 'beginner', 'intermediate', 'advanced'] as const;
export const LMS_ENROLLMENT_STATUSES = ['active', 'completed', 'dropped', 'expired'] as const;
export const LMS_PROGRESS_STATUSES = ['not_started', 'in_progress', 'completed'] as const;
export const LMS_LESSON_TYPES = ['video', 'text', 'quiz', 'assignment', 'live'] as const;
export const LMS_CONTENT_TYPES = ['video', 'pdf', 'slides', 'text', 'external_link', 'audio'] as const;

/** Recalculate enrollment progressPct from lesson progress */
export async function recalcEnrollmentProgress(prisma: any, enrollmentId: string) {
  const enrollment = await prisma.lmsEnrollment.findUnique({
    where: { id: enrollmentId },
    include: {
      lmsCourse: {
        include: { lessons: { where: { isPublished: true }, select: { id: true } } }
      },
      progress: true
    }
  });
  if (!enrollment) return;

  const totalLessons = enrollment.lmsCourse.lessons.length;
  if (totalLessons === 0) return;

  const completedLessons = enrollment.progress.filter((p: any) => p.status === 'completed').length;
  const pct = Math.round((completedLessons / totalLessons) * 100);

  const updateData: any = { progressPct: pct, lastAccessedAt: new Date() };
  if (pct >= 100 && enrollment.status === 'active') {
    updateData.status = 'completed';
    updateData.completedAt = new Date();
  }

  await prisma.lmsEnrollment.update({ where: { id: enrollmentId }, data: updateData });
  return pct;
}
