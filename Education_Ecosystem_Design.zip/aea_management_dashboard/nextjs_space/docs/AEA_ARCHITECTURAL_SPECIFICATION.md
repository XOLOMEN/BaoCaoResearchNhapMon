# BẢN ĐẶC TẢ KIẾN TRÚC HỆ THỐNG
# AEA Education Super App — Architectural Specification

> **Version:** 2.0  
> **Classification:** Internal — System Architecture Team  
> **Last Updated:** 2026-06-02  
> **Author:** AEA Architecture Team  
> **Status:** Living Document  

---

## MỤC LỤC

1. [Tổng quan Kiến trúc Hệ thống](#1-tổng-quan-kiến-trúc-hệ-thống)
2. [Data Namespace & Module Organization](#2-data-namespace--module-organization)
3. [Cross-Module Data Flows](#3-cross-module-data-flows)
4. [Security-by-Design](#4-security-by-design)
5. [Mobile App API Specification](#5-mobile-app-api-specification)
6. [HR Module — Schema & Functional Spec](#6-hr-module--schema--functional-spec)
7. [LMS Module — Schema & Functional Spec](#7-lms-module--schema--functional-spec)
8. [Boilerplate Code Samples](#8-boilerplate-code-samples)
9. [Appendix](#9-appendix)

---

## 1. TỔNG QUAN KIẾN TRÚC HỆ THỐNG

### 1.1 Triết lý thiết kế: Agility ↔ Security Balance

Hệ thống AEA được thiết kế theo nguyên tắc **Monolithic-Modular Architecture** — một codebase duy nhất nhưng phân tách rõ ràng thành các module độc lập về logic, dữ liệu, và quyền truy cập.

```
┌─────────────────────────────────────────────────────────────┐
│                    AEA SUPER APP PLATFORM                   │
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │
│  │ ACADEMIC  │  │ FINANCE  │  │    HR    │  │    AI    │  │   LMS    │ │
│  │  Module   │  │  Module  │  │  Module  │  │ LEARNING │  │  Module  │ │
│  │          │  │          │  │          │  │  Module  │  │          │ │
│  │ Students │  │ Invoices │  │Employees │  │ Modules  │  │LmsCourse │ │
│  │ Teachers │  │ Payments │  │ Payroll  │  │Submissions│ │LmsLesson │ │
│  │ Courses  │  │ Expenses │  │Attendance│  │ Results  │  │LmsContent│ │
│  │ Classes  │  │ Discounts│  │ Leaves   │  │ Paths    │  │LmsEnroll │ │
│  │Enrollment│  │ Plans    │  │Contracts │  │Gamification│ │LmsProgress││
│  │ Grades   │  │          │  │TeachLog  │  │          │  │LmsQuiz   │ │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘ │
│       │             │             │              │             │       │
│  ─────┴─────────────┴─────────────┴──────────────┴─────────────┴─────  │
│                         SHARED DATA LAYER                              │
│              PostgreSQL + Prisma ORM + Branch-Scoping                  │
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │   CRM    │  │  SYSTEM  │  │  AUTH    │  │  CORE    │    │
│  │  Module  │  │  Module  │  │  Layer   │  │  Models  │    │
│  │          │  │AuditLog  │  │NextAuth  │  │   Org    │    │
│  │  Leads   │  │EventStore│  │JWT/RBAC  │  │ Branch   │    │
│  │Campaigns │  │Notif.    │  │Sessions  │  │  User    │    │
│  │Interact. │  │Settings  │  │          │  │UserBranch│    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Nguyên tắc thiết kế cốt lõi

| # | Nguyên tắc | Agility | Security |
|---|-----------|---------|----------|
| 1 | **Branch-Scoped Data** | Mỗi branch hoạt động như tenant riêng | Data isolation tự động theo branchId |
| 2 | **Metadata Extensibility** | Mọi table đều có `metadata Json @default("{}")` | Schema stable, extension qua JSON |
| 3 | **Event Sourcing** | EventStore ghi lại mọi state change | Full audit trail, không mất dữ liệu |
| 4 | **Modular Boundaries** | Module giao tiếp qua well-defined interfaces | Không cross-reference trực tiếp |
| 5 | **Vietnamese UI / English Code** | Frontend hiển thị tiếng Việt | Backend chuẩn hóa tiếng Anh |

### 1.3 Tech Stack Overview

| Layer | Technology | Vai trò |
|-------|-----------|--------|
| Frontend | React 18 + Next.js 14 (App Router) | SSR, SPA routing |
| UI Framework | Tailwind CSS + shadcn/ui | Component library |
| Authentication | NextAuth.js (JWT strategy) | Session management |
| ORM | Prisma 5 | Type-safe database access |
| Database | PostgreSQL 15 | Primary data store |
| AI Integration | Abacus.AI RouteLLM API | AI grading, content gen |
| Video/Media | HLS.js + Cloud Storage | LMS video streaming |
| API Protocol | REST (JSON) | Internal + Mobile API |

---

## 2. DATA NAMESPACE & MODULE ORGANIZATION

### 2.1 Database Table Namespace Map

Mỗi module sở hữu một nhóm bảng với prefix rõ ràng trong mapping name:

```
┌─────────────────────────────────────────────────────────────────┐
│                    DATABASE NAMESPACE MAP                       │
├─────────────┬──────────────────────────────────────────────────┤
│   MODULE    │              TABLES (@@map name)                 │
├─────────────┼──────────────────────────────────────────────────┤
│             │ organizations, branches, users, user_branches    │
│   CORE      │                                                  │
│             │ → Shared identity & org structure                │
├─────────────┼──────────────────────────────────────────────────┤
│             │ students, parents, student_parents, teachers,    │
│  ACADEMIC   │ courses, classes, class_sessions, enrollments,   │
│             │ attendance, grade_records                        │
│             │ → Toàn bộ nghiệp vụ giáo dục                    │
├─────────────┼──────────────────────────────────────────────────┤
│             │ invoices, invoice_items, payments,               │
│  FINANCE    │ payment_plans, discounts, expenses               │
│             │ → Tài chính, thu chi, công nợ                    │
├─────────────┼──────────────────────────────────────────────────┤
│             │ hr_employees, hr_contracts, hr_attendance,       │
│    HR       │ hr_leave_requests, hr_payroll                    │
│             │ → Nhân sự, lương, chấm công nhân viên            │
├─────────────┼──────────────────────────────────────────────────┤
│             │ ai_learning_modules, ai_submissions,             │
│ AI-LEARNING │ ai_submission_results, ai_learning_paths,        │
│             │ ai_gamification_scores                           │
│             │ → Adaptive learning, AI grading                  │
├─────────────┼──────────────────────────────────────────────────┤
│             │ crm_campaigns, crm_leads, crm_interactions,      │
│    CRM      │ crm_tasks                                        │
│             │ → Marketing, lead pipeline                       │
├─────────────┼──────────────────────────────────────────────────┤
│             │ lms_courses, lms_lessons, lms_contents,           │
│    LMS      │ lms_enrollments, lms_progress, lms_quizzes,       │
│             │ lms_quiz_attempts, lms_certificates               │
│             │ → Online learning, student self-study portal      │
├─────────────┼──────────────────────────────────────────────────┤
│             │ audit_logs, event_store, notifications,          │
│   SYSTEM    │ system_settings, file_attachments,               │
│             │ contact_inquiries                                │
│             │ → Infrastructure, observability                  │
└─────────────┴──────────────────────────────────────────────────┘
```

### 2.2 Branch-Scoping Strategy

Mọi dữ liệu nghiệp vụ đều được scope theo `branchId`. Đây là cơ chế **soft multi-tenancy** cho phép:
- Mỗi chi nhánh chỉ thấy dữ liệu của mình
- Super Admin có thể xem cross-branch
- Query performance tối ưu qua `@@index([branchId])`

```typescript
// Pattern: Branch-scoped query helper
function buildBranchFilter(session: SessionUser): Record<string, string> {
  if (session.role === 'super_admin') return {}; // Cross-branch access
  return { branchId: session.primaryBranchId };  // Single-branch scope
}
```

### 2.3 Entity Relationship Overview (Core Links)

```
  Organization (1) ──→ (N) Branch
       Branch (1) ──→ (N) User
         User (1) ──→ (0..1) Teacher      [Academic identity]
      Teacher (1) ──→ (0..1) HrEmployee   [HR identity bridge]
      Student (N) ←──→ (N) Parent         [via StudentParent]
       Course (1) ──→ (N) Class
        Class (1) ──→ (N) Enrollment
   Enrollment (1) ──→ (0..N) Invoice      [Auto-generated]
   Enrollment (1) ──→ (N) Attendance
   Enrollment (1) ──→ (N) GradeRecord
   Enrollment (1) ──→ (N) AiSubmission
      Invoice (1) ──→ (N) Payment
   HrEmployee (1) ──→ (N) HrPayroll
   HrEmployee (1) ──→ (N) HrAttendance
  ClassSession (1) ──→ (N) HrTeachingLog  [Bridge: Academic→HR]
     LmsCourse (1) ──→ (N) LmsLesson
     LmsLesson (1) ──→ (N) LmsContent       [Video, doc, quiz]
     LmsCourse (1) ──→ (N) LmsEnrollment
 LmsEnrollment (1) ──→ (N) LmsProgress     [Per-lesson completion]
     LmsLesson (1) ──→ (0..1) LmsQuiz
       LmsQuiz (1) ──→ (N) LmsQuizAttempt
     LmsCourse  ──→  Course                 [Optional link to Academic]
```

---

## 3. CROSS-MODULE DATA FLOWS

### 3.1 Flow Map tổng quan

```
 ┌──────────┐         ┌──────────┐         ┌──────────┐
 │ ACADEMIC │ ──(1)──→│ FINANCE  │ ──(2)──→│  SYSTEM  │
 │          │         │          │         │EventStore│
 └────┬─────┘         └──────────┘         └──────────┘
      │                                          ▲
      │(3)                                       │(6)
      ▼                                          │
 ┌──────────┐         ┌──────────┐    ┌──────────┐
 │    HR    │ ──(4)──→│ FINANCE  │    │   LMS    │
 │TeachLog  │         │ Payroll  │    │  Module  │
 └──────────┘         └──────────┘    └──┬─┬─────┘
                                          │ │
                    ┌─────────────────┘ └─────────────┐
                    │(5)                              │(7)
                    ▼                                  ▼
              ┌──────────┐              ┌─────────────┐
              │ ACADEMIC │              │  AI-LEARNING  │
              │GradeRecord│             │ AiSubmission  │
              └──────────┘              └─────────────┘

  (1) Enrollment → Auto-Invoice Creation
  (2) Payment    → EventStore Logging
  (3) ClassSession completed → HrTeachingLog
  (4) HrTeachingLog aggregation → Payroll Generation
  (5) LMS Quiz completion → GradeRecord sync (optional)
  (6) LMS progress events → EventStore Logging
  (7) LMS lesson → AI-Learning module link (optional AI grading)
```

### 3.2 Flow #1: Enrollment → Auto-Invoice (✅ Implemented)

**Trigger:** `POST /api/enrollments` — Khi học sinh đăng ký vào lớp  
**Operation:** Atomic `$transaction` tạo enrollment + draft invoice

```
[Student đăng ký lớp]
        │
        ▼
┌──────────────────┐
│ Validate capacity │
│ Class.capacity >  │
│ enrollment count  │
└────────┬─────────┘
         │ OK
         ▼
┌──────────────────────────────────────────────┐
│              $transaction {                  │
│  1. Create Enrollment (status: active)       │
│  2. Lookup Course.tuitionFee + materialsFee  │
│  3. Generate invoiceNumber:                  │
│     INV-{branchCode}-{YYMM}-{seq:4}         │
│  4. Create Invoice (status: draft)           │
│     + InvoiceItems (tuition + materials)     │
│  5. Create EventStore entry:                 │
│     { type: 'ENROLLMENT_INVOICE_CREATED' }   │
│ }                                            │
└──────────────────────────────────────────────┘
```

**Data contract:**
```typescript
// Input
interface EnrollmentRequest {
  studentId: string;   // FK → students.id
  classId: string;     // FK → classes.id
  branchId: string;    // FK → branches.id
}

// Output side-effect: Invoice auto-created
interface AutoInvoice {
  invoiceNumber: string;  // INV-HCM-Q1-2606-0001
  type: 'tuition';
  status: 'draft';
  items: [
    { description: 'Học phí - {courseName}', unitPrice: course.tuitionFee },
    { description: 'Phí tài liệu - {courseName}', unitPrice: course.materialsFee }  // if > 0
  ];
}
```

### 3.3 Flow #2: Payment → Invoice Status Update (✅ Implemented)

**Trigger:** `POST /api/finance/payments`  
**State Machine:** Invoice lifecycle

```
  draft ──→ issued ──→ paid
              │         ▲
              │    partially_paid
              │         │
              ▼         │
           overdue ─────┘
              │
              ▼
          cancelled
```

**Business Logic:**
```typescript
// Pseudo-code for payment processing
async function processPayment(invoiceId: string, amount: number) {
  return prisma.$transaction(async (tx) => {
    const invoice = await tx.invoice.findUnique({ where: { id: invoiceId } });
    
    const newPaidAmount = invoice.paidAmount + amount;
    const newStatus = newPaidAmount >= invoice.totalAmount ? 'paid' : 'partially_paid';
    
    // 1. Create Payment record
    const payment = await tx.payment.create({ data: { invoiceId, amount, ... } });
    
    // 2. Update Invoice aggregate
    await tx.invoice.update({
      where: { id: invoiceId },
      data: { paidAmount: newPaidAmount, status: newStatus }
    });
    
    // 3. Event sourcing entry
    await tx.eventStore.create({
      data: {
        aggregateType: 'Invoice',
        aggregateId: invoiceId,
        eventType: 'PAYMENT_RECORDED',
        payload: { paymentId: payment.id, amount, newStatus },
        sequenceNumber: nextSeq
      }
    });
    
    return payment;
  });
}
```

### 3.4 Flow #3: ClassSession → HrTeachingLog (📋 Designed)

**Trigger:** ClassSession status changes to `completed`  
**Purpose:** Bridge Academic ↔ HR for salary calculation

```
[ClassSession marked completed]
        │
        ▼
┌──────────────────────────────┐
│ Lookup teacher assignment:   │
│ ClassSession.teacherId       │
│   → User.id                 │
│   → Teacher.id (via userId) │
│   → HrEmployee.teacherId    │
└────────────┬─────────────────┘
             │
             ▼
┌──────────────────────────────┐
│ Create HrTeachingLog:        │
│  - employeeId (from HR)      │
│  - sessionId (from Academic) │
│  - teachingHours (calculated)│
│  - hourlyRate (from Teacher) │
│  - totalAmount (auto)        │
│  - status: 'pending_review'  │
└──────────────────────────────┘
```

### 3.5 Flow #4: HrTeachingLog → Payroll Generation (📋 Designed)

**Trigger:** Monthly payroll batch job  
**Aggregation:** Sum all approved teaching logs for each employee within pay period

```typescript
// Pseudo-code: Monthly payroll generation
async function generateMonthlyPayroll(branchId: string, month: Date) {
  const employees = await prisma.hrEmployee.findMany({ where: { branchId, status: 'active' } });
  
  for (const emp of employees) {
    // Aggregate teaching hours (from HrTeachingLog)
    const teachingLogs = await prisma.hrTeachingLog.findMany({
      where: {
        employeeId: emp.id,
        sessionDate: { gte: monthStart, lt: monthEnd },
        status: 'approved'
      }
    });
    const teachingPay = teachingLogs.reduce((sum, log) => sum + log.totalAmount, 0);
    
    // Combine with base salary from HrContract
    const contract = await prisma.hrContract.findFirst({
      where: { employeeId: emp.id, status: 'active' }
    });
    
    await prisma.hrPayroll.create({
      data: {
        employeeId: emp.id,
        branchId,
        period: formatPeriod(month),  // '2026-06'
        baseSalary: contract?.salary ?? 0,
        teachingPay,
        bonuses: 0,
        deductions: 0,
        netSalary: (contract?.salary ?? 0) + teachingPay,
        status: 'draft'
      }
    });
  }
}
```

---

## 4. SECURITY-BY-DESIGN

### 4.1 RBAC Model — Ma trận Phân quyền

#### 4.1.1 Định nghĩa vai trò (Role Definitions)

| Role | DB Value | Scope | Mô tả |
|------|----------|-------|--------|
| **Super Admin** | `super_admin` | Cross-branch | Toàn quyền hệ thống, quản lý tất cả chi nhánh |
| **Staff** | `staff` | Single-branch | Nhân viên văn phòng, quản lý học vụ + tài chính |
| **Teacher** | `teacher` | Single-branch (limited) | Giáo viên, chỉ truy cập lớp/học sinh được phân công |
| **Parent** | `parent` | Student-scoped (Mobile) | Phụ huynh, xem thông tin con em qua Mobile App |
| **Student** | `student` | Self-scoped (Mobile) | Học sinh, truy cập bài học AI + điểm số cá nhân |

> **Lưu ý:** Parent và Student hiện CHƯA có trong bảng `users`. Họ sử dụng bảng riêng (`students`, `parents`) với optional `userId` link. Mobile App sẽ cần **dedicated auth flow** cho 2 role này.

#### 4.1.2 Permission Matrix — Admin Panel (Web)

```
┌──────────────────────┬───────────┬──────────┬──────────┐
│      Resource        │Super Admin│  Staff   │ Teacher  │
├──────────────────────┼───────────┼──────────┼──────────┤
│ Dashboard (all)      │   ✅ RW   │  ✅ R    │  ⚠️ Own  │
│ Students CRUD        │   ✅ RW   │  ✅ RW   │  ⚠️ R    │
│ Teachers CRUD        │   ✅ RW   │  ✅ RW   │  ❌      │
│ Courses CRUD         │   ✅ RW   │  ✅ RW   │  ⚠️ R    │
│ Classes CRUD         │   ✅ RW   │  ✅ RW   │  ⚠️ Own  │
│ Enrollments          │   ✅ RW   │  ✅ RW   │  ⚠️ R    │
│ Grades               │   ✅ RW   │  ✅ RW   │  ⚠️ Own  │
├──────────────────────┼───────────┼──────────┼──────────┤
│ Invoices             │   ✅ RW   │  ✅ RW   │  ❌      │
│ Payments             │   ✅ RW   │  ✅ RW   │  ❌      │
│ Expenses             │   ✅ RW   │  ✅ RW   │  ❌      │
│ Revenue Reports      │   ✅ R    │  ✅ R    │  ❌      │
├──────────────────────┼───────────┼──────────┼──────────┤
│ HR Employees         │   ✅ RW   │  ⚠️ R    │  ❌      │
│ HR Payroll           │   ✅ RW   │  ❌      │  ❌      │
│ HR Contracts         │   ✅ RW   │  ❌      │  ❌      │
│ HR Leave Requests    │   ✅ RW   │  ⚠️ Own  │  ⚠️ Own  │
├──────────────────────┼───────────┼──────────┼──────────┤
│ CRM Leads            │   ✅ RW   │  ✅ RW   │  ❌      │
│ CRM Campaigns        │   ✅ RW   │  ✅ RW   │  ❌      │
├──────────────────────┼───────────┼──────────┼──────────┤
│ System Settings      │   ✅ RW   │  ❌      │  ❌      │
│ Audit Logs           │   ✅ R    │  ❌      │  ❌      │
│ User Management      │   ✅ RW   │  ❌      │  ❌      │
│ Branch Management    │   ✅ RW   │  ❌      │  ❌      │
└──────────────────────┴───────────┴──────────┴──────────┘

Legend: ✅ Full access | ⚠️ Conditional | ❌ No access
        RW = Read+Write | R = Read only | Own = Own data only
```

#### 4.1.3 Permission Matrix — Mobile App

```
┌──────────────────────────┬──────────┬──────────┐
│        Resource          │  Parent  │ Student  │
├──────────────────────────┼──────────┼──────────┤
│ Dashboard (child info)   │  ✅ R    │  ✅ R    │
│ Class Schedule           │  ✅ R    │  ✅ R    │
│ Attendance History       │  ✅ R    │  ✅ R    │
│ Grade Reports            │  ✅ R    │  ✅ R    │
│ Invoice / Payment Status │  ✅ R    │  ❌      │
│ Make Payment             │  ✅ W    │  ❌      │
│ AI Learning Modules      │  ❌      │  ✅ RW   │
│ AI Submissions           │  ❌      │  ✅ RW   │
│ AI Learning Path         │  ⚠️ R    │  ✅ R    │
│ Gamification / XP        │  ⚠️ R    │  ✅ R    │
│ Notifications            │  ✅ R    │  ✅ R    │
│ Profile Settings         │  ✅ RW   │  ✅ RW   │
└──────────────────────────┴──────────┴──────────┘
```

### 4.2 Financial Data Isolation

#### 4.2.1 Nguyên tắc cách ly dữ liệu tài chính

```
┌─────────────────────────────────────────────────────┐
│              FINANCIAL DATA ISOLATION                │
├─────────────────────────────────────────────────────┤
│                                                     │
│  Layer 1: Branch Scoping                            │
│  ├─ Mọi invoice/payment đều có branchId             │
│  ├─ Query LUÔN filter theo session.primaryBranchId  │
│  └─ Super Admin bypass → aggregate reports          │
│                                                     │
│  Layer 2: Role-Based Access                         │
│  ├─ Chỉ super_admin + staff được tạo payment       │
│  ├─ Teacher KHÔNG thấy module Finance               │
│  └─ Parent chỉ thấy invoice của CON MÌNH            │
│                                                     │
│  Layer 3: Atomic Transactions                       │
│  ├─ Payment + Invoice update = $transaction         │
│  ├─ Enrollment + Invoice creation = $transaction    │
│  └─ Payroll generation = batch $transaction         │
│                                                     │
│  Layer 4: Audit Trail                               │
│  ├─ EventStore ghi mọi financial operation          │
│  ├─ AuditLog ghi user action + IP + timestamp       │
│  └─ Immutable append-only log                       │
│                                                     │
└─────────────────────────────────────────────────────┘
```

#### 4.2.2 Financial API Authorization Pattern

```typescript
// Pattern: Financial API route guard
export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);
  
  // Layer 1: Authentication
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  
  // Layer 2: Role authorization — chỉ super_admin & staff
  const { role } = session.user;
  if (role !== 'super_admin' && role !== 'staff') {
    return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
  }
  
  // Layer 3: Branch scoping
  const body = await request.json();
  if (role !== 'super_admin' && body.branchId !== session.user.primaryBranchId) {
    return NextResponse.json({ error: 'Không có quyền truy cập chi nhánh này' }, { status: 403 });
  }
  
  // Layer 4: Audit logging
  await prisma.auditLog.create({
    data: {
      userId: session.user.id,
      branchId: body.branchId,
      entityType: 'Payment',
      entityId: payment.id,
      action: 'CREATE',
      newValues: { amount, method },
      ipAddress: request.headers.get('x-forwarded-for'),
    }
  });
}
```

### 4.3 Audit Logging Architecture

#### 4.3.1 Dual-Track Logging

Hệ thống sử dụng 2 cơ chế logging song song:

| Mechanism | Table | Purpose | Retention |
|-----------|-------|---------|----------|
| **AuditLog** | `audit_logs` | WHO did WHAT to WHICH entity | 2 years |
| **EventStore** | `event_store` | State transitions (event sourcing) | Permanent |

```typescript
// AuditLog: User action tracking
interface AuditLogEntry {
  userId: string;       // WHO
  branchId?: string;    // WHERE (branch context)
  entityType: string;   // WHAT TYPE (Invoice, Payment, Student...)
  entityId: string;     // WHICH RECORD
  action: string;       // WHAT ACTION (CREATE, UPDATE, DELETE)
  oldValues?: Json;     // BEFORE state
  newValues?: Json;     // AFTER state
  ipAddress?: string;   // FROM WHERE
  userAgent?: string;   // USING WHAT
  createdAt: DateTime;  // WHEN
}

// EventStore: Domain event sourcing
interface EventStoreEntry {
  aggregateType: string;   // Domain entity (Invoice, Enrollment...)
  aggregateId: string;     // Entity ID
  eventType: string;       // Domain event (PAYMENT_RECORDED, STATUS_CHANGED...)
  payload: Json;           // Event data
  sequenceNumber: number;  // Ordering guarantee
  createdAt: DateTime;     // Timestamp
}
```

#### 4.3.2 Events đang được tracked

| Module | Event Type | Trigger |
|--------|-----------|--------|
| Finance | `ENROLLMENT_INVOICE_CREATED` | Enrollment tạo auto-invoice |
| Finance | `PAYMENT_RECORDED` | Payment mới được ghi nhận |
| Finance | `INVOICE_STATUS_CHANGED` | Invoice chuyển trạng thái |
| Academic | `STUDENT_ENROLLED` | Học sinh đăng ký lớp |
| HR | `TEACHING_LOG_CREATED` | (Planned) Buổi dạy được ghi |
| HR | `PAYROLL_GENERATED` | (Planned) Bảng lương được tạo |
| HR | `PAYROLL_APPROVED` | (Planned) Bảng lương được duyệt |

### 4.4 API Security — JWT + Transport Layer

#### 4.4.1 Authentication Flow (Web Admin)

```
┌──────────┐     ┌──────────────┐     ┌──────────┐
│  Browser │────→│ POST /api/   │────→│ Prisma   │
│  Client  │     │ auth/[...    │     │ User     │
│          │     │ nextauth]    │     │ lookup   │
│          │←────│              │←────│ + bcrypt │
│  JWT     │     │ Set JWT      │     │ verify   │
│  Cookie  │     │ HttpOnly     │     │          │
└──────────┘     └──────────────┘     └──────────┘
```

**JWT Token Payload:**
```typescript
interface JWTPayload {
  id: string;               // User UUID
  email: string;            // User email
  name: string;             // Full name
  role: string;             // 'super_admin' | 'staff' | 'teacher'
  primaryBranchId: string;  // Default branch scope
  primaryBranchName: string;
  iat: number;              // Issued at
  exp: number;              // Expiration
}
```

**Security measures hiện tại:**
- ✅ JWT stored in HttpOnly cookie (XSS protection)
- ✅ bcrypt password hashing (salt rounds: 10)
- ✅ Session strategy: JWT (stateless, scalable)
- ✅ `getServerSession(authOptions)` trên mọi API route
- ✅ Role check trên financial/HR endpoints
- ✅ `lastLoginAt` tracking

#### 4.4.2 Mobile App API Security (📋 Specification)

Mobile App sẽ cần authentication flow riêng cho Parent/Student:

```
┌──────────────┐     ┌──────────────┐     ┌──────────┐
│  Mobile App  │────→│ POST /api/   │────→│ Verify   │
│  (Flutter/   │     │ mobile/auth/ │     │ parent   │
│   React      │     │ login        │     │ /student │
│   Native)    │     │              │     │ creds    │
│              │←────│ Return:      │←────│          │
│  Store JWT   │     │ { token,     │     │          │
│  in Secure   │     │   refresh }  │     │          │
│  Storage     │     │              │     │          │
└──────┬───────┘     └──────────────┘     └──────────┘
       │
       │ Subsequent requests:
       │ Authorization: Bearer <jwt_token>
       ▼
┌──────────────┐
│ API Gateway  │
│ - Validate   │
│   JWT        │
│ - Check exp  │
│ - Extract    │
│   student_id │
│   or parent  │
│   _id        │
│ - Scope data │
└──────────────┘
```

**Mobile Auth Requirements:**

| Requirement | Specification |
|------------|---------------|
| Token Type | JWT (access) + Opaque (refresh) |
| Access Token TTL | 15 minutes |
| Refresh Token TTL | 30 days |
| Storage | Secure Keychain (iOS) / EncryptedSharedPreferences (Android) |
| Transport | HTTPS/TLS 1.3 only |
| Rate Limiting | 5 login attempts / 15 min per IP |
| Device Binding | Optional: device fingerprint in JWT claims |

---

## 5. MOBILE APP API SPECIFICATION

### 5.1 API Design Principles

- **RESTful** JSON API under `/api/mobile/` prefix
- **Student-scoped**: Mọi data query đều filter theo `student_id` từ JWT
- **Parent delegation**: Parent truy cập data của children qua `StudentParent` link
- **Pagination**: Cursor-based cho lists, offset cho dashboard
- **Versioning**: `/api/mobile/v1/` prefix

### 5.2 Endpoint Specification

#### 5.2.1 Authentication

```
POST /api/mobile/v1/auth/login
  Body: { identifier: string, password: string, role: 'parent' | 'student' }
  Response: { accessToken, refreshToken, user: { id, name, role, children? } }

POST /api/mobile/v1/auth/refresh
  Body: { refreshToken: string }
  Response: { accessToken, refreshToken }

POST /api/mobile/v1/auth/logout
  Body: { refreshToken: string }
  Response: { success: true }
```

#### 5.2.2 Dashboard

```
GET /api/mobile/v1/dashboard
  Headers: Authorization: Bearer <token>
  Query: ?student_id=<uuid>  (required for parent, auto for student)
  
  Response (Parent):
  {
    children: [
      {
        studentId: "uuid",
        name: "Nguyễn Văn A",
        level: "intermediate",
        activeClasses: 2,
        attendanceRate: 92.5,
        latestGrade: { subject: "IELTS Writing", score: 7.5 },
        unpaidInvoices: 1,
        totalDue: 5000000  // VND
      }
    ],
    notifications: [...]
  }
  
  Response (Student):
  {
    profile: { name, level, studentCode },
    todaySchedule: [
      { classId, className, time: "14:00-15:30", room: "A201", teacher: "Ms. Hoa" }
    ],
    aiProgress: {
      currentStreak: 5,
      weeklyGoal: 5,
      weeklyProgress: 3,
      totalXp: 1250,
      level: 8
    },
    recentGrades: [...]
  }
```

#### 5.2.3 Academic — Schedule & Attendance

```
GET /api/mobile/v1/schedule
  Query: ?student_id=<uuid>&week=2026-W23
  Response: {
    week: "2026-W23",
    sessions: [
      {
        date: "2026-06-02",
        sessions: [
          {
            sessionId: "uuid",
            classId: "uuid",
            className: "IELTS Advanced - T5.01",
            time: "14:00-15:30",
            room: "A201",
            teacher: "Nguyễn Thị Hoa",
            topic: "Writing Task 2 - Discussion Essay",
            status: "scheduled"  // scheduled | completed | cancelled
          }
        ]
      }
    ]
  }

GET /api/mobile/v1/attendance
  Query: ?student_id=<uuid>&class_id=<uuid>
  Response: {
    summary: { total: 20, present: 18, absent: 1, late: 1, rate: 90.0 },
    records: [
      { date: "2026-06-01", status: "present", checkIn: "14:02", checkOut: "15:30" }
    ]
  }
```

#### 5.2.4 Grades & Academic Progress

```
GET /api/mobile/v1/grades
  Query: ?student_id=<uuid>&enrollment_id=<uuid>
  Response: {
    enrollment: {
      className: "IELTS Advanced",
      courseName: "IELTS Preparation",
      teacher: "Ms. Hoa",
      status: "active"
    },
    grades: [
      {
        type: "midterm",
        name: "Bài kiểm tra giữa kỳ",
        score: 7.5,
        maxScore: 10,
        weight: 0.3,
        gradedAt: "2026-05-15T10:00:00Z",
        comments: "Excellent writing structure"
      }
    ],
    average: 8.2,
    weightedAverage: 7.9
  }
```

#### 5.2.5 Finance — Invoices & Payments (Parent only)

```
GET /api/mobile/v1/invoices
  Query: ?student_id=<uuid>&status=issued|overdue
  Response: {
    invoices: [
      {
        id: "uuid",
        invoiceNumber: "INV-HCM-Q1-2606-0012",
        type: "tuition",
        totalAmount: 15000000,
        paidAmount: 10000000,
        dueDate: "2026-06-30",
        status: "partially_paid",
        items: [
          { description: "Học phí - IELTS Preparation", amount: 12000000 },
          { description: "Phí tài liệu", amount: 3000000 }
        ],
        payments: [
          { date: "2026-06-01", amount: 10000000, method: "bank_transfer" }
        ]
      }
    ],
    summary: {
      totalDue: 5000000,
      overdueCount: 0
    }
  }

POST /api/mobile/v1/payments/initiate
  Body: {
    invoiceId: "uuid",
    amount: 5000000,
    paymentMethod: "momo" | "vnpay" | "bank_transfer"
  }
  Response: {
    paymentUrl: "https://payment-gateway.vn/...",  // Redirect to payment gateway
    transactionRef: "TXN-..."
  }

// Webhook callback from payment gateway
POST /api/mobile/v1/payments/callback
  Body: { transactionRef, status, amount, signature }
```

#### 5.2.6 AI Learning (Student only)

```
GET /api/mobile/v1/ai-learning/modules
  Query: ?student_id=<uuid>&course_id=<uuid>
  Response: {
    modules: [
      {
        id: "uuid",
        title: "Speaking Practice - Part 2",
        type: "speaking",
        difficulty: "intermediate",
        maxScore: 100,
        timeLimit: 300,
        isCompleted: false,
        bestScore: null
      }
    ],
    path: {
      currentLevel: "intermediate",
      completionPct: 45.5,
      recommendedNext: "uuid"
    }
  }

POST /api/mobile/v1/ai-learning/submit
  Body: {
    moduleId: "uuid",
    studentId: "uuid",
    submittedData: {
      type: "speaking",
      audioUrl: "https://storage.../recording.wav",
      duration: 120
    }
  }
  Response: {
    submissionId: "uuid",
    status: "grading",  // Async — poll for result
    estimatedWait: 15   // seconds
  }

GET /api/mobile/v1/ai-learning/result/:submissionId
  Response: {
    status: "graded",
    score: 78.5,
    maxScore: 100,
    feedback: {
      strengths: ["Good pronunciation", "Clear structure"],
      improvements: ["Expand vocabulary range", "Use more complex sentences"],
      detailed: { pronunciation: 8.0, fluency: 7.5, grammar: 7.0, vocabulary: 6.5 }
    },
    xpEarned: 50,
    newStreak: 6
  }

GET /api/mobile/v1/ai-learning/gamification
  Query: ?student_id=<uuid>
  Response: {
    totalXp: 1250,
    level: 8,
    currentStreak: 5,
    longestStreak: 12,
    weeklyGoal: 5,
    weeklyProgress: 3,
    badges: [
      { name: "7-Day Streak", icon: "🔥", earnedAt: "2026-05-28" },
      { name: "Perfect Score", icon: "⭐", earnedAt: "2026-05-20" }
    ],
    leaderboard: {
      rank: 5,
      totalStudents: 42
    }
  }
```

#### 5.2.7 Notifications

```
GET /api/mobile/v1/notifications
  Query: ?page=1&limit=20
  Response: {
    notifications: [
      {
        id: "uuid",
        type: "payment_reminder",
        title: "Nhắc nhở thanh toán",
        body: "Hóa đơn INV-HCM-Q1-2606-0012 sắp đến hạn",
        data: { invoiceId: "uuid" },
        readAt: null,
        createdAt: "2026-06-01T08:00:00Z"
      }
    ],
    unreadCount: 3,
    total: 45
  }

PATCH /api/mobile/v1/notifications/:id/read
  Response: { success: true }
```

### 5.3 Mobile API Security Middleware (Boilerplate)

```typescript
// lib/mobile-auth.ts — Mobile JWT validation middleware
import jwt from 'jsonwebtoken';
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

interface MobileTokenPayload {
  sub: string;         // parent_id or student_id
  role: 'parent' | 'student';
  children?: string[]; // student_ids (parent only)
  branchId: string;
  iat: number;
  exp: number;
}

export async function validateMobileToken(
  request: NextRequest
): Promise<{ valid: true; payload: MobileTokenPayload } | { valid: false; error: string }> {
  const authHeader = request.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return { valid: false, error: 'Missing or invalid Authorization header' };
  }

  const token = authHeader.slice(7);
  try {
    const payload = jwt.verify(token, process.env.MOBILE_JWT_SECRET!) as MobileTokenPayload;
    return { valid: true, payload };
  } catch (err: any) {
    if (err.name === 'TokenExpiredError') {
      return { valid: false, error: 'Token expired' };
    }
    return { valid: false, error: 'Invalid token' };
  }
}

// Helper: Validate student_id access for parent
export function canAccessStudent(
  payload: MobileTokenPayload,
  studentId: string
): boolean {
  if (payload.role === 'student') {
    return payload.sub === studentId;
  }
  if (payload.role === 'parent') {
    return payload.children?.includes(studentId) ?? false;
  }
  return false;
}

// Usage in API route:
export async function GET(request: NextRequest) {
  const auth = await validateMobileToken(request);
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 });
  }

  const studentId = new URL(request.url).searchParams.get('student_id');
  if (!studentId || !canAccessStudent(auth.payload, studentId)) {
    return NextResponse.json({ error: 'Access denied' }, { status: 403 });
  }

  // Proceed with student-scoped query...
}
```

---

## 6. HR MODULE — SCHEMA & FUNCTIONAL SPEC

### 6.1 HR Module Overview

```
┌─────────────────────────────────────────────────────────────┐
│                      HR MODULE                              │
│                                                             │
│  ┌──────────┐    ┌──────────┐    ┌──────────────────┐       │
│  │HrEmployee│───→│HrContract│    │ HrTeachingLog    │       │
│  │          │    │          │    │ (Bridge Table)   │       │
│  │ ┌────┐   │    │ salary   │    │                  │       │
│  │ │ FK │───┼──→ │ type     │    │ ClassSession ──→ │       │
│  │ │Tea-│   │    │ startDate│    │ Employee    ──→ │       │
│  │ │cher│   │    │ endDate  │    │ teachingHours   │       │
│  │ └────┘   │    └──────────┘    │ hourlyRate      │       │
│  │          │                    │ totalAmount     │       │
│  │          │    ┌──────────┐    └────────┬─────────┘       │
│  │          │───→│HrPayroll │←───────────┘                  │
│  │          │    │          │    ┌──────────────┐            │
│  │          │───→│ period   │    │HrLeaveRequest│            │
│  │          │    │baseSalary│    │              │            │
│  │          │───→│teachPay  │    │ type         │            │
│  │          │    │ bonuses  │    │ startDate    │            │
│  │          │    │ net      │    │ endDate      │            │
│  └──────────┘    └──────────┘    │ status       │            │
│                                  └──────────────┘            │
│  ┌──────────────┐                                            │
│  │HrAttendance  │  ← Chấm công nhân viên (khác attendance   │
│  │              │     học sinh)                              │
│  │ checkIn/Out  │                                            │
│  │ hoursWorked  │                                            │
│  └──────────────┘                                            │
└─────────────────────────────────────────────────────────────┘
```

### 6.2 Schema Definition (Prisma)

#### 6.2.1 HrEmployee — Nhân viên

```prisma
model HrEmployee {
  id             String   @id @default(uuid())
  branchId       String   @map("branch_id")
  teacherId      String?  @unique @map("teacher_id")  // Bridge → Academic
  employeeCode   String   @map("employee_code")
  fullName       String   @map("full_name")
  email          String?
  phone          String?
  position       String?            // 'teacher' | 'staff' | 'manager' | 'admin'
  department     String?            // 'academic' | 'finance' | 'hr' | 'marketing'
  dateOfBirth    DateTime? @map("date_of_birth")
  gender         String?
  address        String?
  taxCode        String?  @map("tax_code")
  bankAccount    String?  @map("bank_account")
  bankName       String?  @map("bank_name")
  status         String   @default("active")  // active | on_leave | terminated
  hireDate       DateTime @map("hire_date")
  terminateDate  DateTime? @map("terminate_date")
  metadata       Json     @default("{}")
  createdAt      DateTime @default(now()) @map("created_at")
  updatedAt      DateTime @updatedAt @map("updated_at")

  branch         Branch       @relation(fields: [branchId], references: [id])
  teacher        Teacher?     @relation(fields: [teacherId], references: [id])
  contracts      HrContract[]
  attendance     HrAttendance[]
  leaveRequests  HrLeaveRequest[]
  payrolls       HrPayroll[]

  @@unique([branchId, employeeCode])
  @@index([branchId])
  @@map("hr_employees")
}
```

**Key Design Decision — Teacher↔Employee Bridge:**
```
  Teacher (Academic)          HrEmployee (HR)
  ┌──────────────┐           ┌──────────────┐
  │ id: uuid     │←──unique──│ teacherId    │
  │ fullName     │           │ fullName     │
  │ hourlyRate   │           │ position     │
  │ specializ.   │           │ department   │
  │ classes[]    │           │ bankAccount  │
  └──────────────┘           │ contracts[]  │
                             │ payrolls[]   │
                             └──────────────┘

  Nguyên tắc:
  - Teacher = Academic identity (dạy lớp nào, chuyên môn gì)
  - HrEmployee = HR identity (lương, hợp đồng, chấm công)
  - teacherId nullable: non-teaching employees don't have a Teacher record
  - teacherId unique: one Teacher maps to exactly one HrEmployee
```

#### 6.2.2 HrContract — Hợp đồng lao động

```prisma
model HrContract {
  id            String    @id @default(uuid())
  employeeId    String    @map("employee_id")
  branchId      String    @map("branch_id")
  contractType  String    @map("contract_type")  // 'full_time' | 'part_time' | 'freelance'
  contractNumber String?  @map("contract_number")
  startDate     DateTime  @map("start_date")
  endDate       DateTime? @map("end_date")
  salary        Float                              // Base monthly salary
  allowances    Json      @default("{}")           // { housing: 2000000, transport: 500000 }
  benefits      Json      @default("[]")
  workingHours  Float     @default(40) @map("working_hours")  // Hours per week
  probationEnd  DateTime? @map("probation_end")
  status        String    @default("active")       // active | expired | terminated
  notes         String?
  metadata      Json      @default("{}")
  createdAt     DateTime  @default(now()) @map("created_at")
  updatedAt     DateTime  @updatedAt @map("updated_at")

  employee HrEmployee @relation(fields: [employeeId], references: [id])
  branch   Branch     @relation(fields: [branchId], references: [id])

  @@index([employeeId])
  @@map("hr_contracts")
}
```

#### 6.2.3 HrAttendance — Chấm công nhân viên

```prisma
model HrAttendance {
  id           String    @id @default(uuid())
  employeeId   String    @map("employee_id")
  branchId     String    @map("branch_id")
  date         DateTime
  checkIn      DateTime? @map("check_in")
  checkOut     DateTime? @map("check_out")
  hoursWorked  Float?    @map("hours_worked")
  status       String    @default("present")  // present | absent | late | half_day | on_leave
  overtimeHours Float?   @map("overtime_hours")
  notes        String?
  metadata     Json      @default("{}")
  createdAt    DateTime  @default(now()) @map("created_at")

  employee HrEmployee @relation(fields: [employeeId], references: [id])
  branch   Branch     @relation(fields: [branchId], references: [id])

  @@unique([employeeId, date])
  @@index([employeeId])
  @@index([date])
  @@map("hr_attendance")
}
```

#### 6.2.4 HrLeaveRequest — Đơn xin nghỉ phép

```prisma
model HrLeaveRequest {
  id          String    @id @default(uuid())
  employeeId  String    @map("employee_id")
  branchId    String    @map("branch_id")
  type        String                    // 'annual' | 'sick' | 'maternity' | 'unpaid' | 'other'
  startDate   DateTime  @map("start_date")
  endDate     DateTime  @map("end_date")
  totalDays   Float     @map("total_days")
  reason      String?
  status      String    @default("pending")  // pending | approved | rejected | cancelled
  approvedBy  String?   @map("approved_by")
  approvedAt  DateTime? @map("approved_at")
  notes       String?
  metadata    Json      @default("{}")
  createdAt   DateTime  @default(now()) @map("created_at")
  updatedAt   DateTime  @updatedAt @map("updated_at")

  employee HrEmployee @relation(fields: [employeeId], references: [id])
  branch   Branch     @relation(fields: [branchId], references: [id])
  approver User?      @relation("LeaveApprover", fields: [approvedBy], references: [id])

  @@index([employeeId])
  @@index([status])
  @@map("hr_leave_requests")
}
```

#### 6.2.5 HrPayroll — Bảng lương

```prisma
model HrPayroll {
  id            String    @id @default(uuid())
  employeeId    String    @map("employee_id")
  branchId      String    @map("branch_id")
  period        String                           // '2026-06' (YYYY-MM)
  baseSalary    Float     @map("base_salary")
  teachingPay   Float     @default(0) @map("teaching_pay")  // From HrTeachingLog
  overtimePay   Float     @default(0) @map("overtime_pay")
  bonuses       Float     @default(0)
  allowances    Float     @default(0)
  deductions    Float     @default(0)
  socialIns     Float     @default(0) @map("social_ins")     // BHXH
  healthIns     Float     @default(0) @map("health_ins")     // BHYT
  taxAmount     Float     @default(0) @map("tax_amount")     // Thuế TNCN
  netSalary     Float     @map("net_salary")
  status        String    @default("draft")  // draft | approved | paid | cancelled
  approvedBy    String?   @map("approved_by")
  approvedAt    DateTime? @map("approved_at")
  paidAt        DateTime? @map("paid_at")
  notes         String?
  metadata      Json      @default("{}")
  createdAt     DateTime  @default(now()) @map("created_at")
  updatedAt     DateTime  @updatedAt @map("updated_at")

  employee HrEmployee @relation(fields: [employeeId], references: [id])
  branch   Branch     @relation(fields: [branchId], references: [id])
  approver User?      @relation("PayrollApprover", fields: [approvedBy], references: [id])

  @@unique([employeeId, period])
  @@index([branchId])
  @@index([period])
  @@index([status])
  @@map("hr_payroll")
}
```

#### 6.2.6 HrTeachingLog — Bridge Table (Academic↔HR)

```prisma
// PROPOSED — Chưa implement trong schema hiện tại
model HrTeachingLog {
  id              String    @id @default(uuid())
  employeeId      String    @map("employee_id")
  classSessionId  String    @map("class_session_id")
  classId         String    @map("class_id")
  branchId        String    @map("branch_id")
  sessionDate     DateTime  @map("session_date")
  teachingHours   Float     @map("teaching_hours")   // Calculated from session duration
  hourlyRate      Float     @map("hourly_rate")       // Snapshot from Teacher.hourlyRate
  totalAmount     Float     @map("total_amount")      // teachingHours × hourlyRate
  status          String    @default("pending_review") // pending_review | approved | rejected
  approvedBy      String?   @map("approved_by")
  approvedAt      DateTime? @map("approved_at")
  notes           String?
  metadata        Json      @default("{}")
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @updatedAt @map("updated_at")

  employee     HrEmployee   @relation(fields: [employeeId], references: [id])
  classSession ClassSession @relation(fields: [classSessionId], references: [id])
  class        Class        @relation(fields: [classId], references: [id])
  branch       Branch       @relation(fields: [branchId], references: [id])
  approver     User?        @relation("TeachingLogApprover", fields: [approvedBy], references: [id])

  @@unique([employeeId, classSessionId])  // One log per employee per session
  @@index([employeeId])
  @@index([sessionDate])
  @@index([status])
  @@map("hr_teaching_logs")
}
```

### 6.3 HR State Machines

#### 6.3.1 Payroll Lifecycle

```
                    ┌───────────┐
                    │   draft   │
                    └─────┬─────┘
                          │ approve()
                          ▼
                    ┌───────────┐
           ┌────────│  approved │────────┐
           │        └───────────┘        │
           │ cancel()                    │ pay()
           ▼                            ▼
     ┌───────────┐                ┌───────────┐
     │ cancelled │                │   paid    │
     └───────────┘                └───────────┘

  Transitions:
  - draft → approved   : Super Admin reviews and approves
  - approved → paid     : Payment processed, paidAt set
  - approved → cancelled: Error found, rollback
  - draft → cancelled   : Discarded before approval
```

#### 6.3.2 Leave Request Lifecycle

```
     ┌───────────┐
     │  pending   │
     └─────┬─────┘
           │
     ┌─────┼──────────┐
     │     │          │
     ▼     ▼          ▼
 ┌───────┐ ┌────────┐ ┌───────────┐
 │approved│ │rejected│ │ cancelled │
 └───────┘ └────────┘ └───────────┘
                       (by employee)
```

#### 6.3.3 Teaching Log Lifecycle

```
  [ClassSession completed]
          │
          ▼
   ┌────────────────┐
   │ pending_review  │
   └───────┬────────┘
           │
     ┌─────┼──────┐
     ▼            ▼
 ┌────────┐  ┌──────────┐
 │approved│  │ rejected │
 └────┬───┘  └──────────┘
      │
      ▼
 [Included in Payroll calculation]
```

### 6.4 HR Cross-Module Integration APIs

#### 6.4.1 Sync Teaching Log from ClassSession

```typescript
// POST /api/hr/teaching-logs/sync
// Trigger: Called when ClassSession status → 'completed'

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return unauthorized();
  if (!['super_admin', 'staff'].includes(session.user.role)) return forbidden();

  const { classSessionId } = await request.json();

  // 1. Get ClassSession details
  const classSession = await prisma.classSession.findUnique({
    where: { id: classSessionId },
    include: {
      class: {
        include: {
          teacher: true,
          branch: true,
        }
      }
    }
  });

  if (!classSession || classSession.status !== 'completed') {
    return error('Session chưa hoàn thành hoặc không tồn tại');
  }

  // 2. Find linked HrEmployee via Teacher
  const teacher = classSession.class.teacher;
  if (!teacher) return error('Lớp chưa được phân công giáo viên');

  const hrEmployee = await prisma.hrEmployee.findUnique({
    where: { teacherId: teacher.id }
  });

  if (!hrEmployee) {
    return error('Giáo viên chưa có hồ sơ nhân sự (HrEmployee)');
  }

  // 3. Calculate teaching hours
  const startTime = parseTime(classSession.startTime);  // "14:00" → minutes
  const endTime = parseTime(classSession.endTime);      // "15:30" → minutes
  const teachingHours = (endTime - startTime) / 60;     // 1.5 hours

  // 4. Create HrTeachingLog
  const teachingLog = await prisma.hrTeachingLog.upsert({
    where: {
      employeeId_classSessionId: {
        employeeId: hrEmployee.id,
        classSessionId: classSession.id
      }
    },
    create: {
      employeeId: hrEmployee.id,
      classSessionId: classSession.id,
      classId: classSession.classId,
      branchId: classSession.class.branchId,
      sessionDate: classSession.sessionDate,
      teachingHours,
      hourlyRate: teacher.hourlyRate ?? 0,
      totalAmount: teachingHours * (teacher.hourlyRate ?? 0),
      status: 'pending_review'
    },
    update: {} // Idempotent — don't overwrite if exists
  });

  // 5. Audit trail
  await prisma.eventStore.create({
    data: {
      branchId: classSession.class.branchId,
      aggregateType: 'HrTeachingLog',
      aggregateId: teachingLog.id,
      eventType: 'TEACHING_LOG_CREATED',
      payload: {
        employeeId: hrEmployee.id,
        classSessionId,
        teachingHours,
        hourlyRate: teacher.hourlyRate,
        totalAmount: teachingLog.totalAmount
      },
      sequenceNumber: 1
    }
  });

  return NextResponse.json({ teachingLog });
}
```

#### 6.4.2 Generate Monthly Payroll

```typescript
// POST /api/hr/payroll/generate
// Input: { branchId, period: '2026-06' }

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);
  if (session?.user?.role !== 'super_admin') return forbidden();

  const { branchId, period } = await request.json();
  const [year, month] = period.split('-').map(Number);
  const monthStart = new Date(year, month - 1, 1);
  const monthEnd = new Date(year, month, 1);

  const employees = await prisma.hrEmployee.findMany({
    where: { branchId, status: 'active' },
    include: {
      contracts: {
        where: { status: 'active' },
        orderBy: { startDate: 'desc' },
        take: 1
      }
    }
  });

  const results = await prisma.$transaction(async (tx) => {
    const payrolls = [];

    for (const emp of employees) {
      const contract = emp.contracts[0];
      if (!contract) continue;

      // Aggregate approved teaching logs
      const teachingLogs = await tx.hrTeachingLog.findMany({
        where: {
          employeeId: emp.id,
          sessionDate: { gte: monthStart, lt: monthEnd },
          status: 'approved'
        }
      });
      const teachingPay = teachingLogs.reduce(
        (sum: number, log: any) => sum + (log.totalAmount ?? 0), 0
      );

      // Aggregate overtime from HrAttendance
      const attendanceRecords = await tx.hrAttendance.findMany({
        where: {
          employeeId: emp.id,
          date: { gte: monthStart, lt: monthEnd }
        }
      });
      const overtimeHours = attendanceRecords.reduce(
        (sum: number, a: any) => sum + (a.overtimeHours ?? 0), 0
      );
      const overtimeRate = (contract.salary / (contract.workingHours * 4.33)) * 1.5;
      const overtimePay = overtimeHours * overtimeRate;

      // Calculate deductions (simplified)
      const grossSalary = contract.salary + teachingPay + overtimePay;
      const socialIns = grossSalary * 0.08;   // 8% BHXH
      const healthIns = grossSalary * 0.015;  // 1.5% BHYT

      const payroll = await tx.hrPayroll.upsert({
        where: {
          employeeId_period: { employeeId: emp.id, period }
        },
        create: {
          employeeId: emp.id,
          branchId,
          period,
          baseSalary: contract.salary,
          teachingPay,
          overtimePay,
          bonuses: 0,
          allowances: Object.values(contract.allowances as any || {}).reduce(
            (sum: number, v: any) => sum + (Number(v) || 0), 0
          ),
          deductions: 0,
          socialIns,
          healthIns,
          taxAmount: 0,  // Calculated separately based on tax brackets
          netSalary: grossSalary - socialIns - healthIns,
          status: 'draft'
        },
        update: {} // Don't overwrite existing payroll
      });

      payrolls.push(payroll);
    }

    return payrolls;
  });

  return NextResponse.json({
    generated: results.length,
    period,
    payrolls: results
  });
}
```

---

## 7. LMS MODULE — SCHEMA & FUNCTIONAL SPEC

### 7.1 LMS Module Overview

Module LMS (Learning Management System) cung cấp nền tảng học trực tuyến cho học viên và student portal. LMS được thiết kế độc lập với Academic module nhưng có thể **liên kết** với Course/Class hiện tại để mở rộng.

```
┌─────────────────────────────────────────────────────────────┐
│                     LMS MODULE ARCHITECTURE                    │
│                                                                 │
│  ┌───────────────┐   ┌───────────────┐   ┌───────────────┐  │
│  │  Course Mgmt   │   │ Content Mgmt  │   │  Assessment   │  │
│  │               │   │               │   │               │  │
│  │ LmsCourse     │   │ LmsContent    │   │ LmsQuiz       │  │
│  │ LmsLesson     │   │ (video, pdf,  │   │ LmsQuizAttempt│  │
│  │ LmsEnrollment │   │  slides, text) │   │ LmsCertificate│  │
│  └───────┬───────┘   └───────┬───────┘   └───────┬───────┘  │
│          │               │               │               │
│          └───────┬───────┘               │               │
│                  │                       │               │
│          ┌───────┴───────┐   ┌───────┴───────┐               │
│          │  LmsProgress  │   │  EventStore  │               │
│          │ (per-student  │   │ (LMS events) │               │
│          │  completion)  │   └───────────────┘               │
│          └───────────────┘                               │
│                                                                 │
│  Cross-Module Links:                                             │
│  • LmsCourse.courseId → Course.id (optional Academic bridge)     │
│  • LmsEnrollment.studentId → Student.id                         │
│  • LmsQuizAttempt → GradeRecord (optional grade sync)            │
│  • LmsContent supports: video, pdf, slides, text, external_link │
└─────────────────────────────────────────────────────────────┘
```

### 7.2 Schema Definition (Prisma)

#### 7.2.1 LmsCourse — Khóa học trực tuyến

```prisma
model LmsCourse {
  id           String   @id @default(uuid())
  branchId     String   @map("branch_id")
  courseId     String?  @map("course_id")        // Optional link to Academic Course
  title        String
  slug         String   @unique                  // URL-friendly identifier
  description  String?
  thumbnail    String?                           // Cover image URL
  level        String   @default("all")          // 'beginner' | 'intermediate' | 'advanced' | 'all'
  category     String?                           // 'english' | 'math' | 'science' | ...
  tags         Json     @default("[]")           // Searchable tags
  instructor   String?  @map("instructor_id")    // Teacher/User ID
  price        Float    @default(0)              // 0 = free
  currency     String   @default("VND")
  totalLessons Int      @default(0) @map("total_lessons")
  totalDuration Int     @default(0) @map("total_duration") // minutes
  isPublished  Boolean  @default(false) @map("is_published")
  publishedAt  DateTime? @map("published_at")
  sortOrder    Int      @default(0)  @map("sort_order")
  metadata     Json     @default("{}")           // AI-ready extensibility
  createdAt    DateTime @default(now()) @map("created_at")
  updatedAt    DateTime @updatedAt @map("updated_at")

  branch       Branch    @relation(fields: [branchId], references: [id])
  course       Course?   @relation(fields: [courseId], references: [id])
  instructorUser User?   @relation("LmsInstructor", fields: [instructor], references: [id])
  lessons      LmsLesson[]
  enrollments  LmsEnrollment[]
  certificates LmsCertificate[]

  @@index([branchId])
  @@index([isPublished])
  @@index([branchId, isPublished])
  @@map("lms_courses")
}
```

#### 7.2.2 LmsLesson — Bài học

```prisma
model LmsLesson {
  id           String   @id @default(uuid())
  lmsCourseId  String   @map("lms_course_id")
  title        String
  description  String?
  type         String   @default("video")        // 'video' | 'text' | 'quiz' | 'assignment' | 'live'
  sortOrder    Int      @default(0)  @map("sort_order")
  durationMin  Int?     @map("duration_min")     // Estimated minutes
  isFree       Boolean  @default(false) @map("is_free")  // Free preview lesson
  isPublished  Boolean  @default(true) @map("is_published")
  metadata     Json     @default("{}")           // AI-ready extensibility
  createdAt    DateTime @default(now()) @map("created_at")
  updatedAt    DateTime @updatedAt @map("updated_at")

  lmsCourse    LmsCourse  @relation(fields: [lmsCourseId], references: [id], onDelete: Cascade)
  contents     LmsContent[]
  progress     LmsProgress[]
  quiz         LmsQuiz?

  @@index([lmsCourseId])
  @@index([lmsCourseId, sortOrder])
  @@map("lms_lessons")
}
```

#### 7.2.3 LmsContent — Nội dung bài học

```prisma
model LmsContent {
  id           String   @id @default(uuid())
  lessonId     String   @map("lesson_id")
  type         String                            // 'video' | 'pdf' | 'slides' | 'text' | 'external_link' | 'audio'
  title        String?
  body         String?                           // Rich text / markdown content
  fileUrl      String?  @map("file_url")         // Cloud storage URL
  fileSizeBytes Int?    @map("file_size_bytes")
  durationSec  Int?     @map("duration_sec")     // For video/audio
  sortOrder    Int      @default(0)  @map("sort_order")
  metadata     Json     @default("{}")           // Transcripts, captions, etc.
  createdAt    DateTime @default(now()) @map("created_at")

  lesson       LmsLesson @relation(fields: [lessonId], references: [id], onDelete: Cascade)

  @@index([lessonId])
  @@map("lms_contents")
}
```

#### 7.2.4 LmsEnrollment — Đăng ký khóa học online

```prisma
model LmsEnrollment {
  id            String    @id @default(uuid())
  lmsCourseId   String    @map("lms_course_id")
  studentId     String    @map("student_id")
  branchId      String    @map("branch_id")
  enrolledAt    DateTime  @default(now()) @map("enrolled_at")
  completedAt   DateTime? @map("completed_at")
  status        String    @default("active")     // 'active' | 'completed' | 'dropped' | 'expired'
  progressPct   Float     @default(0) @map("progress_pct")  // 0–100
  lastAccessedAt DateTime? @map("last_accessed_at")
  metadata      Json      @default("{}")         // Certificate ID, notes
  createdAt     DateTime  @default(now()) @map("created_at")
  updatedAt     DateTime  @updatedAt @map("updated_at")

  lmsCourse     LmsCourse @relation(fields: [lmsCourseId], references: [id])
  student       Student   @relation(fields: [studentId], references: [id])
  branch        Branch    @relation(fields: [branchId], references: [id])
  progress      LmsProgress[]

  @@unique([lmsCourseId, studentId])
  @@index([studentId])
  @@index([branchId])
  @@index([lmsCourseId])
  @@map("lms_enrollments")
}
```

#### 7.2.5 LmsProgress — Tiến độ từng bài học

```prisma
model LmsProgress {
  id              String    @id @default(uuid())
  lmsEnrollmentId String    @map("lms_enrollment_id")
  lessonId        String    @map("lesson_id")
  status          String    @default("not_started") // 'not_started' | 'in_progress' | 'completed'
  progressPct     Float     @default(0) @map("progress_pct")
  timeSpentSec    Int       @default(0) @map("time_spent_sec")
  completedAt     DateTime? @map("completed_at")
  lastPosition    Json?     @map("last_position")   // Video timestamp, scroll position
  metadata        Json      @default("{}")          // Notes, bookmarks
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @updatedAt @map("updated_at")

  enrollment      LmsEnrollment @relation(fields: [lmsEnrollmentId], references: [id], onDelete: Cascade)
  lesson          LmsLesson     @relation(fields: [lessonId], references: [id])

  @@unique([lmsEnrollmentId, lessonId])
  @@index([lmsEnrollmentId])
  @@index([lessonId])
  @@map("lms_progress")
}
```

#### 7.2.6 LmsQuiz — Bài kiểm tra trong bài học

```prisma
model LmsQuiz {
  id           String   @id @default(uuid())
  lessonId     String   @unique @map("lesson_id")  // 1:1 with lesson
  title        String
  description  String?
  questions    Json                               // Array of question objects
  passingScore Float    @default(70) @map("passing_score") // Percentage to pass
  maxAttempts  Int      @default(3) @map("max_attempts")
  timeLimitMin Int?     @map("time_limit_min")
  shuffleQuestions Boolean @default(false) @map("shuffle_questions")
  metadata     Json     @default("{}")            // Rubric, AI grading config
  createdAt    DateTime @default(now()) @map("created_at")
  updatedAt    DateTime @updatedAt @map("updated_at")

  lesson       LmsLesson      @relation(fields: [lessonId], references: [id], onDelete: Cascade)
  attempts     LmsQuizAttempt[]

  @@map("lms_quizzes")
}
```

#### 7.2.7 LmsQuizAttempt — Lượt làm bài

```prisma
model LmsQuizAttempt {
  id           String    @id @default(uuid())
  quizId       String    @map("quiz_id")
  studentId    String    @map("student_id")
  attemptNumber Int      @map("attempt_number")
  answers      Json                               // Student's submitted answers
  score        Float?                             // Points achieved
  maxScore     Float?    @map("max_score")
  percentage   Float?                             // Score percentage
  passed       Boolean?                           // Met passing score?
  timeTakenSec Int?      @map("time_taken_sec")
  startedAt    DateTime  @default(now()) @map("started_at")
  submittedAt  DateTime? @map("submitted_at")
  gradedAt     DateTime? @map("graded_at")
  feedback     Json?                              // AI/manual feedback per question
  metadata     Json      @default("{}")           // AI-ready
  createdAt    DateTime  @default(now()) @map("created_at")

  quiz         LmsQuiz   @relation(fields: [quizId], references: [id], onDelete: Cascade)
  student      Student   @relation(fields: [studentId], references: [id])

  @@index([quizId])
  @@index([studentId])
  @@index([quizId, studentId])
  @@map("lms_quiz_attempts")
}
```

#### 7.2.8 LmsCertificate — Chứng chỉ

```prisma
model LmsCertificate {
  id            String   @id @default(uuid())
  lmsCourseId   String   @map("lms_course_id")
  studentId     String   @map("student_id")
  branchId      String   @map("branch_id")
  certificateNo String   @unique @map("certificate_no") // e.g., CERT-HCM-Q1-2506-0001
  issuedAt      DateTime @default(now()) @map("issued_at")
  expiresAt     DateTime? @map("expires_at")
  grade         String?                            // 'distinction' | 'merit' | 'pass'
  pdfUrl        String?  @map("pdf_url")           // Generated PDF
  metadata      Json     @default("{}")            // QR code, verification hash
  createdAt     DateTime @default(now()) @map("created_at")

  lmsCourse     LmsCourse @relation(fields: [lmsCourseId], references: [id])
  student       Student   @relation(fields: [studentId], references: [id])
  branch        Branch    @relation(fields: [branchId], references: [id])

  @@unique([lmsCourseId, studentId])
  @@index([studentId])
  @@index([branchId])
  @@map("lms_certificates")
}
```

### 7.3 LMS State Machines

#### 7.3.1 LmsEnrollment Lifecycle

```
  ┌────────┐     ┌───────────┐     ┌───────────┐
  │ active │───→│ completed │     │  expired  │
  └────┬───┘     └───────────┘     └───────────┘
       │                              ▲
       └─────────────┬──────────────┘
                   │
            ┌──────┴──────┐
            │   dropped   │
            └─────────────┘

  Transitions:
  - active → completed: All lessons completed + quiz passed
  - active → dropped: Student drops course
  - active → expired: Course access period ends
```

#### 7.3.2 LmsProgress Lifecycle

```
  ┌─────────────┐     ┌─────────────┐     ┌───────────┐
  │ not_started │───→│ in_progress │───→│ completed │
  └─────────────┘     └─────────────┘     └───────────┘

  Triggers:
  - not_started → in_progress: Student opens lesson content
  - in_progress → completed: Video watched 90%+ OR quiz passed OR content read
  - Completion auto-updates LmsEnrollment.progressPct
```

### 7.4 LMS Cross-Module Integration

#### 7.4.1 LMS ↔ Academic Bridge

```
  ┌───────────────┐         ┌───────────────┐
  │  LmsCourse     │────────→│  Course        │  (Optional FK)
  │  (online)      │         │  (in-person)   │
  └───────┬───────┘         └───────────────┘
          │
          │ LmsQuizAttempt.score
          ▼
  ┌───────────────┐
  │  GradeRecord   │  (Optional sync: assessmentType = 'lms_quiz')
  └───────────────┘

  Use cases:
  - Blended learning: In-person course has supplementary online LMS content
  - Teacher assigns LMS modules as homework for their class
  - LMS quiz scores optionally sync to Academic GradeRecord
```

#### 7.4.2 LMS ↔ Finance Bridge

```
  ┌───────────────┐         ┌───────────────┐
  │ LmsEnrollment │────────→│  Invoice       │  (If price > 0)
  │ (student      │         │  (auto-draft)  │
  │  enrolls)     │         └───────────────┘
  └───────────────┘

  Flow: LMS enrollment with price > 0 → Auto-generate draft invoice
  Reuses existing Academic Enrollment → Invoice pattern
```

#### 7.4.3 LMS ↔ AI-Learning Bridge

```
  ┌───────────────┐         ┌───────────────────┐
  │  LmsLesson    │────────→│  AiLearningModule │  (Optional link)
  │ type='quiz'   │         │  (AI grading)     │
  └───────────────┘         └───────────────────┘

  Flow: LMS quiz lessons can link to AiLearningModule for AI-powered grading
  Enables: Adaptive quiz difficulty, AI feedback, pronunciation assessment
```

### 7.5 LMS API Route Map

| Method | Route | Mô tả | RBAC |
|--------|-------|--------|------|
| GET | `/api/lms/courses` | List published courses | All authenticated |
| POST | `/api/lms/courses` | Create LMS course | super_admin, staff |
| PUT | `/api/lms/courses` | Update course | super_admin, staff |
| DELETE | `/api/lms/courses?id=` | Delete course | super_admin |
| GET | `/api/lms/courses/[id]/lessons` | List lessons for course | All authenticated |
| POST | `/api/lms/lessons` | Create lesson | super_admin, staff |
| PUT | `/api/lms/lessons` | Update lesson | super_admin, staff |
| POST | `/api/lms/contents` | Upload content to lesson | super_admin, staff |
| POST | `/api/lms/enroll` | Enroll student in course | super_admin, staff, student |
| GET | `/api/lms/progress` | Get enrollment progress | Student (own), staff |
| PUT | `/api/lms/progress` | Update lesson progress | Student (own) |
| GET | `/api/lms/quizzes/[id]` | Get quiz details | Enrolled students |
| POST | `/api/lms/quizzes/[id]/attempt` | Submit quiz attempt | Enrolled students |
| GET | `/api/lms/certificates` | List certificates | Student (own), staff |
| POST | `/api/lms/certificates/generate` | Generate certificate | super_admin, staff |

---

## 8. BOILERPLATE CODE SAMPLES

### 8.1 RBAC Middleware

```typescript
// lib/rbac.ts — Role-Based Access Control utility

import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { NextRequest, NextResponse } from 'next/server';

type Role = 'super_admin' | 'staff' | 'teacher' | 'parent' | 'student';

interface RBACOptions {
  allowedRoles: Role[];
  requireBranchMatch?: boolean;  // Enforce branch scoping
}

export async function withRBAC(
  request: NextRequest,
  options: RBACOptions,
  handler: (session: any, request: NextRequest) => Promise<NextResponse>
): Promise<NextResponse> {
  // Step 1: Authentication
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return NextResponse.json(
      { error: 'Vui lòng đăng nhập', code: 'UNAUTHENTICATED' },
      { status: 401 }
    );
  }

  // Step 2: Role Authorization
  const userRole = session.user.role as Role;
  if (!options.allowedRoles.includes(userRole)) {
    return NextResponse.json(
      { error: 'Không có quyền truy cập', code: 'FORBIDDEN' },
      { status: 403 }
    );
  }

  // Step 3: Branch Scoping (optional)
  if (options.requireBranchMatch && userRole !== 'super_admin') {
    const url = new URL(request.url);
    const requestBranchId = url.searchParams.get('branchId')
      || (request.method !== 'GET' ? (await request.clone().json())?.branchId : null);

    if (requestBranchId && requestBranchId !== session.user.primaryBranchId) {
      return NextResponse.json(
        { error: 'Không có quyền truy cập chi nhánh này', code: 'BRANCH_MISMATCH' },
        { status: 403 }
      );
    }
  }

  // Step 4: Execute handler
  return handler(session, request);
}

// Usage example:
export async function GET(request: NextRequest) {
  return withRBAC(request, {
    allowedRoles: ['super_admin', 'staff'],
    requireBranchMatch: true
  }, async (session, req) => {
    const branchFilter = session.user.role === 'super_admin'
      ? {} : { branchId: session.user.primaryBranchId };

    const data = await prisma.hrEmployee.findMany({ where: branchFilter });
    return NextResponse.json({ data });
  });
}
```

### 8.2 Audit Logging Decorator

```typescript
// lib/audit.ts — Audit logging utility

import { prisma } from '@/lib/db';
import { NextRequest } from 'next/server';

interface AuditParams {
  userId: string;
  branchId?: string;
  entityType: string;  // 'Invoice' | 'Payment' | 'Student' | 'HrPayroll' ...
  entityId: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'VIEW' | 'APPROVE' | 'REJECT';
  oldValues?: Record<string, any>;
  newValues?: Record<string, any>;
  request?: NextRequest;
}

export async function createAuditLog(params: AuditParams): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId,
        branchId: params.branchId,
        entityType: params.entityType,
        entityId: params.entityId,
        action: params.action,
        oldValues: params.oldValues ?? undefined,
        newValues: params.newValues ?? undefined,
        ipAddress: params.request?.headers.get('x-forwarded-for')
          ?? params.request?.headers.get('x-real-ip')
          ?? undefined,
        userAgent: params.request?.headers.get('user-agent') ?? undefined,
      }
    });
  } catch (error) {
    // Audit logging should never break the main operation
    console.error('[AuditLog] Failed to create audit entry:', error);
  }
}

// Usage:
await createAuditLog({
  userId: session.user.id,
  branchId: payroll.branchId,
  entityType: 'HrPayroll',
  entityId: payroll.id,
  action: 'APPROVE',
  oldValues: { status: 'draft' },
  newValues: { status: 'approved', approvedBy: session.user.id },
  request
});
```

### 8.3 Event Store Helper

```typescript
// lib/event-store.ts — Domain event recording

import { prisma } from '@/lib/db';

interface DomainEvent {
  branchId?: string;
  aggregateType: string;  // 'Invoice' | 'Enrollment' | 'HrPayroll' ...
  aggregateId: string;
  eventType: string;      // 'PAYMENT_RECORDED' | 'PAYROLL_APPROVED' ...
  payload: Record<string, any>;
}

export async function recordEvent(event: DomainEvent): Promise<void> {
  // Get next sequence number for this aggregate
  const lastEvent = await prisma.eventStore.findFirst({
    where: {
      aggregateType: event.aggregateType,
      aggregateId: event.aggregateId
    },
    orderBy: { sequenceNumber: 'desc' },
    select: { sequenceNumber: true }
  });

  await prisma.eventStore.create({
    data: {
      ...event,
      sequenceNumber: (lastEvent?.sequenceNumber ?? 0) + 1
    }
  });
}

// Usage:
await recordEvent({
  branchId: invoice.branchId,
  aggregateType: 'Invoice',
  aggregateId: invoice.id,
  eventType: 'PAYMENT_RECORDED',
  payload: {
    paymentId: payment.id,
    amount: payment.amount,
    previousStatus: invoice.status,
    newStatus: updatedInvoice.status,
    paidAmount: updatedInvoice.paidAmount,
    totalAmount: invoice.totalAmount
  }
});
```

### 8.4 Branch-Scoped Query Builder

```typescript
// lib/query-helpers.ts — Reusable query patterns

interface SessionUser {
  id: string;
  role: string;
  primaryBranchId: string;
}

/**
 * Build Prisma where clause with automatic branch scoping.
 * Super Admin: no branch filter (cross-branch access)
 * Others: filtered to their primaryBranchId
 */
export function branchScope(session: SessionUser): Record<string, any> {
  if (session.role === 'super_admin') return {};
  return { branchId: session.primaryBranchId };
}

/**
 * Build student-scoped filter for Mobile App queries.
 * Student: only own data
 * Parent: only linked children
 */
export function studentScope(
  role: 'parent' | 'student',
  subjectId: string,
  childrenIds?: string[]
): Record<string, any> {
  if (role === 'student') {
    return { studentId: subjectId };
  }
  if (role === 'parent' && childrenIds?.length) {
    return { studentId: { in: childrenIds } };
  }
  return { studentId: 'NONE' }; // Fail-safe: no access
}

/**
 * Date range filter for period-based queries (payroll, reports)
 */
export function periodFilter(period: string): { gte: Date; lt: Date } {
  const [year, month] = period.split('-').map(Number);
  return {
    gte: new Date(year, month - 1, 1),
    lt: new Date(year, month, 1)
  };
}
```

---

## 9. APPENDIX

### 9.1 Tài liệu liên quan

| Document | Path | Mô tả |
|----------|------|--------|
| Integrated Ecosystem Architecture | `docs/AEA_INTEGRATED_ECOSYSTEM_ARCHITECTURE.md` | Kiến trúc tổng thể v1 (AI-Learning focus) |
| HR Module Tech Spec | `docs/TECH_SPEC_HR_MODULE.md` | Chi tiết kỹ thuật module HR |
| Finance Module Tech Spec | `docs/TECH_SPEC_FINANCE_MODULE.md` | Chi tiết kỹ thuật module Finance |
| LMS Module Tech Spec | `docs/AEA_ARCHITECTURAL_SPECIFICATION.md#7` | Section 7: LMS schema & functional spec |
| Prisma Schema | `prisma/schema.prisma` | Database schema (source of truth) |

### 9.2 Glossary

| Term | Vietnamese | Definition |
|------|-----------|------------|
| Branch | Chi nhánh | Physical location / organizational unit |
| Enrollment | Đăng ký lớp | Student ↔ Class registration |
| ClassSession | Buổi học | Single instance of a class meeting |
| HrTeachingLog | Nhật ký giảng dạy | Bridge record: session taught → HR payroll |
| Payroll | Bảng lương | Monthly salary calculation record |
| EventStore | Kho sự kiện | Append-only event log for domain events |
| RBAC | Phân quyền vai trò | Role-Based Access Control |
| LMS | Hệ thống quản lý học tập | Learning Management System — online courses, quizzes, certificates |
| LmsCourse | Khóa học trực tuyến | Online course container with lessons and content |
| LmsEnrollment | Ghi danh khóa học | Student enrollment record linking User → LmsCourse |
| LmsCertificate | Chứng chỉ | Auto-generated certificate upon course completion |

### 9.3 Implementation Roadmap

```
 Phase 1 (✅ Done): Academic + Finance Core
   - Student/Teacher/Course/Class CRUD
   - Enrollment → Auto-Invoice flow
   - Payment recording + status machine
   - Revenue analytics

 Phase 2 (📋 In Progress): HR Module
   - HrEmployee, HrContract, HrAttendance schema
   - HrTeachingLog bridge table
   - Payroll generation from teaching logs
   - Leave request management

 Phase 3 (📋 Planned): Mobile App API
   - Parent/Student authentication flow
   - Dashboard + Schedule + Grades API
   - Payment integration (MoMo/VNPay)
   - Push notifications

 Phase 4 (📋 Planned): LMS & Student Portal
   - LmsCourse / LmsLesson / LmsContent schema
   - Student self-study portal (video streaming + progress tracking)
   - Quiz system + auto-grading
   - Certificate generation
   - LMS ↔ Academic grade sync (GradeRecord bridge)

 Phase 5 (📋 Planned): AI-Learning Production
   - Full AI grading pipeline
   - Adaptive learning paths
   - Gamification system
   - Progress analytics for parents

 Phase 6 (📋 Planned): CRM + Advanced
   - Lead pipeline management
   - Campaign ROI tracking
   - Cross-module analytics dashboard
   - Multi-org support
```

### 9.4 Quy ước đặt tên (Naming Conventions)

| Context | Convention | Example |
|---------|-----------|--------|
| Prisma Model | PascalCase | `HrEmployee`, `ClassSession` |
| DB Table (@@map) | snake_case | `hr_employees`, `class_sessions` |
| DB Column (@map) | snake_case | `employee_code`, `branch_id` |
| API Route | kebab-case | `/api/hr/teaching-logs/sync` |
| TypeScript Interface | PascalCase | `MobileTokenPayload` |
| Function | camelCase | `buildBranchFilter`, `createAuditLog` |
| Constant | UPPER_SNAKE | `MOBILE_JWT_SECRET` |
| UI Label (Vietnamese) | Natural | "Bảng lương", "Đơn nghỉ phép" |

---

> **Document Status:** Living document — cập nhật theo từng phase implementation.  
> **Next Review:** Khi bắt đầu Phase 2 (HR Module Implementation)  
> **Maintainer:** AEA Architecture Team