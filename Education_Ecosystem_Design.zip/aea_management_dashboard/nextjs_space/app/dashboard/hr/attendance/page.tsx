export default function HrAttendancePage() {
  return <AttendanceContent />;
}
import { AttendanceContent } from './attendance-content';
