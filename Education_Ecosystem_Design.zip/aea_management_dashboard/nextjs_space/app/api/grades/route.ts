export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const classId = url.searchParams.get('classId');

    const where: any = {};
    if (classId) where.enrollment = { classId };
    if (branchId) where.enrollment = { ...(where.enrollment ?? {}), branchId };

    const grades = await prisma.gradeRecord.findMany({
      where,
      include: {
        enrollment: {
          select: {
            student: { select: { fullName: true, studentCode: true } },
            class: { select: { name: true, classCode: true } },
          },
        },
      },
      orderBy: { gradedAt: 'desc' },
      take: 100,
    });
    return NextResponse.json({ grades });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const grade = await prisma.gradeRecord.create({
      data: {
        enrollmentId: body.enrollmentId,
        assessmentType: body.assessmentType,
        assessmentName: body.assessmentName,
        score: parseFloat(body.score ?? '0'),
        maxScore: parseFloat(body.maxScore ?? '100'),
        weight: parseFloat(body.weight ?? '1'),
        gradedBy: session.user.id,
        comments: body.comments,
      },
    });
    return NextResponse.json({ grade }, { status: 201 });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
