import { LmsCoursesContent } from './lms-courses-content';
export default function LmsCoursesPage() { return <LmsCoursesContent />; }
