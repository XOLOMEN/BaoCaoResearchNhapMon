import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { SignupForm } from './signup-form';

export default async function SignupPage() {
  const session = await getServerSession(authOptions);
  if (session) redirect('/dashboard');
  return <SignupForm />;
}
