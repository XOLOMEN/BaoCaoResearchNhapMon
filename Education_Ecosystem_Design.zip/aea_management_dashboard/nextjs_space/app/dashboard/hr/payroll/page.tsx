export default function HrPayrollPage() {
  return <PayrollContent />;
}
import { PayrollContent } from './payroll-content';
