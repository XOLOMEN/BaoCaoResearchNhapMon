import { TeachersContent } from './teachers-content';
export default function TeachersPage() { return <TeachersContent />; }
