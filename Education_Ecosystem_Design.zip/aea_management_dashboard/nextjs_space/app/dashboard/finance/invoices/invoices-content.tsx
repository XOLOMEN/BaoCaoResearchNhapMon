'use client';
import { useState, useEffect, useCallback } from 'react';
import { FileText, Search, Eye, Send, Ban, Plus, CreditCard, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useBranch } from '@/hooks/use-branch';
import { formatCurrency, formatDate, getStatusColor, getStatusLabel } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn, Stagger, StaggerItem } from '@/components/ui/animate';

const STATUSES = [
  { value: '', label: 'Tất cả' },
  { value: 'draft', label: 'Nháp' },
  { value: 'issued', label: 'Đã phát hành' },
  { value: 'paid', label: 'Đã thanh toán' },
  { value: 'partially_paid', label: 'TT một phần' },
  { value: 'overdue', label: 'Quá hạn' },
  { value: 'cancelled', label: 'Đã hủy' },
];

export function InvoicesContent() {
  const { branchId } = useBranch();
  const [invoices, setInvoices] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [viewInvoice, setViewInvoice] = useState<any>(null);
  const [showPayment, setShowPayment] = useState<any>(null);
  const [paymentForm, setPaymentForm] = useState({ amount: '', method: 'cash', note: '' });
  const [submitting, setSubmitting] = useState(false);
  const perPage = 20;

  const loadInvoices = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (branchId) params.set('branchId', branchId);
    if (search) params.set('search', search);
    if (filterStatus) params.set('status', filterStatus);
    params.set('page', String(page));
    params.set('limit', String(perPage));
    fetch(`/api/finance/invoices?${params}`)
      .then((r: any) => r?.json?.())
      .then((d: any) => { setInvoices(d?.invoices ?? []); setTotal(d?.total ?? 0); })
      .catch(() => toast.error('Không thể tải dữ liệu'))
      .finally(() => setLoading(false));
  }, [branchId, search, filterStatus, page]);

  useEffect(() => { loadInvoices(); }, [loadInvoices]);

  const changeStatus = async (invoiceId: string, newStatus: string) => {
    try {
      const res = await fetch('/api/finance/invoices', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoiceId, status: newStatus }),
      });
      const data = await res?.json?.();
      if (!res?.ok) { toast.error(data?.error ?? 'Lỗi cập nhật'); return; }
      toast.success(`Cập nhật trạng thái thành công`);
      loadInvoices();
      if (viewInvoice?.id === invoiceId) setViewInvoice(null);
    } catch { toast.error('Đã xảy ra lỗi'); }
  };

  const handleRecordPayment = async () => {
    if (!showPayment) return;
    const amount = parseFloat(paymentForm.amount);
    if (!amount || amount <= 0) { toast.error('Số tiền không hợp lệ'); return; }
    setSubmitting(true);
    try {
      const res = await fetch('/api/finance/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoiceId: showPayment.id,
          amount,
          method: paymentForm.method,
          note: paymentForm.note || undefined,
        }),
      });
      const data = await res?.json?.();
      if (!res?.ok) { toast.error(data?.error ?? 'Lỗi ghi nhận thanh toán'); return; }
      toast.success('Ghi nhận thanh toán thành công');
      setShowPayment(null);
      setPaymentForm({ amount: '', method: 'cash', note: '' });
      loadInvoices();
    } catch { toast.error('Đã xảy ra lỗi'); }
    finally { setSubmitting(false); }
  };

  const totalPages = Math.ceil(total / perPage);
  const remaining = (inv: any) => (inv?.totalAmount ?? 0) - (inv?.paidAmount ?? 0);

  return (
    <div className="space-y-6">
      <FadeIn>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
              <FileText className="w-6 h-6 text-primary" /> Quản lý Hóa đơn
            </h1>
            <p className="text-muted-foreground text-sm">Theo dõi và quản lý hóa đơn học phí</p>
          </div>
        </div>
      </FadeIn>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Tìm theo số hóa đơn, tên học viên..."
                value={search}
                onChange={(e: any) => { setSearch(e?.target?.value ?? ''); setPage(1); }}
                className="pl-10 h-9 text-sm"
              />
            </div>
            <Select value={filterStatus || 'all'} onValueChange={(v: string) => { setFilterStatus(v === 'all' ? '' : v); setPage(1); }}>
              <SelectTrigger className="w-44 h-9 text-xs"><SelectValue placeholder="Trạng thái" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                {STATUSES.filter(s => s.value).map(s => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Badge variant="secondary" className="text-xs">{total} hóa đơn</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Số HĐ</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Học viên</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">Tổng tiền</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">Đã thu</th>
                  <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">Còn lại</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Trạng thái</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Hạn TT</th>
                  <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">Đang tải...</td></tr>
                ) : invoices.length === 0 ? (
                  <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">Không có hóa đơn nào</td></tr>
                ) : (
                  invoices.map((inv: any) => (
                    <tr key={inv.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs font-medium">{inv.invoiceNumber}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-sm">{inv.student?.fullName ?? '—'}</p>
                        <p className="text-xs text-muted-foreground">{inv.student?.studentCode ?? ''}</p>
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-sm">{formatCurrency(inv.totalAmount)}</td>
                      <td className="px-4 py-3 text-right font-mono text-sm text-emerald-600">{formatCurrency(inv.paidAmount)}</td>
                      <td className="px-4 py-3 text-right font-mono text-sm text-orange-600">{formatCurrency(remaining(inv))}</td>
                      <td className="px-4 py-3">
                        <Badge variant="secondary" className={`text-[10px] ${getStatusColor(inv.status)}`}>
                          {getStatusLabel(inv.status)}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(inv.dueDate)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setViewInvoice(inv)} title="Xem chi tiết">
                            <Eye className="w-3.5 h-3.5" />
                          </Button>
                          {inv.status === 'draft' && (
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600" onClick={() => changeStatus(inv.id, 'issued')} title="Phát hành">
                              <Send className="w-3.5 h-3.5" />
                            </Button>
                          )}
                          {['issued', 'partially_paid', 'overdue'].includes(inv.status) && (
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-emerald-600" onClick={() => { setShowPayment(inv); setPaymentForm({ amount: String(remaining(inv)), method: 'cash', note: '' }); }} title="Thu tiền">
                              <CreditCard className="w-3.5 h-3.5" />
                            </Button>
                          )}
                          {['draft', 'issued'].includes(inv.status) && (
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => changeStatus(inv.id, 'cancelled')} title="Hủy">
                              <Ban className="w-3.5 h-3.5" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t">
              <p className="text-xs text-muted-foreground">Trang {page}/{totalPages} ({total} kết quả)</p>
              <div className="flex gap-1">
                <Button variant="outline" size="icon" className="h-7 w-7" disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronLeft className="w-3.5 h-3.5" /></Button>
                <Button variant="outline" size="icon" className="h-7 w-7" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}><ChevronRight className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Invoice Dialog */}
      <Dialog open={!!viewInvoice} onOpenChange={() => setViewInvoice(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Chi tiết Hóa đơn</DialogTitle></DialogHeader>
          {viewInvoice && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground text-xs">Số HĐ</span><p className="font-mono font-medium">{viewInvoice.invoiceNumber}</p></div>
                <div><span className="text-muted-foreground text-xs">Trạng thái</span><p><Badge variant="secondary" className={`text-[10px] ${getStatusColor(viewInvoice.status)}`}>{getStatusLabel(viewInvoice.status)}</Badge></p></div>
                <div><span className="text-muted-foreground text-xs">Học viên</span><p className="font-medium">{viewInvoice.student?.fullName}</p></div>
                <div><span className="text-muted-foreground text-xs">Chi nhánh</span><p>{viewInvoice.branch?.name ?? '—'}</p></div>
                <div><span className="text-muted-foreground text-xs">Ngày tạo</span><p>{formatDate(viewInvoice.issueDate)}</p></div>
                <div><span className="text-muted-foreground text-xs">Hạn thanh toán</span><p>{formatDate(viewInvoice.dueDate)}</p></div>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50"><tr><th className="text-left px-3 py-2 text-xs">Mô tả</th><th className="text-right px-3 py-2 text-xs">Số lượng</th><th className="text-right px-3 py-2 text-xs">Đơn giá</th><th className="text-right px-3 py-2 text-xs">Thành tiền</th></tr></thead>
                  <tbody>
                    {(viewInvoice.items ?? []).map((item: any) => (
                      <tr key={item.id} className="border-t">
                        <td className="px-3 py-2 text-xs">{item.description}</td>
                        <td className="px-3 py-2 text-xs text-right">{item.quantity}</td>
                        <td className="px-3 py-2 text-xs text-right font-mono">{formatCurrency(item.unitPrice)}</td>
                        <td className="px-3 py-2 text-xs text-right font-mono">{formatCurrency(item.amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex justify-between items-center pt-2 border-t">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Tổng: <span className="font-mono font-medium text-foreground">{formatCurrency(viewInvoice.totalAmount)}</span></p>
                  <p className="text-xs text-muted-foreground">Đã thu: <span className="font-mono font-medium text-emerald-600">{formatCurrency(viewInvoice.paidAmount)}</span></p>
                  <p className="text-xs text-muted-foreground">Còn lại: <span className="font-mono font-bold text-orange-600">{formatCurrency(remaining(viewInvoice))}</span></p>
                </div>
                <div className="flex gap-2">
                  {viewInvoice.status === 'draft' && <Button size="sm" onClick={() => changeStatus(viewInvoice.id, 'issued')}>Phát hành</Button>}
                  {['issued', 'partially_paid', 'overdue'].includes(viewInvoice.status) && (
                    <Button size="sm" variant="default" onClick={() => { setViewInvoice(null); setShowPayment(viewInvoice); setPaymentForm({ amount: String(remaining(viewInvoice)), method: 'cash', note: '' }); }}>
                      <CreditCard className="w-3.5 h-3.5 mr-1" /> Thu tiền
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Record Payment Dialog */}
      <Dialog open={!!showPayment} onOpenChange={() => setShowPayment(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Ghi nhận thanh toán</DialogTitle></DialogHeader>
          {showPayment && (
            <div className="space-y-4">
              <div className="p-3 bg-muted/50 rounded-lg text-sm">
                <p className="font-medium">{showPayment.invoiceNumber}</p>
                <p className="text-xs text-muted-foreground">{showPayment.student?.fullName}</p>
                <p className="text-xs mt-1">Còn lại: <span className="font-mono font-bold text-orange-600">{formatCurrency(remaining(showPayment))}</span></p>
              </div>
              <div>
                <Label className="text-xs">Số tiền thanh toán (VNĐ)</Label>
                <Input
                  type="number"
                  value={paymentForm.amount}
                  onChange={(e: any) => setPaymentForm(p => ({ ...p, amount: e?.target?.value ?? '' }))}
                  placeholder="0"
                  className="font-mono"
                />
              </div>
              <div>
                <Label className="text-xs">Phương thức</Label>
                <Select value={paymentForm.method} onValueChange={(v: string) => setPaymentForm(p => ({ ...p, method: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Tiền mặt</SelectItem>
                    <SelectItem value="bank_transfer">Chuyển khoản</SelectItem>
                    <SelectItem value="card">Thẻ</SelectItem>
                    <SelectItem value="e_wallet">Ví điện tử</SelectItem>
                    <SelectItem value="other">Khác</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Ghi chú</Label>
                <Input
                  value={paymentForm.note}
                  onChange={(e: any) => setPaymentForm(p => ({ ...p, note: e?.target?.value ?? '' }))}
                  placeholder="Ghi chú (không bắt buộc)"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowPayment(null)}>Hủy</Button>
                <Button onClick={handleRecordPayment} disabled={submitting}>
                  {submitting ? 'Đang xử lý...' : 'Xác nhận thanh toán'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
