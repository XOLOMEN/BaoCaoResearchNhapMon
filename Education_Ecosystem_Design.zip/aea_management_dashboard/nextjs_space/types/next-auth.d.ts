import 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      email: string;
      name: string;
      role: string;
      primaryBranchId: string;
      primaryBranchName: string;
      studentId: string | null;
      parentId: string | null;
      childStudentIds: string[];
    };
  }
  interface User {
    id: string;
    email: string;
    name: string;
    role: string;
    primaryBranchId: string | null;
    primaryBranchName: string | null;
    studentId: string | null;
    parentId: string | null;
    childStudentIds: string[];
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string;
    role: string;
    primaryBranchId: string;
    primaryBranchName: string;
    studentId: string | null;
    parentId: string | null;
    childStudentIds: string[];
  }
}
