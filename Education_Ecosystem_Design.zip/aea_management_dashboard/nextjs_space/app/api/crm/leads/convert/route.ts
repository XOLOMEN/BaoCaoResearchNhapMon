export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

// ── POST: Atomic Lead → Student Conversion ──
// Creates Student, updates Lead status, logs EventStore, auto-generates draft Invoice
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const role = session.user.role;
    if (role !== 'super_admin' && role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền chuyển đổi lead' }, { status: 403 });
    }

    const body = await request.json();
    const { leadId, courseId, tuitionAmount, notes } = body ?? {};

    if (!leadId) {
      return NextResponse.json({ error: 'Thiếu leadId' }, { status: 400 });
    }

    // ── Validate lead exists and is in convertible state ──
    const lead = await prisma.crmLead.findUnique({
      where: { id: leadId },
      include: {
        branch: { select: { id: true, code: true, name: true } },
        interestCourse: { select: { id: true, name: true, tuitionFee: true } },
      },
    });

    if (!lead) return NextResponse.json({ error: 'Không tìm thấy lead' }, { status: 404 });

    if (lead.status === 'converted') {
      return NextResponse.json({ error: 'Lead đã được chuyển đổi trước đó' }, { status: 400 });
    }
    if (lead.status === 'lost') {
      return NextResponse.json({ error: 'Không thể chuyển đổi lead đã mất' }, { status: 400 });
    }

    // Branch scope check
    if (role !== 'super_admin' && lead.branchId !== session.user.primaryBranchId) {
      return NextResponse.json({ error: 'Không có quyền chuyển đổi lead chi nhánh khác' }, { status: 403 });
    }

    // ── Generate student code ──
    const branchCode = lead.branch.code || 'XX';
    const now = new Date();
    const yy = String(now.getFullYear()).slice(-2);
    const studentCount = await prisma.student.count({ where: { branchId: lead.branchId } });
    const seq = String(studentCount + 1).padStart(4, '0');
    const studentCode = `STU-${branchCode}-${yy}-${seq}`;

    // ── Determine course & tuition ──
    const selectedCourseId = courseId || lead.interestCourseId;
    let courseName = 'Khóa học';
    let finalTuition = tuitionAmount || 0;

    if (selectedCourseId) {
      const course = selectedCourseId === lead.interestCourseId
        ? lead.interestCourse
        : await prisma.course.findUnique({ where: { id: selectedCourseId }, select: { id: true, name: true, tuitionFee: true } });
      if (course) {
        courseName = course.name;
        if (!tuitionAmount && course.tuitionFee) {
          finalTuition = course.tuitionFee;
        }
      }
    }

    // ── Generate invoice number ──
    const yyMM = `${yy}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const invoiceCount = await prisma.invoice.count({
      where: { branchId: lead.branchId, createdAt: { gte: monthStart, lt: monthEnd } },
    });
    const invSeq = String(invoiceCount + 1).padStart(4, '0');
    const invoiceNumber = `INV-${branchCode}-${yyMM}-${invSeq}`;

    // ── Atomic transaction: Student + Lead update + EventStore + Invoice ──
    const result = await prisma.$transaction(async (tx) => {
      // 1. Create Student
      const student = await tx.student.create({
        data: {
          branchId: lead.branchId,
          studentCode,
          fullName: lead.fullName,
          email: lead.email,
          phone: lead.phone,
          source: `crm_lead:${lead.id}`,
          status: 'active',
          notes: notes || `Chuyển đổi từ CRM Lead. ${lead.notes || ''}`.trim(),
          metadata: {
            convertedFromLead: lead.id,
            leadSource: lead.source,
            campaignId: lead.campaignId,
          },
        },
      });

      // 2. Update Lead status to CONVERTED
      const updatedLead = await tx.crmLead.update({
        where: { id: leadId },
        data: {
          status: 'converted',
          convertedStudentId: student.id,
          convertedAt: now,
        },
      });

      // 3. EventStore: LEAD_CONVERTED
      await tx.eventStore.create({
        data: {
          branchId: lead.branchId,
          aggregateType: 'CrmLead',
          aggregateId: lead.id,
          eventType: 'LEAD_CONVERTED',
          payload: {
            leadId: lead.id,
            studentId: student.id,
            studentCode,
            convertedBy: session.user.id,
            courseName,
            tuitionAmount: finalTuition,
          },
          sequenceNumber: 1,
        },
      });

      // 4. Auto-generate draft Invoice (if tuition > 0)
      let invoice = null;
      if (finalTuition > 0) {
        invoice = await tx.invoice.create({
          data: {
            branchId: lead.branchId,
            invoiceNumber,
            studentId: student.id,
            type: 'tuition',
            subtotal: finalTuition,
            discountAmount: 0,
            taxAmount: 0,
            totalAmount: finalTuition,
            paidAmount: 0,
            currency: 'VND',
            dueDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000), // 30 days
            status: 'draft',
            issuedBy: session.user.id,
            notes: `Hóa đơn tự động từ chuyển đổi lead - ${lead.fullName}`,
            items: {
              create: [{
                description: `Học phí: ${courseName}`,
                quantity: 1,
                unitPrice: finalTuition,
                amount: finalTuition,
              }],
            },
          },
          include: { items: true },
        });

        // EventStore: Invoice created from conversion
        await tx.eventStore.create({
          data: {
            branchId: lead.branchId,
            aggregateType: 'Invoice',
            aggregateId: invoice.id,
            eventType: 'INVOICE_CREATED_FROM_CONVERSION',
            payload: {
              invoiceNumber,
              studentId: student.id,
              leadId: lead.id,
              totalAmount: finalTuition,
              createdBy: session.user.id,
            },
            sequenceNumber: 1,
          },
        });
      }

      return { student, updatedLead, invoice };
    });

    return NextResponse.json({
      success: true,
      message: `Lead "${lead.fullName}" đã chuyển đổi thành học viên thành công`,
      student: {
        id: result.student.id,
        studentCode: result.student.studentCode,
        fullName: result.student.fullName,
      },
      lead: {
        id: result.updatedLead.id,
        status: result.updatedLead.status,
        convertedAt: result.updatedLead.convertedAt?.toISOString(),
      },
      invoice: result.invoice ? {
        id: result.invoice.id,
        invoiceNumber: result.invoice.invoiceNumber,
        totalAmount: result.invoice.totalAmount,
        status: result.invoice.status,
      } : null,
    }, { status: 201 });
  } catch (error: any) {
    console.error('[CRM/Leads/Convert POST]', error);
    if (error?.code === 'P2002') {
      return NextResponse.json({ error: 'Mã học viên hoặc hóa đơn bị trùng. Vui lòng thử lại.' }, { status: 409 });
    }
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống khi chuyển đổi lead' }, { status: 500 });
  }
}
