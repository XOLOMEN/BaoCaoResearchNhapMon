export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { canModifyLms } from '@/lib/lms/helpers';

// ── GET: List lessons for a course ──
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const lessons = await prisma.lmsLesson.findMany({
      where: { lmsCourseId: params.id },
      orderBy: { sortOrder: 'asc' },
      include: {
        contents: { orderBy: { sortOrder: 'asc' }, select: { id: true, type: true, title: true, durationSec: true } },
        quiz: { select: { id: true, title: true } },
        _count: { select: { contents: true, progress: true } },
      },
    });

    return NextResponse.json(lessons);
  } catch (error: any) {
    console.error('LMS lessons GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Create lesson ──
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLms(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const body = await request.json();
    const { title, description, type, durationMin, isFree, sortOrder } = body;
    if (!title) return NextResponse.json({ error: 'title bắt buộc' }, { status: 400 });

    // Auto-set sortOrder to last position
    let order = sortOrder;
    if (order === undefined || order === null) {
      const lastLesson = await prisma.lmsLesson.findFirst({
        where: { lmsCourseId: params.id },
        orderBy: { sortOrder: 'desc' },
        select: { sortOrder: true },
      });
      order = (lastLesson?.sortOrder ?? -1) + 1;
    }

    const lesson = await prisma.lmsLesson.create({
      data: {
        lmsCourseId: params.id,
        title,
        description: description || null,
        type: type || 'video',
        durationMin: durationMin ? parseInt(durationMin) : null,
        isFree: isFree || false,
        sortOrder: order,
      },
    });

    // Update course stats
    const stats = await prisma.lmsLesson.aggregate({
      where: { lmsCourseId: params.id },
      _count: true,
      _sum: { durationMin: true },
    });
    await prisma.lmsCourse.update({
      where: { id: params.id },
      data: { totalLessons: stats._count, totalDuration: stats._sum.durationMin || 0 },
    });

    return NextResponse.json(lesson, { status: 201 });
  } catch (error: any) {
    console.error('LMS lessons POST error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
