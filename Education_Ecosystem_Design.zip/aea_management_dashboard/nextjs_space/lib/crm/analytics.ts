import { prisma } from '@/lib/db';

export interface ConversionRate {
  branchId: string;
  branchName: string;
  branchCode: string;
  totalLeads: number;
  convertedLeads: number;
  lostLeads: number;
  activeLeads: number;
  conversionRate: number;  // percentage
  lostRate: number;        // percentage
  avgScore: number;
  avgDaysToConvert: number | null;
  totalExpectedValue: number;
  totalConvertedValue: number;
}

export interface ConversionAnalytics {
  overall: {
    totalLeads: number;
    convertedLeads: number;
    lostLeads: number;
    activeLeads: number;
    conversionRate: number;
    lostRate: number;
  };
  byBranch: ConversionRate[];
  bySource: { source: string; total: number; converted: number; rate: number }[];
  pipeline: { status: string; count: number; totalValue: number }[];
}

// ── Calculate conversion rates by branch ──
export async function calculateConversionAnalytics(
  branchId?: string,
  dateFrom?: Date,
  dateTo?: Date,
): Promise<ConversionAnalytics> {
  const where: any = {};
  if (branchId) where.branchId = branchId;
  if (dateFrom || dateTo) {
    where.createdAt = {};
    if (dateFrom) where.createdAt.gte = dateFrom;
    if (dateTo) where.createdAt.lte = dateTo;
  }

  // ── All leads grouped by branch ──
  const leadsByBranch = await prisma.crmLead.groupBy({
    by: ['branchId', 'status'],
    where,
    _count: { id: true },
    _avg: { score: true },
    _sum: { expectedValue: true },
  });

  // ── Branches for names ──
  const branchIds = [...new Set(leadsByBranch.map((l) => l.branchId))];
  const branches = await prisma.branch.findMany({
    where: { id: { in: branchIds } },
    select: { id: true, name: true, code: true },
  });
  const branchMap = new Map(branches.map((b) => [b.id, b]));

  // ── Avg days to convert (for converted leads) ──
  const convertedLeads = await prisma.crmLead.findMany({
    where: { ...where, status: 'converted', convertedAt: { not: null } },
    select: { branchId: true, createdAt: true, convertedAt: true },
  });

  const avgDaysByBranch = new Map<string, number>();
  const daysByBranch = new Map<string, number[]>();
  for (const lead of convertedLeads) {
    if (!lead.convertedAt) continue;
    const days = Math.ceil(
      (lead.convertedAt.getTime() - lead.createdAt.getTime()) / (1000 * 60 * 60 * 24)
    );
    const arr = daysByBranch.get(lead.branchId) || [];
    arr.push(days);
    daysByBranch.set(lead.branchId, arr);
  }
  for (const [bid, days] of daysByBranch.entries()) {
    avgDaysByBranch.set(bid, Math.round(days.reduce((a, b) => a + b, 0) / days.length));
  }

  // ── Build per-branch stats ──
  const branchStatsMap = new Map<string, ConversionRate>();

  for (const row of leadsByBranch) {
    const branch = branchMap.get(row.branchId);
    if (!branchStatsMap.has(row.branchId)) {
      branchStatsMap.set(row.branchId, {
        branchId: row.branchId,
        branchName: branch?.name || 'Unknown',
        branchCode: branch?.code || 'XX',
        totalLeads: 0,
        convertedLeads: 0,
        lostLeads: 0,
        activeLeads: 0,
        conversionRate: 0,
        lostRate: 0,
        avgScore: 0,
        avgDaysToConvert: null,
        totalExpectedValue: 0,
        totalConvertedValue: 0,
      });
    }

    const stats = branchStatsMap.get(row.branchId)!;
    const count = row._count.id;
    stats.totalLeads += count;

    if (row.status === 'converted') {
      stats.convertedLeads += count;
      stats.totalConvertedValue += row._sum.expectedValue || 0;
    } else if (row.status === 'lost') {
      stats.lostLeads += count;
    } else {
      stats.activeLeads += count;
    }
    stats.totalExpectedValue += row._sum.expectedValue || 0;
  }

  // Calculate rates
  const byBranch: ConversionRate[] = [];
  for (const stats of branchStatsMap.values()) {
    stats.conversionRate = stats.totalLeads > 0
      ? Math.round((stats.convertedLeads / stats.totalLeads) * 10000) / 100
      : 0;
    stats.lostRate = stats.totalLeads > 0
      ? Math.round((stats.lostLeads / stats.totalLeads) * 10000) / 100
      : 0;
    stats.avgDaysToConvert = avgDaysByBranch.get(stats.branchId) ?? null;
    byBranch.push(stats);
  }

  // ── By source ──
  const leadsBySource = await prisma.crmLead.groupBy({
    by: ['source', 'status'],
    where,
    _count: { id: true },
  });

  const sourceMap = new Map<string, { total: number; converted: number }>();
  for (const row of leadsBySource) {
    if (!sourceMap.has(row.source)) {
      sourceMap.set(row.source, { total: 0, converted: 0 });
    }
    const s = sourceMap.get(row.source)!;
    s.total += row._count.id;
    if (row.status === 'converted') s.converted += row._count.id;
  }
  const bySource = Array.from(sourceMap.entries()).map(([source, s]) => ({
    source,
    total: s.total,
    converted: s.converted,
    rate: s.total > 0 ? Math.round((s.converted / s.total) * 10000) / 100 : 0,
  }));

  // ── Pipeline ──
  const pipelineData = await prisma.crmLead.groupBy({
    by: ['status'],
    where,
    _count: { id: true },
    _sum: { expectedValue: true },
  });
  const statusOrder = ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'converted', 'lost'];
  const pipeline = statusOrder
    .map((status) => {
      const row = pipelineData.find((r) => r.status === status);
      return {
        status,
        count: row?._count.id || 0,
        totalValue: row?._sum.expectedValue || 0,
      };
    })
    .filter((p) => p.count > 0);

  // ── Overall ──
  const overall = {
    totalLeads: byBranch.reduce((s, b) => s + b.totalLeads, 0),
    convertedLeads: byBranch.reduce((s, b) => s + b.convertedLeads, 0),
    lostLeads: byBranch.reduce((s, b) => s + b.lostLeads, 0),
    activeLeads: byBranch.reduce((s, b) => s + b.activeLeads, 0),
    conversionRate: 0,
    lostRate: 0,
  };
  overall.conversionRate = overall.totalLeads > 0
    ? Math.round((overall.convertedLeads / overall.totalLeads) * 10000) / 100
    : 0;
  overall.lostRate = overall.totalLeads > 0
    ? Math.round((overall.lostLeads / overall.totalLeads) * 10000) / 100
    : 0;

  return { overall, byBranch, bySource, pipeline };
}
