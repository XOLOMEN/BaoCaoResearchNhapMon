'use client';
import { useState, useEffect } from 'react';
import { BookOpen, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useBranch } from '@/hooks/use-branch';
import { formatCurrency, getLevelLabel } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

export function CoursesContent() {
  const { branchId } = useBranch();
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [branches, setBranches] = useState<any[]>([]);
  const [form, setForm] = useState<any>({});

  useEffect(() => { fetch('/api/branches').then((r:any)=>r?.json?.()).then((d:any)=>setBranches(d?.branches??[])).catch(()=>{}); }, []);
  useEffect(() => {
    setLoading(true);
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/courses${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setCourses(d?.courses??[])).catch(()=>{}).finally(()=>setLoading(false));
  }, [branchId]);

  const handleAdd = async () => {
    const res = await fetch('/api/courses', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...form,branchId:form.branchId||branchId}) });
    const data = await res?.json?.();
    if (!res?.ok) { toast.error(data?.error??'Lỗi'); return; }
    toast.success('Thêm khóa học thành công'); setShowAdd(false); setForm({});
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/courses${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setCourses(d?.courses??[]));
  };

  return (
    <div className="space-y-6">
      <FadeIn><div className="flex items-center justify-between">
        <div><h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><BookOpen className="w-6 h-6 text-primary" /> Quản lý Khóa học</h1><p className="text-muted-foreground text-sm">Quản lý chương trình và khóa học</p></div>
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogTrigger asChild><Button size="sm" className="gap-1"><Plus className="w-4 h-4" /> Thêm khóa học</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Thêm khóa học mới</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label className="text-xs">Chi nhánh</Label>
                <Select value={form.branchId||branchId||''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),branchId:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent>{branches?.map?.((b:any)=><SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select></div>
              <div><Label className="text-xs">Mã KH</Label><Input value={form.code??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),code:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Tên khóa học</Label><Input value={form.name??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),name:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Số giờ</Label><Input type="number" value={form.durationHours??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),durationHours:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Số buổi</Label><Input type="number" value={form.totalSessions??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),totalSessions:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Học phí (đ)</Label><Input type="number" value={form.tuitionFee??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),tuitionFee:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Trình độ</Label>
                <Select value={form.level??''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),level:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent><SelectItem value="beginner">Cơ bản</SelectItem><SelectItem value="intermediate">Trung cấp</SelectItem><SelectItem value="advanced">Nâng cao</SelectItem></SelectContent>
                </Select></div>
              <div className="col-span-2"><Label className="text-xs">Mô tả</Label><Textarea value={form.description??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),description:e?.target?.value??''}))} rows={2} /></div>
            </div>
            <div className="flex justify-end gap-2 mt-4"><Button variant="outline" onClick={()=>setShowAdd(false)}>Hủy</Button><Button onClick={handleAdd}>Lưu</Button></div>
          </DialogContent>
        </Dialog>
      </div></FadeIn>
      <Card><CardContent className="p-0"><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-muted/50"><tr>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Mã</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Tên khóa học</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Trình độ</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Số giờ</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Học phí</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Số lớp</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Chi nhánh</th>
      </tr></thead><tbody>
        {loading ? <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Đang tải...</td></tr> :
        (courses??[])?.length===0 ? <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Không có dữ liệu</td></tr> :
        (courses??[])?.map?.((c:any)=>(
          <tr key={c?.id} className="border-t border-border hover:bg-muted/30 transition-colors">
            <td className="px-4 py-3 font-mono text-xs">{c?.code??''}</td>
            <td className="px-4 py-3 font-medium">{c?.name??''}</td>
            <td className="px-4 py-3"><Badge variant="outline" className="text-[10px]">{getLevelLabel(c?.level)}</Badge></td>
            <td className="px-4 py-3 font-mono text-xs">{c?.durationHours??0}h / {c?.totalSessions??0} buổi</td>
            <td className="px-4 py-3 font-mono text-xs">{formatCurrency(c?.tuitionFee)}</td>
            <td className="px-4 py-3 text-center font-mono">{c?._count?.classes??0}</td>
            <td className="px-4 py-3 text-xs text-muted-foreground">{c?.branch?.name??''}</td>
          </tr>
        ))}
      </tbody></table></div></CardContent></Card>
    </div>
  );
}
