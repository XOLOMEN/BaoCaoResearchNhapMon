export default function CrmCampaignsPage() {
  return <CampaignsContent />;
}
import { CampaignsContent } from './campaigns-content';
