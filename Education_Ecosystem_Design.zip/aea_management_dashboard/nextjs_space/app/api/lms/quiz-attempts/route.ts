export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

// ── GET: Get quiz attempts ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const quizId = url.searchParams.get('quizId');
    const studentId = url.searchParams.get('studentId');

    const where: any = {};
    if (quizId) where.quizId = quizId;
    if (studentId) where.studentId = studentId;

    const attempts = await prisma.lmsQuizAttempt.findMany({
      where,
      include: {
        quiz: { select: { id: true, title: true, passingScore: true } },
        student: { select: { id: true, fullName: true, studentCode: true } },
      },
      orderBy: { startedAt: 'desc' },
      take: 100,
    });

    return NextResponse.json(attempts);
  } catch (error: any) {
    console.error('LMS quiz attempts GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Submit quiz attempt ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { quizId, studentId, answers, timeTakenSec } = body;
    if (!quizId || !studentId || !answers) {
      return NextResponse.json({ error: 'quizId, studentId, answers bắt buộc' }, { status: 400 });
    }

    // Get quiz with questions for auto-grading
    const quiz = await prisma.lmsQuiz.findUnique({ where: { id: quizId } });
    if (!quiz) return NextResponse.json({ error: 'Quiz không tồn tại' }, { status: 404 });

    // Check max attempts
    const attemptCount = await prisma.lmsQuizAttempt.count({ where: { quizId, studentId } });
    if (attemptCount >= quiz.maxAttempts) {
      return NextResponse.json({ error: `Đã hết lượt làm bài (tối đa ${quiz.maxAttempts})` }, { status: 400 });
    }

    // Auto-grade: compare answers against correct answers in questions JSON
    const questions = quiz.questions as any[];
    let score = 0;
    const maxScore = questions.length;
    const feedback: any[] = [];

    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      const studentAnswer = answers[i]?.answer;
      const isCorrect = String(studentAnswer).toLowerCase().trim() === String(q.correctAnswer).toLowerCase().trim();
      if (isCorrect) score++;
      feedback.push({
        questionIndex: i,
        correct: isCorrect,
        studentAnswer,
        correctAnswer: q.correctAnswer,
      });
    }

    const percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
    const passed = percentage >= quiz.passingScore;

    const attempt = await prisma.lmsQuizAttempt.create({
      data: {
        quizId,
        studentId,
        attemptNumber: attemptCount + 1,
        answers,
        score,
        maxScore,
        percentage,
        passed,
        timeTakenSec: timeTakenSec || null,
        submittedAt: new Date(),
        gradedAt: new Date(),
        feedback,
      },
    });

    return NextResponse.json(attempt, { status: 201 });
  } catch (error: any) {
    console.error('LMS quiz attempt POST error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
