'use client';
import { useState, useEffect } from 'react';
import { School, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBranch } from '@/hooks/use-branch';
import { formatDate, getStatusColor, getStatusLabel } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

export function ClassesContent() {
  const { branchId } = useBranch();
  const [classes, setClasses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [branches, setBranches] = useState<any[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [form, setForm] = useState<any>({});

  useEffect(() => {
    fetch('/api/branches').then((r:any)=>r?.json?.()).then((d:any)=>setBranches(d?.branches??[])).catch(()=>{});
    fetch('/api/courses').then((r:any)=>r?.json?.()).then((d:any)=>setCourses(d?.courses??[])).catch(()=>{});
    fetch('/api/teachers').then((r:any)=>r?.json?.()).then((d:any)=>setTeachers(d?.teachers??[])).catch(()=>{});
  }, []);

  useEffect(() => {
    setLoading(true);
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/classes${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setClasses(d?.classes??[])).catch(()=>{}).finally(()=>setLoading(false));
  }, [branchId]);

  const handleAdd = async () => {
    const res = await fetch('/api/classes', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...form,branchId:form.branchId||branchId}) });
    if (!res?.ok) { toast.error('Lỗi tạo lớp'); return; }
    toast.success('Tạo lớp thành công'); setShowAdd(false); setForm({});
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/classes${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setClasses(d?.classes??[]));
  };

  return (
    <div className="space-y-6">
      <FadeIn><div className="flex items-center justify-between">
        <div><h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><School className="w-6 h-6 text-primary" /> Quản lý Lớp học</h1><p className="text-muted-foreground text-sm">Quản lý lớp học và lịch học</p></div>
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogTrigger asChild><Button size="sm" className="gap-1"><Plus className="w-4 h-4" /> Tạo lớp</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Tạo lớp mới</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label className="text-xs">Chi nhánh</Label>
                <Select value={form.branchId||branchId||''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),branchId:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent>{branches?.map?.((b:any)=><SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select></div>
              <div><Label className="text-xs">Khóa học</Label>
                <Select value={form.courseId??''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),courseId:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent>{courses?.map?.((c:any)=><SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select></div>
              <div><Label className="text-xs">Giáo viên</Label>
                <Select value={form.teacherId??''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),teacherId:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent>{teachers?.map?.((t:any)=><SelectItem key={t.id} value={t.id}>{t.fullName}</SelectItem>)}</SelectContent>
                </Select></div>
              <div><Label className="text-xs">Mã lớp</Label><Input value={form.classCode??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),classCode:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Tên lớp</Label><Input value={form.name??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),name:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Phòng</Label><Input value={form.room??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),room:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Sĩ số</Label><Input type="number" value={form.capacity??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),capacity:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Ngày bắt đầu</Label><Input type="date" value={form.startDate??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),startDate:e?.target?.value??''}))} /></div>
              <div><Label className="text-xs">Ngày kết thúc</Label><Input type="date" value={form.endDate??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),endDate:e?.target?.value??''}))} /></div>
            </div>
            <div className="flex justify-end gap-2 mt-4"><Button variant="outline" onClick={()=>setShowAdd(false)}>Hủy</Button><Button onClick={handleAdd}>Tạo</Button></div>
          </DialogContent>
        </Dialog>
      </div></FadeIn>
      <Card><CardContent className="p-0"><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-muted/50"><tr>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Mã lớp</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Tên lớp</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Khóa học</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Giáo viên</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Sĩ số</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Lịch học</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Trạng thái</th>
      </tr></thead><tbody>
        {loading ? <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Đang tải...</td></tr> :
        (classes??[])?.length===0 ? <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Không có dữ liệu</td></tr> :
        (classes??[])?.map?.((c:any)=>{
          const sched = c?.schedule ?? {};
          return (
            <tr key={c?.id} className="border-t border-border hover:bg-muted/30 transition-colors">
              <td className="px-4 py-3 font-mono text-xs">{c?.classCode??''}</td>
              <td className="px-4 py-3 font-medium">{c?.name??''}</td>
              <td className="px-4 py-3 text-xs">{c?.course?.name??''}</td>
              <td className="px-4 py-3 text-xs">{c?.teacher?.fullName??'Chưa phân công'}</td>
              <td className="px-4 py-3 font-mono text-xs">{c?._count?.enrollments??0}/{c?.capacity??0}</td>
              <td className="px-4 py-3 text-xs text-muted-foreground">{sched?.days?.join?.(', ')??''} {sched?.time??''}</td>
              <td className="px-4 py-3"><Badge className={`text-[10px] ${getStatusColor(c?.status??'')}`}>{getStatusLabel(c?.status??'')}</Badge></td>
            </tr>
          );
        })}
      </tbody></table></div></CardContent></Card>
    </div>
  );
}
