export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { canModifyLms } from '@/lib/lms/helpers';

// ── GET: Get quiz for a lesson ──
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const quiz = await prisma.lmsQuiz.findUnique({
      where: { lessonId: params.id },
      include: { _count: { select: { attempts: true } } },
    });
    if (!quiz) return NextResponse.json({ error: 'Chưa có quiz cho bài học này' }, { status: 404 });
    return NextResponse.json(quiz);
  } catch (error: any) {
    console.error('LMS quiz GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Create/Update quiz for lesson (upsert) ──
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLms(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const body = await request.json();
    const { title, description, questions, passingScore, maxAttempts, timeLimitMin, shuffleQuestions } = body;
    if (!title || !questions || !Array.isArray(questions)) {
      return NextResponse.json({ error: 'title và questions (array) bắt buộc' }, { status: 400 });
    }

    const quiz = await prisma.lmsQuiz.upsert({
      where: { lessonId: params.id },
      update: {
        title,
        description: description || null,
        questions,
        passingScore: passingScore ?? 70,
        maxAttempts: maxAttempts ?? 3,
        timeLimitMin: timeLimitMin || null,
        shuffleQuestions: shuffleQuestions || false,
      },
      create: {
        lessonId: params.id,
        title,
        description: description || null,
        questions,
        passingScore: passingScore ?? 70,
        maxAttempts: maxAttempts ?? 3,
        timeLimitMin: timeLimitMin || null,
        shuffleQuestions: shuffleQuestions || false,
      },
    });

    return NextResponse.json(quiz, { status: 201 });
  } catch (error: any) {
    console.error('LMS quiz POST error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
