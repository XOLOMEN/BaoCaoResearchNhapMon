export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');

    const branchFilter: any = {};
    if (session.user.role !== 'super_admin') {
      branchFilter.branchId = session.user.primaryBranchId;
    } else if (branchId) {
      branchFilter.branchId = branchId;
    }

    const [totalEmployees, activeEmployees, onLeave, departments, pendingLeaves, pendingLogs] = await Promise.all([
      prisma.hrEmployee.count({ where: branchFilter }),
      prisma.hrEmployee.count({ where: { ...branchFilter, status: 'active' } }),
      prisma.hrEmployee.count({ where: { ...branchFilter, status: 'on_leave' } }),
      prisma.hrEmployee.groupBy({ by: ['department'], where: { ...branchFilter, status: 'active' }, _count: true }),
      prisma.hrLeaveRequest.count({ where: { status: 'pending', employee: { ...branchFilter } } }),
      prisma.hrTeachingLog.count({ where: { ...branchFilter, status: 'pending_review' } }),
    ]);

    return NextResponse.json({
      totalEmployees,
      activeEmployees,
      onLeave,
      pendingLeaves,
      pendingLogs,
      departments: departments.map((d: any) => ({ department: d.department, count: d._count })),
    });
  } catch (error: any) {
    console.error('[HR/Stats GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
