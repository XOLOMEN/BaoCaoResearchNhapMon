export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Chỉ Super Admin có quyền xem bảng lương' }, { status: 403 });
    }

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const status = url.searchParams.get('status');
    const period = url.searchParams.get('period'); // YYYY-MM

    const where: any = {};
    if (branchId) where.branchId = branchId;
    if (status) where.status = status;
    if (period) {
      const [y, m] = period.split('-').map(Number);
      const pStart = new Date(y, m - 1, 1);
      const pEnd = new Date(y, m, 0); // last day of month
      where.periodStart = { gte: pStart };
      where.periodEnd = { lte: new Date(y, m, 1) };
    }

    const payrolls = await prisma.hrPayroll.findMany({
      where,
      include: {
        employee: { select: { fullName: true, employeeCode: true, position: true, department: true } },
        branch: { select: { name: true } },
        approver: { select: { fullName: true } },
      },
      orderBy: [{ periodStart: 'desc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({
      payrolls: payrolls.map((p: any) => ({
        ...p,
        periodStart: p.periodStart?.toISOString(),
        periodEnd: p.periodEnd?.toISOString(),
        paidAt: p.paidAt?.toISOString(),
        createdAt: p.createdAt?.toISOString(),
        updatedAt: p.updatedAt?.toISOString(),
      })),
    });
  } catch (error: any) {
    console.error('[HR/Payroll GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// POST: Generate monthly payroll for all active employees
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Chỉ Super Admin có quyền tạo bảng lương' }, { status: 403 });
    }

    const body = await request.json();
    const { branchId, period } = body ?? {}; // period: 'YYYY-MM'

    if (!branchId || !period) {
      return NextResponse.json({ error: 'Thiếu branchId hoặc period' }, { status: 400 });
    }

    const [year, month] = period.split('-').map(Number);
    const periodStart = new Date(year, month - 1, 1);
    const periodEnd = new Date(year, month, 0); // last day of month

    // Get all active employees in branch
    const employees = await prisma.hrEmployee.findMany({
      where: { branchId, status: 'active' },
      include: {
        contracts: { where: { status: 'active' }, take: 1, orderBy: { startDate: 'desc' } },
        teacher: { select: { hourlyRate: true } },
      },
    });

    const results = await prisma.$transaction(async (tx: any) => {
      const payrolls = [];

      for (const emp of employees) {
        const contract = emp.contracts[0];
        const baseSalary = contract?.baseSalary ?? 0;

        // Aggregate approved teaching logs for this period
        const teachingLogs = await tx.hrTeachingLog.findMany({
          where: {
            employeeId: emp.id,
            sessionDate: { gte: periodStart, lte: periodEnd },
            status: 'approved',
          },
        });
        const teachingPay = teachingLogs.reduce(
          (sum: number, log: any) => sum + (log.totalAmount ?? 0), 0
        );

        // Aggregate attendance for overtime
        const attendanceRecords = await tx.hrAttendance.findMany({
          where: {
            employeeId: emp.id,
            workDate: { gte: periodStart, lte: periodEnd },
          },
        });
        const workDays = attendanceRecords.filter((a: any) => a.status === 'present' || a.status === 'late').length;
        const overtimeHours = attendanceRecords.reduce(
          (sum: number, a: any) => sum + (a.overtimeHours ?? 0), 0
        );

        // Calculate allowances from contract
        let allowancesTotal = 0;
        if (contract?.allowances && typeof contract.allowances === 'object') {
          allowancesTotal = Object.values(contract.allowances as Record<string, number>).reduce(
            (sum: number, v: any) => sum + (Number(v) || 0), 0
          );
        }

        // Overtime pay: base salary / 26 working days / 8 hours * 1.5 * overtime hours
        const hourlyBase = baseSalary / 26 / 8;
        const overtimePay = Math.round(overtimeHours * hourlyBase * 1.5);

        const grossSalary = baseSalary + teachingPay + overtimePay + allowancesTotal;

        // Deductions (simplified Vietnamese social insurance)
        const socialIns = Math.round(grossSalary * 0.08);   // BHXH 8%
        const healthIns = Math.round(grossSalary * 0.015);  // BHYT 1.5%
        const unemploymentIns = Math.round(grossSalary * 0.01); // BHTN 1%
        const totalInsurance = socialIns + healthIns + unemploymentIns;

        const netSalary = grossSalary - totalInsurance;

        const payroll = await tx.hrPayroll.upsert({
          where: {
            employeeId_periodStart_periodEnd: {
              employeeId: emp.id,
              periodStart,
              periodEnd,
            },
          },
          create: {
            employeeId: emp.id,
            branchId,
            periodStart,
            periodEnd,
            workDays,
            actualDays: workDays,
            baseSalary,
            allowances: allowancesTotal,
            overtimePay,
            bonuses: teachingPay, // Teaching pay categorized under bonuses/variable
            grossSalary,
            taxDeduction: 0,
            insuranceDeduction: totalInsurance,
            otherDeductions: 0,
            deductionDetails: {
              socialInsurance: socialIns,
              healthInsurance: healthIns,
              unemploymentInsurance: unemploymentIns,
              teachingPay,
              overtimeHours,
            },
            netSalary,
            status: 'draft',
          },
          update: {}, // Don't overwrite existing payroll
        });

        payrolls.push({
          ...payroll,
          employeeName: emp.fullName,
          employeeCode: emp.employeeCode,
          teachingPay,
          overtimeHours,
        });
      }

      // Event store entry
      await tx.eventStore.create({
        data: {
          branchId,
          aggregateType: 'HrPayroll',
          aggregateId: `batch-${period}`,
          eventType: 'PAYROLL_BATCH_GENERATED',
          payload: {
            period,
            employeeCount: payrolls.length,
            totalGross: payrolls.reduce((s: number, p: any) => s + p.grossSalary, 0),
            totalNet: payrolls.reduce((s: number, p: any) => s + p.netSalary, 0),
          },
          sequenceNumber: 1,
        },
      });

      return payrolls;
    });

    return NextResponse.json({
      generated: results.length,
      period,
      payrolls: results,
    }, { status: 201 });
  } catch (error: any) {
    console.error('[HR/Payroll POST]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// PUT: Update payroll status (approve / pay)
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
    }

    const body = await request.json();
    const { payrollId, action } = body ?? {};

    if (!payrollId || !action) {
      return NextResponse.json({ error: 'Thiếu payrollId hoặc action' }, { status: 400 });
    }

    const payroll = await prisma.hrPayroll.findUnique({ where: { id: payrollId } });
    if (!payroll) return NextResponse.json({ error: 'Không tìm thấy bảng lương' }, { status: 404 });

    // State machine transitions
    const validTransitions: Record<string, string[]> = {
      draft: ['approved', 'cancelled'],
      approved: ['paid', 'cancelled'],
    };

    const allowed = validTransitions[payroll.status] || [];
    if (!allowed.includes(action)) {
      return NextResponse.json({
        error: `Không thể chuyển từ "${payroll.status}" sang "${action}"`,
      }, { status: 400 });
    }

    const updateData: any = { status: action };
    if (action === 'approved') {
      updateData.approvedBy = session.user.id;
    }
    if (action === 'paid') {
      updateData.paidAt = new Date();
    }

    const updated = await prisma.hrPayroll.update({
      where: { id: payrollId },
      data: updateData,
    });

    // Audit
    await prisma.eventStore.create({
      data: {
        branchId: payroll.branchId,
        aggregateType: 'HrPayroll',
        aggregateId: payrollId,
        eventType: `PAYROLL_${action.toUpperCase()}`,
        payload: { previousStatus: payroll.status, newStatus: action, userId: session.user.id },
        sequenceNumber: 1,
      },
    });

    return NextResponse.json({ payroll: updated });
  } catch (error: any) {
    console.error('[HR/Payroll PUT]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
