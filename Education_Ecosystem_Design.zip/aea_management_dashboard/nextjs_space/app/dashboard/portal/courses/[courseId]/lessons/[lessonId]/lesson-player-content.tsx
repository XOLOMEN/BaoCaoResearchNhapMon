'use client';
import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FadeIn } from '@/components/ui/animate';
import {
  ArrowLeft, ArrowRight, CheckCircle2, PlayCircle, FileText,
  Clock, BookOpen
} from 'lucide-react';

export default function LessonPlayerContent({ courseId, lessonId }: { courseId: string; lessonId: string }) {
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [marking, setMarking] = useState(false);

  useEffect(() => {
    fetch(`/api/portal/my-courses/${courseId}/lessons/${lessonId}`)
      .then(r => r.json())
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [courseId, lessonId]);

  const markComplete = useCallback(async () => {
    setMarking(true);
    try {
      await fetch(`/api/portal/my-courses/${courseId}/lessons/${lessonId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'completed', progressPct: 100 }),
      });
      // Refresh data
      const r = await fetch(`/api/portal/my-courses/${courseId}/lessons/${lessonId}`);
      setData(await r.json());
    } catch (err) {
      console.error('Mark complete error:', err);
    } finally {
      setMarking(false);
    }
  }, [courseId, lessonId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="h-96 bg-muted animate-pulse rounded-xl" />
      </div>
    );
  }

  if (!data?.lesson) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground">Không tìm thấy bài học.</p>
        <Button variant="outline" className="mt-4" onClick={() => router.push(`/dashboard/portal/courses/${courseId}`)}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Quay lại
        </Button>
      </div>
    );
  }

  const { lesson, progress, prevLesson, nextLesson } = data;
  const isCompleted = progress?.status === 'completed';
  const contents = lesson.contents ?? [];

  return (
    <FadeIn>
      <div className="space-y-6 max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push(`/dashboard/portal/courses/${courseId}`)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">{lesson.title}</h2>
              {isCompleted && <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
              <Badge variant="outline" className="text-xs">
                {lesson.type === 'video' ? 'Video' : lesson.type === 'text' ? 'Bài đọc' : lesson.type === 'quiz' ? 'Quiz' : lesson.type}
              </Badge>
              {lesson.durationMin && (
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> {lesson.durationMin} phút
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Lesson Content */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            {contents.length === 0 ? (
              <div className="text-center py-12">
                <BookOpen className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                <p className="text-muted-foreground">Chưa có nội dung cho bài học này.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {contents.map((content: any) => (
                  <div key={content.id}>
                    {content.title && (
                      <h3 className="text-lg font-semibold mb-3">{content.title}</h3>
                    )}
                    {content.type === 'video' && content.body && (
                      <div className="aspect-video bg-black rounded-lg flex items-center justify-center">
                        {content.body.includes('example.com') ? (
                          <div className="text-center text-white/60">
                            <PlayCircle className="w-16 h-16 mx-auto mb-2" />
                            <p className="text-sm">Video bài giảng sẽ được hiển thị ở đây</p>
                          </div>
                        ) : (
                          <video controls className="w-full h-full rounded-lg" src={content.body}>
                            Trình duyệt của bạn không hỗ trợ phát video.
                          </video>
                        )}
                      </div>
                    )}
                    {content.type === 'text' && content.body && (
                      <div className="prose prose-sm max-w-none dark:prose-invert">
                        <div dangerouslySetInnerHTML={{ __html: content.body
                          .replace(/## (.*)/g, '<h2>$1</h2>')
                          .replace(/### (.*)/g, '<h3>$1</h3>')
                          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                          .replace(/- (.*)/g, '<li>$1</li>')
                          .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
                          .replace(/\n/g, '<br />')
                        }} />
                      </div>
                    )}
                    {content.type === 'pdf' && content.fileUrl && (
                      <div className="border rounded-lg p-4 flex items-center gap-3">
                        <FileText className="w-8 h-8 text-red-500" />
                        <div>
                          <p className="font-medium">{content.title || 'Tài liệu PDF'}</p>
                          <a href={content.fileUrl} target="_blank" rel="noopener" className="text-sm text-primary hover:underline">Tải xuống</a>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <div>
            {prevLesson && (
              <Button
                variant="outline"
                onClick={() => router.push(`/dashboard/portal/courses/${courseId}/lessons/${prevLesson.id}`)}
              >
                <ArrowLeft className="w-4 h-4 mr-2" /> {prevLesson.title}
              </Button>
            )}
          </div>
          <div className="flex items-center gap-3">
            {!isCompleted && (
              <Button onClick={markComplete} disabled={marking}>
                <CheckCircle2 className="w-4 h-4 mr-2" />
                {marking ? 'Đang cập nhật...' : 'Đánh dấu hoàn thành'}
              </Button>
            )}
            {nextLesson && (
              <Button
                variant={isCompleted ? 'default' : 'outline'}
                onClick={() => router.push(`/dashboard/portal/courses/${courseId}/lessons/${nextLesson.id}`)}
              >
                {nextLesson.title} <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </FadeIn>
  );
}
