'use client';
import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { DollarSign, Calculator, CheckCircle, FileText, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useBranch } from '@/hooks/use-branch';
import { formatCurrency, getStatusColor, getStatusLabel } from '@/lib/helpers';
import { FadeIn } from '@/components/ui/animate';

export function PayrollContent() {
  const { branchId } = useBranch();
  const [payrolls, setPayrolls] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [showGenerate, setShowGenerate] = useState(false);
  const [genBranch, setGenBranch] = useState('');
  const [genPeriod, setGenPeriod] = useState(() => {
    const n = new Date();
    return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}`;
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (branchId) params.set('branchId', branchId);

      const [pRes, bRes] = await Promise.all([
        fetch(`/api/hr/payroll?${params}`),
        fetch('/api/branches'),
      ]);
      const [pData, bData] = await Promise.all([pRes.json(), bRes.json()]);
      setPayrolls(pData.payrolls || []);
      setBranches(bData.branches || []);
    } catch { toast.error('Lỗi tải dữ liệu'); }
    setLoading(false);
  }, [branchId]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleGenerate = async () => {
    if (!genBranch || !genPeriod) { toast.error('Vui lòng chọn chi nhánh và kỳ lương'); return; }
    setGenerating(true);
    try {
      const res = await fetch('/api/hr/payroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ branchId: genBranch, period: genPeriod }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success(`Đã tạo ${data.generated} bảng lương`);
      setShowGenerate(false);
      fetchData();
    } catch { toast.error('Lỗi hệ thống'); }
    setGenerating(false);
  };

  const handleAction = async (payrollId: string, action: string) => {
    try {
      const res = await fetch('/api/hr/payroll', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payrollId, action }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success(action === 'approved' ? 'Đã duyệt' : action === 'paid' ? 'Đã đánh dấu thanh toán' : 'Thành công');
      fetchData();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  const totalGross = payrolls.reduce((s: number, p: any) => s + (p.grossSalary || 0), 0);
  const totalNet = payrolls.reduce((s: number, p: any) => s + (p.netSalary || 0), 0);

  const statusCfg: Record<string, { color: string; label: string }> = {
    draft: { color: 'bg-slate-100 text-slate-600', label: 'Nháp' },
    approved: { color: 'bg-blue-100 text-blue-700', label: 'Đã duyệt' },
    paid: { color: 'bg-emerald-100 text-emerald-700', label: 'Đã trả' },
    cancelled: { color: 'bg-red-100 text-red-700', label: 'Đã hủy' },
  };

  return (
    <FadeIn>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Bảng Lương</h2>
            <p className="text-sm text-muted-foreground">Quản lý lương nhân viên hàng tháng</p>
          </div>
          <Button onClick={() => { setGenBranch(branchId || ''); setShowGenerate(true); }}>
            <Calculator className="w-4 h-4 mr-2" /> Tạo bảng lương
          </Button>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100"><FileText className="w-5 h-5 text-blue-600" /></div>
              <div><p className="text-sm text-muted-foreground">Số phiếu lương</p><p className="text-xl font-bold">{payrolls.length}</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100"><DollarSign className="w-5 h-5 text-emerald-600" /></div>
              <div><p className="text-sm text-muted-foreground">Tổng gross</p><p className="text-xl font-bold">{formatCurrency(totalGross)}</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-100"><CheckCircle className="w-5 h-5 text-purple-600" /></div>
              <div><p className="text-sm text-muted-foreground">Tổng net</p><p className="text-xl font-bold">{formatCurrency(totalNet)}</p></div>
            </CardContent>
          </Card>
        </div>

        {/* Payroll Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="p-3 text-left font-medium">Nhân viên</th>
                    <th className="p-3 text-left font-medium">Phòng ban</th>
                    <th className="p-3 text-left font-medium">Kỳ lương</th>
                    <th className="p-3 text-right font-medium">Lương cơ bản</th>
                    <th className="p-3 text-right font-medium">Thưởng/GD</th>
                    <th className="p-3 text-right font-medium">Khấu trừ</th>
                    <th className="p-3 text-right font-medium">Thực lĩnh</th>
                    <th className="p-3 text-left font-medium">Trạng thái</th>
                    <th className="p-3 text-left font-medium">Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">Đang tải...</td></tr>
                  ) : payrolls.length === 0 ? (
                    <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">Chưa có bảng lương</td></tr>
                  ) : payrolls.map((p: any) => {
                    const sc = statusCfg[p.status] || { color: 'bg-gray-100 text-gray-600', label: p.status };
                    const periodLabel = p.periodStart ? new Date(p.periodStart).toLocaleDateString('vi-VN', { month: '2-digit', year: 'numeric' }) : '';
                    return (
                      <tr key={p.id} className="border-b hover:bg-muted/30 transition-colors">
                        <td className="p-3">
                          <div className="font-medium">{p.employee?.fullName}</div>
                          <div className="text-xs text-muted-foreground">{p.employee?.employeeCode}</div>
                        </td>
                        <td className="p-3 text-xs">{p.employee?.department}</td>
                        <td className="p-3 text-xs">{periodLabel}</td>
                        <td className="p-3 text-right">{formatCurrency(p.baseSalary)}</td>
                        <td className="p-3 text-right text-emerald-600">{formatCurrency(p.bonuses)}</td>
                        <td className="p-3 text-right text-red-500">{formatCurrency(p.insuranceDeduction)}</td>
                        <td className="p-3 text-right font-semibold">{formatCurrency(p.netSalary)}</td>
                        <td className="p-3"><Badge className={sc.color}>{sc.label}</Badge></td>
                        <td className="p-3">
                          <div className="flex gap-1">
                            {p.status === 'draft' && (
                              <Button size="sm" variant="outline" onClick={() => handleAction(p.id, 'approved')} className="text-xs h-7">Duyệt</Button>
                            )}
                            {p.status === 'approved' && (
                              <Button size="sm" variant="outline" onClick={() => handleAction(p.id, 'paid')} className="text-xs h-7">Thanh toán</Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Generate Dialog */}
        <Dialog open={showGenerate} onOpenChange={setShowGenerate}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Tạo bảng lương tháng</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-2">
              <div>
                <Label>Chi nhánh *</Label>
                <Select value={genBranch} onValueChange={setGenBranch}>
                  <SelectTrigger><SelectValue placeholder="Chọn chi nhánh" /></SelectTrigger>
                  <SelectContent>
                    {branches.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Kỳ lương (YYYY-MM)</Label>
                <input type="month" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={genPeriod} onChange={e => setGenPeriod(e.target.value)} />
              </div>
              <p className="text-xs text-muted-foreground">
                Hệ thống sẽ tự động tính: Lương cơ bản (từ hợp đồng) + Tiền giảng dạy (đã duyệt) + Làm thêm giờ − Bảo hiểm.
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowGenerate(false)}>Hủy</Button>
              <Button onClick={handleGenerate} disabled={generating}>
                {generating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Tạo bảng lương
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </FadeIn>
  );
}
