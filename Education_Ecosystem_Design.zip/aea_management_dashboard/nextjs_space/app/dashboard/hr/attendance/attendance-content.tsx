'use client';
import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { CalendarCheck, Plus, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { useBranch } from '@/hooks/use-branch';
import { formatDate } from '@/lib/helpers';
import { FadeIn } from '@/components/ui/animate';

export function AttendanceContent() {
  const { branchId } = useBranch();
  const [records, setRecords] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [month, setMonth] = useState(() => {
    const n = new Date();
    return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}`;
  });
  const [form, setForm] = useState({
    employeeId: '', branchId: '', workDate: '', checkIn: '', checkOut: '', status: 'present', notes: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (branchId) params.set('branchId', branchId);
      if (month) params.set('month', month);

      const [aRes, eRes] = await Promise.all([
        fetch(`/api/hr/attendance?${params}`),
        fetch(`/api/hr/employees?${branchId ? `branchId=${branchId}` : ''}`),
      ]);
      const [aData, eData] = await Promise.all([aRes.json(), eRes.json()]);
      setRecords(aData.attendance || []);
      setEmployees(eData.employees || []);
    } catch { toast.error('Lỗi tải dữ liệu'); }
    setLoading(false);
  }, [branchId, month]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleAdd = async () => {
    if (!form.employeeId || !form.workDate) { toast.error('Vui lòng chọn nhân viên và ngày'); return; }
    const emp = employees.find((e: any) => e.id === form.employeeId);
    try {
      const res = await fetch('/api/hr/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, branchId: emp?.branchId || branchId }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success('Chấm công thành công');
      setShowAdd(false);
      fetchData();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  const statusMap: Record<string, { color: string; label: string }> = {
    present: { color: 'bg-emerald-100 text-emerald-700', label: 'Có mặt' },
    absent: { color: 'bg-red-100 text-red-700', label: 'Vắng' },
    late: { color: 'bg-amber-100 text-amber-700', label: 'Muộn' },
    half_day: { color: 'bg-blue-100 text-blue-700', label: 'Nửa ngày' },
    on_leave: { color: 'bg-purple-100 text-purple-700', label: 'Nghỉ phép' },
  };

  const presentCount = records.filter(r => r.status === 'present' || r.status === 'late').length;
  const absentCount = records.filter(r => r.status === 'absent').length;

  return (
    <FadeIn>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Chấm Công Nhân Viên</h2>
            <p className="text-sm text-muted-foreground">Theo dõi giờ làm việc hàng ngày</p>
          </div>
          <div className="flex gap-3">
            <input type="month" className="flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm" value={month} onChange={e => setMonth(e.target.value)} />
            <Button onClick={() => { setForm(f => ({ ...f, branchId: branchId || '' })); setShowAdd(true); }}>
              <Plus className="w-4 h-4 mr-2" /> Chấm công
            </Button>
          </div>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100"><CalendarCheck className="w-5 h-5 text-blue-600" /></div>
              <div><p className="text-sm text-muted-foreground">Tổng bản ghi</p><p className="text-xl font-bold">{records.length}</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100"><Clock className="w-5 h-5 text-emerald-600" /></div>
              <div><p className="text-sm text-muted-foreground">Có mặt</p><p className="text-xl font-bold">{presentCount}</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-100"><Clock className="w-5 h-5 text-red-600" /></div>
              <div><p className="text-sm text-muted-foreground">Vắng mặt</p><p className="text-xl font-bold">{absentCount}</p></div>
            </CardContent>
          </Card>
        </div>

        {/* Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="p-3 text-left font-medium">Nhân viên</th>
                    <th className="p-3 text-left font-medium">Ngày</th>
                    <th className="p-3 text-left font-medium">Check-in</th>
                    <th className="p-3 text-left font-medium">Check-out</th>
                    <th className="p-3 text-left font-medium">Giờ làm</th>
                    <th className="p-3 text-left font-medium">OT (giờ)</th>
                    <th className="p-3 text-left font-medium">Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Đang tải...</td></tr>
                  ) : records.length === 0 ? (
                    <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Chưa có dữ liệu</td></tr>
                  ) : records.map((r: any) => {
                    const sm = statusMap[r.status] || { color: 'bg-gray-100 text-gray-600', label: r.status };
                    const timeStr = (iso: string | null) => {
                      if (!iso) return '—';
                      const d = new Date(iso);
                      return d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
                    };
                    return (
                      <tr key={r.id} className="border-b hover:bg-muted/30 transition-colors">
                        <td className="p-3">
                          <div className="font-medium">{r.employee?.fullName}</div>
                          <div className="text-xs text-muted-foreground">{r.employee?.employeeCode}</div>
                        </td>
                        <td className="p-3">{formatDate(r.workDate)}</td>
                        <td className="p-3 font-mono text-xs">{timeStr(r.checkIn)}</td>
                        <td className="p-3 font-mono text-xs">{timeStr(r.checkOut)}</td>
                        <td className="p-3">{r.workHours ? `${r.workHours}h` : '—'}</td>
                        <td className="p-3">{r.overtimeHours > 0 ? `${r.overtimeHours}h` : '—'}</td>
                        <td className="p-3"><Badge className={sm.color}>{sm.label}</Badge></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Add Dialog */}
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Chấm công nhân viên</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-2">
              <div>
                <Label>Nhân viên *</Label>
                <Select value={form.employeeId} onValueChange={v => setForm(f => ({ ...f, employeeId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent>
                    {employees.map((e: any) => <SelectItem key={e.id} value={e.id}>{e.fullName} ({e.employeeCode})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Ngày làm việc *</Label>
                <Input type="date" value={form.workDate} onChange={e => setForm(f => ({ ...f, workDate: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Check-in</Label>
                  <Input type="time" value={form.checkIn} onChange={e => setForm(f => ({ ...f, checkIn: e.target.value }))} />
                </div>
                <div>
                  <Label>Check-out</Label>
                  <Input type="time" value={form.checkOut} onChange={e => setForm(f => ({ ...f, checkOut: e.target.value }))} />
                </div>
              </div>
              <div>
                <Label>Trạng thái</Label>
                <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="present">Có mặt</SelectItem>
                    <SelectItem value="absent">Vắng</SelectItem>
                    <SelectItem value="late">Muộn</SelectItem>
                    <SelectItem value="half_day">Nửa ngày</SelectItem>
                    <SelectItem value="on_leave">Nghỉ phép</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Ghi chú</Label>
                <Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAdd(false)}>Hủy</Button>
              <Button onClick={handleAdd}>Lưu</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </FadeIn>
  );
}
