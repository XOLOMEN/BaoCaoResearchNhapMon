'use client';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

const formatVND = (v: number) => {
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(0)}tr`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(0)}k`;
  return String(v);
};

export default function RevenueChart({ data }: { data: any[] }) {
  const chartData = (data ?? []).map((d: any) => ({
    month: d?.month ?? '',
    'Doanh thu': d?.revenue ?? 0,
    'Đã thu': d?.collected ?? 0,
  }));

  if (chartData.length === 0) {
    return <div className="h-full flex items-center justify-center text-sm text-muted-foreground">Chưa có dữ liệu</div>;
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 20 }}>
        <XAxis dataKey="month" tickLine={false} tick={{ fontSize: 10 }} interval="preserveStartEnd" />
        <YAxis tickLine={false} tick={{ fontSize: 10 }} tickFormatter={formatVND} />
        <Tooltip
          contentStyle={{ fontSize: 11 }}
          formatter={(value: any) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value)}
        />
        <Area type="monotone" dataKey="Doanh thu" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.15} strokeWidth={2} />
        <Area type="monotone" dataKey="Đã thu" stroke="#10b981" fill="#10b981" fillOpacity={0.15} strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}
