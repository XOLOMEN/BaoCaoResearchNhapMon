export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { buildBranchWhere } from '@/lib/lms/helpers';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const bw = buildBranchWhere(session, branchId);

    const [totalCourses, publishedCourses, totalEnrollments, activeEnrollments, completedEnrollments, totalCertificates] = await Promise.all([
      prisma.lmsCourse.count({ where: bw }),
      prisma.lmsCourse.count({ where: { ...bw, isPublished: true } }),
      prisma.lmsEnrollment.count({ where: bw }),
      prisma.lmsEnrollment.count({ where: { ...bw, status: 'active' } }),
      prisma.lmsEnrollment.count({ where: { ...bw, status: 'completed' } }),
      prisma.lmsCertificate.count({ where: bw }),
    ]);

    // Recent enrollments
    const recentEnrollments = await prisma.lmsEnrollment.findMany({
      where: bw,
      include: {
        lmsCourse: { select: { title: true } },
        student: { select: { fullName: true } },
      },
      orderBy: { enrolledAt: 'desc' },
      take: 10,
    });

    // Course enrollment distribution
    const courseStats = await prisma.lmsCourse.findMany({
      where: bw,
      select: {
        id: true,
        title: true,
        isPublished: true,
        _count: { select: { enrollments: true, lessons: true, certificates: true } },
      },
      orderBy: { sortOrder: 'asc' },
      take: 20,
    });

    return NextResponse.json({
      totalCourses,
      publishedCourses,
      totalEnrollments,
      activeEnrollments,
      completedEnrollments,
      completionRate: totalEnrollments > 0 ? Math.round((completedEnrollments / totalEnrollments) * 100) : 0,
      totalCertificates,
      recentEnrollments,
      courseStats,
    });
  } catch (error: any) {
    console.error('LMS stats error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
