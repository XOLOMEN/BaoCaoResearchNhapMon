import { ClassesContent } from './classes-content';
export default function ClassesPage() { return <ClassesContent />; }
