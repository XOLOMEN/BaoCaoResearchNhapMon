export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const branchFilter = branchId ? { branchId } : {};

    const [totalStudents, activeStudents, totalTeachers, totalClasses, activeClasses, totalEnrollments, totalCourses] = await Promise.all([
      prisma.student.count({ where: branchFilter }),
      prisma.student.count({ where: { ...branchFilter, status: 'active' } }),
      prisma.teacher.count({ where: { ...branchFilter, status: 'active' } }),
      prisma.class.count({ where: branchFilter }),
      prisma.class.count({ where: { ...branchFilter, status: 'in_progress' } }),
      prisma.enrollment.count({ where: { ...branchFilter, status: 'active' } }),
      prisma.course.count({ where: { ...branchFilter, isActive: true } }),
    ]);

    // Recent enrollments
    const recentEnrollments = await prisma.enrollment.findMany({
      where: branchFilter,
      include: {
        student: { select: { fullName: true, studentCode: true } },
        class: { select: { name: true, classCode: true } },
      },
      orderBy: { enrolledAt: 'desc' },
      take: 5,
    });

    // Class utilization
    const classesWithEnrollments = await prisma.class.findMany({
      where: { ...branchFilter, status: 'in_progress' },
      select: {
        id: true, name: true, classCode: true, capacity: true,
        _count: { select: { enrollments: true } },
      },
    });

    const classUtilization = classesWithEnrollments?.map?.((c: any) => ({
      name: c?.name ?? '',
      code: c?.classCode ?? '',
      capacity: c?.capacity ?? 0,
      enrolled: c?._count?.enrollments ?? 0,
      rate: c?.capacity ? Math.round(((c?._count?.enrollments ?? 0) / c.capacity) * 100) : 0,
    })) ?? [];

    // Enrollment by month (last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    const enrollmentsByMonth = await prisma.enrollment.groupBy({
      by: ['enrolledAt'],
      where: { ...branchFilter, enrolledAt: { gte: sixMonthsAgo } },
      _count: true,
    });

    // Aggregate by month
    const monthMap: Record<string, number> = {};
    for (const e of enrollmentsByMonth ?? []) {
      const d = new Date(e?.enrolledAt ?? 0);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthMap[key] = (monthMap[key] ?? 0) + (e?._count ?? 0);
    }
    const enrollmentTrend = Object.entries(monthMap ?? {}).sort(([a]: any, [b]: any) => (a ?? '').localeCompare(b ?? '')).map(([month, count]: any) => ({
      month: month ?? '',
      count: count ?? 0,
    }));

    // Branch stats
    const branches = await prisma.branch.findMany({
      where: { isActive: true },
      select: {
        id: true, name: true, code: true,
        _count: { select: { students: true, classes: true, teachers: true } },
      },
    });

    const branchStats = branches?.map?.((b: any) => ({
      name: b?.name ?? '',
      code: b?.code ?? '',
      students: b?._count?.students ?? 0,
      classes: b?._count?.classes ?? 0,
      teachers: b?._count?.teachers ?? 0,
    })) ?? [];

    return NextResponse.json({
      totalStudents,
      activeStudents,
      totalTeachers,
      totalClasses,
      activeClasses,
      totalEnrollments,
      totalCourses,
      recentEnrollments: recentEnrollments?.map?.((e: any) => ({
        id: e?.id,
        studentName: e?.student?.fullName ?? '',
        studentCode: e?.student?.studentCode ?? '',
        className: e?.class?.name ?? '',
        classCode: e?.class?.classCode ?? '',
        enrolledAt: e?.enrolledAt,
        status: e?.status ?? '',
      })) ?? [],
      classUtilization,
      enrollmentTrend,
      branchStats,
    });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
