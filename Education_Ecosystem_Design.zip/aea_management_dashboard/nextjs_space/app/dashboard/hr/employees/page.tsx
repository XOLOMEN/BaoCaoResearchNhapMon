export default function HrEmployeesPage() {
  return <EmployeesContent />;
}
import { EmployeesContent } from './employees-content';
