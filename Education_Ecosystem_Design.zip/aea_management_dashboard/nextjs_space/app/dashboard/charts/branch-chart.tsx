'use client';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';

export default function BranchChart({ data }: { data: any[] }) {
  const chartData = (data ?? [])?.map?.((d: any) => ({
    name: d?.code ?? d?.name ?? '',
    'Học viên': d?.students ?? 0,
    'Lớp học': d?.classes ?? 0,
    'Giáo viên': d?.teachers ?? 0,
  })) ?? [];

  if (chartData.length === 0) {
    return <div className="h-full flex items-center justify-center text-sm text-muted-foreground">Chưa có dữ liệu</div>;
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 20 }}>
        <XAxis dataKey="name" tickLine={false} tick={{ fontSize: 10 }} />
        <YAxis tickLine={false} tick={{ fontSize: 10 }} allowDecimals={false} />
        <Tooltip contentStyle={{ fontSize: 11 }} />
        <Legend verticalAlign="top" wrapperStyle={{ fontSize: 11 }} />
        <Bar dataKey="Học viên" fill="#60B5FF" radius={[3, 3, 0, 0]} />
        <Bar dataKey="Lớp học" fill="#FF9149" radius={[3, 3, 0, 0]} />
        <Bar dataKey="Giáo viên" fill="#80D8C3" radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
