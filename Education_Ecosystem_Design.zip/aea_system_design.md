# AEA – Education Management Ecosystem
## Technical Design Document v1.0

> **Project:** Academic Education Administration (AEA)
> **Domain:** Language Center / Education Institution Management
> **Architecture:** Multi-app, Modular Monolith → Microservice-ready
> **Database:** PostgreSQL 15+ with full multi-branch tenancy
> **UI Language:** Vietnamese | **Code Language:** English
> **Date:** June 2026

---

## Table of Contents

1. [System Architecture Overview](#1-system-architecture-overview)
2. [Entity Relationship Diagram (ERD)](#2-entity-relationship-diagram-erd)
3. [Detailed Database Schema](#3-detailed-database-schema)
4. [User Role Hierarchy & Access Control](#4-user-role-hierarchy--access-control)
5. [AI-Ready Data Architecture](#5-ai-ready-data-architecture)
6. [Phased Development Roadmap](#6-phased-development-roadmap)
7. [API Integration Strategy & Security](#7-api-integration-strategy--security)
8. [Synchronization Architecture](#8-synchronization-architecture)

---

## 1. System Architecture Overview

### 1.1 Design Philosophy

The AEA platform follows a **Modular Monolith** architecture — a single deployable unit composed of strictly bounded modules that communicate through well-defined internal interfaces. This approach delivers the development speed of a monolith with the logical separation of microservices, and provides a clean migration path to true microservices when scale demands it.

**Core Principles:**

| Principle | Implementation |
|---|---|
| **Multi-branch from Day One** | Every entity carries a `branch_id` foreign key; all queries are branch-scoped by default via Row-Level Security (RLS) |
| **Module Independence** | Each module owns its schema namespace; cross-module access happens only through service interfaces, never direct table joins |
| **AI-Ready Data** | All tables include `created_at`, `updated_at`, `metadata JSONB` columns; event sourcing on key state transitions |
| **Offline-First Design** | Client apps cache critical data locally; sync engine reconciles on reconnect |
| **Vietnamese UI / English Code** | All database columns, API fields, and code identifiers in English; all UI labels, messages, and reports in Vietnamese via i18n |

### 1.2 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         CLIENT APPLICATIONS                             │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │  Management   │  │   Student    │  │   Parent     │  │  Teacher   │  │
│  │  Dashboard    │  │   Portal     │  │   Portal     │  │  Portal    │  │
│  │  (React/Next) │  │  (React/Next)│  │ (React/Next) │  │(React/Next)│  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └─────┬──────┘  │
│         │                 │                 │                 │          │
└─────────┼─────────────────┼─────────────────┼─────────────────┼──────────┘
          │                 │                 │                 │
          ▼                 ▼                 ▼                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        API GATEWAY / BFF LAYER                          │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │  Authentication │ Rate Limiting │ Request Routing │ Response Cache │ │
│  └────────────────────────────────────────────────────────────────────┘ │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     CORE APPLICATION SERVER (Node.js / NestJS)          │
│                                                                         │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐      │
│  │  ACADEMIC    │ │  FINANCE    │ │  HR          │ │  CRM        │      │
│  │  MODULE      │ │  MODULE     │ │  MODULE      │ │  MODULE     │      │
│  │             │ │             │ │             │ │             │      │
│  │ • Students  │ │ • Invoices  │ │ • Employees │ │ • Leads     │      │
│  │ • Classes   │ │ • Payments  │ │ • Payroll   │ │ • Campaigns │      │
│  │ • Courses   │ │ • Receipts  │ │ • Attendance│ │ • Follow-ups│      │
│  │ • Enroll    │ │ • Discounts │ │ • Leave     │ │ • Conversions│     │
│  │ • Schedule  │ │ • Reports   │ │ • Contracts │ │ • Pipeline  │      │
│  │ • Grades    │ │ • Budgets   │ │ • Benefits  │ │ • Analytics │      │
│  └──────┬──────┘ └──────┬──────┘ └──────┬──────┘ └──────┬──────┘      │
│         │               │               │               │              │
│  ┌──────┴───────────────┴───────────────┴───────────────┴──────┐       │
│  │                    SHARED SERVICES LAYER                     │       │
│  │                                                              │       │
│  │  Auth/RBAC │ Notification │ File Storage │ Audit Log │ i18n │       │
│  │  Branch Ctx│ Event Bus    │ Report Engine│ Search    │ Cache│       │
│  └──────────────────────────┬───────────────────────────────────┘       │
└─────────────────────────────┼───────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         DATA LAYER                                      │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │  PostgreSQL   │  │    Redis     │  │  S3/MinIO    │  │ Event Store│  │
│  │  (Primary DB) │  │  (Cache +    │  │  (Files +    │  │ (Audit +   │  │
│  │              │  │   Sessions)  │  │   Media)     │  │  AI Data)  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  └────────────┘  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 1.3 Module Dependency Map

```
                    ┌─────────────┐
                    │   SHARED    │
                    │  SERVICES   │
                    │  (Auth,     │
                    │  Branch,    │
                    │  Notif)     │
                    └──────┬──────┘
                           │
            ┌──────────────┼──────────────┐
            │              │              │
            ▼              ▼              ▼
     ┌─────────────┐ ┌──────────┐ ┌─────────────┐
     │  ACADEMIC   │ │    HR    │ │    CRM      │
     │  (Core)     │ │          │ │             │
     └──────┬──────┘ └────┬─────┘ └──────┬──────┘
            │              │              │
            │         ┌────┘              │
            ▼         ▼                   │
     ┌─────────────────────┐              │
     │      FINANCE        │◄─────────────┘
     │  (depends on        │
     │   Academic + HR)    │
     └─────────────────────┘

Dependency Rules:
  • Academic → Shared (auth, branch context)
  • Finance  → Shared + Academic (student invoices) + HR (payroll)
  • HR       → Shared (employee = user)
  • CRM      → Shared + Finance (conversion → invoice)
```

### 1.4 Technology Stack

| Layer | Technology | Rationale |
|---|---|---|
| **Frontend** | Next.js 14+ (App Router), TypeScript, Tailwind CSS, shadcn/ui | SSR/SSG, excellent DX, Vietnamese locale support |
| **Backend** | NestJS (Node.js), TypeScript | Modular architecture, decorators for RBAC, excellent ORM integration |
| **ORM** | Prisma with raw SQL fallback | Type-safe queries, migration management, multi-schema support |
| **Database** | PostgreSQL 15+ | JSONB, RLS, partitioning, full-text search for Vietnamese |
| **Cache** | Redis 7+ | Session store, query cache, real-time pub/sub |
| **File Storage** | S3-compatible (MinIO for self-hosted) | Documents, avatars, certificates |
| **Search** | PostgreSQL FTS + pg_trgm | Vietnamese text search without external dependencies |
| **Queue** | BullMQ (Redis-backed) | Background jobs: reports, notifications, sync |
| **Real-time** | Socket.IO / Server-Sent Events | Live updates for dashboards, notifications |
| **Auth** | JWT (access) + Refresh Token rotation | Stateless auth with secure refresh flow |

---

## 2. Entity Relationship Diagram (ERD)

### 2.1 Complete ERD – All Modules

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              ORGANIZATION LAYER                                  │
│                                                                                  │
│  ┌──────────────────┐         ┌──────────────────┐                              │
│  │   organizations  │────1:N──│    branches       │                              │
│  │──────────────────│         │──────────────────│                              │
│  │ id (PK)          │         │ id (PK)          │                              │
│  │ name             │         │ org_id (FK)      │                              │
│  │ slug             │         │ name             │                              │
│  │ settings (JSONB) │         │ code             │                              │
│  │ created_at       │         │ address          │                              │
│  │ updated_at       │         │ phone            │                              │
│  └──────────────────┘         │ is_active        │                              │
│                               │ settings (JSONB) │                              │
│                               └────────┬─────────┘                              │
│                                        │                                         │
│                    ┌───────────────┬────┴────┬────────────────┐                  │
│                    │               │         │                │                  │
└────────────────────┼───────────────┼─────────┼────────────────┼──────────────────┘
                     │               │         │                │
                     ▼               ▼         ▼                ▼
┌────────────────────────────────────────────────────────────────────────────────────┐
│                               PEOPLE LAYER                                         │
│                                                                                    │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐             │
│  │     users         │    │    students       │    │    parents        │             │
│  │──────────────────│    │──────────────────│    │──────────────────│             │
│  │ id (PK)          │    │ id (PK)          │    │ id (PK)          │             │
│  │ email            │    │ user_id (FK)     │    │ user_id (FK)     │             │
│  │ phone            │    │ branch_id (FK)   │    │ branch_id (FK)   │             │
│  │ password_hash    │    │ student_code     │    │ phone            │             │
│  │ full_name        │    │ date_of_birth    │    │ full_name        │             │
│  │ role             │    │ gender           │    │ email            │             │
│  │ avatar_url       │    │ enrollment_date  │    │ address          │             │
│  │ is_active        │    │ status           │    │ occupation       │             │
│  │ metadata (JSONB) │    │ level            │    │ metadata (JSONB) │             │
│  └────────┬─────────┘    │ notes            │    └────────┬─────────┘             │
│           │              │ metadata (JSONB) │             │                        │
│           │              └────────┬─────────┘             │                        │
│           │                       │                       │                        │
│           │              ┌────────┴─────────┐             │                        │
│           │              │ student_parents   │◄────────────┘                        │
│           │              │──────────────────│  (M:N junction)                      │
│           │              │ student_id (FK)  │                                      │
│           │              │ parent_id (FK)   │                                      │
│           │              │ relationship     │                                      │
│           │              │ is_primary       │                                      │
│           │              └──────────────────┘                                      │
│           │                                                                        │
│  ┌────────┴─────────┐    ┌──────────────────┐                                     │
│  │    teachers       │    │      staff        │                                     │
│  │──────────────────│    │──────────────────│                                     │
│  │ id (PK)          │    │ id (PK)          │                                     │
│  │ user_id (FK)     │    │ user_id (FK)     │                                     │
│  │ branch_id (FK)   │    │ branch_id (FK)   │                                     │
│  │ employee_code    │    │ employee_code    │                                     │
│  │ specializations  │    │ department       │                                     │
│  │  (JSONB)         │    │ position         │                                     │
│  │ hire_date        │    │ hire_date        │                                     │
│  │ status           │    │ status           │                                     │
│  │ hourly_rate      │    │ salary           │                                     │
│  │ metadata (JSONB) │    │ metadata (JSONB) │                                     │
│  └────────┬─────────┘    └──────────────────┘                                     │
│           │                                                                        │
└───────────┼────────────────────────────────────────────────────────────────────────┘
            │
            ▼
┌────────────────────────────────────────────────────────────────────────────────────┐
│                             ACADEMIC LAYER                                         │
│                                                                                    │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐             │
│  │    courses        │    │     classes       │    │   enrollments    │             │
│  │──────────────────│    │──────────────────│    │──────────────────│             │
│  │ id (PK)          │    │ id (PK)          │    │ id (PK)          │             │
│  │ branch_id (FK)   │    │ course_id (FK)   │    │ student_id (FK)  │             │
│  │ name             │    │ branch_id (FK)   │    │ class_id (FK)    │             │
│  │ code             │    │ teacher_id (FK)  │    │ branch_id (FK)   │             │
│  │ description      │    │ name             │    │ enrolled_at      │             │
│  │ level            │    │ class_code       │    │ status           │             │
│  │ duration_hours   │    │ room             │    │ completion_date  │             │
│  │ max_students     │    │ schedule (JSONB) │    │ final_grade      │             │
│  │ tuition_fee      │    │ start_date       │    │ certificate_url  │             │
│  │ materials_fee    │    │ end_date         │    │ notes            │             │
│  │ is_active        │    │ capacity         │    │ metadata (JSONB) │             │
│  │ metadata (JSONB) │    │ status           │    └──────────────────┘             │
│  └──────────────────┘    │ metadata (JSONB) │                                     │
│                          └──────────────────┘                                     │
│                                                                                    │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐             │
│  │  class_sessions   │    │   attendance      │    │   grade_records   │             │
│  │──────────────────│    │──────────────────│    │──────────────────│             │
│  │ id (PK)          │    │ id (PK)          │    │ id (PK)          │             │
│  │ class_id (FK)    │    │ session_id (FK)  │    │ enrollment_id(FK)│             │
│  │ session_number   │    │ student_id (FK)  │    │ assessment_type  │             │
│  │ session_date     │    │ status           │    │ score            │             │
│  │ start_time       │    │ check_in_time    │    │ max_score        │             │
│  │ end_time         │    │ notes            │    │ graded_by (FK)   │             │
│  │ topic            │    │ metadata (JSONB) │    │ graded_at        │             │
│  │ teacher_id (FK)  │    └──────────────────┘    │ comments         │             │
│  │ status           │                            │ metadata (JSONB) │             │
│  │ notes            │                            └──────────────────┘             │
│  │ metadata (JSONB) │                                                             │
│  └──────────────────┘                                                             │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────────────────┐
│                             FINANCE LAYER                                          │
│                                                                                    │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐             │
│  │    invoices       │    │    payments       │    │   discounts      │             │
│  │──────────────────│    │──────────────────│    │──────────────────│             │
│  │ id (PK)          │    │ id (PK)          │    │ id (PK)          │             │
│  │ branch_id (FK)   │    │ invoice_id (FK)  │    │ branch_id (FK)   │             │
│  │ invoice_number   │    │ branch_id (FK)   │    │ name             │             │
│  │ student_id (FK)  │    │ amount           │    │ type             │             │
│  │ enrollment_id(FK)│    │ payment_method   │    │ value            │             │
│  │ type             │    │ payment_date     │    │ min_amount        │             │
│  │ subtotal         │    │ transaction_ref  │    │ valid_from       │             │
│  │ discount_id (FK) │    │ status           │    │ valid_until      │             │
│  │ discount_amount  │    │ received_by (FK) │    │ usage_limit      │             │
│  │ tax_amount       │    │ notes            │    │ usage_count      │             │
│  │ total_amount     │    │ metadata (JSONB) │    │ conditions(JSONB)│             │
│  │ due_date         │    └──────────────────┘    │ is_active        │             │
│  │ status           │                            │ metadata (JSONB) │             │
│  │ issued_by (FK)   │    ┌──────────────────┐    └──────────────────┘             │
│  │ notes            │    │  payment_plans    │                                     │
│  │ metadata (JSONB) │    │──────────────────│    ┌──────────────────┐             │
│  └──────────────────┘    │ id (PK)          │    │   expenses       │             │
│                          │ invoice_id (FK)  │    │──────────────────│             │
│  ┌──────────────────┐    │ installment_no   │    │ id (PK)          │             │
│  │  invoice_items    │    │ amount           │    │ branch_id (FK)   │             │
│  │──────────────────│    │ due_date         │    │ category         │             │
│  │ id (PK)          │    │ status           │    │ amount           │             │
│  │ invoice_id (FK)  │    │ paid_at          │    │ description      │             │
│  │ description      │    │ metadata (JSONB) │    │ expense_date     │             │
│  │ quantity         │    └──────────────────┘    │ approved_by (FK) │             │
│  │ unit_price       │                            │ receipt_url      │             │
│  │ amount           │                            │ status           │             │
│  │ metadata (JSONB) │                            │ metadata (JSONB) │             │
│  └──────────────────┘                            └──────────────────┘             │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────────────────┐
│                               HR LAYER                                             │
│                                                                                    │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐             │
│  │  hr_employees     │    │  hr_contracts     │    │  hr_attendance    │             │
│  │──────────────────│    │──────────────────│    │──────────────────│             │
│  │ id (PK)          │    │ id (PK)          │    │ id (PK)          │             │
│  │ user_id (FK)     │    │ employee_id (FK) │    │ employee_id (FK) │             │
│  │ branch_id (FK)   │    │ contract_type    │    │ branch_id (FK)   │             │
│  │ employee_code    │    │ start_date       │    │ check_in         │             │
│  │ department       │    │ end_date         │    │ check_out        │             │
│  │ position         │    │ base_salary      │    │ work_hours       │             │
│  │ employment_type  │    │ allowances(JSONB)│    │ overtime_hours   │             │
│  │ hire_date        │    │ benefits (JSONB) │    │ status           │             │
│  │ tax_code         │    │ signed_doc_url   │    │ notes            │             │
│  │ bank_account     │    │ status           │    │ metadata (JSONB) │             │
│  │ bank_name        │    │ metadata (JSONB) │    └──────────────────┘             │
│  │ insurance_number │    └──────────────────┘                                     │
│  │ emergency_contact│                            ┌──────────────────┐             │
│  │  (JSONB)         │    ┌──────────────────┐    │  hr_payroll       │             │
│  │ status           │    │  hr_leave         │    │──────────────────│             │
│  │ metadata (JSONB) │    │──────────────────│    │ id (PK)          │             │
│  └──────────────────┘    │ id (PK)          │    │ employee_id (FK) │             │
│                          │ employee_id (FK) │    │ branch_id (FK)   │             │
│                          │ leave_type       │    │ period_start     │             │
│                          │ start_date       │    │ period_end       │             │
│                          │ end_date         │    │ base_salary      │             │
│                          │ days_count       │    │ allowances       │             │
│                          │ reason           │    │ overtime_pay     │             │
│                          │ approved_by (FK) │    │ deductions       │             │
│                          │ status           │    │ tax              │             │
│                          │ metadata (JSONB) │    │ insurance        │             │
│                          └──────────────────┘    │ net_salary       │             │
│                                                  │ status           │             │
│                                                  │ paid_at          │             │
│                                                  │ metadata (JSONB) │             │
│                                                  └──────────────────┘             │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────────────────┐
│                               CRM LAYER                                            │
│                                                                                    │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐             │
│  │   crm_leads       │    │ crm_interactions  │    │  crm_campaigns   │             │
│  │──────────────────│    │──────────────────│    │──────────────────│             │
│  │ id (PK)          │    │ id (PK)          │    │ id (PK)          │             │
│  │ branch_id (FK)   │    │ lead_id (FK)     │    │ branch_id (FK)   │             │
│  │ full_name        │    │ type             │    │ name             │             │
│  │ email            │    │ channel          │    │ type             │             │
│  │ phone            │    │ content          │    │ start_date       │             │
│  │ source           │    │ contacted_by(FK) │    │ end_date         │             │
│  │ campaign_id (FK) │    │ outcome          │    │ budget           │             │
│  │ interest_course  │    │ next_follow_up   │    │ target_audience  │             │
│  │  (FK → courses)  │    │ metadata (JSONB) │    │  (JSONB)         │             │
│  │ assigned_to (FK) │    │ created_at       │    │ channels (JSONB) │             │
│  │ status           │    └──────────────────┘    │ status           │             │
│  │ score            │                            │ results (JSONB)  │             │
│  │ converted_student│    ┌──────────────────┐    │ metadata (JSONB) │             │
│  │  _id (FK)        │    │  crm_tasks       │    └──────────────────┘             │
│  │ notes            │    │──────────────────│                                     │
│  │ metadata (JSONB) │    │ id (PK)          │                                     │
│  │ created_at       │    │ lead_id (FK)     │                                     │
│  │ updated_at       │    │ assigned_to (FK) │                                     │
│  └──────────────────┘    │ title            │                                     │
│                          │ description      │                                     │
│                          │ due_date         │                                     │
│                          │ priority         │                                     │
│                          │ status           │                                     │
│                          │ completed_at     │                                     │
│                          │ metadata (JSONB) │                                     │
│                          └──────────────────┘                                     │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────────────────┐
│                           SYSTEM / SHARED LAYER                                    │
│                                                                                    │
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐             │
│  │  audit_logs       │    │  notifications    │    │  system_settings  │             │
│  │──────────────────│    │──────────────────│    │──────────────────│             │
│  │ id (PK)          │    │ id (PK)          │    │ id (PK)          │             │
│  │ branch_id (FK)   │    │ user_id (FK)     │    │ branch_id (FK)   │             │
│  │ user_id (FK)     │    │ branch_id (FK)   │    │ key              │             │
│  │ entity_type      │    │ type             │    │ value (JSONB)    │             │
│  │ entity_id        │    │ title            │    │ updated_by (FK)  │             │
│  │ action           │    │ body             │    │ updated_at       │             │
│  │ old_values(JSONB)│    │ data (JSONB)     │    └──────────────────┘             │
│  │ new_values(JSONB)│    │ read_at          │                                     │
│  │ ip_address       │    │ created_at       │    ┌──────────────────┐             │
│  │ user_agent       │    └──────────────────┘    │  file_attachments │             │
│  │ created_at       │                            │──────────────────│             │
│  └──────────────────┘    ┌──────────────────┐    │ id (PK)          │             │
│                          │  event_store      │    │ entity_type      │             │
│                          │──────────────────│    │ entity_id        │             │
│                          │ id (PK)          │    │ file_name        │             │
│                          │ branch_id (FK)   │    │ file_url         │             │
│                          │ aggregate_type   │    │ file_size        │             │
│                          │ aggregate_id     │    │ mime_type        │             │
│                          │ event_type       │    │ uploaded_by (FK) │             │
│                          │ payload (JSONB)  │    │ created_at       │             │
│                          │ metadata (JSONB) │    └──────────────────┘             │
│                          │ created_at       │                                     │
│                          │ sequence_number  │                                     │
│                          └──────────────────┘                                     │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Key Relationship Summary

| Relationship | Type | Description |
|---|---|---|
| Organization → Branch | 1:N | One org owns many branches |
| Branch → Student | 1:N | Students belong to a primary branch |
| Student ↔ Parent | M:N | Via `student_parents` junction table with `relationship` type |
| User → Student/Teacher/Staff | 1:1 | User is the auth identity; role profile is the domain entity |
| Branch → Course | 1:N | Courses are branch-scoped (can be shared via templates) |
| Course → Class | 1:N | A course can run multiple classes (semesters/cohorts) |
| Class → Teacher | N:1 | Each class has a primary teacher (substitutes via sessions) |
| Student + Class → Enrollment | M:N | Junction with status, grade, certificate tracking |
| Class → ClassSession | 1:N | Individual scheduled sessions within a class |
| Session + Student → Attendance | M:N | Per-session attendance tracking |
| Enrollment → GradeRecord | 1:N | Multiple assessments per enrollment |
| Student + Enrollment → Invoice | 1:N | Financial records linked to enrollments |
| Invoice → Payment | 1:N | Multiple partial payments per invoice |
| Invoice → PaymentPlan | 1:N | Installment schedules |
| User → HREmployee | 1:1 | HR profile for payroll, contracts |
| HREmployee → HRContract | 1:N | Contract history |
| HREmployee → HRPayroll | 1:N | Monthly payroll records |
| CRMLead → CRMInteraction | 1:N | Follow-up history |
| CRMLead → Student | 1:1 (optional) | Conversion tracking |
| CRMCampaign → CRMLead | 1:N | Lead source attribution |

---

## 3. Detailed Database Schema

### 3.1 Schema Namespaces

```sql
-- Logical schema separation within PostgreSQL
CREATE SCHEMA IF NOT EXISTS core;      -- Organizations, branches, users
CREATE SCHEMA IF NOT EXISTS academic;  -- Courses, classes, enrollments, grades
CREATE SCHEMA IF NOT EXISTS finance;   -- Invoices, payments, expenses
CREATE SCHEMA IF NOT EXISTS hr;        -- Employees, contracts, payroll, leave
CREATE SCHEMA IF NOT EXISTS crm;       -- Leads, campaigns, interactions
CREATE SCHEMA IF NOT EXISTS system;    -- Audit logs, events, settings, files
```

### 3.2 Core Schema

```sql
-- =============================================================================
-- CORE SCHEMA: Organizations, Branches, Users
-- =============================================================================

CREATE TABLE core.organizations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    slug            VARCHAR(100) NOT NULL UNIQUE,
    logo_url        TEXT,
    settings        JSONB DEFAULT '{}',
    -- settings: { timezone, locale, currency, academic_year_start, ... }
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE core.branches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id          UUID NOT NULL REFERENCES core.organizations(id),
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(20) NOT NULL,
    address         TEXT,
    city            VARCHAR(100),
    phone           VARCHAR(20),
    email           VARCHAR(255),
    is_headquarters BOOLEAN DEFAULT false,
    is_active       BOOLEAN DEFAULT true,
    settings        JSONB DEFAULT '{}',
    -- settings: { working_hours, class_slots, rooms: [...], ... }
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, code)
);

CREATE TABLE core.users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email           VARCHAR(255) UNIQUE,
    phone           VARCHAR(20) UNIQUE,
    password_hash   TEXT NOT NULL,
    full_name       VARCHAR(255) NOT NULL,
    avatar_url      TEXT,
    role            VARCHAR(20) NOT NULL CHECK (role IN (
                        'super_admin', 'branch_admin', 'manager',
                        'staff', 'teacher', 'parent', 'student'
                    )),
    primary_branch_id UUID REFERENCES core.branches(id),
    is_active       BOOLEAN DEFAULT true,
    email_verified  BOOLEAN DEFAULT false,
    phone_verified  BOOLEAN DEFAULT false,
    last_login_at   TIMESTAMPTZ,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Users can access multiple branches
CREATE TABLE core.user_branches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES core.users(id) ON DELETE CASCADE,
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    role_override   VARCHAR(20),  -- optional branch-specific role
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, branch_id)
);

-- Refresh tokens for JWT rotation
CREATE TABLE core.refresh_tokens (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES core.users(id) ON DELETE CASCADE,
    token_hash      TEXT NOT NULL UNIQUE,
    device_info     JSONB DEFAULT '{}',
    expires_at      TIMESTAMPTZ NOT NULL,
    revoked_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_email ON core.users(email);
CREATE INDEX idx_users_phone ON core.users(phone);
CREATE INDEX idx_users_role ON core.users(role);
CREATE INDEX idx_user_branches_user ON core.user_branches(user_id);
CREATE INDEX idx_user_branches_branch ON core.user_branches(branch_id);
CREATE INDEX idx_refresh_tokens_user ON core.refresh_tokens(user_id);
```

### 3.3 Academic Schema

```sql
-- =============================================================================
-- ACADEMIC SCHEMA: Students, Parents, Teachers, Courses, Classes, Enrollments
-- =============================================================================

CREATE TABLE academic.students (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID UNIQUE REFERENCES core.users(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    student_code    VARCHAR(20) NOT NULL,
    full_name       VARCHAR(255) NOT NULL,
    date_of_birth   DATE,
    gender          VARCHAR(10) CHECK (gender IN ('male', 'female', 'other')),
    phone           VARCHAR(20),
    email           VARCHAR(255),
    address         TEXT,
    enrollment_date DATE NOT NULL DEFAULT CURRENT_DATE,
    status          VARCHAR(20) DEFAULT 'active' CHECK (status IN (
                        'active', 'inactive', 'graduated', 'suspended', 'withdrawn'
                    )),
    level           VARCHAR(50),  -- e.g., 'beginner', 'intermediate', 'advanced'
    source          VARCHAR(50),  -- how the student found us (CRM link)
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, student_code)
);

CREATE TABLE academic.parents (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID UNIQUE REFERENCES core.users(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    full_name       VARCHAR(255) NOT NULL,
    phone           VARCHAR(20) NOT NULL,
    email           VARCHAR(255),
    address         TEXT,
    occupation      VARCHAR(255),
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE academic.student_parents (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id      UUID NOT NULL REFERENCES academic.students(id) ON DELETE CASCADE,
    parent_id       UUID NOT NULL REFERENCES academic.parents(id) ON DELETE CASCADE,
    relationship    VARCHAR(20) NOT NULL CHECK (relationship IN (
                        'father', 'mother', 'guardian', 'other'
                    )),
    is_primary      BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(student_id, parent_id)
);

CREATE TABLE academic.teachers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID UNIQUE REFERENCES core.users(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    employee_code   VARCHAR(20) NOT NULL,
    full_name       VARCHAR(255) NOT NULL,
    phone           VARCHAR(20),
    email           VARCHAR(255),
    specializations JSONB DEFAULT '[]',
    -- e.g., ["English", "IELTS", "Business English"]
    certifications  JSONB DEFAULT '[]',
    -- e.g., [{"name": "TESOL", "issued_date": "2023-01-15", "expiry": "2028-01-15"}]
    hire_date       DATE NOT NULL,
    hourly_rate     DECIMAL(12, 2),
    status          VARCHAR(20) DEFAULT 'active' CHECK (status IN (
                        'active', 'inactive', 'on_leave', 'terminated'
                    )),
    bio             TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, employee_code)
);

CREATE TABLE academic.courses (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(20) NOT NULL,
    description     TEXT,
    level           VARCHAR(50),
    category        VARCHAR(100),  -- e.g., 'General English', 'IELTS', 'Kids'
    duration_hours  INTEGER NOT NULL,
    total_sessions  INTEGER NOT NULL,
    max_students    INTEGER DEFAULT 20,
    tuition_fee     DECIMAL(12, 2) NOT NULL,
    materials_fee   DECIMAL(12, 2) DEFAULT 0,
    syllabus        JSONB DEFAULT '{}',
    -- syllabus: { units: [{ name, topics: [], hours }] }
    prerequisites   JSONB DEFAULT '[]',
    -- prerequisite course IDs
    is_active       BOOLEAN DEFAULT true,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, code)
);

CREATE TABLE academic.classes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    course_id       UUID NOT NULL REFERENCES academic.courses(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    teacher_id      UUID NOT NULL REFERENCES academic.teachers(id),
    name            VARCHAR(255) NOT NULL,
    class_code      VARCHAR(30) NOT NULL,
    room            VARCHAR(50),
    schedule        JSONB NOT NULL,
    -- schedule: [{ day: "monday", start: "18:00", end: "20:00" }]
    start_date      DATE NOT NULL,
    end_date        DATE,
    capacity        INTEGER NOT NULL,
    current_count   INTEGER DEFAULT 0,
    status          VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN (
                        'scheduled', 'in_progress', 'completed', 'cancelled'
                    )),
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, class_code)
);

CREATE TABLE academic.enrollments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id      UUID NOT NULL REFERENCES academic.students(id),
    class_id        UUID NOT NULL REFERENCES academic.classes(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    enrolled_at     TIMESTAMPTZ DEFAULT NOW(),
    status          VARCHAR(20) DEFAULT 'active' CHECK (status IN (
                        'pending', 'active', 'completed', 'dropped', 'transferred'
                    )),
    completion_date DATE,
    final_grade     DECIMAL(5, 2),
    grade_letter    VARCHAR(5),
    certificate_url TEXT,
    attendance_rate DECIMAL(5, 2),  -- calculated, denormalized for performance
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(student_id, class_id)
);

CREATE TABLE academic.class_sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    class_id        UUID NOT NULL REFERENCES academic.classes(id),
    session_number  INTEGER NOT NULL,
    session_date    DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    topic           VARCHAR(500),
    description     TEXT,
    teacher_id      UUID REFERENCES academic.teachers(id),
    -- nullable: allows substitute teacher tracking
    room_override   VARCHAR(50),
    status          VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN (
                        'scheduled', 'in_progress', 'completed', 'cancelled', 'rescheduled'
                    )),
    homework        JSONB DEFAULT '{}',
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(class_id, session_number)
);

CREATE TABLE academic.attendance (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id      UUID NOT NULL REFERENCES academic.class_sessions(id),
    student_id      UUID NOT NULL REFERENCES academic.students(id),
    enrollment_id   UUID NOT NULL REFERENCES academic.enrollments(id),
    status          VARCHAR(20) NOT NULL CHECK (status IN (
                        'present', 'absent', 'late', 'excused', 'early_leave'
                    )),
    check_in_time   TIMESTAMPTZ,
    check_out_time  TIMESTAMPTZ,
    marked_by       UUID REFERENCES core.users(id),
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(session_id, student_id)
);

CREATE TABLE academic.grade_records (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    enrollment_id   UUID NOT NULL REFERENCES academic.enrollments(id),
    assessment_type VARCHAR(50) NOT NULL,
    -- e.g., 'midterm', 'final', 'quiz', 'homework', 'speaking', 'writing'
    assessment_name VARCHAR(255),
    score           DECIMAL(5, 2) NOT NULL,
    max_score       DECIMAL(5, 2) NOT NULL,
    weight          DECIMAL(3, 2) DEFAULT 1.0,
    -- weight in final grade calculation
    graded_by       UUID REFERENCES core.users(id),
    graded_at       TIMESTAMPTZ DEFAULT NOW(),
    comments        TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Academic indexes
CREATE INDEX idx_students_branch ON academic.students(branch_id);
CREATE INDEX idx_students_status ON academic.students(branch_id, status);
CREATE INDEX idx_students_code ON academic.students(student_code);
CREATE INDEX idx_teachers_branch ON academic.teachers(branch_id);
CREATE INDEX idx_courses_branch ON academic.courses(branch_id);
CREATE INDEX idx_classes_branch ON academic.classes(branch_id);
CREATE INDEX idx_classes_teacher ON academic.classes(teacher_id);
CREATE INDEX idx_classes_course ON academic.classes(course_id);
CREATE INDEX idx_classes_status ON academic.classes(branch_id, status);
CREATE INDEX idx_enrollments_student ON academic.enrollments(student_id);
CREATE INDEX idx_enrollments_class ON academic.enrollments(class_id);
CREATE INDEX idx_enrollments_branch ON academic.enrollments(branch_id);
CREATE INDEX idx_sessions_class ON academic.class_sessions(class_id);
CREATE INDEX idx_sessions_date ON academic.class_sessions(session_date);
CREATE INDEX idx_attendance_session ON academic.attendance(session_id);
CREATE INDEX idx_attendance_student ON academic.attendance(student_id);
CREATE INDEX idx_grades_enrollment ON academic.grade_records(enrollment_id);
```

### 3.4 Finance Schema

```sql
-- =============================================================================
-- FINANCE SCHEMA: Invoices, Payments, Discounts, Expenses
-- =============================================================================

CREATE TABLE finance.discounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(50) UNIQUE,
    type            VARCHAR(20) NOT NULL CHECK (type IN ('percentage', 'fixed')),
    value           DECIMAL(12, 2) NOT NULL,
    min_amount      DECIMAL(12, 2) DEFAULT 0,
    max_discount    DECIMAL(12, 2),
    valid_from      DATE,
    valid_until     DATE,
    usage_limit     INTEGER,
    usage_count     INTEGER DEFAULT 0,
    applicable_to   JSONB DEFAULT '{}',
    -- { course_ids: [], student_types: [], ... }
    conditions      JSONB DEFAULT '{}',
    -- { min_courses: 2, sibling_discount: true, early_bird_days: 30, ... }
    is_active       BOOLEAN DEFAULT true,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE finance.invoices (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    invoice_number  VARCHAR(50) NOT NULL,
    student_id      UUID NOT NULL REFERENCES academic.students(id),
    enrollment_id   UUID REFERENCES academic.enrollments(id),
    type            VARCHAR(30) NOT NULL CHECK (type IN (
                        'tuition', 'materials', 'registration', 'exam_fee',
                        'penalty', 'other'
                    )),
    subtotal        DECIMAL(12, 2) NOT NULL,
    discount_id     UUID REFERENCES finance.discounts(id),
    discount_amount DECIMAL(12, 2) DEFAULT 0,
    tax_amount      DECIMAL(12, 2) DEFAULT 0,
    total_amount    DECIMAL(12, 2) NOT NULL,
    paid_amount     DECIMAL(12, 2) DEFAULT 0,
    balance         DECIMAL(12, 2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
    currency        VARCHAR(3) DEFAULT 'VND',
    due_date        DATE NOT NULL,
    status          VARCHAR(20) DEFAULT 'draft' CHECK (status IN (
                        'draft', 'issued', 'partially_paid', 'paid',
                        'overdue', 'cancelled', 'refunded'
                    )),
    issued_at       TIMESTAMPTZ,
    issued_by       UUID REFERENCES core.users(id),
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, invoice_number)
);

CREATE TABLE finance.invoice_items (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id      UUID NOT NULL REFERENCES finance.invoices(id) ON DELETE CASCADE,
    description     VARCHAR(500) NOT NULL,
    quantity        INTEGER DEFAULT 1,
    unit_price      DECIMAL(12, 2) NOT NULL,
    amount          DECIMAL(12, 2) NOT NULL,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE finance.payments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id      UUID NOT NULL REFERENCES finance.invoices(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    amount          DECIMAL(12, 2) NOT NULL,
    payment_method  VARCHAR(30) NOT NULL CHECK (payment_method IN (
                        'cash', 'bank_transfer', 'credit_card', 'momo',
                        'zalopay', 'vnpay', 'other'
                    )),
    payment_date    DATE NOT NULL DEFAULT CURRENT_DATE,
    transaction_ref VARCHAR(100),
    receipt_number  VARCHAR(50),
    status          VARCHAR(20) DEFAULT 'completed' CHECK (status IN (
                        'pending', 'completed', 'failed', 'refunded'
                    )),
    received_by     UUID REFERENCES core.users(id),
    refund_reason   TEXT,
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE finance.payment_plans (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id      UUID NOT NULL REFERENCES finance.invoices(id),
    installment_no  INTEGER NOT NULL,
    amount          DECIMAL(12, 2) NOT NULL,
    due_date        DATE NOT NULL,
    status          VARCHAR(20) DEFAULT 'pending' CHECK (status IN (
                        'pending', 'paid', 'overdue', 'waived'
                    )),
    paid_at         TIMESTAMPTZ,
    payment_id      UUID REFERENCES finance.payments(id),
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(invoice_id, installment_no)
);

CREATE TABLE finance.expenses (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    category        VARCHAR(50) NOT NULL CHECK (category IN (
                        'rent', 'utilities', 'supplies', 'marketing',
                        'equipment', 'maintenance', 'salary', 'other'
                    )),
    amount          DECIMAL(12, 2) NOT NULL,
    currency        VARCHAR(3) DEFAULT 'VND',
    description     TEXT NOT NULL,
    expense_date    DATE NOT NULL,
    vendor          VARCHAR(255),
    receipt_url     TEXT,
    approved_by     UUID REFERENCES core.users(id),
    submitted_by    UUID NOT NULL REFERENCES core.users(id),
    status          VARCHAR(20) DEFAULT 'pending' CHECK (status IN (
                        'pending', 'approved', 'rejected', 'reimbursed'
                    )),
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Finance indexes
CREATE INDEX idx_invoices_branch ON finance.invoices(branch_id);
CREATE INDEX idx_invoices_student ON finance.invoices(student_id);
CREATE INDEX idx_invoices_status ON finance.invoices(branch_id, status);
CREATE INDEX idx_invoices_due_date ON finance.invoices(due_date);
CREATE INDEX idx_payments_invoice ON finance.payments(invoice_id);
CREATE INDEX idx_payments_branch ON finance.payments(branch_id);
CREATE INDEX idx_payments_date ON finance.payments(payment_date);
CREATE INDEX idx_expenses_branch ON finance.expenses(branch_id);
CREATE INDEX idx_expenses_date ON finance.expenses(expense_date);
CREATE INDEX idx_expenses_category ON finance.expenses(branch_id, category);
```

### 3.5 HR Schema

```sql
-- =============================================================================
-- HR SCHEMA: Employees, Contracts, Attendance, Leave, Payroll
-- =============================================================================

CREATE TABLE hr.employees (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID UNIQUE REFERENCES core.users(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    employee_code   VARCHAR(20) NOT NULL,
    full_name       VARCHAR(255) NOT NULL,
    date_of_birth   DATE,
    gender          VARCHAR(10),
    phone           VARCHAR(20),
    email           VARCHAR(255),
    address         TEXT,
    id_number       VARCHAR(20),  -- CMND/CCCD
    tax_code        VARCHAR(20),
    bank_account    VARCHAR(30),
    bank_name       VARCHAR(100),
    insurance_number VARCHAR(20),
    department      VARCHAR(100) NOT NULL,
    position        VARCHAR(100) NOT NULL,
    employment_type VARCHAR(20) CHECK (employment_type IN (
                        'full_time', 'part_time', 'contract', 'intern'
                    )),
    hire_date       DATE NOT NULL,
    termination_date DATE,
    emergency_contact JSONB DEFAULT '{}',
    -- { name, phone, relationship }
    status          VARCHAR(20) DEFAULT 'active' CHECK (status IN (
                        'active', 'on_leave', 'suspended', 'terminated'
                    )),
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, employee_code)
);

CREATE TABLE hr.contracts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id     UUID NOT NULL REFERENCES hr.employees(id),
    contract_type   VARCHAR(30) NOT NULL CHECK (contract_type IN (
                        'probation', 'fixed_term', 'indefinite', 'seasonal'
                    )),
    contract_number VARCHAR(50),
    start_date      DATE NOT NULL,
    end_date        DATE,
    base_salary     DECIMAL(12, 2) NOT NULL,
    allowances      JSONB DEFAULT '{}',
    -- { housing: 2000000, transport: 500000, phone: 200000 }
    benefits        JSONB DEFAULT '{}',
    -- { health_insurance: true, annual_leave_days: 12, ... }
    working_hours   JSONB DEFAULT '{}',
    -- { hours_per_week: 40, schedule: "Mon-Fri 8:00-17:00" }
    signed_doc_url  TEXT,
    status          VARCHAR(20) DEFAULT 'active' CHECK (status IN (
                        'draft', 'active', 'expired', 'terminated', 'renewed'
                    )),
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE hr.attendance (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id     UUID NOT NULL REFERENCES hr.employees(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    work_date       DATE NOT NULL,
    check_in        TIMESTAMPTZ,
    check_out       TIMESTAMPTZ,
    work_hours      DECIMAL(4, 2),
    overtime_hours  DECIMAL(4, 2) DEFAULT 0,
    status          VARCHAR(20) DEFAULT 'present' CHECK (status IN (
                        'present', 'absent', 'late', 'half_day',
                        'remote', 'holiday', 'leave'
                    )),
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(employee_id, work_date)
);

CREATE TABLE hr.leave_requests (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id     UUID NOT NULL REFERENCES hr.employees(id),
    leave_type      VARCHAR(30) NOT NULL CHECK (leave_type IN (
                        'annual', 'sick', 'maternity', 'paternity',
                        'unpaid', 'compassionate', 'other'
                    )),
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    days_count      DECIMAL(3, 1) NOT NULL,
    reason          TEXT,
    approved_by     UUID REFERENCES core.users(id),
    status          VARCHAR(20) DEFAULT 'pending' CHECK (status IN (
                        'pending', 'approved', 'rejected', 'cancelled'
                    )),
    reviewed_at     TIMESTAMPTZ,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE hr.payroll (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id     UUID NOT NULL REFERENCES hr.employees(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    work_days       INTEGER,
    actual_days     INTEGER,
    base_salary     DECIMAL(12, 2) NOT NULL,
    allowances      DECIMAL(12, 2) DEFAULT 0,
    overtime_pay    DECIMAL(12, 2) DEFAULT 0,
    bonuses         DECIMAL(12, 2) DEFAULT 0,
    gross_salary    DECIMAL(12, 2) NOT NULL,
    tax_deduction   DECIMAL(12, 2) DEFAULT 0,
    insurance_deduction DECIMAL(12, 2) DEFAULT 0,
    other_deductions DECIMAL(12, 2) DEFAULT 0,
    deduction_details JSONB DEFAULT '{}',
    net_salary      DECIMAL(12, 2) NOT NULL,
    currency        VARCHAR(3) DEFAULT 'VND',
    status          VARCHAR(20) DEFAULT 'draft' CHECK (status IN (
                        'draft', 'calculated', 'approved', 'paid'
                    )),
    approved_by     UUID REFERENCES core.users(id),
    paid_at         TIMESTAMPTZ,
    payment_ref     VARCHAR(100),
    notes           TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(employee_id, period_start, period_end)
);

-- HR indexes
CREATE INDEX idx_hr_employees_branch ON hr.employees(branch_id);
CREATE INDEX idx_hr_employees_dept ON hr.employees(branch_id, department);
CREATE INDEX idx_hr_contracts_employee ON hr.contracts(employee_id);
CREATE INDEX idx_hr_attendance_employee ON hr.attendance(employee_id);
CREATE INDEX idx_hr_attendance_date ON hr.attendance(work_date);
CREATE INDEX idx_hr_leave_employee ON hr.leave_requests(employee_id);
CREATE INDEX idx_hr_leave_status ON hr.leave_requests(status);
CREATE INDEX idx_hr_payroll_employee ON hr.payroll(employee_id);
CREATE INDEX idx_hr_payroll_period ON hr.payroll(period_start, period_end);
```

### 3.6 CRM Schema

```sql
-- =============================================================================
-- CRM SCHEMA: Leads, Campaigns, Interactions, Tasks
-- =============================================================================

CREATE TABLE crm.campaigns (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    name            VARCHAR(255) NOT NULL,
    type            VARCHAR(30) CHECK (type IN (
                        'digital_ad', 'social_media', 'referral',
                        'event', 'flyer', 'partnership', 'other'
                    )),
    description     TEXT,
    start_date      DATE,
    end_date        DATE,
    budget          DECIMAL(12, 2),
    spent           DECIMAL(12, 2) DEFAULT 0,
    target_audience JSONB DEFAULT '{}',
    -- { age_range: [18, 35], interests: ["IELTS"], locations: ["HCMC"] }
    channels        JSONB DEFAULT '[]',
    -- ["facebook", "google_ads", "zalo"]
    status          VARCHAR(20) DEFAULT 'draft' CHECK (status IN (
                        'draft', 'active', 'paused', 'completed', 'cancelled'
                    )),
    results         JSONB DEFAULT '{}',
    -- { impressions, clicks, leads_generated, conversions, roi }
    created_by      UUID REFERENCES core.users(id),
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE crm.leads (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    full_name       VARCHAR(255) NOT NULL,
    email           VARCHAR(255),
    phone           VARCHAR(20) NOT NULL,
    source          VARCHAR(50) NOT NULL CHECK (source IN (
                        'website', 'facebook', 'zalo', 'google',
                        'referral', 'walk_in', 'phone_call',
                        'event', 'partner', 'other'
                    )),
    campaign_id     UUID REFERENCES crm.campaigns(id),
    interest_course_id UUID REFERENCES academic.courses(id),
    interest_notes  TEXT,
    assigned_to     UUID REFERENCES core.users(id),
    status          VARCHAR(20) DEFAULT 'new' CHECK (status IN (
                        'new', 'contacted', 'qualified', 'trial_scheduled',
                        'trial_completed', 'negotiation', 'converted',
                        'lost', 'dormant'
                    )),
    score           INTEGER DEFAULT 0 CHECK (score >= 0 AND score <= 100),
    -- Lead scoring: 0-100 based on engagement
    expected_value  DECIMAL(12, 2),
    lost_reason     VARCHAR(100),
    converted_student_id UUID REFERENCES academic.students(id),
    converted_at    TIMESTAMPTZ,
    last_contacted  TIMESTAMPTZ,
    next_follow_up  TIMESTAMPTZ,
    notes           TEXT,
    tags            JSONB DEFAULT '[]',
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE crm.interactions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id         UUID NOT NULL REFERENCES crm.leads(id) ON DELETE CASCADE,
    type            VARCHAR(30) NOT NULL CHECK (type IN (
                        'phone_call', 'email', 'sms', 'zalo_message',
                        'facebook_message', 'meeting', 'trial_class',
                        'note', 'other'
                    )),
    direction       VARCHAR(10) CHECK (direction IN ('inbound', 'outbound')),
    channel         VARCHAR(30),
    subject         VARCHAR(255),
    content         TEXT,
    duration_minutes INTEGER,
    contacted_by    UUID REFERENCES core.users(id),
    outcome         VARCHAR(50),
    -- e.g., 'interested', 'callback_requested', 'not_interested', 'no_answer'
    next_follow_up  TIMESTAMPTZ,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE crm.tasks (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id         UUID REFERENCES crm.leads(id),
    branch_id       UUID NOT NULL REFERENCES core.branches(id),
    assigned_to     UUID NOT NULL REFERENCES core.users(id),
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    task_type       VARCHAR(30) CHECK (task_type IN (
                        'follow_up', 'call', 'email', 'meeting',
                        'trial_arrangement', 'document', 'other'
                    )),
    due_date        TIMESTAMPTZ NOT NULL,
    priority        VARCHAR(10) DEFAULT 'medium' CHECK (priority IN (
                        'low', 'medium', 'high', 'urgent'
                    )),
    status          VARCHAR(20) DEFAULT 'pending' CHECK (status IN (
                        'pending', 'in_progress', 'completed', 'cancelled'
                    )),
    completed_at    TIMESTAMPTZ,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- CRM indexes
CREATE INDEX idx_crm_leads_branch ON crm.leads(branch_id);
CREATE INDEX idx_crm_leads_status ON crm.leads(branch_id, status);
CREATE INDEX idx_crm_leads_assigned ON crm.leads(assigned_to);
CREATE INDEX idx_crm_leads_source ON crm.leads(source);
CREATE INDEX idx_crm_leads_phone ON crm.leads(phone);
CREATE INDEX idx_crm_leads_next_followup ON crm.leads(next_follow_up);
CREATE INDEX idx_crm_interactions_lead ON crm.interactions(lead_id);
CREATE INDEX idx_crm_tasks_assigned ON crm.tasks(assigned_to);
CREATE INDEX idx_crm_tasks_due ON crm.tasks(due_date);
CREATE INDEX idx_crm_tasks_status ON crm.tasks(status);
CREATE INDEX idx_crm_campaigns_branch ON crm.campaigns(branch_id);
```

### 3.7 System Schema

```sql
-- =============================================================================
-- SYSTEM SCHEMA: Audit, Events, Settings, Notifications, Files
-- =============================================================================

CREATE TABLE system.audit_logs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID REFERENCES core.branches(id),
    user_id         UUID REFERENCES core.users(id),
    entity_type     VARCHAR(50) NOT NULL,
    entity_id       UUID NOT NULL,
    action          VARCHAR(20) NOT NULL CHECK (action IN (
                        'create', 'update', 'delete', 'status_change',
                        'login', 'logout', 'export', 'import'
                    )),
    old_values      JSONB,
    new_values      JSONB,
    ip_address      INET,
    user_agent      TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Partitioned by month for performance
-- CREATE TABLE system.audit_logs ... PARTITION BY RANGE (created_at);

CREATE TABLE system.event_store (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID REFERENCES core.branches(id),
    aggregate_type  VARCHAR(50) NOT NULL,
    -- e.g., 'enrollment', 'payment', 'lead'
    aggregate_id    UUID NOT NULL,
    event_type      VARCHAR(100) NOT NULL,
    -- e.g., 'enrollment.created', 'payment.received', 'lead.status_changed'
    payload         JSONB NOT NULL,
    metadata        JSONB DEFAULT '{}',
    -- { triggered_by, ip, correlation_id }
    sequence_number BIGINT NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE system.notifications (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES core.users(id),
    branch_id       UUID REFERENCES core.branches(id),
    type            VARCHAR(30) NOT NULL,
    -- e.g., 'payment_due', 'class_reminder', 'grade_posted', 'leave_approved'
    title           VARCHAR(255) NOT NULL,
    body            TEXT,
    data            JSONB DEFAULT '{}',
    -- { link_to, entity_type, entity_id }
    channels        JSONB DEFAULT '["in_app"]',
    -- ["in_app", "email", "sms", "push"]
    read_at         TIMESTAMPTZ,
    sent_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE system.settings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID REFERENCES core.branches(id),
    -- NULL = organization-level setting
    category        VARCHAR(50) NOT NULL,
    key             VARCHAR(100) NOT NULL,
    value           JSONB NOT NULL,
    description     TEXT,
    updated_by      UUID REFERENCES core.users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, category, key)
);

CREATE TABLE system.file_attachments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type     VARCHAR(50) NOT NULL,
    entity_id       UUID NOT NULL,
    file_name       VARCHAR(255) NOT NULL,
    file_url        TEXT NOT NULL,
    file_size       BIGINT,
    mime_type       VARCHAR(100),
    category        VARCHAR(50),
    -- e.g., 'avatar', 'certificate', 'receipt', 'contract'
    uploaded_by     UUID REFERENCES core.users(id),
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- System indexes
CREATE INDEX idx_audit_entity ON system.audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_user ON system.audit_logs(user_id);
CREATE INDEX idx_audit_created ON system.audit_logs(created_at);
CREATE INDEX idx_events_aggregate ON system.event_store(aggregate_type, aggregate_id);
CREATE INDEX idx_events_type ON system.event_store(event_type);
CREATE INDEX idx_events_created ON system.event_store(created_at);
CREATE INDEX idx_notifications_user ON system.notifications(user_id);
CREATE INDEX idx_notifications_unread ON system.notifications(user_id, read_at) WHERE read_at IS NULL;
CREATE INDEX idx_settings_branch ON system.settings(branch_id, category);
CREATE INDEX idx_files_entity ON system.file_attachments(entity_type, entity_id);
```

### 3.8 Row-Level Security (Multi-Branch Isolation)

```sql
-- =============================================================================
-- ROW-LEVEL SECURITY: Automatic branch data isolation
-- =============================================================================

-- Enable RLS on all branch-scoped tables
ALTER TABLE academic.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE academic.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE academic.enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE hr.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm.leads ENABLE ROW LEVEL SECURITY;

-- Application sets current_setting on each request:
-- SET LOCAL app.current_branch_id = '<branch_uuid>';
-- SET LOCAL app.current_user_role = '<role>';

-- Example RLS policies
CREATE POLICY branch_isolation_students ON academic.students
    USING (
        branch_id::text = current_setting('app.current_branch_id', true)
        OR current_setting('app.current_user_role', true) = 'super_admin'
    );

CREATE POLICY branch_isolation_invoices ON finance.invoices
    USING (
        branch_id::text = current_setting('app.current_branch_id', true)
        OR current_setting('app.current_user_role', true) = 'super_admin'
    );

-- Pattern repeats for all branch-scoped tables
```

---

## 4. User Role Hierarchy & Access Control

### 4.1 Role Hierarchy

```
┌──────────────────────────────────────────────────────────────────┐
│                     ROLE HIERARCHY                                │
│                                                                  │
│                    ┌─────────────────┐                           │
│                    │   SUPER ADMIN   │                           │
│                    │  (System Owner) │                           │
│                    └────────┬────────┘                           │
│                             │                                    │
│               ┌─────────────┼─────────────┐                     │
│               ▼             ▼             ▼                      │
│    ┌──────────────┐ ┌────────────┐ ┌────────────┐              │
│    │BRANCH ADMIN  │ │  MANAGER   │ │    ...     │              │
│    │(Branch Owner)│ │(Department)│ │(Future)    │              │
│    └──────┬───────┘ └─────┬──────┘ └────────────┘              │
│           │               │                                     │
│     ┌─────┴──────┐   ┌───┴────┐                                │
│     ▼            ▼   ▼        ▼                                 │
│ ┌────────┐ ┌────────┐ ┌──────────┐                             │
│ │ STAFF  │ │TEACHER │ │ACCOUNTANT│                             │
│ └────────┘ └────────┘ └──────────┘                             │
│                                                                  │
│     ┌──────────────────────────────┐                            │
│     ▼                              ▼                             │
│ ┌────────┐                   ┌──────────┐                       │
│ │ PARENT │                   │ STUDENT  │                       │
│ └────────┘                   └──────────┘                       │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

### 4.2 Permission Matrix

| Resource / Action | Super Admin | Branch Admin | Manager | Staff | Teacher | Parent | Student |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Organization** | ||||||||
| View org settings | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Edit org settings | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Manage branches | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Users** | ||||||||
| Create any user | ✅ | ✅* | ✅* | ❌ | ❌ | ❌ | ❌ |
| Manage branch users | ✅ | ✅ | ✅* | ❌ | ❌ | ❌ | ❌ |
| View all users | ✅ | ✅* | ✅* | ✅* | ❌ | ❌ | ❌ |
| Edit own profile | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Academic** | ||||||||
| Manage courses | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Manage classes | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Manage enrollments | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Mark attendance | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| Enter grades | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| View own grades | — | — | — | — | — | ✅† | ✅ |
| View own attendance | — | — | — | — | — | ✅† | ✅ |
| View class schedule | ✅ | ✅ | ✅ | ✅ | ✅ | ✅† | ✅ |
| **Finance** | ||||||||
| Create invoices | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Process payments | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| View all finances | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| View own invoices | — | — | — | — | — | ✅† | ✅ |
| Finance reports | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Manage expenses | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **HR** | ||||||||
| View all employees | ✅ | ✅ | ✅* | ❌ | ❌ | ❌ | ❌ |
| Manage contracts | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Approve leave | ✅ | ✅ | ✅* | ❌ | ❌ | ❌ | ❌ |
| Process payroll | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| View own HR data | — | — | ✅ | ✅ | ✅ | ❌ | ❌ |
| **CRM** | ||||||||
| Manage leads | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Manage campaigns | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| CRM reports | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **System** | ||||||||
| View audit logs | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| System settings | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |

> `*` = within their branch only | `†` = only for their linked students

### 4.3 RBAC Implementation Pattern

```typescript
// Permission definition structure
interface Permission {
  resource: string;     // e.g., 'academic.students'
  action: string;       // e.g., 'read', 'create', 'update', 'delete'
  scope: 'own' | 'branch' | 'all';
  conditions?: Record<string, any>;
}

// Role → Permission mapping (stored in DB as system.settings)
const ROLE_PERMISSIONS: Record<string, Permission[]> = {
  super_admin: [
    { resource: '*', action: '*', scope: 'all' }
  ],
  branch_admin: [
    { resource: '*', action: '*', scope: 'branch' }
  ],
  teacher: [
    { resource: 'academic.classes', action: 'read', scope: 'own' },
    { resource: 'academic.attendance', action: '*', scope: 'own' },
    { resource: 'academic.grade_records', action: '*', scope: 'own' },
    { resource: 'academic.students', action: 'read', scope: 'own' },
    // "own" = classes assigned to this teacher
  ],
  parent: [
    { resource: 'academic.students', action: 'read', scope: 'own',
      conditions: { linked_via: 'student_parents' } },
    { resource: 'academic.attendance', action: 'read', scope: 'own' },
    { resource: 'academic.grade_records', action: 'read', scope: 'own' },
    { resource: 'finance.invoices', action: 'read', scope: 'own' },
  ],
  student: [
    { resource: 'academic.enrollments', action: 'read', scope: 'own' },
    { resource: 'academic.attendance', action: 'read', scope: 'own' },
    { resource: 'academic.grade_records', action: 'read', scope: 'own' },
    { resource: 'finance.invoices', action: 'read', scope: 'own' },
  ]
};

// Middleware enforcement
@UseGuards(AuthGuard, RBACGuard)
@RequirePermission('academic.students', 'read')
@Get('/students')
async listStudents(@CurrentUser() user: AuthUser) {
  // RBACGuard automatically:
  // 1. Checks role has permission
  // 2. Applies scope filter (branch_id for branch-scoped roles)
  // 3. Sets PostgreSQL session variables for RLS
}
```

### 4.4 Branch Context Middleware

```typescript
// Every API request passes through branch context middleware
async function branchContextMiddleware(req, res, next) {
  const user = req.user; // from JWT
  const requestedBranch = req.headers['x-branch-id'] || user.primary_branch_id;

  // Super admin can access any branch
  if (user.role === 'super_admin') {
    req.branchId = requestedBranch;
  }
  // Other roles: verify branch membership
  else {
    const membership = await userBranchService.verify(user.id, requestedBranch);
    if (!membership) throw new ForbiddenException('No access to this branch');
    req.branchId = requestedBranch;
  }

  // Set PostgreSQL session variables for RLS
  await db.raw(`SET LOCAL app.current_branch_id = '${req.branchId}'`);
  await db.raw(`SET LOCAL app.current_user_role = '${user.role}'`);

  next();
}
```

---

## 5. AI-Ready Data Architecture

### 5.1 Design Principles for AI Readiness

The schema is designed to serve as a rich data foundation for AI/ML features without requiring schema changes:

| Principle | Implementation |
|---|---|
| **Event Sourcing** | `system.event_store` captures every significant state transition with full payload |
| **JSONB Metadata** | Every table has `metadata JSONB` for extensible, unstructured data (AI model outputs, feature vectors) |
| **Temporal Data** | `created_at` + `updated_at` on all tables enable time-series analysis |
| **Denormalized Aggregates** | Calculated fields (e.g., `attendance_rate`, `balance`) provide immediate feature access |
| **Audit Trail** | Complete `old_values → new_values` change tracking for behavioral analysis |

### 5.2 AI Feature Domains & Trigger Points

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      AI / ML FEATURE MAP                                │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                  1. STUDENT PROGRESS AI                         │   │
│  │                                                                 │   │
│  │  Data Sources:                                                  │   │
│  │  • grade_records (scores, trends)                               │   │
│  │  • attendance (patterns, consistency)                           │   │
│  │  • enrollments (completion rates)                               │   │
│  │  • class_sessions (topic progression)                           │   │
│  │                                                                 │   │
│  │  Trigger Points:                                                │   │
│  │  ► EVENT: grade_record.created                                  │   │
│  │    → Calculate running average, detect declining trend          │   │
│  │    → If 3+ consecutive drops → alert teacher + parent           │   │
│  │                                                                 │   │
│  │  ► EVENT: attendance.marked (status = 'absent')                 │   │
│  │    → Check absence streak                                      │   │
│  │    → If 3+ consecutive → flag at-risk, notify staff             │   │
│  │                                                                 │   │
│  │  ► SCHEDULED: weekly_progress_digest                            │   │
│  │    → Aggregate week's data per student                          │   │
│  │    → Generate natural-language progress summary                 │   │
│  │    → Push to parent portal / notification                       │   │
│  │                                                                 │   │
│  │  AI Models (Future):                                            │   │
│  │  • Dropout prediction (logistic regression on engagement)       │   │
│  │  • Optimal class placement (clustering on assessment scores)    │   │
│  │  • Personalized learning path recommendation                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                  2. FINANCIAL ANOMALY AI                         │   │
│  │                                                                 │   │
│  │  Data Sources:                                                  │   │
│  │  • invoices (amounts, timing)                                   │   │
│  │  • payments (methods, patterns)                                 │   │
│  │  • expenses (categories, amounts)                               │   │
│  │  • discounts (usage patterns)                                   │   │
│  │                                                                 │   │
│  │  Trigger Points:                                                │   │
│  │  ► EVENT: payment.created                                       │   │
│  │    → Check for duplicate payment (same amount, same day)        │   │
│  │    → Validate against invoice total                             │   │
│  │    → Flag unusual payment methods for amount threshold          │   │
│  │                                                                 │   │
│  │  ► EVENT: invoice.status → 'overdue'                            │   │
│  │    → Auto-escalation workflow                                   │   │
│  │    → Predict payment likelihood based on history                │   │
│  │                                                                 │   │
│  │  ► SCHEDULED: daily_financial_health_check                      │   │
│  │    → Revenue vs. forecast variance                              │   │
│  │    → Expense spike detection (Z-score > 2)                      │   │
│  │    → Discount abuse detection (code usage > threshold)          │   │
│  │    → Cash flow prediction (30/60/90 day)                        │   │
│  │                                                                 │   │
│  │  AI Models (Future):                                            │   │
│  │  • Revenue forecasting (time-series on enrollment + payment)    │   │
│  │  • Churn-revenue impact (enrollment drop → revenue prediction)  │   │
│  │  • Dynamic pricing recommendations                              │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                  3. HR INSIGHTS AI                               │   │
│  │                                                                 │   │
│  │  Data Sources:                                                  │   │
│  │  • hr.attendance (check-in patterns)                            │   │
│  │  • hr.leave_requests (frequency, types)                         │   │
│  │  • hr.payroll (compensation trends)                             │   │
│  │  • academic.classes + grade_records (teacher effectiveness)     │   │
│  │                                                                 │   │
│  │  Trigger Points:                                                │   │
│  │  ► EVENT: hr_leave.approved (type = 'sick')                     │   │
│  │    → Track sick-leave frequency per employee                    │   │
│  │    → Alert HR if pattern suggests burnout                       │   │
│  │                                                                 │   │
│  │  ► EVENT: hr_attendance.created (status = 'late')               │   │
│  │    → Late arrival pattern detection                             │   │
│  │    → Correlate with class feedback scores                       │   │
│  │                                                                 │   │
│  │  ► SCHEDULED: monthly_teacher_effectiveness                     │   │
│  │    → Cross-reference: teacher → classes → student grades        │   │
│  │    → Calculate improvement rates per teacher                    │   │
│  │    → Generate teacher performance scorecards                    │   │
│  │                                                                 │   │
│  │  AI Models (Future):                                            │   │
│  │  • Employee satisfaction prediction                             │   │
│  │  • Optimal scheduling (workload balancing)                      │   │
│  │  • Teacher-student matching optimization                        │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                  4. CRM INTELLIGENCE AI                          │   │
│  │                                                                 │   │
│  │  Data Sources:                                                  │   │
│  │  • crm.leads (demographics, source, status history)             │   │
│  │  • crm.interactions (engagement frequency, channels)            │   │
│  │  • crm.campaigns (channel performance)                          │   │
│  │  • academic.students (conversion data)                          │   │
│  │                                                                 │   │
│  │  Trigger Points:                                                │   │
│  │  ► EVENT: lead.created                                          │   │
│  │    → Auto-score based on source + interest_course               │   │
│  │    → Auto-assign to best-performing staff for that source       │   │
│  │                                                                 │   │
│  │  ► EVENT: interaction.created                                   │   │
│  │    → Recalculate lead score                                     │   │
│  │    → Predict conversion probability                             │   │
│  │    → Suggest optimal next action + timing                       │   │
│  │                                                                 │   │
│  │  ► SCHEDULED: weekly_crm_analytics                              │   │
│  │    → Funnel conversion rates by stage                           │   │
│  │    → Campaign ROI calculation                                   │   │
│  │    → Lead source quality ranking                                │   │
│  │    → Stale lead identification                                  │   │
│  │                                                                 │   │
│  │  AI Models (Future):                                            │   │
│  │  • Lead scoring ML model (gradient boosting)                    │   │
│  │  • Optimal contact time prediction                              │   │
│  │  • Campaign budget allocation optimization                      │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 5.3 Event Store Design for AI Consumption

```sql
-- Example events stored for AI pipeline consumption:

-- Student progress event
INSERT INTO system.event_store (branch_id, aggregate_type, aggregate_id, event_type, payload, sequence_number)
VALUES (
    'branch-uuid',
    'enrollment',
    'enrollment-uuid',
    'grade.recorded',
    '{
        "student_id": "student-uuid",
        "class_id": "class-uuid",
        "assessment_type": "midterm",
        "score": 75,
        "max_score": 100,
        "running_average": 78.5,
        "trend": "declining",
        "percentile_in_class": 45
    }',
    nextval('event_sequence')
);

-- Financial anomaly event
INSERT INTO system.event_store (branch_id, aggregate_type, aggregate_id, event_type, payload, sequence_number)
VALUES (
    'branch-uuid',
    'payment',
    'payment-uuid',
    'payment.anomaly_detected',
    '{
        "invoice_id": "invoice-uuid",
        "amount": 15000000,
        "expected_range": [5000000, 10000000],
        "anomaly_type": "amount_exceeds_2_sigma",
        "confidence": 0.92
    }',
    nextval('event_sequence')
);
```

### 5.4 Metadata Schema Convention

Every `metadata JSONB` column follows a reserved-key convention for AI features:

```jsonc
{
  // User-defined metadata (free-form)
  "custom_field_1": "value",

  // Reserved: AI-generated insights (populated by AI pipelines)
  "_ai": {
    "risk_score": 0.35,
    "last_analyzed": "2026-06-01T10:00:00Z",
    "predictions": {
      "dropout_probability": 0.12,
      "expected_final_grade": 82
    },
    "tags": ["at_risk", "needs_attention"],
    "model_version": "v1.2"
  },

  // Reserved: Feature vectors for ML models
  "_features": {
    "attendance_rate_30d": 0.85,
    "grade_trend_slope": -2.3,
    "engagement_score": 67
  }
}
```

---

## 6. Phased Development Roadmap

### 6.1 Overview Timeline

```
Phase 1: ACADEMIC CORE          Phase 2: FINANCE           Phase 3: HR & CRM
┌──────────────────────┐   ┌──────────────────────┐   ┌──────────────────────┐
│  Weeks 1-8           │   │  Weeks 9-14          │   │  Weeks 15-22         │
│                      │   │                      │   │                      │
│  Foundation +        │   │  Invoicing +         │   │  Employee Mgmt +     │
│  Academic Module     │   │  Payments +          │   │  Payroll +           │
│  Management Dashboard│   │  Financial Reports   │   │  Lead Pipeline +     │
│                      │   │                      │   │  Campaign Tracking   │
└──────────────────────┘   └──────────────────────┘   └──────────────────────┘
         │                          │                          │
         ▼                          ▼                          ▼
   MVP Launch               Finance Launch              Full Platform
   (Internal Use)           (Billing Active)            (All Modules)
```

### 6.2 Phase 1 — Academic Core (Weeks 1–8)

**Goal:** Fully functional academic management system with multi-branch support.

| Week | Sprint | Deliverables |
|---|---|---|
| **1–2** | Foundation | • Project scaffolding (NestJS + Next.js + Prisma) |
| | | • PostgreSQL setup with all schemas (full DDL execution) |
| | | • Auth system (JWT + refresh + RBAC middleware) |
| | | • Branch context middleware + RLS policies |
| | | • Core API: organizations, branches, users |
| | | • Login/logout, password reset |
| **3–4** | People | • Student CRUD with search, filter, pagination |
| | | • Parent management + student-parent linking |
| | | • Teacher management with specializations |
| | | • Staff management |
| | | • Bulk import (CSV/Excel) for students |
| | | • Dashboard: student/teacher statistics cards |
| **5–6** | Classes | • Course management (CRUD, syllabus builder) |
| | | • Class creation with schedule builder |
| | | • Enrollment workflow (pending → active) |
| | | • Session auto-generation from class schedule |
| | | • Attendance marking interface (per session) |
| | | • Dashboard: class overview, enrollment stats |
| **7–8** | Grades & Polish | • Grade entry interface (per assessment type) |
| | | • Grade calculation engine (weighted averages) |
| | | • Student progress view (grades + attendance) |
| | | • Notification system (in-app) |
| | | • Audit logging for all mutations |
| | | • Responsive UI polish + Vietnamese i18n |
| | | • Testing + bug fixes + deployment |

**Phase 1 Deliverables:**
- ✅ Management Dashboard (web app)
- ✅ Full academic CRUD operations
- ✅ Multi-branch data isolation
- ✅ Role-based access control (5 roles)
- ✅ Student progress tracking
- ✅ Audit trail
- ✅ Database schema for ALL modules (finance, HR, CRM tables exist but UI not built)

### 6.3 Phase 2 — Finance Module (Weeks 9–14)

**Goal:** Complete financial management with invoicing, payments, and reporting.

| Week | Sprint | Deliverables |
|---|---|---|
| **9–10** | Invoicing | • Invoice creation (manual + auto from enrollment) |
| | | • Invoice item management |
| | | • Discount engine (codes, early bird, sibling) |
| | | • Invoice PDF generation (Vietnamese template) |
| | | • Invoice status lifecycle management |
| **11–12** | Payments | • Payment recording (cash, transfer, e-wallet) |
| | | • Payment plan / installment setup |
| | | • Receipt generation |
| | | • Overdue invoice detection + auto-notifications |
| | | • Student financial dashboard (parent-visible) |
| **13–14** | Reports & Expenses | • Revenue reports (daily/weekly/monthly, by branch) |
| | | • Expense tracking and approval workflow |
| | | • Financial dashboard (charts, KPIs) |
| | | • Cash flow overview |
| | | • Export to Excel/PDF |
| | | • AI trigger: payment anomaly detection (basic rules) |

### 6.4 Phase 3 — HR & CRM Modules (Weeks 15–22)

**Goal:** Employee lifecycle management and lead-to-student conversion pipeline.

| Week | Sprint | Deliverables |
|---|---|---|
| **15–16** | HR Core | • Employee profile management |
| | | • Contract management (create, renew, terminate) |
| | | • Employee attendance tracking (check-in/out) |
| | | • Leave request + approval workflow |
| **17–18** | HR Payroll | • Payroll calculation engine |
| | | • Salary slip generation |
| | | • Tax + insurance deduction rules (Vietnam) |
| | | • Payroll approval + payment workflow |
| | | • HR dashboard with workforce analytics |
| **19–20** | CRM Pipeline | • Lead capture (manual + form integration) |
| | | • Lead pipeline (Kanban board view) |
| | | • Interaction logging (calls, emails, messages) |
| | | • Follow-up task management |
| | | • Lead → Student conversion flow |
| **21–22** | CRM Campaigns & AI | • Campaign management |
| | | • Campaign ROI tracking |
| | | • Lead scoring (rule-based → ML-ready) |
| | | • CRM dashboard + funnel analytics |
| | | • AI trigger setup: auto-scoring, auto-assignment |
| | | • Full platform integration testing |

### 6.5 Future Phases (Post-Launch)

| Phase | Timeline | Features |
|---|---|---|
| **Phase 4** | Weeks 23–28 | Student/Parent Portal (separate app), mobile-responsive |
| **Phase 5** | Weeks 29–34 | AI/ML Pipeline (automated progress reports, predictions) |
| **Phase 6** | Weeks 35–40 | Advanced: LMS integration, online classes, resource library |

---

## 7. API Integration Strategy & Security

### 7.1 API Design Standards

**RESTful Convention:**

```
Base URL: /api/v1

Academic Module:
  GET    /api/v1/students                    # List (paginated, filtered)
  POST   /api/v1/students                    # Create
  GET    /api/v1/students/:id                # Read
  PATCH  /api/v1/students/:id                # Update
  DELETE /api/v1/students/:id                # Soft delete
  GET    /api/v1/students/:id/enrollments    # Nested resource
  GET    /api/v1/students/:id/grades         # Nested resource
  POST   /api/v1/students/import             # Bulk import

  GET    /api/v1/classes                     # List
  POST   /api/v1/classes                     # Create
  GET    /api/v1/classes/:id/sessions        # Session list
  POST   /api/v1/classes/:id/sessions/:sid/attendance  # Mark attendance

Finance Module:
  GET    /api/v1/invoices                    # List
  POST   /api/v1/invoices                    # Create
  POST   /api/v1/invoices/:id/payments       # Record payment
  GET    /api/v1/finance/reports/revenue      # Revenue report
  GET    /api/v1/finance/reports/cashflow     # Cash flow report

HR Module:
  GET    /api/v1/hr/employees                # List
  POST   /api/v1/hr/employees/:id/attendance # Record check-in/out
  POST   /api/v1/hr/leave-requests           # Submit leave request
  PATCH  /api/v1/hr/leave-requests/:id       # Approve/reject

CRM Module:
  GET    /api/v1/crm/leads                   # List with pipeline view
  POST   /api/v1/crm/leads                   # Create
  POST   /api/v1/crm/leads/:id/interactions  # Log interaction
  POST   /api/v1/crm/leads/:id/convert       # Convert to student
```

**Standard Response Envelope:**

```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 150,
    "total_pages": 8
  },
  "errors": null,
  "timestamp": "2026-06-01T10:30:00Z"
}
```

**Standard Error Response:**

```json
{
  "success": false,
  "data": null,
  "errors": [
    {
      "code": "VALIDATION_ERROR",
      "field": "email",
      "message": "Email đã tồn tại trong hệ thống"
    }
  ],
  "timestamp": "2026-06-01T10:30:00Z"
}
```

### 7.2 Authentication & Authorization Flow

```
┌──────────┐                    ┌──────────────┐                    ┌──────────┐
│  Client   │                    │  API Gateway  │                    │ Database │
└─────┬────┘                    └──────┬───────┘                    └─────┬────┘
      │                               │                                  │
      │ 1. POST /auth/login            │                                  │
      │   { email, password }          │                                  │
      │──────────────────────────────►│                                  │
      │                               │ 2. Verify credentials            │
      │                               │─────────────────────────────────►│
      │                               │◄─────────────────────────────────│
      │                               │                                  │
      │ 3. { access_token (15min),     │                                  │
      │      refresh_token (7d) }      │                                  │
      │◄──────────────────────────────│                                  │
      │                               │                                  │
      │ 4. GET /api/v1/students        │                                  │
      │   Authorization: Bearer <AT>   │                                  │
      │   X-Branch-Id: <branch_uuid>   │                                  │
      │──────────────────────────────►│                                  │
      │                               │ 5. Verify JWT                    │
      │                               │ 6. Check RBAC permissions        │
      │                               │ 7. Set branch context (RLS)      │
      │                               │─────────────────────────────────►│
      │                               │  SELECT * FROM students          │
      │                               │  (RLS filters by branch)         │
      │                               │◄─────────────────────────────────│
      │ 8. { data: [...students] }     │                                  │
      │◄──────────────────────────────│                                  │
      │                               │                                  │
      │ 9. POST /auth/refresh          │                                  │
      │   { refresh_token }            │                                  │
      │──────────────────────────────►│                                  │
      │                               │ 10. Validate + rotate token      │
      │ 11. { new access_token,        │                                  │
      │       new refresh_token }      │                                  │
      │◄──────────────────────────────│                                  │
```

### 7.3 Security Measures

| Layer | Measure | Details |
|---|---|---|
| **Transport** | HTTPS/TLS 1.3 | All traffic encrypted; HSTS enabled |
| **Authentication** | JWT + Refresh Token Rotation | Access: 15-min; Refresh: 7-day; single-use rotation prevents replay |
| **Authorization** | RBAC + RLS | Application-level RBAC + database-level Row Level Security |
| **Input Validation** | Zod/class-validator | All inputs validated and sanitized at API boundary |
| **SQL Injection** | Parameterized Queries | Prisma ORM; raw SQL uses `$queryRawUnsafe` sparingly with params |
| **XSS** | CSP + Output Encoding | Content-Security-Policy headers; React auto-escapes by default |
| **CSRF** | SameSite Cookies + CSRF Token | Double-submit cookie pattern for session-based flows |
| **Rate Limiting** | Per-user + per-IP | Login: 5/min; API: 100/min per user; Global: 1000/min per IP |
| **Brute Force** | Account Lockout | 5 failed logins → 15-min lockout → escalating lockout |
| **Data at Rest** | Encryption | Sensitive fields (SSN, bank details) encrypted via application-level AES-256 |
| **Audit** | Full audit trail | Every mutation logged with user, IP, old/new values |
| **Secrets** | Environment variables | No secrets in code; .env files excluded from VCS; secrets manager in production |
| **Dependencies** | Automated scanning | `npm audit` + Snyk in CI/CD pipeline |
| **CORS** | Whitelist origins | Only known frontend domains allowed |
| **File Uploads** | Type + size validation | Allowed types whitelist, 10MB limit, virus scanning |

### 7.4 External Integration Points

```
┌─────────────────────────────────────────────────────────────────┐
│                  EXTERNAL INTEGRATIONS                           │
│                                                                 │
│  ┌─────────────────┐    ┌──────────────────┐                   │
│  │  Payment Gateways│    │  Communication    │                   │
│  │                 │    │                  │                   │
│  │  • VNPay        │    │  • Zalo OA (API) │                   │
│  │  • MoMo         │    │  • SMS Gateway   │                   │
│  │  • ZaloPay      │    │  • Email (SMTP)  │                   │
│  │  • Bank Transfer│    │  • Push (FCM)    │                   │
│  │    (webhook)    │    │                  │                   │
│  └─────────────────┘    └──────────────────┘                   │
│                                                                 │
│  ┌─────────────────┐    ┌──────────────────┐                   │
│  │  Cloud Services  │    │  Future AI/ML     │                   │
│  │                 │    │                  │                   │
│  │  • S3 (files)   │    │  • OpenAI API    │                   │
│  │  • CDN (assets) │    │  • Custom ML     │                   │
│  │  • Monitoring   │    │    models        │                   │
│  │    (Sentry)     │    │  • Analytics     │                   │
│  └─────────────────┘    └──────────────────┘                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 8. Synchronization Architecture

### 8.1 Real-Time Data Consistency Model

```
┌────────────────────────────────────────────────────────────────────────┐
│                   SYNC ARCHITECTURE                                    │
│                                                                        │
│   ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐       │
│   │ Client A  │    │ Client B  │    │ Client C  │    │ Client D  │       │
│   │(Dashboard)│    │(Teacher)  │    │(Parent)   │    │(Student)  │       │
│   └─────┬────┘    └─────┬────┘    └─────┬────┘    └─────┬────┘       │
│         │               │               │               │             │
│         │    WebSocket / Server-Sent Events (SSE)        │             │
│         │               │               │               │             │
│         ▼               ▼               ▼               ▼             │
│   ┌─────────────────────────────────────────────────────────┐         │
│   │                  REAL-TIME GATEWAY                       │         │
│   │                                                         │         │
│   │  • Connection Manager (Socket.IO rooms per branch)      │         │
│   │  • Event Router (role-based channel filtering)          │         │
│   │  • Presence Tracking (online users per branch)          │         │
│   └──────────────────────┬──────────────────────────────────┘         │
│                          │                                             │
│                          ▼                                             │
│   ┌─────────────────────────────────────────────────────────┐         │
│   │                  EVENT BUS (Redis Pub/Sub)               │         │
│   │                                                         │         │
│   │  Channels:                                              │         │
│   │  • branch:{id}:academic   (enrollment, attendance)      │         │
│   │  • branch:{id}:finance    (payment received)            │         │
│   │  • branch:{id}:hr         (leave approved)              │         │
│   │  • branch:{id}:crm        (lead status change)          │         │
│   │  • user:{id}:notifications (personal alerts)            │         │
│   │  • global:system          (maintenance, announcements)  │         │
│   └──────────────────────┬──────────────────────────────────┘         │
│                          │                                             │
│                          ▼                                             │
│   ┌─────────────────────────────────────────────────────────┐         │
│   │              APPLICATION SERVICES                        │         │
│   │                                                         │         │
│   │  On every mutation:                                     │         │
│   │  1. Write to PostgreSQL (source of truth)               │         │
│   │  2. Write to Event Store (audit + AI)                   │         │
│   │  3. Publish to Redis channel (real-time)                │         │
│   │  4. Invalidate Redis cache (stale data)                 │         │
│   │  5. Enqueue background jobs (notifications, reports)    │         │
│   └─────────────────────────────────────────────────────────┘         │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### 8.2 Consistency Guarantees

| Scenario | Strategy | Implementation |
|---|---|---|
| **Write consistency** | Synchronous DB write + async event publish | PostgreSQL transaction commits first; Redis publish is fire-and-forget with retry |
| **Read-after-write** | Immediate database read for the writing client | Mutations return the created/updated entity directly from DB |
| **Cross-client sync** | Eventual consistency via events (< 500ms) | Redis pub/sub delivers real-time updates; clients merge into local state |
| **Cache invalidation** | Write-through invalidation | Every write to DB triggers `CACHE.del(key)` for affected entities |
| **Conflict resolution** | Last-write-wins with optimistic locking | `updated_at` timestamp comparison; 409 Conflict on stale writes |
| **Offline reconciliation** | Queue + merge on reconnect | Client stores mutations locally; on reconnect, sends batch with timestamps |

### 8.3 Optimistic Locking Pattern

```typescript
// Every update includes version check
async updateStudent(id: string, data: UpdateStudentDto, expectedUpdatedAt: Date) {
  const result = await prisma.student.updateMany({
    where: {
      id,
      updated_at: expectedUpdatedAt  // optimistic lock
    },
    data: {
      ...data,
      updated_at: new Date()
    }
  });

  if (result.count === 0) {
    throw new ConflictException(
      'Record was modified by another user. Please refresh and try again.'
    );
  }

  // Publish real-time event
  await eventBus.publish(`branch:${branchId}:academic`, {
    type: 'student.updated',
    data: { id, changes: data },
    timestamp: new Date()
  });
}
```

### 8.4 Multi-Branch Data Sync Patterns

```
Scenario: Super Admin views data across all branches

┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  Branch HCM  │    │  Branch HN   │    │  Branch DN   │
│  (Primary)   │    │  (Branch 2)  │    │  (Branch 3)  │
└──────┬──────┘    └──────┬──────┘    └──────┬──────┘
       │                  │                  │
       └──────────────────┴──────────────────┘
                          │
                          ▼
              ┌──────────────────────┐
              │  Aggregation Layer    │
              │                      │
              │  • Cross-branch SQL  │
              │    (super_admin      │
              │     bypasses RLS)    │
              │  • Materialized      │
              │    views for KPIs    │
              │  • Redis-cached      │
              │    aggregate stats   │
              └──────────────────────┘
```

**Cross-Branch Aggregation Queries (Super Admin only):**

```sql
-- Materialized view: refreshed every 5 minutes via background job
CREATE MATERIALIZED VIEW system.branch_kpi_summary AS
SELECT
    b.id AS branch_id,
    b.name AS branch_name,
    (SELECT COUNT(*) FROM academic.students s WHERE s.branch_id = b.id AND s.status = 'active') AS active_students,
    (SELECT COUNT(*) FROM academic.classes c WHERE c.branch_id = b.id AND c.status = 'in_progress') AS active_classes,
    (SELECT COALESCE(SUM(p.amount), 0) FROM finance.payments p WHERE p.branch_id = b.id AND p.payment_date >= date_trunc('month', CURRENT_DATE)) AS mtd_revenue,
    (SELECT COUNT(*) FROM crm.leads l WHERE l.branch_id = b.id AND l.status = 'new' AND l.created_at >= date_trunc('week', CURRENT_DATE)) AS new_leads_this_week
FROM core.branches b
WHERE b.is_active = true;

-- Refresh schedule
CREATE OR REPLACE FUNCTION system.refresh_kpi_summary()
RETURNS void AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY system.branch_kpi_summary;
END;
$$ LANGUAGE plpgsql;
```

### 8.5 Background Job Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                  BACKGROUND JOB QUEUES (BullMQ)                 │
│                                                                 │
│  ┌─────────────────┐  Priority: CRITICAL                       │
│  │ notification     │  • Payment confirmation                   │
│  │ queue            │  • Class reminders (30min before)          │
│  │                 │  • Overdue invoice alerts                  │
│  └─────────────────┘                                            │
│                                                                 │
│  ┌─────────────────┐  Priority: HIGH                           │
│  │ sync             │  • Attendance rate recalculation           │
│  │ queue            │  • Invoice balance sync after payment      │
│  │                 │  • Lead score recalculation                │
│  └─────────────────┘                                            │
│                                                                 │
│  ┌─────────────────┐  Priority: NORMAL                         │
│  │ report           │  • PDF report generation                  │
│  │ queue            │  • Excel export                           │
│  │                 │  • Bulk email campaigns                   │
│  └─────────────────┘                                            │
│                                                                 │
│  ┌─────────────────┐  Priority: LOW                            │
│  │ analytics        │  • KPI materialized view refresh          │
│  │ queue            │  • AI feature computation                 │
│  │                 │  • Data cleanup / archival                 │
│  └─────────────────┘                                            │
│                                                                 │
│  ┌─────────────────┐  Schedule: CRON                           │
│  │ scheduled        │  • Daily: overdue invoice check            │
│  │ queue            │  • Weekly: progress digest emails          │
│  │                 │  • Monthly: payroll calculation trigger     │
│  │                 │  • Every 5min: KPI summary refresh         │
│  └─────────────────┘                                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Appendix A: Database Naming Conventions

| Convention | Example | Rule |
|---|---|---|
| Table names | `students`, `class_sessions` | Plural, snake_case |
| Column names | `student_code`, `created_at` | Singular, snake_case |
| Primary keys | `id` | Always `UUID`, column named `id` |
| Foreign keys | `student_id`, `branch_id` | `{referenced_table_singular}_id` |
| Timestamps | `created_at`, `updated_at` | Always `TIMESTAMPTZ`, always present |
| Boolean | `is_active`, `is_primary` | Prefix with `is_` or `has_` |
| JSONB | `metadata`, `settings` | Used for extensible / semi-structured data |
| Status enums | `status VARCHAR(20)` with CHECK | Inline CHECK constraint, not separate enum type |
| Indexes | `idx_{table}_{column}` | Descriptive, prefixed with `idx_` |

## Appendix B: Vietnamese i18n Strategy

```typescript
// i18n structure: /locales/vi.json
{
  "academic": {
    "student": {
      "title": "Quản lý Học viên",
      "fields": {
        "student_code": "Mã học viên",
        "full_name": "Họ và tên",
        "date_of_birth": "Ngày sinh",
        "enrollment_date": "Ngày nhập học",
        "status": "Trạng thái"
      },
      "status_labels": {
        "active": "Đang học",
        "inactive": "Tạm nghỉ",
        "graduated": "Đã tốt nghiệp",
        "suspended": "Đình chỉ",
        "withdrawn": "Đã rút"
      },
      "actions": {
        "create": "Thêm học viên mới",
        "edit": "Chỉnh sửa thông tin",
        "enroll": "Đăng ký lớp học"
      }
    }
  }
}
```

## Appendix C: Environment Configuration

```bash
# .env.example
# ─── Database ───
DATABASE_URL=postgresql://aea_user:password@localhost:5432/aea_db?schema=public
DATABASE_POOL_MIN=5
DATABASE_POOL_MAX=20

# ─── Redis ───
REDIS_URL=redis://localhost:6379

# ─── Auth ───
JWT_SECRET=<64-char-random>
JWT_ACCESS_EXPIRES=15m
JWT_REFRESH_EXPIRES=7d

# ─── File Storage ───
S3_ENDPOINT=http://localhost:9000
S3_BUCKET=aea-files
S3_ACCESS_KEY=<key>
S3_SECRET_KEY=<secret>

# ─── App ───
APP_PORT=3000
APP_ENV=development
FRONTEND_URL=http://localhost:3001
CORS_ORIGINS=http://localhost:3001

# ─── Notifications ───
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=noreply@yourdomain.com
SMTP_PASS=<app-password>
```

---

*Document prepared as the architectural blueprint for the AEA Education Management Ecosystem. All schemas, patterns, and designs in this document are intended to guide implementation across all development phases.*
