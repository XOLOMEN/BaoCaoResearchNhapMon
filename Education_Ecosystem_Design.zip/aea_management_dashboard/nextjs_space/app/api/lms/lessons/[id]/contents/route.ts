export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { canModifyLms } from '@/lib/lms/helpers';

// ── GET: List contents for a lesson ──
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const contents = await prisma.lmsContent.findMany({
      where: { lessonId: params.id },
      orderBy: { sortOrder: 'asc' },
    });
    return NextResponse.json(contents);
  } catch (error: any) {
    console.error('LMS contents GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Add content to lesson ──
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLms(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const body = await request.json();
    const { type, title, body: bodyContent, fileUrl, fileSizeBytes, durationSec, sortOrder, metadata } = body;
    if (!type) return NextResponse.json({ error: 'type bắt buộc' }, { status: 400 });

    const content = await prisma.lmsContent.create({
      data: {
        lessonId: params.id,
        type,
        title: title || null,
        body: bodyContent || null,
        fileUrl: fileUrl || null,
        fileSizeBytes: fileSizeBytes ? parseInt(fileSizeBytes) : null,
        durationSec: durationSec ? parseInt(durationSec) : null,
        sortOrder: sortOrder || 0,
        metadata: metadata || {},
      },
    });

    return NextResponse.json(content, { status: 201 });
  } catch (error: any) {
    console.error('LMS contents POST error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
