export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const classId = url.searchParams.get('classId');
    const studentId = url.searchParams.get('studentId');
    const where: any = {};
    if (branchId) where.branchId = branchId;
    if (classId) where.classId = classId;
    if (studentId) where.studentId = studentId;

    const enrollments = await prisma.enrollment.findMany({
      where,
      include: {
        student: { select: { fullName: true, studentCode: true, level: true } },
        class: {
          select: { name: true, classCode: true, status: true,
            course: { select: { name: true, code: true } },
            teacher: { select: { fullName: true } },
          },
        },
        branch: { select: { name: true } },
      },
      orderBy: { enrolledAt: 'desc' },
    });
    return NextResponse.json({ enrollments });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { studentId, classId, branchId } = body ?? {};
    if (!studentId || !classId || !branchId) {
      return NextResponse.json({ error: 'Thiếu thông tin' }, { status: 400 });
    }

    // Check capacity
    const cls = await prisma.class.findUnique({
      where: { id: classId },
      include: { _count: { select: { enrollments: true } } },
    });
    if (!cls) return NextResponse.json({ error: 'Lớp không tồn tại' }, { status: 404 });
    if ((cls?._count?.enrollments ?? 0) >= (cls?.capacity ?? 0)) {
      return NextResponse.json({ error: 'Lớp đã đầy' }, { status: 400 });
    }

    // Get course tuition fee for auto-invoice
    const course = await prisma.course.findFirst({
      where: { classes: { some: { id: classId } } },
      select: { id: true, name: true, tuitionFee: true, materialsFee: true },
    });

    // Get branch code for invoice number
    const branch = await prisma.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const branchCode = branch?.code || 'XX';
    const now = new Date();
    const yyMM = `${String(now.getFullYear()).slice(-2)}${String(now.getMonth() + 1).padStart(2, '0')}`;

    // Count existing invoices this month for sequence number
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const invoiceCount = await prisma.invoice.count({
      where: { branchId, createdAt: { gte: monthStart, lt: monthEnd } },
    });
    const seq = String(invoiceCount + 1).padStart(4, '0');
    const invoiceNumber = `INV-${branchCode}-${yyMM}-${seq}`;

    const tuitionFee = course?.tuitionFee || 0;
    const materialsFee = course?.materialsFee || 0;
    const totalAmount = tuitionFee + materialsFee;
    const dueDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // +30 days

    // Transaction: create enrollment + auto-create draft invoice
    const [enrollment, invoice] = await prisma.$transaction([
      prisma.enrollment.create({
        data: { studentId, classId, branchId, status: 'active', enrolledAt: now },
      }),
      ...(totalAmount > 0 ? [
        prisma.invoice.create({
          data: {
            branchId,
            invoiceNumber,
            studentId,
            type: 'tuition',
            subtotal: totalAmount,
            discountAmount: 0,
            taxAmount: 0,
            totalAmount,
            paidAmount: 0,
            currency: 'VND',
            dueDate,
            status: 'draft',
            notes: `Tự động tạo khi ghi danh khóa ${course?.name || ''}`,
            items: {
              create: [
                ...(tuitionFee > 0 ? [{ description: `Học phí - ${course?.name || 'Khóa học'}`, quantity: 1, unitPrice: tuitionFee, amount: tuitionFee }] : []),
                ...(materialsFee > 0 ? [{ description: 'Phí tài liệu', quantity: 1, unitPrice: materialsFee, amount: materialsFee }] : []),
              ],
            },
          },
        }),
      ] : []),
    ]);

    // Link invoice to enrollment if created
    if (invoice && totalAmount > 0) {
      await prisma.invoice.update({
        where: { id: invoice.id },
        data: { enrollmentId: enrollment.id },
      });
    }

    return NextResponse.json({ enrollment, invoice: invoice || null }, { status: 201 });
  } catch (error: any) {
    console.error(error);
    if (error?.code === 'P2002') return NextResponse.json({ error: 'Học viên đã ghi danh lớp này' }, { status: 409 });
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
