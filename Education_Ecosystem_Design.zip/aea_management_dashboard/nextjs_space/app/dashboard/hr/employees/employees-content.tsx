'use client';
import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Users, Plus, Search, Briefcase, Building2, UserCog } from 'lucide-react';
import { toast } from 'sonner';
import { useBranch } from '@/hooks/use-branch';
import { formatDate, formatCurrency, getStatusColor, getStatusLabel } from '@/lib/helpers';
import { FadeIn } from '@/components/ui/animate';

export function EmployeesContent() {
  const { branchId } = useBranch();
  const [employees, setEmployees] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    branchId: '', employeeCode: '', fullName: '', email: '', phone: '',
    department: 'academic', position: 'teacher', employmentType: 'full_time',
    hireDate: '', gender: '', teacherId: '',
  });

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (branchId) params.set('branchId', branchId);
      if (search) params.set('search', search);

      const [empRes, brRes, teaRes] = await Promise.all([
        fetch(`/api/hr/employees?${params}`),
        fetch('/api/branches'),
        fetch('/api/teachers'),
      ]);
      const [empData, brData, teaData] = await Promise.all([empRes.json(), brRes.json(), teaRes.json()]);
      setEmployees(empData.employees || []);
      setBranches(brData.branches || []);
      setTeachers(teaData.teachers || []);
    } catch { toast.error('Lỗi tải dữ liệu'); }
    setLoading(false);
  }, [branchId, search]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleAdd = async () => {
    if (!form.branchId || !form.employeeCode || !form.fullName) {
      toast.error('Vui lòng nhập mã NV, họ tên và chọn chi nhánh');
      return;
    }
    try {
      const res = await fetch('/api/hr/employees', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, teacherId: form.teacherId === 'none' ? '' : form.teacherId }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success('Thêm nhân viên thành công');
      setShowAdd(false);
      setForm({ branchId: '', employeeCode: '', fullName: '', email: '', phone: '', department: 'academic', position: 'teacher', employmentType: 'full_time', hireDate: '', gender: '', teacherId: '' });
      fetchData();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  const deptLabels: Record<string, string> = {
    academic: 'Giáo vụ', finance: 'Tài chính', hr: 'Nhân sự',
    marketing: 'Marketing', admin: 'Hành chính', it: 'CNTT',
  };
  const posLabels: Record<string, string> = {
    teacher: 'Giáo viên', manager: 'Quản lý', staff: 'Nhân viên',
    admin: 'Hành chính', director: 'Giám đốc',
  };

  return (
    <FadeIn>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Quản lý Nhân viên</h2>
            <p className="text-sm text-muted-foreground">Danh sách nhân sự toàn hệ thống</p>
          </div>
          <Button onClick={() => { setForm(f => ({ ...f, branchId: branchId || '' })); setShowAdd(true); }}>
            <Plus className="w-4 h-4 mr-2" /> Thêm nhân viên
          </Button>
        </div>

        {/* Search */}
        <div className="flex gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Tìm theo tên, mã NV, email..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100"><Users className="w-5 h-5 text-blue-600" /></div>
              <div><p className="text-sm text-muted-foreground">Tổng NV</p><p className="text-xl font-bold">{employees.length}</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-100"><Briefcase className="w-5 h-5 text-emerald-600" /></div>
              <div><p className="text-sm text-muted-foreground">Đang làm việc</p><p className="text-xl font-bold">{employees.filter(e => e.status === 'active').length}</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-100"><Building2 className="w-5 h-5 text-amber-600" /></div>
              <div><p className="text-sm text-muted-foreground">Phòng ban</p><p className="text-xl font-bold">{new Set(employees.map(e => e.department)).size}</p></div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-100"><UserCog className="w-5 h-5 text-purple-600" /></div>
              <div><p className="text-sm text-muted-foreground">Liên kết GV</p><p className="text-xl font-bold">{employees.filter(e => e.teacherId).length}</p></div>
            </CardContent>
          </Card>
        </div>

        {/* Employee Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="p-3 text-left font-medium">Mã NV</th>
                    <th className="p-3 text-left font-medium">Họ tên</th>
                    <th className="p-3 text-left font-medium">Phòng ban</th>
                    <th className="p-3 text-left font-medium">Chức vụ</th>
                    <th className="p-3 text-left font-medium">Chi nhánh</th>
                    <th className="p-3 text-left font-medium">Liên kết GV</th>
                    <th className="p-3 text-left font-medium">Lương cơ bản</th>
                    <th className="p-3 text-left font-medium">Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">Đang tải...</td></tr>
                  ) : employees.length === 0 ? (
                    <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">Chưa có nhân viên nào</td></tr>
                  ) : employees.map((emp: any) => (
                    <tr key={emp.id} className="border-b hover:bg-muted/30 transition-colors">
                      <td className="p-3 font-mono text-xs">{emp.employeeCode}</td>
                      <td className="p-3 font-medium">{emp.fullName}</td>
                      <td className="p-3">{deptLabels[emp.department] || emp.department}</td>
                      <td className="p-3">{posLabels[emp.position] || emp.position}</td>
                      <td className="p-3">{emp.branch?.name}</td>
                      <td className="p-3">
                        {emp.teacher ? (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 text-xs">
                            {emp.teacher.fullName}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </td>
                      <td className="p-3">
                        {emp.contracts?.[0] ? formatCurrency(emp.contracts[0].baseSalary) : '—'}
                      </td>
                      <td className="p-3">
                        <Badge className={getStatusColor(emp.status)}>{getStatusLabel(emp.status)}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Add Dialog */}
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Thêm nhân viên mới</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-2">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Chi nhánh *</Label>
                  <Select value={form.branchId} onValueChange={v => setForm(f => ({ ...f, branchId: v }))}>
                    <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                    <SelectContent>
                      {branches.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Mã nhân viên *</Label>
                  <Input value={form.employeeCode} onChange={e => setForm(f => ({ ...f, employeeCode: e.target.value }))} placeholder="NV-001" />
                </div>
              </div>
              <div>
                <Label>Họ và tên *</Label>
                <Input value={form.fullName} onChange={e => setForm(f => ({ ...f, fullName: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Email</Label>
                  <Input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                </div>
                <div>
                  <Label>SĐT</Label>
                  <Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Phòng ban</Label>
                  <Select value={form.department} onValueChange={v => setForm(f => ({ ...f, department: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="academic">Giáo vụ</SelectItem>
                      <SelectItem value="finance">Tài chính</SelectItem>
                      <SelectItem value="hr">Nhân sự</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="admin">Hành chính</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Chức vụ</Label>
                  <Select value={form.position} onValueChange={v => setForm(f => ({ ...f, position: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="teacher">Giáo viên</SelectItem>
                      <SelectItem value="manager">Quản lý</SelectItem>
                      <SelectItem value="staff">Nhân viên</SelectItem>
                      <SelectItem value="admin">Hành chính</SelectItem>
                      <SelectItem value="director">Giám đốc</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Hình thức</Label>
                  <Select value={form.employmentType} onValueChange={v => setForm(f => ({ ...f, employmentType: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full_time">Toàn thời gian</SelectItem>
                      <SelectItem value="part_time">Bán thời gian</SelectItem>
                      <SelectItem value="freelance">Freelance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Ngày vào làm</Label>
                  <Input type="date" value={form.hireDate} onChange={e => setForm(f => ({ ...f, hireDate: e.target.value }))} />
                </div>
              </div>
              <div>
                <Label>Liên kết giáo viên (nếu là GV)</Label>
                <Select value={form.teacherId} onValueChange={v => setForm(f => ({ ...f, teacherId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Không liên kết" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Không liên kết</SelectItem>
                    {teachers.map((t: any) => <SelectItem key={t.id} value={t.id}>{t.fullName} ({t.employeeCode})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAdd(false)}>Hủy</Button>
              <Button onClick={handleAdd}>Lưu</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </FadeIn>
  );
}
