import { EnrollmentsContent } from './enrollments-content';
export default function EnrollmentsPage() { return <EnrollmentsContent />; }
