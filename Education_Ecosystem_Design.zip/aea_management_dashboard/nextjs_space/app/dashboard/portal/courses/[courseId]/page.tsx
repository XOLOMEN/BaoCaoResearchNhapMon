import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import CourseDetailContent from './course-detail-content';

export default async function CourseDetailPage({ params }: { params: { courseId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== 'student') redirect('/dashboard');
  return <CourseDetailContent courseId={params.courseId} />;
}
