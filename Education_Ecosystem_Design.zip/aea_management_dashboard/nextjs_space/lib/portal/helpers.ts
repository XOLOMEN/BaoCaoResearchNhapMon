import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { NextResponse } from 'next/server';

export async function getStudentSession() {
  const session = await getServerSession(authOptions);
  if (!session) return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }), session: null };
  if (session.user.role !== 'student' || !session.user.studentId) {
    return { error: NextResponse.json({ error: 'Student access only' }, { status: 403 }), session: null };
  }
  return { error: null, session };
}

export async function getParentSession() {
  const session = await getServerSession(authOptions);
  if (!session) return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }), session: null };
  if (session.user.role !== 'parent' || !session.user.parentId) {
    return { error: NextResponse.json({ error: 'Parent access only' }, { status: 403 }), session: null };
  }
  return { error: null, session };
}

export async function getPortalSession() {
  const session = await getServerSession(authOptions);
  if (!session) return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }), session: null };
  if (!['student', 'parent'].includes(session.user.role)) {
    return { error: NextResponse.json({ error: 'Portal access only' }, { status: 403 }), session: null };
  }
  return { error: null, session };
}
