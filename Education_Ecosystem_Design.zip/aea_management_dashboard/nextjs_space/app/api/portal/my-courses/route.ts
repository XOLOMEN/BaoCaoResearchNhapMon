export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getStudentSession } from '@/lib/portal/helpers';

export async function GET(req: NextRequest) {
  const { error, session } = await getStudentSession();
  if (error) return error;
  const studentId = session!.user.studentId!;
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') || undefined;

  try {
    const enrollments = await prisma.lmsEnrollment.findMany({
      where: { studentId, ...(status ? { status } : {}) },
      include: {
        lmsCourse: {
          select: {
            id: true, title: true, slug: true, description: true, thumbnail: true,
            level: true, category: true, totalLessons: true, totalDuration: true,
            instructorUser: { select: { fullName: true, avatarUrl: true } },
          },
        },
      },
      orderBy: { enrolledAt: 'desc' },
    });

    return NextResponse.json({ enrollments });
  } catch (err: any) {
    console.error('Portal my-courses error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
