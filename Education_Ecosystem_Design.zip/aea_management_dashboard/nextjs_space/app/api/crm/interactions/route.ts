export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

const VALID_TYPES = ['call', 'email', 'meeting', 'note', 'sms', 'visit', 'demo', 'other'];
const VALID_DIRECTIONS = ['inbound', 'outbound'];

// ── GET: List interactions for a lead ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const leadId = url.searchParams.get('leadId');
    if (!leadId) return NextResponse.json({ error: 'Thiếu leadId' }, { status: 400 });

    // Branch-scope: verify lead belongs to user's branch
    const lead = await prisma.crmLead.findUnique({ where: { id: leadId }, select: { branchId: true } });
    if (!lead) return NextResponse.json({ error: 'Không tìm thấy lead' }, { status: 404 });
    if (session.user.role !== 'super_admin' && lead.branchId !== session.user.primaryBranchId) {
      return NextResponse.json({ error: 'Không có quyền xem tương tác lead chi nhánh khác' }, { status: 403 });
    }

    const interactions = await prisma.crmInteraction.findMany({
      where: { leadId },
      include: {
        contactor: { select: { id: true, fullName: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      interactions: interactions.map((i: any) => ({
        ...i,
        createdAt: i.createdAt?.toISOString(),
        nextFollowUp: i.nextFollowUp?.toISOString() || null,
      })),
    });
  } catch (error: any) {
    console.error('[CRM/Interactions GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Create new interaction ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const role = session.user.role;
    if (role !== 'super_admin' && role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền tạo tương tác' }, { status: 403 });
    }

    const body = await request.json();
    const { leadId, type, direction, channel, subject, content, durationMinutes, outcome, nextFollowUp } = body ?? {};

    if (!leadId || !type) {
      return NextResponse.json({ error: 'Thiếu leadId hoặc type' }, { status: 400 });
    }
    if (!VALID_TYPES.includes(type)) {
      return NextResponse.json({ error: `Loại tương tác không hợp lệ. Chấp nhận: ${VALID_TYPES.join(', ')}` }, { status: 400 });
    }

    // Verify lead & branch scope
    const lead = await prisma.crmLead.findUnique({ where: { id: leadId }, select: { branchId: true, status: true } });
    if (!lead) return NextResponse.json({ error: 'Không tìm thấy lead' }, { status: 404 });
    if (role !== 'super_admin' && lead.branchId !== session.user.primaryBranchId) {
      return NextResponse.json({ error: 'Không có quyền thao tác lead chi nhánh khác' }, { status: 403 });
    }

    const interaction = await prisma.crmInteraction.create({
      data: {
        leadId,
        type,
        direction: direction && VALID_DIRECTIONS.includes(direction) ? direction : null,
        channel: channel || null,
        subject: subject || null,
        content: content || null,
        durationMinutes: durationMinutes ? parseInt(durationMinutes) : null,
        contactedBy: session.user.id,
        outcome: outcome || null,
        nextFollowUp: nextFollowUp ? new Date(nextFollowUp) : null,
      },
      include: {
        contactor: { select: { fullName: true } },
      },
    });

    // Update lead's lastContacted and nextFollowUp
    const updateData: any = { lastContacted: new Date() };
    if (nextFollowUp) updateData.nextFollowUp = new Date(nextFollowUp);
    await prisma.crmLead.update({ where: { id: leadId }, data: updateData });

    return NextResponse.json({ interaction }, { status: 201 });
  } catch (error: any) {
    console.error('[CRM/Interactions POST]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}
