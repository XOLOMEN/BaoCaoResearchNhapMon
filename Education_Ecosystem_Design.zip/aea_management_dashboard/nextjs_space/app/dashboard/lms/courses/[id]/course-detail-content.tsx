'use client';

import { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FadeIn } from '@/components/ui/animate';
import { ArrowLeft, Plus, BookOpen, Video, FileText, HelpCircle, Users, Clock, GripVertical, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { formatCurrency, getStatusColor, getLevelLabel } from '@/lib/helpers';
import Link from 'next/link';

const LESSON_TYPE_ICONS: Record<string, any> = {
  video: Video,
  text: FileText,
  quiz: HelpCircle,
  assignment: FileText,
  live: Video,
};

const LESSON_TYPE_LABELS: Record<string, string> = {
  video: 'Video',
  text: 'Văn bản',
  quiz: 'Quiz',
  assignment: 'Bài tập',
  live: 'Live',
};

export function CourseDetailContent() {
  const params = useParams();
  const router = useRouter();
  const courseId = params.id as string;
  const [course, setCourse] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [lessonDialogOpen, setLessonDialogOpen] = useState(false);
  const [lessonForm, setLessonForm] = useState({ title: '', description: '', type: 'video', durationMin: '', isFree: false });
  const [enrollDialogOpen, setEnrollDialogOpen] = useState(false);
  const [students, setStudents] = useState<any[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [enrollments, setEnrollments] = useState<any[]>([]);

  const fetchCourse = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/lms/courses/${courseId}`);
      if (!res.ok) { toast.error('Không tìm thấy khóa học'); router.push('/dashboard/lms/courses'); return; }
      setCourse(await res.json());
    } catch { toast.error('Lỗi tải dữ liệu'); }
    setLoading(false);
  }, [courseId, router]);

  const fetchEnrollments = useCallback(async () => {
    const res = await fetch(`/api/lms/enrollments?lmsCourseId=${courseId}`);
    if (res.ok) setEnrollments(await res.json());
  }, [courseId]);

  useEffect(() => { fetchCourse(); fetchEnrollments(); }, [fetchCourse, fetchEnrollments]);

  const handleAddLesson = async () => {
    if (!lessonForm.title) { toast.error('Tên bài học bắt buộc'); return; }
    try {
      const res = await fetch(`/api/lms/courses/${courseId}/lessons`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lessonForm),
      });
      if (!res.ok) { const e = await res.json(); toast.error(e.error); return; }
      toast.success('Thêm bài học thành công');
      setLessonDialogOpen(false);
      setLessonForm({ title: '', description: '', type: 'video', durationMin: '', isFree: false });
      fetchCourse();
    } catch { toast.error('Lỗi thêm bài học'); }
  };

  const handleEnroll = async () => {
    if (!selectedStudentId) { toast.error('Chọn học viên'); return; }
    try {
      const res = await fetch('/api/lms/enrollments', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lmsCourseId: courseId, studentId: selectedStudentId, branchId: course?.branchId }),
      });
      if (!res.ok) { const e = await res.json(); toast.error(e.error); return; }
      toast.success('Đăng ký thành công');
      setEnrollDialogOpen(false);
      setSelectedStudentId('');
      fetchEnrollments();
      fetchCourse();
    } catch { toast.error('Lỗi đăng ký'); }
  };

  const openEnrollDialog = async () => {
    const res = await fetch(`/api/students?branchId=${course?.branchId || ''}&limit=200`);
    if (res.ok) { const d = await res.json(); setStudents(d.students || d); }
    setEnrollDialogOpen(true);
  };

  if (loading) return <div className="p-8 text-muted-foreground">Đang tải...</div>;
  if (!course) return null;

  return (
    <FadeIn>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Link href="/dashboard/lms/courses"><Button variant="ghost" size="icon"><ArrowLeft className="h-4 w-4" /></Button></Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{course.title}</h1>
            <p className="text-muted-foreground">{course.description || 'Chưa có mô tả'}</p>
          </div>
          <Badge className={course.isPublished ? getStatusColor('published') : getStatusColor('draft')}>
            {course.isPublished ? 'Đã xuất bản' : 'Nháp'}
          </Badge>
        </div>

        {/* Course Info */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card><CardContent className="pt-4 text-center"><p className="text-sm text-muted-foreground">Bài học</p><p className="text-xl font-bold">{course._count?.lessons || 0}</p></CardContent></Card>
          <Card><CardContent className="pt-4 text-center"><p className="text-sm text-muted-foreground">Học viên</p><p className="text-xl font-bold">{course._count?.enrollments || 0}</p></CardContent></Card>
          <Card><CardContent className="pt-4 text-center"><p className="text-sm text-muted-foreground">Chứng chỉ</p><p className="text-xl font-bold">{course._count?.certificates || 0}</p></CardContent></Card>
          <Card><CardContent className="pt-4 text-center"><p className="text-sm text-muted-foreground">Trình độ</p><p className="text-xl font-bold">{getLevelLabel(course.level)}</p></CardContent></Card>
          <Card><CardContent className="pt-4 text-center"><p className="text-sm text-muted-foreground">Học phí</p><p className="text-xl font-bold">{course.price > 0 ? formatCurrency(course.price) : 'Miễn phí'}</p></CardContent></Card>
        </div>

        {/* Lessons */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2"><BookOpen className="h-5 w-5" /> Danh sách bài học ({course.lessons?.length || 0})</CardTitle>
              <Dialog open={lessonDialogOpen} onOpenChange={setLessonDialogOpen}>
                <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1" /> Thêm bài học</Button></DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Thêm bài học mới</DialogTitle></DialogHeader>
                  <div className="space-y-4 py-4">
                    <div><Label>Tên bài học *</Label><Input value={lessonForm.title} onChange={e => setLessonForm(p => ({...p, title: e.target.value}))} placeholder="Nhập tên bài học" /></div>
                    <div><Label>Mô tả</Label><Input value={lessonForm.description} onChange={e => setLessonForm(p => ({...p, description: e.target.value}))} /></div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><Label>Loại</Label>
                        <Select value={lessonForm.type} onValueChange={v => setLessonForm(p => ({...p, type: v}))}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="video">Video</SelectItem>
                            <SelectItem value="text">Văn bản</SelectItem>
                            <SelectItem value="quiz">Quiz</SelectItem>
                            <SelectItem value="assignment">Bài tập</SelectItem>
                            <SelectItem value="live">Live</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div><Label>Thời lượng (phút)</Label><Input type="number" value={lessonForm.durationMin} onChange={e => setLessonForm(p => ({...p, durationMin: e.target.value}))} /></div>
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="isFree" checked={lessonForm.isFree} onChange={e => setLessonForm(p => ({...p, isFree: e.target.checked}))} />
                      <Label htmlFor="isFree">Bài học miễn phí (xem trước)</Label>
                    </div>
                  </div>
                  <DialogFooter>
                    <DialogClose asChild><Button variant="outline">Hủy</Button></DialogClose>
                    <Button onClick={handleAddLesson}>Thêm</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {(!course.lessons || course.lessons.length === 0) ? (
              <p className="text-muted-foreground text-center py-6">Chưa có bài học. Hãy thêm bài học đầu tiên!</p>
            ) : (
              <div className="space-y-2">
                {course.lessons.map((lesson: any, idx: number) => {
                  const Icon = LESSON_TYPE_ICONS[lesson.type] || FileText;
                  return (
                    <div key={lesson.id} className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                      <span className="text-muted-foreground text-sm font-medium w-6 text-center">{idx + 1}</span>
                      <Icon className="h-5 w-5 text-muted-foreground shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{lesson.title}</p>
                        <div className="flex gap-2 text-xs text-muted-foreground">
                          <span>{LESSON_TYPE_LABELS[lesson.type] || lesson.type}</span>
                          {lesson.durationMin && <span>· {lesson.durationMin} phút</span>}
                          {lesson.isFree && <Badge variant="outline" className="text-xs h-4">Miễn phí</Badge>}
                          {lesson.quiz && <Badge variant="outline" className="text-xs h-4">Có Quiz</Badge>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Users className="h-3 w-3" /> {lesson._count?.progress || 0}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Enrollments */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2"><Users className="h-5 w-5" /> Học viên đăng ký ({enrollments.length})</CardTitle>
              <Button size="sm" onClick={openEnrollDialog}><Plus className="h-4 w-4 mr-1" /> Đăng ký học viên</Button>
            </div>
          </CardHeader>
          <CardContent>
            {enrollments.length === 0 ? (
              <p className="text-muted-foreground text-center py-6">Chưa có học viên đăng ký</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b text-left">
                    <th className="p-2">Học viên</th><th className="p-2">Mã HV</th><th className="p-2">Tiến độ</th><th className="p-2">Trạng thái</th>
                  </tr></thead>
                  <tbody>
                    {enrollments.map((e: any) => (
                      <tr key={e.id} className="border-b hover:bg-muted/50">
                        <td className="p-2 font-medium">{e.student?.fullName}</td>
                        <td className="p-2 text-muted-foreground">{e.student?.studentCode}</td>
                        <td className="p-2">
                          <div className="flex items-center gap-2">
                            <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                              <div className="h-full bg-blue-500 rounded-full" style={{ width: `${e.progressPct}%` }} />
                            </div>
                            <span className="text-xs">{Math.round(e.progressPct)}%</span>
                          </div>
                        </td>
                        <td className="p-2"><Badge className={getStatusColor(e.status)}>{e.status === 'active' ? 'Đang học' : e.status === 'completed' ? 'Hoàn thành' : e.status}</Badge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Enroll Dialog */}
        <Dialog open={enrollDialogOpen} onOpenChange={setEnrollDialogOpen}>
          <DialogContent>
            <DialogHeader><DialogTitle>Đăng ký học viên vào khóa học</DialogTitle></DialogHeader>
            <div className="py-4">
              <Label>Chọn học viên</Label>
              <Select value={selectedStudentId} onValueChange={setSelectedStudentId}>
                <SelectTrigger><SelectValue placeholder="Chọn học viên" /></SelectTrigger>
                <SelectContent>
                  {students.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.fullName} ({s.studentCode})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline">Hủy</Button></DialogClose>
              <Button onClick={handleEnroll}>Đăng ký</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </FadeIn>
  );
}
