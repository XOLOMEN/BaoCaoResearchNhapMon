'use client';
import { useState, useEffect, useCallback } from 'react';

export function useBranch() {
  const [branchId, setBranchId] = useState<string | null>(null);
  const [allBranches, setAllBranches] = useState(false);

  useEffect(() => {
    const stored = typeof window !== 'undefined' ? window.localStorage?.getItem?.('aea_branch_id') : null;
    if (stored) {
      setBranchId(stored);
      setAllBranches(false);
    } else {
      setAllBranches(true);
    }

    const handler = (e: any) => {
      const detail = e?.detail ?? {};
      if (detail.all) {
        setBranchId(null);
        setAllBranches(true);
      } else {
        setBranchId(detail.branchId ?? null);
        setAllBranches(false);
      }
    };
    window.addEventListener?.('branch-changed', handler);
    return () => window.removeEventListener?.('branch-changed', handler);
  }, []);

  const queryParam = useCallback(() => {
    if (allBranches || !branchId) return '';
    return `branchId=${branchId}`;
  }, [branchId, allBranches]);

  return { branchId, allBranches, queryParam };
}
