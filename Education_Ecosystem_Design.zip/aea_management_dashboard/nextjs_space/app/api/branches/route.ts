export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    let branches;
    if (session.user.role === 'super_admin') {
      branches = await prisma.branch.findMany({
        where: { isActive: true },
        select: { id: true, name: true, code: true, city: true, phone: true, email: true, address: true, isHeadquarters: true },
        orderBy: { name: 'asc' },
      });
    } else {
      const ub = await prisma.userBranch.findMany({
        where: { userId: session.user.id, isActive: true },
        include: { branch: { select: { id: true, name: true, code: true, city: true, phone: true, email: true, address: true, isHeadquarters: true } } },
      });
      branches = ub?.map?.((u: any) => u?.branch)?.filter?.(Boolean) ?? [];
    }
    return NextResponse.json({ branches });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
