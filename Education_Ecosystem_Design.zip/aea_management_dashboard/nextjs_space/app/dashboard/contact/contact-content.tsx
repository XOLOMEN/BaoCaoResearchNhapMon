'use client';
import { useState } from 'react';
import { Mail, Send, User, MessageSquare, Phone } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

export function ContactContent() {
  const [form, setForm] = useState<any>({ name: '', email: '', phone: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) { toast.error('Vui lòng điền đầy đủ thông tin'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      const data = await res?.json?.();
      if (res?.ok) { toast.success('Gửi thành công! Chúng tôi sẽ phản hồi sớm nhất.'); setSent(true); }
      else toast.error(data?.error ?? 'Lỗi gửi');
    } catch { toast.error('Đã xảy ra lỗi'); }
    finally { setLoading(false); }
  };

  if (sent) return (
    <FadeIn>
      <Card className="max-w-lg mx-auto mt-12">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-4">
            <Send className="w-7 h-7 text-emerald-600" />
          </div>
          <h2 className="font-display text-xl font-bold">Cảm ơn bạn!</h2>
          <p className="text-muted-foreground text-sm mt-2">Yêu cầu của bạn đã được gửi đi. Chúng tôi sẽ liên hệ lại trong thời gian sớm nhất.</p>
          <Button className="mt-4" onClick={() => { setSent(false); setForm({ name: '', email: '', phone: '', subject: '', message: '' }); }}>Gửi tiếp</Button>
        </CardContent>
      </Card>
    </FadeIn>
  );

  return (
    <div className="space-y-6">
      <FadeIn><div>
        <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><Mail className="w-6 h-6 text-primary" /> Liên hệ</h1>
        <p className="text-muted-foreground text-sm">Gửi yêu cầu hoặc thắc mắc đến ban quản lý</p>
      </div></FadeIn>
      <Card className="max-w-lg">
        <CardHeader><CardTitle className="text-sm">Form liên hệ</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2"><Label className="text-xs">Họ tên *</Label>
              <div className="relative"><User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Nguyễn Văn A" value={form.name??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),name:e?.target?.value??''}))} className="pl-10" /></div></div>
            <div className="space-y-2"><Label className="text-xs">Email *</Label>
              <div className="relative"><Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input type="email" placeholder="email@example.com" value={form.email??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),email:e?.target?.value??''}))} className="pl-10" /></div></div>
            <div className="space-y-2"><Label className="text-xs">Số điện thoại</Label>
              <div className="relative"><Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="0901234567" value={form.phone??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),phone:e?.target?.value??''}))} className="pl-10" /></div></div>
            <div className="space-y-2"><Label className="text-xs">Tiêu đề</Label>
              <Input placeholder="Nội dung yêu cầu" value={form.subject??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),subject:e?.target?.value??''}))} /></div>
            <div className="space-y-2"><Label className="text-xs">Nội dung *</Label>
              <Textarea placeholder="Mô tả chi tiết yêu cầu..." value={form.message??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),message:e?.target?.value??''}))} rows={4} /></div>
            <p className="text-[10px] text-muted-foreground">* Thông tin liên hệ sẽ được lưu lại và gửi đến ban quản lý qua email.</p>
            <Button type="submit" className="w-full gap-1" loading={loading}><Send className="w-4 h-4" /> Gửi yêu cầu</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
