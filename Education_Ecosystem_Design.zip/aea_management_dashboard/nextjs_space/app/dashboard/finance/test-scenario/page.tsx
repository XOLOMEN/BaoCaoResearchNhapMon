import { TestScenarioContent } from './test-scenario-content';
export default function TestScenarioPage() { return <TestScenarioContent />; }
