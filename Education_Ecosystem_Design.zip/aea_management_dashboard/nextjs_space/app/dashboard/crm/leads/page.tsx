import { LeadsContent } from './leads-content';
export default function CrmLeadsPage() { return <LeadsContent />; }
