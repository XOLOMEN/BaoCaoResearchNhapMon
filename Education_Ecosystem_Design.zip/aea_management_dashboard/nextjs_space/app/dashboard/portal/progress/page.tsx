import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import ProgressContent from './progress-content';

export default async function ProgressPage() {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== 'student') redirect('/dashboard');
  return <ProgressContent />;
}
