import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import LessonPlayerContent from './lesson-player-content';

export default async function LessonPlayerPage({ params }: { params: { courseId: string; lessonId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== 'student') redirect('/dashboard');
  return <LessonPlayerContent courseId={params.courseId} lessonId={params.lessonId} />;
}
