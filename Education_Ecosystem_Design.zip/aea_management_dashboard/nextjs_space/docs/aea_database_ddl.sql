-- =============================================================================
-- AEA – Education Management Ecosystem
-- Database DDL (Data Definition Language)
-- =============================================================================
-- Version:     1.0
-- Database:    PostgreSQL 15+
-- Description: Complete schema initialization for the AEA platform
--              covering 6 logical schemas: core, academic, finance, hr, crm, system
-- Features:
--   • Multi-branch tenancy with Row-Level Security (RLS)
--   • JSONB metadata fields with documented structures
--   • Foreign Key constraints for full referential integrity
--   • B-Tree / BRIN indexes optimized for query patterns
--   • AI-ready event sourcing and audit trail
-- =============================================================================

-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 0: EXTENSIONS & SCHEMA CREATION                                ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- Required extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";      -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";       -- Vietnamese full-text trigram search
CREATE EXTENSION IF NOT EXISTS "btree_gist";    -- Exclusion constraints for scheduling

-- Logical schema namespaces
CREATE SCHEMA IF NOT EXISTS core;      -- Organizations, branches, users, auth
CREATE SCHEMA IF NOT EXISTS academic;  -- Students, parents, teachers, courses, classes, enrollments, grades
CREATE SCHEMA IF NOT EXISTS finance;   -- Invoices, payments, discounts, expenses, payment plans
CREATE SCHEMA IF NOT EXISTS hr;        -- Employees, contracts, attendance, leave, payroll
CREATE SCHEMA IF NOT EXISTS crm;       -- Leads, campaigns, interactions, tasks
CREATE SCHEMA IF NOT EXISTS system;    -- Audit logs, event store, notifications, settings, files

-- Global sequence for event sourcing
CREATE SEQUENCE IF NOT EXISTS system.event_sequence START 1 INCREMENT 1;


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 1: CORE SCHEMA                                                 ║
-- ║  Organizations, Branches, Users, User-Branch mapping, Refresh Tokens    ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- -----------------------------------------------------------------------------
-- 1.1 Organizations – Top-level tenant (language center brand)
-- -----------------------------------------------------------------------------
CREATE TABLE core.organizations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    slug            VARCHAR(100) NOT NULL UNIQUE,
    logo_url        TEXT,
    settings        JSONB NOT NULL DEFAULT '{}',
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON COLUMN core.organizations.settings IS
'Organization-wide configuration. Expected structure:
{
  "timezone": "Asia/Ho_Chi_Minh",
  "locale": "vi-VN",
  "currency": "VND",
  "academic_year_start": "09-01",
  "academic_year_end": "06-30",
  "default_grading_scale": "10",
  "logo_dark_url": "https://i.pinimg.com/736x/01/b1/4d/01b14de931747835ffda934e5a45482b.jpg",
  "contact_email": "info@aea.edu.vn",
  "tax_id": "0123456789"
}';

-- -----------------------------------------------------------------------------
-- 1.2 Branches – Physical locations / campus
-- -----------------------------------------------------------------------------
CREATE TABLE core.branches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id          UUID NOT NULL,
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(20) NOT NULL,
    address         TEXT,
    city            VARCHAR(100),
    phone           VARCHAR(20),
    email           VARCHAR(255),
    is_headquarters BOOLEAN NOT NULL DEFAULT false,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    settings        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_branches_org
        FOREIGN KEY (org_id) REFERENCES core.organizations(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT uq_branches_org_code UNIQUE (org_id, code)
);

COMMENT ON COLUMN core.branches.settings IS
'Branch-specific overrides. Expected structure:
{
  "working_hours": { "start": "07:30", "end": "21:00" },
  "class_slots": [
    { "label": "Sáng",  "start": "08:00", "end": "11:30" },
    { "label": "Chiều", "start": "13:30", "end": "17:00" },
    { "label": "Tối",   "start": "18:00", "end": "21:00" }
  ],
  "rooms": [
    { "code": "P101", "capacity": 25, "equipment": ["projector", "whiteboard"] },
    { "code": "P102", "capacity": 15, "equipment": ["smartboard"] }
  ],
  "holidays": ["2026-01-01", "2026-01-29"],
  "grading_scale_override": null
}';

-- -----------------------------------------------------------------------------
-- 1.3 Users – Authentication identity across all roles
-- -----------------------------------------------------------------------------
CREATE TABLE core.users (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email             VARCHAR(255) UNIQUE,
    phone             VARCHAR(20) UNIQUE,
    password_hash     TEXT NOT NULL,
    full_name         VARCHAR(255) NOT NULL,
    avatar_url        TEXT,
    role              VARCHAR(20) NOT NULL
                      CHECK (role IN (
                          'super_admin', 'branch_admin', 'manager',
                          'staff', 'teacher', 'parent', 'student'
                      )),
    primary_branch_id UUID,
    is_active         BOOLEAN NOT NULL DEFAULT true,
    email_verified    BOOLEAN NOT NULL DEFAULT false,
    phone_verified    BOOLEAN NOT NULL DEFAULT false,
    last_login_at     TIMESTAMPTZ,
    metadata          JSONB NOT NULL DEFAULT '{}',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_users_primary_branch
        FOREIGN KEY (primary_branch_id) REFERENCES core.branches(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN core.users.metadata IS
'Extensible user data and AI-generated insights. Expected structure:
{
  "preferred_language": "vi",
  "notification_preferences": {
    "email": true, "sms": false, "push": true, "in_app": true
  },
  "two_factor_enabled": false,
  "last_password_change": "2026-01-15T10:00:00Z",
  "_ai": {
    "activity_score": 85,
    "last_analyzed": "2026-06-01T00:00:00Z"
  }
}';

CREATE INDEX idx_users_email  ON core.users (email);
CREATE INDEX idx_users_phone  ON core.users (phone);
CREATE INDEX idx_users_role   ON core.users (role);
CREATE INDEX idx_users_branch ON core.users (primary_branch_id);

-- -----------------------------------------------------------------------------
-- 1.4 User-Branch mapping – M:N (users can access multiple branches)
-- -----------------------------------------------------------------------------
CREATE TABLE core.user_branches (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL,
    branch_id     UUID NOT NULL,
    role_override VARCHAR(20),
    is_active     BOOLEAN NOT NULL DEFAULT true,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_ub_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ub_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT uq_user_branch UNIQUE (user_id, branch_id)
);

CREATE INDEX idx_ub_user   ON core.user_branches (user_id);
CREATE INDEX idx_ub_branch ON core.user_branches (branch_id);

-- -----------------------------------------------------------------------------
-- 1.5 Refresh Tokens – JWT rotation for secure session management
-- -----------------------------------------------------------------------------
CREATE TABLE core.refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL,
    token_hash  TEXT NOT NULL UNIQUE,
    device_info JSONB NOT NULL DEFAULT '{}',
    expires_at  TIMESTAMPTZ NOT NULL,
    revoked_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_rt_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

COMMENT ON COLUMN core.refresh_tokens.device_info IS
'Client device fingerprint. Expected structure:
{
  "user_agent": "Mozilla/5.0 ...",
  "ip": "192.168.1.100",
  "platform": "Windows",
  "browser": "Chrome 125",
  "device_id": "abc123"
}';

CREATE INDEX idx_rt_user ON core.refresh_tokens (user_id);
CREATE INDEX idx_rt_expires ON core.refresh_tokens (expires_at) WHERE revoked_at IS NULL;


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 2: ACADEMIC SCHEMA                                             ║
-- ║  Students, Parents, Teachers, Courses, Classes, Sessions,               ║
-- ║  Enrollments, Attendance, Grades                                        ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- -----------------------------------------------------------------------------
-- 2.1 Students
-- -----------------------------------------------------------------------------
CREATE TABLE academic.students (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID UNIQUE,
    branch_id       UUID NOT NULL,
    student_code    VARCHAR(20) NOT NULL,
    full_name       VARCHAR(255) NOT NULL,
    date_of_birth   DATE,
    gender          VARCHAR(10) CHECK (gender IN ('male', 'female', 'other')),
    phone           VARCHAR(20),
    email           VARCHAR(255),
    address         TEXT,
    enrollment_date DATE NOT NULL DEFAULT CURRENT_DATE,
    status          VARCHAR(20) NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active', 'inactive', 'graduated', 'suspended', 'withdrawn')),
    level           VARCHAR(50),
    source          VARCHAR(50),
    notes           TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_students_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_students_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT uq_students_branch_code UNIQUE (branch_id, student_code)
);

COMMENT ON COLUMN academic.students.metadata IS
'Extensible student profile and AI insights. Expected structure:
{
  "emergency_contact": { "name": "Nguyễn Văn A", "phone": "0901234567", "relationship": "father" },
  "health_notes": "Dị ứng phấn hoa",
  "previous_school": "Trường THPT Lê Quý Đôn",
  "learning_style": "visual",
  "_ai": {
    "risk_score": 0.15,
    "dropout_probability": 0.08,
    "recommended_level": "intermediate",
    "engagement_score": 82,
    "last_analyzed": "2026-06-01T00:00:00Z",
    "tags": ["high_performer", "consistent"]
  }
}';

COMMENT ON COLUMN academic.students.level IS
'Current proficiency level. Values: beginner, elementary, pre_intermediate, intermediate, upper_intermediate, advanced, proficient';

COMMENT ON COLUMN academic.students.source IS
'Lead source that converted to this student. Links to CRM module. Values: website, facebook, zalo, google, referral, walk_in, phone_call, event, partner, other';

CREATE INDEX idx_students_branch        ON academic.students (branch_id);
CREATE INDEX idx_students_branch_status  ON academic.students (branch_id, status);
CREATE INDEX idx_students_code           ON academic.students (student_code);
CREATE INDEX idx_students_name_trgm      ON academic.students USING gin (full_name gin_trgm_ops);

-- -----------------------------------------------------------------------------
-- 2.2 Parents
-- -----------------------------------------------------------------------------
CREATE TABLE academic.parents (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID UNIQUE,
    branch_id  UUID NOT NULL,
    full_name  VARCHAR(255) NOT NULL,
    phone      VARCHAR(20) NOT NULL,
    email      VARCHAR(255),
    address    TEXT,
    occupation VARCHAR(255),
    metadata   JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_parents_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_parents_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

COMMENT ON COLUMN academic.parents.metadata IS
'Extended parent info. Expected structure:
{
  "preferred_contact_method": "zalo",
  "communication_language": "vi",
  "secondary_phone": "0987654321",
  "_ai": {
    "engagement_level": "high",
    "response_rate": 0.95
  }
}';

CREATE INDEX idx_parents_branch ON academic.parents (branch_id);
CREATE INDEX idx_parents_phone  ON academic.parents (phone);

-- -----------------------------------------------------------------------------
-- 2.3 Student-Parent Junction (M:N)
-- -----------------------------------------------------------------------------
CREATE TABLE academic.student_parents (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id   UUID NOT NULL,
    parent_id    UUID NOT NULL,
    relationship VARCHAR(20) NOT NULL
                 CHECK (relationship IN ('father', 'mother', 'guardian', 'other')),
    is_primary   BOOLEAN NOT NULL DEFAULT false,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_sp_student
        FOREIGN KEY (student_id) REFERENCES academic.students(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sp_parent
        FOREIGN KEY (parent_id) REFERENCES academic.parents(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT uq_student_parent UNIQUE (student_id, parent_id)
);

CREATE INDEX idx_sp_student ON academic.student_parents (student_id);
CREATE INDEX idx_sp_parent  ON academic.student_parents (parent_id);

-- -----------------------------------------------------------------------------
-- 2.4 Teachers
-- -----------------------------------------------------------------------------
CREATE TABLE academic.teachers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID UNIQUE,
    branch_id       UUID NOT NULL,
    employee_code   VARCHAR(20) NOT NULL,
    full_name       VARCHAR(255) NOT NULL,
    phone           VARCHAR(20),
    email           VARCHAR(255),
    specializations JSONB NOT NULL DEFAULT '[]',
    certifications  JSONB NOT NULL DEFAULT '[]',
    hire_date       DATE NOT NULL,
    hourly_rate     DECIMAL(12, 2),
    status          VARCHAR(20) NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active', 'inactive', 'on_leave', 'terminated')),
    bio             TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_teachers_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_teachers_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT uq_teachers_branch_code UNIQUE (branch_id, employee_code)
);

COMMENT ON COLUMN academic.teachers.specializations IS
'Array of teaching specializations. Expected structure:
["English", "IELTS", "TOEIC", "Business English", "Kids English", "Communication"]
-- Used for: class assignment matching, workload balancing AI';

COMMENT ON COLUMN academic.teachers.certifications IS
'Array of professional certifications. Expected structure:
[
  {
    "name": "TESOL",
    "issuing_body": "Cambridge University",
    "issued_date": "2023-01-15",
    "expiry_date": "2028-01-15",
    "certificate_url": "https://...",
    "credential_id": "TESOL-2023-1234"
  },
  {
    "name": "IELTS Band 8.5",
    "issuing_body": "British Council",
    "issued_date": "2024-06-20",
    "expiry_date": "2026-06-20"
  }
]
-- Used for: qualification verification, compliance reporting';

COMMENT ON COLUMN academic.teachers.metadata IS
'Extended teacher profile and AI performance insights. Expected structure:
{
  "native_language": "Vietnamese",
  "teaching_languages": ["en", "vi"],
  "max_hours_per_week": 30,
  "preferred_schedule": { "days": ["Mon","Tue","Wed","Thu","Fri"], "shift": "morning" },
  "_ai": {
    "effectiveness_score": 87.5,
    "student_satisfaction_avg": 4.6,
    "improvement_rate": 0.12,
    "optimal_class_size": 15,
    "last_analyzed": "2026-06-01T00:00:00Z"
  }
}';

CREATE INDEX idx_teachers_branch ON academic.teachers (branch_id);
CREATE INDEX idx_teachers_status ON academic.teachers (branch_id, status);

-- -----------------------------------------------------------------------------
-- 2.5 Courses – Curriculum templates
-- -----------------------------------------------------------------------------
CREATE TABLE academic.courses (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL,
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(20) NOT NULL,
    description     TEXT,
    level           VARCHAR(50),
    category        VARCHAR(100),
    duration_hours  INTEGER NOT NULL,
    total_sessions  INTEGER NOT NULL,
    max_students    INTEGER NOT NULL DEFAULT 20,
    tuition_fee     DECIMAL(12, 2) NOT NULL,
    materials_fee   DECIMAL(12, 2) NOT NULL DEFAULT 0,
    syllabus        JSONB NOT NULL DEFAULT '{}',
    prerequisites   JSONB NOT NULL DEFAULT '[]',
    is_active       BOOLEAN NOT NULL DEFAULT true,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_courses_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT uq_courses_branch_code UNIQUE (branch_id, code)
);

COMMENT ON COLUMN academic.courses.syllabus IS
'Course curriculum structure. Expected structure:
{
  "description": "Khóa IELTS nâng cao - Target 7.0+",
  "learning_outcomes": [
    "Đạt IELTS 7.0 trở lên",
    "Thành thạo 4 kỹ năng"
  ],
  "units": [
    {
      "number": 1,
      "name": "Introduction & Assessment",
      "topics": ["Diagnostic test", "Study plan"],
      "hours": 3,
      "materials": ["Cambridge IELTS 18"]
    },
    {
      "number": 2,
      "name": "Listening Strategies",
      "topics": ["Section 1-2 techniques", "Note completion"],
      "hours": 6
    }
  ],
  "assessment_plan": {
    "midterm": { "weight": 0.3, "type": "mock_test" },
    "final": { "weight": 0.5, "type": "full_mock" },
    "participation": { "weight": 0.2, "type": "continuous" }
  },
  "textbooks": ["Cambridge IELTS 18", "Official Guide to IELTS"]
}';

COMMENT ON COLUMN academic.courses.prerequisites IS
'Array of prerequisite course IDs or level requirements. Expected structure:
["course-uuid-1", "course-uuid-2"]
or
[{ "type": "level", "min_level": "intermediate" }, { "type": "course", "course_id": "uuid" }]';

COMMENT ON COLUMN academic.courses.category IS
'Course category. Values: General English, IELTS, TOEIC, Business English, Kids, Communication, Grammar, Pronunciation, Writing';

CREATE INDEX idx_courses_branch   ON academic.courses (branch_id);
CREATE INDEX idx_courses_active    ON academic.courses (branch_id) WHERE is_active = true;
CREATE INDEX idx_courses_category  ON academic.courses (branch_id, category);

-- -----------------------------------------------------------------------------
-- 2.6 Classes – Instances of courses (cohorts/batches)
-- -----------------------------------------------------------------------------
CREATE TABLE academic.classes (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    course_id   UUID NOT NULL,
    branch_id   UUID NOT NULL,
    teacher_id  UUID,
    name        VARCHAR(255) NOT NULL,
    class_code  VARCHAR(20) NOT NULL,
    room        VARCHAR(50),
    schedule    JSONB NOT NULL DEFAULT '{}',
    start_date  DATE,
    end_date    DATE,
    capacity    INTEGER NOT NULL DEFAULT 20,
    status      VARCHAR(20) NOT NULL DEFAULT 'scheduled'
                CHECK (status IN ('scheduled', 'in_progress', 'completed', 'cancelled', 'suspended')),
    metadata    JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_classes_course
        FOREIGN KEY (course_id) REFERENCES academic.courses(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_classes_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_classes_teacher
        FOREIGN KEY (teacher_id) REFERENCES academic.teachers(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT uq_classes_branch_code UNIQUE (branch_id, class_code),
    CONSTRAINT chk_classes_dates CHECK (end_date IS NULL OR end_date >= start_date)
);

COMMENT ON COLUMN academic.classes.schedule IS
'Weekly schedule configuration. Expected structure:
{
  "days": ["Mon", "Wed", "Fri"],
  "time_start": "18:00",
  "time_end": "20:00",
  "timezone": "Asia/Ho_Chi_Minh",
  "exceptions": [
    { "date": "2026-09-02", "reason": "Ngày Quốc khánh", "action": "skip" },
    { "date": "2026-09-05", "reason": "Bù lịch", "action": "add", "time_start": "09:00", "time_end": "11:00" }
  ]
}';

COMMENT ON COLUMN academic.classes.metadata IS
'Extended class info and AI metrics. Expected structure:
{
  "teaching_method": "blended",
  "online_meeting_url": "https://meet.google.com/xxx",
  "materials_distributed": true,
  "_ai": {
    "utilization_rate": 0.85,
    "avg_attendance_rate": 0.92,
    "predicted_completion_rate": 0.88,
    "class_sentiment": "positive"
  }
}';

CREATE INDEX idx_classes_branch   ON academic.classes (branch_id);
CREATE INDEX idx_classes_course   ON academic.classes (course_id);
CREATE INDEX idx_classes_teacher  ON academic.classes (teacher_id);
CREATE INDEX idx_classes_status   ON academic.classes (branch_id, status);
CREATE INDEX idx_classes_dates    ON academic.classes (start_date, end_date);

-- -----------------------------------------------------------------------------
-- 2.7 Enrollments – Student ↔ Class junction (M:N with attributes)
-- -----------------------------------------------------------------------------
CREATE TABLE academic.enrollments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id      UUID NOT NULL,
    class_id        UUID NOT NULL,
    branch_id       UUID NOT NULL,
    enrolled_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status          VARCHAR(20) NOT NULL DEFAULT 'active'
                    CHECK (status IN ('pending', 'active', 'completed', 'dropped', 'transferred')),
    completion_date DATE,
    final_grade     DECIMAL(5, 2),
    grade_letter    VARCHAR(5),
    certificate_url TEXT,
    attendance_rate DECIMAL(5, 2),
    notes           TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_enrollments_student
        FOREIGN KEY (student_id) REFERENCES academic.students(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_class
        FOREIGN KEY (class_id) REFERENCES academic.classes(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT uq_enrollments_student_class UNIQUE (student_id, class_id),
    CONSTRAINT chk_enrollments_grade CHECK (final_grade IS NULL OR (final_grade >= 0 AND final_grade <= 100)),
    CONSTRAINT chk_enrollments_attendance CHECK (attendance_rate IS NULL OR (attendance_rate >= 0 AND attendance_rate <= 100))
);

COMMENT ON COLUMN academic.enrollments.metadata IS
'Enrollment tracking and AI predictions. Expected structure:
{
  "payment_status": "paid",
  "transfer_from_class_id": null,
  "special_arrangements": "Cần ngồi gần bảng",
  "_ai": {
    "predicted_final_grade": 78.5,
    "dropout_risk": 0.05,
    "engagement_trend": "stable",
    "recommended_actions": []
  }
}';

CREATE INDEX idx_enrollments_student ON academic.enrollments (student_id);
CREATE INDEX idx_enrollments_class   ON academic.enrollments (class_id);
CREATE INDEX idx_enrollments_branch  ON academic.enrollments (branch_id);
CREATE INDEX idx_enrollments_status  ON academic.enrollments (branch_id, status);

-- -----------------------------------------------------------------------------
-- 2.8 Class Sessions – Individual scheduled lessons
-- -----------------------------------------------------------------------------
CREATE TABLE academic.class_sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    class_id        UUID NOT NULL,
    session_number  INTEGER NOT NULL,
    session_date    DATE NOT NULL,
    start_time      TIME,
    end_time        TIME,
    topic           VARCHAR(500),
    description     TEXT,
    teacher_id      UUID,
    room_override   VARCHAR(50),
    status          VARCHAR(20) NOT NULL DEFAULT 'scheduled'
                    CHECK (status IN ('scheduled', 'in_progress', 'completed', 'cancelled', 'rescheduled')),
    homework        JSONB NOT NULL DEFAULT '{}',
    notes           TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_sessions_class
        FOREIGN KEY (class_id) REFERENCES academic.classes(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_sessions_teacher
        FOREIGN KEY (teacher_id) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT uq_sessions_class_number UNIQUE (class_id, session_number)
);

COMMENT ON COLUMN academic.class_sessions.homework IS
'Homework/assignment for this session. Expected structure:
{
  "title": "Bài tập Listening Section 3",
  "description": "Hoàn thành bài 5-8 trang 45-50",
  "due_date": "2026-09-10",
  "materials": [
    { "name": "Worksheet.pdf", "url": "https://..." }
  ],
  "submission_required": true
}';

COMMENT ON COLUMN academic.class_sessions.metadata IS
'Session-level data. Expected structure:
{
  "recording_url": "https://...",
  "slides_url": "https://...",
  "actual_duration_minutes": 115,
  "substitute_reason": null,
  "_ai": {
    "session_quality_score": 88,
    "topics_covered_ratio": 0.95
  }
}';

CREATE INDEX idx_sessions_class ON academic.class_sessions (class_id);
CREATE INDEX idx_sessions_date  ON academic.class_sessions (session_date);
CREATE INDEX idx_sessions_teacher ON academic.class_sessions (teacher_id);

-- -----------------------------------------------------------------------------
-- 2.9 Attendance – Per-session student attendance
-- -----------------------------------------------------------------------------
CREATE TABLE academic.attendance (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id    UUID NOT NULL,
    student_id    UUID NOT NULL,
    enrollment_id UUID NOT NULL,
    status        VARCHAR(20) NOT NULL
                  CHECK (status IN ('present', 'absent', 'late', 'excused', 'early_leave')),
    check_in_time  TIMESTAMPTZ,
    check_out_time TIMESTAMPTZ,
    marked_by     UUID,
    notes         TEXT,
    metadata      JSONB NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_att_session
        FOREIGN KEY (session_id) REFERENCES academic.class_sessions(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_att_student
        FOREIGN KEY (student_id) REFERENCES academic.students(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_att_enrollment
        FOREIGN KEY (enrollment_id) REFERENCES academic.enrollments(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_att_marker
        FOREIGN KEY (marked_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT uq_attendance_session_student UNIQUE (session_id, student_id)
);

COMMENT ON COLUMN academic.attendance.metadata IS
'Attendance metadata. Expected structure:
{
  "device": "qr_scanner",
  "location": { "lat": 10.762622, "lng": 106.660172 },
  "verified_by": "face_recognition",
  "_ai": {
    "absence_streak": 0,
    "pattern": "consistent"
  }
}';

CREATE INDEX idx_att_session    ON academic.attendance (session_id);
CREATE INDEX idx_att_student    ON academic.attendance (student_id);
CREATE INDEX idx_att_enrollment ON academic.attendance (enrollment_id);

-- -----------------------------------------------------------------------------
-- 2.10 Grade Records – Assessment scores
-- -----------------------------------------------------------------------------
CREATE TABLE academic.grade_records (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    enrollment_id   UUID NOT NULL,
    assessment_type VARCHAR(50) NOT NULL,
    assessment_name VARCHAR(255),
    score           DECIMAL(5, 2) NOT NULL,
    max_score       DECIMAL(5, 2) NOT NULL,
    weight          DECIMAL(3, 2) NOT NULL DEFAULT 1.0,
    graded_by       UUID,
    graded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    comments        TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_grades_enrollment
        FOREIGN KEY (enrollment_id) REFERENCES academic.enrollments(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_grades_grader
        FOREIGN KEY (graded_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT chk_grades_score CHECK (score >= 0 AND score <= max_score),
    CONSTRAINT chk_grades_max   CHECK (max_score > 0),
    CONSTRAINT chk_grades_weight CHECK (weight > 0 AND weight <= 1.0)
);

COMMENT ON COLUMN academic.grade_records.assessment_type IS
'Type of assessment. Values: quiz, homework, midterm, final, speaking, writing, listening, reading, project, participation, mock_test';

COMMENT ON COLUMN academic.grade_records.metadata IS
'Grade details and AI analysis. Expected structure:
{
  "rubric_scores": {
    "fluency": 7.0,
    "vocabulary": 6.5,
    "grammar": 7.5,
    "pronunciation": 6.0
  },
  "feedback_audio_url": "https://...",
  "_ai": {
    "percentile_in_class": 75,
    "improvement_since_last": 0.08,
    "strength_areas": ["reading", "grammar"],
    "weakness_areas": ["speaking", "pronunciation"],
    "recommended_practice": "Focus on IELTS Speaking Part 2 techniques"
  }
}';

CREATE INDEX idx_grades_enrollment ON academic.grade_records (enrollment_id);
CREATE INDEX idx_grades_type       ON academic.grade_records (assessment_type);
CREATE INDEX idx_grades_grader     ON academic.grade_records (graded_by);


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 3: FINANCE SCHEMA                                              ║
-- ║  Discounts, Invoices, Invoice Items, Payments, Payment Plans, Expenses  ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- -----------------------------------------------------------------------------
-- 3.1 Discounts / Promotions
-- -----------------------------------------------------------------------------
CREATE TABLE finance.discounts (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id     UUID NOT NULL,
    name          VARCHAR(255) NOT NULL,
    code          VARCHAR(50) UNIQUE,
    type          VARCHAR(20) NOT NULL CHECK (type IN ('percentage', 'fixed')),
    value         DECIMAL(12, 2) NOT NULL,
    min_amount    DECIMAL(12, 2) NOT NULL DEFAULT 0,
    max_discount  DECIMAL(12, 2),
    valid_from    DATE,
    valid_until   DATE,
    usage_limit   INTEGER,
    usage_count   INTEGER NOT NULL DEFAULT 0,
    applicable_to JSONB NOT NULL DEFAULT '{}',
    conditions    JSONB NOT NULL DEFAULT '{}',
    is_active     BOOLEAN NOT NULL DEFAULT true,
    metadata      JSONB NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_discounts_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT chk_discounts_value CHECK (value > 0),
    CONSTRAINT chk_discounts_dates CHECK (valid_until IS NULL OR valid_until >= valid_from)
);

COMMENT ON COLUMN finance.discounts.applicable_to IS
'Scope restrictions for this discount. Expected structure:
{
  "course_ids": ["uuid-1", "uuid-2"],
  "course_categories": ["IELTS", "TOEIC"],
  "student_statuses": ["active"],
  "branch_ids": ["uuid-branch-1"],
  "level_requirements": ["beginner", "elementary"]
}';

COMMENT ON COLUMN finance.discounts.conditions IS
'Complex eligibility conditions. Expected structure:
{
  "min_courses_enrolled": 2,
  "sibling_discount": true,
  "early_bird_days_before_start": 30,
  "referral_required": false,
  "group_min_size": 5,
  "loyalty_months_min": 12,
  "stackable": false,
  "auto_apply": false
}';

CREATE INDEX idx_discounts_branch ON finance.discounts (branch_id);
CREATE INDEX idx_discounts_code   ON finance.discounts (code) WHERE code IS NOT NULL;
CREATE INDEX idx_discounts_active ON finance.discounts (branch_id) WHERE is_active = true;

-- -----------------------------------------------------------------------------
-- 3.2 Invoices
-- -----------------------------------------------------------------------------
CREATE TABLE finance.invoices (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL,
    invoice_number  VARCHAR(50) NOT NULL,
    student_id      UUID NOT NULL,
    enrollment_id   UUID,
    type            VARCHAR(30) NOT NULL
                    CHECK (type IN ('tuition', 'materials', 'registration', 'exam_fee', 'penalty', 'other')),
    subtotal        DECIMAL(12, 2) NOT NULL,
    discount_id     UUID,
    discount_amount DECIMAL(12, 2) NOT NULL DEFAULT 0,
    tax_amount      DECIMAL(12, 2) NOT NULL DEFAULT 0,
    total_amount    DECIMAL(12, 2) NOT NULL,
    paid_amount     DECIMAL(12, 2) NOT NULL DEFAULT 0,
    -- NOTE: balance = total_amount - paid_amount (computed in application layer or via generated column)
    currency        VARCHAR(3) NOT NULL DEFAULT 'VND',
    due_date        DATE NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft', 'issued', 'partially_paid', 'paid', 'overdue', 'cancelled', 'refunded')),
    issued_at       TIMESTAMPTZ,
    issued_by       UUID,
    notes           TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_invoices_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_invoices_student
        FOREIGN KEY (student_id) REFERENCES academic.students(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_invoices_enrollment
        FOREIGN KEY (enrollment_id) REFERENCES academic.enrollments(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_invoices_discount
        FOREIGN KEY (discount_id) REFERENCES finance.discounts(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_invoices_issuer
        FOREIGN KEY (issued_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT uq_invoices_branch_number UNIQUE (branch_id, invoice_number),
    CONSTRAINT chk_invoices_amounts CHECK (total_amount >= 0 AND paid_amount >= 0 AND paid_amount <= total_amount)
);

COMMENT ON COLUMN finance.invoices.metadata IS
'Invoice metadata and AI anomaly flags. Expected structure:
{
  "billing_address": "123 Nguyễn Huệ, Q.1, TP.HCM",
  "tax_invoice_number": "HD-0001234",
  "payment_reminder_sent": 2,
  "last_reminder_at": "2026-05-28T09:00:00Z",
  "_ai": {
    "payment_prediction": {
      "probability_on_time": 0.75,
      "expected_payment_date": "2026-06-10",
      "risk_level": "low"
    },
    "anomaly_flags": []
  }
}';

CREATE INDEX idx_invoices_branch   ON finance.invoices (branch_id);
CREATE INDEX idx_invoices_student  ON finance.invoices (student_id);
CREATE INDEX idx_invoices_status   ON finance.invoices (branch_id, status);
CREATE INDEX idx_invoices_due      ON finance.invoices (due_date) WHERE status NOT IN ('paid', 'cancelled', 'refunded');
CREATE INDEX idx_invoices_enroll   ON finance.invoices (enrollment_id) WHERE enrollment_id IS NOT NULL;

-- -----------------------------------------------------------------------------
-- 3.3 Invoice Items – Line items within an invoice
-- -----------------------------------------------------------------------------
CREATE TABLE finance.invoice_items (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id  UUID NOT NULL,
    description VARCHAR(500) NOT NULL,
    quantity    INTEGER NOT NULL DEFAULT 1,
    unit_price  DECIMAL(12, 2) NOT NULL,
    amount      DECIMAL(12, 2) NOT NULL,
    metadata    JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_items_invoice
        FOREIGN KEY (invoice_id) REFERENCES finance.invoices(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT chk_items_quantity CHECK (quantity > 0),
    CONSTRAINT chk_items_amount   CHECK (amount >= 0)
);

CREATE INDEX idx_invoice_items_invoice ON finance.invoice_items (invoice_id);

-- -----------------------------------------------------------------------------
-- 3.4 Payments
-- -----------------------------------------------------------------------------
CREATE TABLE finance.payments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id      UUID NOT NULL,
    branch_id       UUID NOT NULL,
    amount          DECIMAL(12, 2) NOT NULL,
    payment_method  VARCHAR(30) NOT NULL
                    CHECK (payment_method IN ('cash', 'bank_transfer', 'credit_card', 'momo', 'zalopay', 'vnpay', 'other')),
    payment_date    DATE NOT NULL DEFAULT CURRENT_DATE,
    transaction_ref VARCHAR(100),
    receipt_number  VARCHAR(50),
    status          VARCHAR(20) NOT NULL DEFAULT 'completed'
                    CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
    received_by     UUID,
    refund_reason   TEXT,
    notes           TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_payments_invoice
        FOREIGN KEY (invoice_id) REFERENCES finance.invoices(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_payments_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_payments_receiver
        FOREIGN KEY (received_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT chk_payments_amount CHECK (amount > 0)
);

COMMENT ON COLUMN finance.payments.metadata IS
'Payment verification data and AI flags. Expected structure:
{
  "gateway_response": { "code": "00", "message": "Success", "txn_id": "VNP123456" },
  "bank_name": "Vietcombank",
  "payer_account": "****1234",
  "receipt_image_url": "https://play-lh.googleusercontent.com/d432Nloac_o0C7eW8S9KX_-3ZvbHpcC55U5Ky1rCpyXMbfDv0xmGechTEDUU4x08BwXDxU7hzHi_VJTuaSijaQ=w526-h296-rw",
  "_ai": {
    "duplicate_risk": 0.02,
    "anomaly_score": 0.05,
    "anomaly_type": null
  }
}';

CREATE INDEX idx_payments_invoice ON finance.payments (invoice_id);
CREATE INDEX idx_payments_branch  ON finance.payments (branch_id);
CREATE INDEX idx_payments_date    ON finance.payments (payment_date);
CREATE INDEX idx_payments_method  ON finance.payments (branch_id, payment_method);

-- -----------------------------------------------------------------------------
-- 3.5 Payment Plans – Installment schedules
-- -----------------------------------------------------------------------------
CREATE TABLE finance.payment_plans (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id      UUID NOT NULL,
    installment_no  INTEGER NOT NULL,
    amount          DECIMAL(12, 2) NOT NULL,
    due_date        DATE NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'paid', 'overdue', 'waived')),
    paid_at         TIMESTAMPTZ,
    payment_id      UUID,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_pp_invoice
        FOREIGN KEY (invoice_id) REFERENCES finance.invoices(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_pp_payment
        FOREIGN KEY (payment_id) REFERENCES finance.payments(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT uq_pp_invoice_installment UNIQUE (invoice_id, installment_no),
    CONSTRAINT chk_pp_amount CHECK (amount > 0)
);

CREATE INDEX idx_pp_invoice ON finance.payment_plans (invoice_id);
CREATE INDEX idx_pp_due     ON finance.payment_plans (due_date) WHERE status IN ('pending', 'overdue');

-- -----------------------------------------------------------------------------
-- 3.6 Expenses
-- -----------------------------------------------------------------------------
CREATE TABLE finance.expenses (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id    UUID NOT NULL,
    category     VARCHAR(50) NOT NULL
                 CHECK (category IN ('rent', 'utilities', 'supplies', 'marketing', 'equipment', 'maintenance', 'salary', 'other')),
    amount       DECIMAL(12, 2) NOT NULL,
    currency     VARCHAR(3) NOT NULL DEFAULT 'VND',
    description  TEXT NOT NULL,
    expense_date DATE NOT NULL,
    vendor       VARCHAR(255),
    receipt_url  TEXT,
    approved_by  UUID,
    submitted_by UUID NOT NULL,
    status       VARCHAR(20) NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending', 'approved', 'rejected', 'reimbursed')),
    notes        TEXT,
    metadata     JSONB NOT NULL DEFAULT '{}',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_expenses_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_expenses_approver
        FOREIGN KEY (approved_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_expenses_submitter
        FOREIGN KEY (submitted_by) REFERENCES core.users(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT chk_expenses_amount CHECK (amount > 0)
);

COMMENT ON COLUMN finance.expenses.metadata IS
'Expense details and AI anomaly detection. Expected structure:
{
  "tax_deductible": true,
  "project_code": "MKT-2026-Q2",
  "recurring": { "frequency": "monthly", "auto_create": true },
  "approval_chain": [
    { "user_id": "uuid", "action": "approved", "at": "2026-06-01T10:00:00Z" }
  ],
  "_ai": {
    "anomaly_score": 0.15,
    "category_confidence": 0.92,
    "budget_utilization": 0.65,
    "flagged": false
  }
}';

CREATE INDEX idx_expenses_branch   ON finance.expenses (branch_id);
CREATE INDEX idx_expenses_date     ON finance.expenses (expense_date);
CREATE INDEX idx_expenses_category ON finance.expenses (branch_id, category);
CREATE INDEX idx_expenses_status   ON finance.expenses (branch_id, status);


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 4: HR SCHEMA                                                   ║
-- ║  Employees, Contracts, Attendance, Leave Requests, Payroll              ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- -----------------------------------------------------------------------------
-- 4.1 HR Employees – Extended employee profile beyond core.users
-- -----------------------------------------------------------------------------
CREATE TABLE hr.employees (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID UNIQUE,
    branch_id         UUID NOT NULL,
    employee_code     VARCHAR(20) NOT NULL,
    full_name         VARCHAR(255) NOT NULL,
    date_of_birth     DATE,
    gender            VARCHAR(10),
    phone             VARCHAR(20),
    email             VARCHAR(255),
    address           TEXT,
    id_number         VARCHAR(20),
    tax_code          VARCHAR(20),
    bank_account      VARCHAR(30),
    bank_name         VARCHAR(100),
    insurance_number  VARCHAR(20),
    department        VARCHAR(100) NOT NULL,
    position          VARCHAR(100) NOT NULL,
    employment_type   VARCHAR(20)
                      CHECK (employment_type IN ('full_time', 'part_time', 'contract', 'intern')),
    hire_date         DATE NOT NULL,
    termination_date  DATE,
    emergency_contact JSONB NOT NULL DEFAULT '{}',
    status            VARCHAR(20) NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active', 'on_leave', 'suspended', 'terminated')),
    metadata          JSONB NOT NULL DEFAULT '{}',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_hr_emp_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_hr_emp_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT uq_hr_emp_branch_code UNIQUE (branch_id, employee_code)
);

COMMENT ON COLUMN hr.employees.id_number IS
'Vietnamese national ID (CMND/CCCD). Used for tax and insurance reporting.';

COMMENT ON COLUMN hr.employees.emergency_contact IS
'Emergency contact information. Expected structure:
{
  "name": "Trần Thị B",
  "phone": "0901234567",
  "relationship": "spouse",
  "address": "123 Lê Lợi, Q.1, TP.HCM"
}';

COMMENT ON COLUMN hr.employees.metadata IS
'Extended HR profile and AI insights. Expected structure:
{
  "education": [
    { "degree": "MBA", "institution": "ĐH Kinh tế TP.HCM", "year": 2020 }
  ],
  "skills": ["team_management", "curriculum_design"],
  "probation_end_date": "2026-09-01",
  "_ai": {
    "performance_score": 82,
    "retention_risk": 0.15,
    "burnout_indicator": 0.20,
    "productivity_trend": "improving",
    "recommended_training": ["leadership", "advanced_excel"],
    "last_analyzed": "2026-06-01T00:00:00Z"
  }
}';

CREATE INDEX idx_hr_emp_branch ON hr.employees (branch_id);
CREATE INDEX idx_hr_emp_dept   ON hr.employees (branch_id, department);
CREATE INDEX idx_hr_emp_status ON hr.employees (branch_id, status);

-- -----------------------------------------------------------------------------
-- 4.2 HR Contracts
-- -----------------------------------------------------------------------------
CREATE TABLE hr.contracts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id     UUID NOT NULL,
    contract_type   VARCHAR(30) NOT NULL
                    CHECK (contract_type IN ('probation', 'fixed_term', 'indefinite', 'seasonal')),
    contract_number VARCHAR(50),
    start_date      DATE NOT NULL,
    end_date        DATE,
    base_salary     DECIMAL(12, 2) NOT NULL,
    allowances      JSONB NOT NULL DEFAULT '{}',
    benefits        JSONB NOT NULL DEFAULT '{}',
    working_hours   JSONB NOT NULL DEFAULT '{}',
    signed_doc_url  TEXT,
    status          VARCHAR(20) NOT NULL DEFAULT 'active'
                    CHECK (status IN ('draft', 'active', 'expired', 'terminated', 'renewed')),
    notes           TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_contracts_employee
        FOREIGN KEY (employee_id) REFERENCES hr.employees(id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    CONSTRAINT chk_contracts_salary CHECK (base_salary >= 0),
    CONSTRAINT chk_contracts_dates  CHECK (end_date IS NULL OR end_date >= start_date)
);

COMMENT ON COLUMN hr.contracts.allowances IS
'Monthly allowance breakdown in VND. Expected structure:
{
  "housing":    2000000,
  "transport":   500000,
  "phone":       200000,
  "lunch":       700000,
  "toxic":             0,
  "responsibility": 1000000,
  "language":     500000
}
-- Total allowances calculated as SUM of all values
-- Used by payroll calculation engine';

COMMENT ON COLUMN hr.contracts.benefits IS
'Non-monetary benefits and entitlements. Expected structure:
{
  "health_insurance": true,
  "social_insurance": true,
  "unemployment_insurance": true,
  "annual_leave_days": 12,
  "sick_leave_days": 30,
  "personal_leave_days": 3,
  "tuition_discount_percent": 50,
  "training_budget_annual": 5000000,
  "laptop_provided": true,
  "parking_included": true
}';

COMMENT ON COLUMN hr.contracts.working_hours IS
'Work schedule definition. Expected structure:
{
  "hours_per_week": 40,
  "hours_per_day": 8,
  "schedule": "Mon-Fri 08:00-17:00",
  "break": { "start": "12:00", "end": "13:00" },
  "flexible": false,
  "remote_days_per_week": 0,
  "overtime_rate": 1.5,
  "weekend_rate": 2.0,
  "holiday_rate": 3.0
}';

CREATE INDEX idx_contracts_employee ON hr.contracts (employee_id);
CREATE INDEX idx_contracts_status   ON hr.contracts (status);
CREATE INDEX idx_contracts_dates    ON hr.contracts (start_date, end_date);

-- -----------------------------------------------------------------------------
-- 4.3 HR Attendance (Staff/Employee attendance, separate from student)
-- -----------------------------------------------------------------------------
CREATE TABLE hr.attendance (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id    UUID NOT NULL,
    branch_id      UUID NOT NULL,
    work_date      DATE NOT NULL,
    check_in       TIMESTAMPTZ,
    check_out      TIMESTAMPTZ,
    work_hours     DECIMAL(4, 2),
    overtime_hours DECIMAL(4, 2) NOT NULL DEFAULT 0,
    status         VARCHAR(20) NOT NULL DEFAULT 'present'
                   CHECK (status IN ('present', 'absent', 'late', 'half_day', 'remote', 'holiday', 'leave')),
    notes          TEXT,
    metadata       JSONB NOT NULL DEFAULT '{}',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_hr_att_employee
        FOREIGN KEY (employee_id) REFERENCES hr.employees(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_hr_att_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    CONSTRAINT uq_hr_att_employee_date UNIQUE (employee_id, work_date)
);

COMMENT ON COLUMN hr.attendance.metadata IS
'HR attendance details. Expected structure:
{
  "source": "fingerprint",
  "device_id": "FP-READER-01",
  "location": "Cơ sở Quận 1",
  "late_minutes": 15,
  "early_leave_minutes": 0,
  "_ai": {
    "late_streak": 3,
    "pattern": "frequently_late_monday",
    "burnout_signal": false
  }
}';

CREATE INDEX idx_hr_att_employee ON hr.attendance (employee_id);
CREATE INDEX idx_hr_att_branch   ON hr.attendance (branch_id);
CREATE INDEX idx_hr_att_date     ON hr.attendance (work_date);

-- -----------------------------------------------------------------------------
-- 4.4 HR Leave Requests
-- -----------------------------------------------------------------------------
CREATE TABLE hr.leave_requests (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id UUID NOT NULL,
    leave_type  VARCHAR(30) NOT NULL
                CHECK (leave_type IN ('annual', 'sick', 'maternity', 'paternity', 'unpaid', 'compassionate', 'other')),
    start_date  DATE NOT NULL,
    end_date    DATE NOT NULL,
    days_count  DECIMAL(3, 1) NOT NULL,
    reason      TEXT,
    approved_by UUID,
    status      VARCHAR(20) NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')),
    reviewed_at TIMESTAMPTZ,
    metadata    JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_leave_employee
        FOREIGN KEY (employee_id) REFERENCES hr.employees(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_leave_approver
        FOREIGN KEY (approved_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT chk_leave_dates CHECK (end_date >= start_date),
    CONSTRAINT chk_leave_days  CHECK (days_count > 0)
);

COMMENT ON COLUMN hr.leave_requests.metadata IS
'Leave request details. Expected structure:
{
  "supporting_doc_url": "https://...",
  "handover_to": "uuid-colleague",
  "half_day": false,
  "half_day_period": null,
  "rejection_reason": null,
  "_ai": {
    "leave_balance_after": 8.5,
    "team_coverage_ok": true,
    "sick_leave_frequency_30d": 2
  }
}';

CREATE INDEX idx_leave_employee ON hr.leave_requests (employee_id);
CREATE INDEX idx_leave_status   ON hr.leave_requests (status);
CREATE INDEX idx_leave_dates    ON hr.leave_requests (start_date, end_date);

-- -----------------------------------------------------------------------------
-- 4.5 HR Payroll
-- -----------------------------------------------------------------------------
CREATE TABLE hr.payroll (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id          UUID NOT NULL,
    branch_id            UUID NOT NULL,
    period_start         DATE NOT NULL,
    period_end           DATE NOT NULL,
    work_days            INTEGER,
    actual_days          INTEGER,
    base_salary          DECIMAL(12, 2) NOT NULL,
    allowances           DECIMAL(12, 2) NOT NULL DEFAULT 0,
    overtime_pay         DECIMAL(12, 2) NOT NULL DEFAULT 0,
    bonuses              DECIMAL(12, 2) NOT NULL DEFAULT 0,
    gross_salary         DECIMAL(12, 2) NOT NULL,
    tax_deduction        DECIMAL(12, 2) NOT NULL DEFAULT 0,
    insurance_deduction  DECIMAL(12, 2) NOT NULL DEFAULT 0,
    other_deductions     DECIMAL(12, 2) NOT NULL DEFAULT 0,
    deduction_details    JSONB NOT NULL DEFAULT '{}',
    net_salary           DECIMAL(12, 2) NOT NULL,
    currency             VARCHAR(3) NOT NULL DEFAULT 'VND',
    status               VARCHAR(20) NOT NULL DEFAULT 'draft'
                         CHECK (status IN ('draft', 'calculated', 'approved', 'paid')),
    approved_by          UUID,
    paid_at              TIMESTAMPTZ,
    payment_ref          VARCHAR(100),
    notes                TEXT,
    metadata             JSONB NOT NULL DEFAULT '{}',
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_payroll_employee
        FOREIGN KEY (employee_id) REFERENCES hr.employees(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_approver
        FOREIGN KEY (approved_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT uq_payroll_employee_period UNIQUE (employee_id, period_start, period_end),
    CONSTRAINT chk_payroll_dates CHECK (period_end >= period_start),
    CONSTRAINT chk_payroll_salary CHECK (gross_salary >= 0 AND net_salary >= 0)
);

COMMENT ON COLUMN hr.payroll.deduction_details IS
'Itemized deduction breakdown. Expected structure:
{
  "personal_income_tax": {
    "taxable_income": 15000000,
    "tax_rate": 0.15,
    "amount": 2250000
  },
  "social_insurance": {
    "rate": 0.08,
    "base": 20000000,
    "amount": 1600000
  },
  "health_insurance": {
    "rate": 0.015,
    "base": 20000000,
    "amount": 300000
  },
  "unemployment_insurance": {
    "rate": 0.01,
    "base": 20000000,
    "amount": 200000
  },
  "union_fee": 200000,
  "advance_repayment": 0,
  "other": []
}';

COMMENT ON COLUMN hr.payroll.metadata IS
'Payroll calculation metadata and AI insights. Expected structure:
{
  "calculation_version": "2026-Q2",
  "overtime_details": {
    "weekday_hours": 10, "weekday_amount": 1500000,
    "weekend_hours": 4,  "weekend_amount": 800000
  },
  "bonus_details": [
    { "type": "KPI", "amount": 2000000, "note": "Đạt 120% KPI" },
    { "type": "project", "amount": 500000, "note": "Hoàn thành dự án IELTS Camp" }
  ],
  "_ai": {
    "salary_market_comparison": "above_average",
    "predicted_next_raise": "2026-12-01",
    "cost_per_student_taught": 85000
  }
}';

CREATE INDEX idx_payroll_employee ON hr.payroll (employee_id);
CREATE INDEX idx_payroll_branch   ON hr.payroll (branch_id);
CREATE INDEX idx_payroll_period   ON hr.payroll (period_start, period_end);
CREATE INDEX idx_payroll_status   ON hr.payroll (status);


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 5: CRM SCHEMA                                                  ║
-- ║  Campaigns, Leads, Interactions, Tasks                                  ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- -----------------------------------------------------------------------------
-- 5.1 CRM Campaigns
-- -----------------------------------------------------------------------------
CREATE TABLE crm.campaigns (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID NOT NULL,
    name            VARCHAR(255) NOT NULL,
    type            VARCHAR(30)
                    CHECK (type IN ('digital_ad', 'social_media', 'referral', 'event', 'flyer', 'partnership', 'other')),
    description     TEXT,
    start_date      DATE,
    end_date        DATE,
    budget          DECIMAL(12, 2),
    spent           DECIMAL(12, 2) NOT NULL DEFAULT 0,
    target_audience JSONB NOT NULL DEFAULT '{}',
    channels        JSONB NOT NULL DEFAULT '[]',
    status          VARCHAR(20) NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft', 'active', 'paused', 'completed', 'cancelled')),
    results         JSONB NOT NULL DEFAULT '{}',
    created_by      UUID,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_campaigns_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_campaigns_creator
        FOREIGN KEY (created_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN crm.campaigns.target_audience IS
'Target demographic for the campaign. Expected structure:
{
  "age_range": [18, 35],
  "interests": ["IELTS", "du học"],
  "locations": ["TP.HCM", "Hà Nội"],
  "income_level": "middle_upper",
  "occupation": ["student", "office_worker"],
  "existing_level": ["beginner", "elementary"]
}';

COMMENT ON COLUMN crm.campaigns.channels IS
'Marketing channels used. Expected structure:
["facebook", "google_ads", "zalo", "tiktok", "instagram", "email", "sms", "banner", "flyer"]';

COMMENT ON COLUMN crm.campaigns.results IS
'Campaign performance metrics. Expected structure:
{
  "impressions": 150000,
  "clicks": 4500,
  "ctr": 0.03,
  "leads_generated": 120,
  "trials_scheduled": 45,
  "conversions": 28,
  "conversion_rate": 0.233,
  "revenue_generated": 280000000,
  "cost_per_lead": 83333,
  "cost_per_conversion": 357143,
  "roi": 1.8,
  "_ai": {
    "predicted_final_conversions": 35,
    "recommended_budget_adjustment": "increase_10_percent",
    "best_performing_channel": "facebook"
  }
}';

CREATE INDEX idx_campaigns_branch ON crm.campaigns (branch_id);
CREATE INDEX idx_campaigns_status ON crm.campaigns (status);
CREATE INDEX idx_campaigns_dates  ON crm.campaigns (start_date, end_date);

-- -----------------------------------------------------------------------------
-- 5.2 CRM Leads
-- -----------------------------------------------------------------------------
CREATE TABLE crm.leads (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id            UUID NOT NULL,
    full_name            VARCHAR(255) NOT NULL,
    email                VARCHAR(255),
    phone                VARCHAR(20) NOT NULL,
    source               VARCHAR(50) NOT NULL
                         CHECK (source IN ('website', 'facebook', 'zalo', 'google', 'referral', 'walk_in', 'phone_call', 'event', 'partner', 'other')),
    campaign_id          UUID,
    interest_course_id   UUID,
    interest_notes       TEXT,
    assigned_to          UUID,
    status               VARCHAR(20) NOT NULL DEFAULT 'new'
                         CHECK (status IN ('new', 'contacted', 'qualified', 'trial_scheduled', 'trial_completed', 'negotiation', 'converted', 'lost', 'dormant')),
    score                INTEGER NOT NULL DEFAULT 0 CHECK (score >= 0 AND score <= 100),
    expected_value       DECIMAL(12, 2),
    lost_reason          VARCHAR(100),
    converted_student_id UUID,
    converted_at         TIMESTAMPTZ,
    last_contacted       TIMESTAMPTZ,
    next_follow_up       TIMESTAMPTZ,
    notes                TEXT,
    tags                 JSONB NOT NULL DEFAULT '[]',
    metadata             JSONB NOT NULL DEFAULT '{}',
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_leads_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_leads_campaign
        FOREIGN KEY (campaign_id) REFERENCES crm.campaigns(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_leads_course
        FOREIGN KEY (interest_course_id) REFERENCES academic.courses(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_leads_assignee
        FOREIGN KEY (assigned_to) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_leads_converted_student
        FOREIGN KEY (converted_student_id) REFERENCES academic.students(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN crm.leads.score IS
'Lead quality score 0-100. Calculated by AI based on: source quality, engagement frequency, interest level, response time, demographic match. Updated after each interaction.';

COMMENT ON COLUMN crm.leads.tags IS
'Categorization tags for filtering. Expected structure:
["hot_lead", "ielts_interested", "referred_by_student", "price_sensitive", "decision_maker"]
-- Used for: segmentation, AI-driven campaign targeting';

COMMENT ON COLUMN crm.leads.metadata IS
'Extended lead info and AI predictions. Expected structure:
{
  "utm_source": "facebook",
  "utm_medium": "cpc",
  "utm_campaign": "ielts_summer_2026",
  "landing_page": "/courses/ielts",
  "device": "mobile",
  "trial_class_date": "2026-06-15",
  "trial_feedback": "Very interested, asking about schedule",
  "_ai": {
    "conversion_probability": 0.72,
    "predicted_value": 15000000,
    "optimal_next_action": "schedule_trial",
    "optimal_contact_time": "10:00",
    "similar_converted_profiles": 15,
    "last_scored": "2026-06-01T00:00:00Z"
  }
}';

CREATE INDEX idx_leads_branch       ON crm.leads (branch_id);
CREATE INDEX idx_leads_status       ON crm.leads (branch_id, status);
CREATE INDEX idx_leads_assigned     ON crm.leads (assigned_to);
CREATE INDEX idx_leads_source       ON crm.leads (source);
CREATE INDEX idx_leads_phone        ON crm.leads (phone);
CREATE INDEX idx_leads_followup     ON crm.leads (next_follow_up) WHERE status NOT IN ('converted', 'lost');
CREATE INDEX idx_leads_score        ON crm.leads (score DESC);

-- -----------------------------------------------------------------------------
-- 5.3 CRM Interactions – Communication log with leads
-- -----------------------------------------------------------------------------
CREATE TABLE crm.interactions (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id          UUID NOT NULL,
    type             VARCHAR(30) NOT NULL
                     CHECK (type IN ('phone_call', 'email', 'sms', 'zalo_message', 'facebook_message', 'meeting', 'trial_class', 'note', 'other')),
    direction        VARCHAR(10) CHECK (direction IN ('inbound', 'outbound')),
    channel          VARCHAR(30),
    subject          VARCHAR(255),
    content          TEXT,
    duration_minutes INTEGER,
    contacted_by     UUID,
    outcome          VARCHAR(50),
    next_follow_up   TIMESTAMPTZ,
    metadata         JSONB NOT NULL DEFAULT '{}',
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_interactions_lead
        FOREIGN KEY (lead_id) REFERENCES crm.leads(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_interactions_contactor
        FOREIGN KEY (contacted_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN crm.interactions.outcome IS
'Interaction result. Values: interested, callback_requested, not_interested, no_answer, voicemail, busy, wrong_number, trial_booked, enrolled, price_objection, schedule_conflict';

COMMENT ON COLUMN crm.interactions.metadata IS
'Interaction details. Expected structure:
{
  "call_recording_url": "https://...",
  "email_thread_id": "thread-abc123",
  "satisfaction_rating": 4,
  "_ai": {
    "sentiment": "positive",
    "key_topics": ["pricing", "schedule", "trial"],
    "urgency_level": "medium",
    "suggested_response": "Offer trial class this Saturday"
  }
}';

CREATE INDEX idx_interactions_lead ON crm.interactions (lead_id);
CREATE INDEX idx_interactions_date ON crm.interactions (created_at);
CREATE INDEX idx_interactions_by   ON crm.interactions (contacted_by);

-- -----------------------------------------------------------------------------
-- 5.4 CRM Tasks
-- -----------------------------------------------------------------------------
CREATE TABLE crm.tasks (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id      UUID,
    branch_id    UUID NOT NULL,
    assigned_to  UUID NOT NULL,
    title        VARCHAR(255) NOT NULL,
    description  TEXT,
    task_type    VARCHAR(30)
                 CHECK (task_type IN ('follow_up', 'call', 'email', 'meeting', 'trial_arrangement', 'document', 'other')),
    due_date     TIMESTAMPTZ NOT NULL,
    priority     VARCHAR(10) NOT NULL DEFAULT 'medium'
                 CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
    status       VARCHAR(20) NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
    completed_at TIMESTAMPTZ,
    metadata     JSONB NOT NULL DEFAULT '{}',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_tasks_lead
        FOREIGN KEY (lead_id) REFERENCES crm.leads(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_tasks_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_tasks_assignee
        FOREIGN KEY (assigned_to) REFERENCES core.users(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE INDEX idx_tasks_assigned ON crm.tasks (assigned_to);
CREATE INDEX idx_tasks_due      ON crm.tasks (due_date) WHERE status IN ('pending', 'in_progress');
CREATE INDEX idx_tasks_branch   ON crm.tasks (branch_id);
CREATE INDEX idx_tasks_lead     ON crm.tasks (lead_id) WHERE lead_id IS NOT NULL;


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 6: SYSTEM SCHEMA                                               ║
-- ║  Audit Logs, Event Store, Notifications, Settings, Files, Contact       ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- -----------------------------------------------------------------------------
-- 6.1 Audit Logs – Complete change tracking
-- -----------------------------------------------------------------------------
CREATE TABLE system.audit_logs (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id   UUID,
    user_id     UUID,
    entity_type VARCHAR(50) NOT NULL,
    entity_id   UUID NOT NULL,
    action      VARCHAR(20) NOT NULL
                CHECK (action IN ('create', 'update', 'delete', 'status_change', 'login', 'logout', 'export', 'import')),
    old_values  JSONB,
    new_values  JSONB,
    ip_address  INET,
    user_agent  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_audit_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_audit_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN system.audit_logs.old_values IS
'Previous state of changed fields. Expected structure:
{ "status": "active", "level": "beginner" }
-- Only includes fields that were actually changed';

COMMENT ON COLUMN system.audit_logs.new_values IS
'New state of changed fields. Expected structure:
{ "status": "graduated", "level": "intermediate" }
-- Mirrors old_values keys with new values';

CREATE INDEX idx_audit_entity  ON system.audit_logs (entity_type, entity_id);
CREATE INDEX idx_audit_user    ON system.audit_logs (user_id);
CREATE INDEX idx_audit_branch  ON system.audit_logs (branch_id);
CREATE INDEX idx_audit_created ON system.audit_logs USING BRIN (created_at);

-- -----------------------------------------------------------------------------
-- 6.2 Event Store – AI pipeline data source (event sourcing)
-- -----------------------------------------------------------------------------
CREATE TABLE system.event_store (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id       UUID,
    aggregate_type  VARCHAR(50) NOT NULL,
    aggregate_id    UUID NOT NULL,
    event_type      VARCHAR(100) NOT NULL,
    payload         JSONB NOT NULL,
    metadata        JSONB NOT NULL DEFAULT '{}',
    sequence_number BIGINT NOT NULL DEFAULT nextval('system.event_sequence'),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_events_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON TABLE system.event_store IS
'Event sourcing table for AI/ML pipeline consumption. Every significant state
transition in the system is recorded here with full payload for:
  • Student progress AI (grade.recorded, attendance.marked)
  • Financial anomaly detection (payment.received, invoice.overdue)
  • HR insights (leave.approved, attendance.late_pattern)
  • CRM intelligence (lead.score_updated, interaction.logged)';

COMMENT ON COLUMN system.event_store.aggregate_type IS
'Domain aggregate. Values: enrollment, payment, invoice, lead, employee, class, campaign';

COMMENT ON COLUMN system.event_store.event_type IS
'Dot-notation event name. Examples:
  enrollment.created, enrollment.completed, enrollment.dropped
  grade.recorded, grade.updated
  attendance.marked, attendance.absent_streak
  payment.received, payment.refunded, payment.anomaly_detected
  invoice.issued, invoice.overdue
  lead.created, lead.score_updated, lead.converted, lead.lost
  hr.leave_approved, hr.late_pattern_detected';

COMMENT ON COLUMN system.event_store.payload IS
'Full event data for AI consumption. Structure varies by event_type.
Example for grade.recorded:
{
  "student_id": "uuid",
  "class_id": "uuid",
  "assessment_type": "midterm",
  "score": 75,
  "max_score": 100,
  "percentage": 0.75,
  "running_average": 78.5,
  "trend": "declining",
  "percentile_in_class": 45,
  "previous_scores": [82, 80, 75]
}';

COMMENT ON COLUMN system.event_store.metadata IS
'Event context. Expected structure:
{
  "triggered_by": "user-uuid",
  "ip": "192.168.1.100",
  "correlation_id": "req-uuid-123",
  "source": "api",
  "version": 1
}';

CREATE INDEX idx_events_aggregate ON system.event_store (aggregate_type, aggregate_id);
CREATE INDEX idx_events_type      ON system.event_store (event_type);
CREATE INDEX idx_events_branch    ON system.event_store (branch_id);
CREATE INDEX idx_events_created   ON system.event_store USING BRIN (created_at);
CREATE INDEX idx_events_sequence  ON system.event_store (sequence_number);

-- -----------------------------------------------------------------------------
-- 6.3 Notifications
-- -----------------------------------------------------------------------------
CREATE TABLE system.notifications (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL,
    branch_id  UUID,
    type       VARCHAR(30) NOT NULL,
    title      VARCHAR(255) NOT NULL,
    body       TEXT,
    data       JSONB NOT NULL DEFAULT '{}',
    channels   JSONB NOT NULL DEFAULT '["in_app"]',
    read_at    TIMESTAMPTZ,
    sent_at    TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_notif_user
        FOREIGN KEY (user_id) REFERENCES core.users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_notif_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN system.notifications.type IS
'Notification category. Values: payment_due, payment_received, class_reminder, grade_posted, leave_approved, leave_rejected, new_enrollment, attendance_alert, system_update, campaign_result';

COMMENT ON COLUMN system.notifications.data IS
'Notification payload for deep linking. Expected structure:
{
  "link_to": "/dashboard/students/uuid",
  "entity_type": "invoice",
  "entity_id": "uuid",
  "action_required": true,
  "priority": "high"
}';

COMMENT ON COLUMN system.notifications.channels IS
'Delivery channels. Expected structure:
["in_app", "email", "sms", "push", "zalo"]
-- Multiple channels can be active simultaneously';

CREATE INDEX idx_notif_user   ON system.notifications (user_id);
CREATE INDEX idx_notif_unread ON system.notifications (user_id) WHERE read_at IS NULL;
CREATE INDEX idx_notif_branch ON system.notifications (branch_id);

-- -----------------------------------------------------------------------------
-- 6.4 System Settings – Key-value configuration store
-- -----------------------------------------------------------------------------
CREATE TABLE system.settings (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id   UUID,
    category    VARCHAR(50) NOT NULL,
    key         VARCHAR(100) NOT NULL,
    value       JSONB NOT NULL,
    description TEXT,
    updated_by  UUID,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_settings_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_settings_updater
        FOREIGN KEY (updated_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,

    CONSTRAINT uq_settings_branch_cat_key UNIQUE (branch_id, category, key)
);

COMMENT ON TABLE system.settings IS
'Hierarchical settings: branch_id = NULL for org-level defaults,
branch_id set for branch-specific overrides.
Categories: academic, finance, hr, crm, notification, security, integration';

CREATE INDEX idx_settings_branch ON system.settings (branch_id, category);

-- -----------------------------------------------------------------------------
-- 6.5 File Attachments – Polymorphic file storage references
-- -----------------------------------------------------------------------------
CREATE TABLE system.file_attachments (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(50) NOT NULL,
    entity_id   UUID NOT NULL,
    file_name   VARCHAR(255) NOT NULL,
    file_url    TEXT NOT NULL,
    file_size   BIGINT,
    mime_type   VARCHAR(100),
    category    VARCHAR(50),
    uploaded_by UUID,
    metadata    JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_files_uploader
        FOREIGN KEY (uploaded_by) REFERENCES core.users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN system.file_attachments.entity_type IS
'Polymorphic entity reference. Values: student, teacher, employee, invoice, expense, contract, course, class, lead, campaign';

COMMENT ON COLUMN system.file_attachments.category IS
'File purpose. Values: avatar, certificate, receipt, contract, syllabus, homework, report, id_document, medical_certificate, other';

COMMENT ON COLUMN system.file_attachments.metadata IS
'File metadata. Expected structure:
{
  "original_name": "hợp_đồng_lao_động.pdf",
  "dimensions": { "width": 1200, "height": 800 },
  "thumbnail_url": "https://pubchem.ncbi.nlm.nih.gov/image/nmr.cgi?peaks=8.04:469.00,7.36:144.00,7.46:535.00,7.38:731.00,7.90:159.00,8.06:113.00,7.93:624.00,8.40:818.00,7.97:474.00,7.53:160.00,7.52:162.00,8.00:450.00,7.49:1000.00,7.42:613.00",
  "virus_scanned": true,
  "is_public": false
}';

CREATE INDEX idx_files_entity ON system.file_attachments (entity_type, entity_id);
CREATE INDEX idx_files_uploader ON system.file_attachments (uploaded_by);

-- -----------------------------------------------------------------------------
-- 6.6 Contact Inquiries – Public contact form submissions
-- -----------------------------------------------------------------------------
CREATE TABLE system.contact_inquiries (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id  UUID,
    name       VARCHAR(255) NOT NULL,
    email      VARCHAR(255) NOT NULL,
    phone      VARCHAR(20),
    subject    VARCHAR(500),
    message    TEXT NOT NULL,
    status     VARCHAR(20) NOT NULL DEFAULT 'new'
               CHECK (status IN ('new', 'read', 'replied', 'converted', 'archived')),
    metadata   JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_contact_branch
        FOREIGN KEY (branch_id) REFERENCES core.branches(id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

COMMENT ON COLUMN system.contact_inquiries.metadata IS
'Contact form metadata. Expected structure:
{
  "source_page": "/contact",
  "utm_source": "google",
  "ip_address": "192.168.1.100",
  "converted_to_lead_id": null,
  "replied_by": "user-uuid",
  "replied_at": "2026-06-02T10:00:00Z"
}';

CREATE INDEX idx_contact_status ON system.contact_inquiries (status);
CREATE INDEX idx_contact_branch ON system.contact_inquiries (branch_id);


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 7: ROW-LEVEL SECURITY (RLS) – Multi-Branch Data Isolation      ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝
--
-- HOW IT WORKS:
--   1. Application sets session variables on each request:
--        SET LOCAL app.current_branch_id = '<branch_uuid>';
--        SET LOCAL app.current_user_role  = '<role>';
--   2. RLS policies automatically filter rows by branch_id.
--   3. super_admin bypasses branch filter (sees all branches).
--   4. branch_admin/staff/teacher only see their assigned branch data.
--
-- NOTE: RLS is enforced for all non-superuser database roles.
--       The application connects as a non-superuser role.
-- =============================================================================

-- Helper function to check if current user is super_admin
CREATE OR REPLACE FUNCTION core.is_super_admin() RETURNS BOOLEAN AS $$
BEGIN
    RETURN COALESCE(current_setting('app.current_user_role', true), '') = 'super_admin';
END;
$$ LANGUAGE plpgsql STABLE;

-- Helper function to get current branch_id
CREATE OR REPLACE FUNCTION core.current_branch_id() RETURNS UUID AS $$
BEGIN
    RETURN NULLIF(current_setting('app.current_branch_id', true), '')::UUID;
END;
$$ LANGUAGE plpgsql STABLE;

-- ── ACADEMIC module RLS ──────────────────────────────────────────────────────

ALTER TABLE academic.students ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_students ON academic.students
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE academic.parents ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_parents ON academic.parents
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE academic.teachers ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_teachers ON academic.teachers
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE academic.courses ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_courses ON academic.courses
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE academic.classes ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_classes ON academic.classes
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE academic.enrollments ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_enrollments ON academic.enrollments
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

-- Sessions don't have branch_id directly; filtered via class join
-- or add branch_id denormalized column for direct RLS

-- ── FINANCE module RLS ───────────────────────────────────────────────────────

ALTER TABLE finance.discounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_discounts ON finance.discounts
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE finance.invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_invoices ON finance.invoices
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE finance.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_payments ON finance.payments
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE finance.expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_expenses ON finance.expenses
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

-- ── HR module RLS ────────────────────────────────────────────────────────────

ALTER TABLE hr.employees ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_hr_employees ON hr.employees
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE hr.attendance ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_hr_attendance ON hr.attendance
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE hr.payroll ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_hr_payroll ON hr.payroll
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

-- ── CRM module RLS ───────────────────────────────────────────────────────────

ALTER TABLE crm.campaigns ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_crm_campaigns ON crm.campaigns
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE crm.leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_crm_leads ON crm.leads
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

ALTER TABLE crm.tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_crm_tasks ON crm.tasks
    USING (core.is_super_admin() OR branch_id = core.current_branch_id());

-- ── SYSTEM module RLS ────────────────────────────────────────────────────────

ALTER TABLE system.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_audit_logs ON system.audit_logs
    USING (core.is_super_admin() OR branch_id = core.current_branch_id() OR branch_id IS NULL);

ALTER TABLE system.event_store ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_event_store ON system.event_store
    USING (core.is_super_admin() OR branch_id = core.current_branch_id() OR branch_id IS NULL);

ALTER TABLE system.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_notifications ON system.notifications
    USING (
        core.is_super_admin()
        OR branch_id = core.current_branch_id()
        OR branch_id IS NULL
        -- Users always see their own notifications:
        OR user_id::text = COALESCE(current_setting('app.current_user_id', true), '')
    );

ALTER TABLE system.settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_settings ON system.settings
    USING (core.is_super_admin() OR branch_id = core.current_branch_id() OR branch_id IS NULL);

ALTER TABLE system.contact_inquiries ENABLE ROW LEVEL SECURITY;
CREATE POLICY rls_contact_inquiries ON system.contact_inquiries
    USING (core.is_super_admin() OR branch_id = core.current_branch_id() OR branch_id IS NULL);


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 8: UTILITY TRIGGERS                                            ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝

-- Auto-update updated_at timestamp on any row modification
CREATE OR REPLACE FUNCTION core.trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to all tables with updated_at column
DO $$
DECLARE
    tbl RECORD;
BEGIN
    FOR tbl IN
        SELECT schemaname, tablename
        FROM pg_tables
        WHERE schemaname IN ('core', 'academic', 'finance', 'hr', 'crm', 'system')
    LOOP
        IF EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_schema = tbl.schemaname
              AND table_name = tbl.tablename
              AND column_name = 'updated_at'
        ) THEN
            EXECUTE format(
                'CREATE TRIGGER trg_%I_%I_updated_at
                 BEFORE UPDATE ON %I.%I
                 FOR EACH ROW
                 EXECUTE FUNCTION core.trigger_set_updated_at()',
                tbl.schemaname, tbl.tablename,
                tbl.schemaname, tbl.tablename
            );
        END IF;
    END LOOP;
END;
$$;


-- ╔═══════════════════════════════════════════════════════════════════════════╗
-- ║  SECTION 9: SUMMARY                                                     ║
-- ╚═══════════════════════════════════════════════════════════════════════════╝
--
--  Schema     | Tables | Description
--  -----------|--------|----------------------------------------------------
--  core       |   4    | organizations, branches, users, user_branches,
--             |   1    | refresh_tokens
--  academic   |   8    | students, parents, student_parents, teachers,
--             |        | courses, classes, enrollments, class_sessions,
--             |        | attendance, grade_records
--  finance    |   6    | discounts, invoices, invoice_items, payments,
--             |        | payment_plans, expenses
--  hr         |   5    | employees, contracts, attendance, leave_requests,
--             |        | payroll
--  crm        |   4    | campaigns, leads, interactions, tasks
--  system     |   6    | audit_logs, event_store, notifications, settings,
--             |        | file_attachments, contact_inquiries
--  -----------|--------|----------------------------------------------------
--  TOTAL      |  33+   | tables across 6 schemas
--
--  Features:
--    ✅ Multi-branch tenancy via branch_id FK on all domain tables
--    ✅ Row-Level Security (RLS) with helper functions
--    ✅ JSONB metadata with documented structures on every table
--    ✅ Foreign Keys with appropriate ON DELETE/UPDATE actions
--    ✅ CHECK constraints for enum values and data validation
--    ✅ B-Tree indexes for common queries, BRIN for time-series
--    ✅ Trigram indexes for Vietnamese full-text search
--    ✅ Event sourcing for AI/ML pipeline consumption
--    ✅ Auto-updated timestamps via triggers
--    ✅ Partial indexes for optimized WHERE clause queries
--
-- =============================================================================
-- END OF DDL
-- =============================================================================
