import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { DashboardContent } from './dashboard-content';

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (session?.user?.role === 'student') redirect('/dashboard/portal');
  if (session?.user?.role === 'parent') redirect('/dashboard/portal/parent');
  return <DashboardContent />;
}
