import { CurriculumContent } from './curriculum-content';
export default function CurriculumPage() { return <CurriculumContent />; }
