'use client';
import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Users, TrendingUp, UserCheck, UserX, ArrowRightLeft,
  BarChart3, Building2, Globe, Timer, Download,
} from 'lucide-react';
import { toast } from 'sonner';
import { useBranch } from '@/hooks/use-branch';
import { FadeIn } from '@/components/ui/animate';
import { formatCurrency } from '@/lib/helpers';

const STATUS_LABELS: Record<string, string> = {
  new: 'Mới', contacted: 'Đã liên hệ', qualified: 'Đủ điều kiện',
  proposal: 'Đề xuất', negotiation: 'Đàm phán', converted: 'Đã chuyển đổi', lost: 'Đã mất',
};
const STATUS_COLORS: Record<string, string> = {
  new: 'bg-blue-500', contacted: 'bg-cyan-500', qualified: 'bg-amber-500',
  proposal: 'bg-purple-500', negotiation: 'bg-orange-500', converted: 'bg-green-500', lost: 'bg-red-500',
};
const SOURCE_LABELS: Record<string, string> = {
  website: 'Website', referral: 'Giới thiệu', social_media: 'Mạng xã hội',
  walk_in: 'Đến trực tiếp', phone: 'Điện thoại', event: 'Sự kiện', campaign: 'Chiến dịch', other: 'Khác',
};

export function AnalyticsCrmContent() {
  const { branchId: globalBranchId } = useBranch();
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const fetchAnalytics = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (globalBranchId) params.set('branchId', globalBranchId);
      if (dateFrom) params.set('dateFrom', dateFrom);
      if (dateTo) params.set('dateTo', dateTo);
      const res = await fetch(`/api/crm/analytics?${params}`);
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      setAnalytics(data.analytics);
    } catch { toast.error('Lỗi tải dữ liệu phân tích'); }
    setLoading(false);
  }, [globalBranchId, dateFrom, dateTo]);

  useEffect(() => { fetchAnalytics(); }, [fetchAnalytics]);

  if (loading) {
    return <div className="flex justify-center py-24"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>;
  }

  const ov = analytics?.overall || { totalLeads: 0, convertedLeads: 0, lostLeads: 0, activeLeads: 0, conversionRate: 0, lostRate: 0 };

  return (
    <FadeIn>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <BarChart3 className="h-7 w-7 text-primary" /> Phân tích CRM
            </h1>
            <p className="text-muted-foreground mt-1">Báo cáo tỷ lệ chuyển đổi và hiệu quả pipeline</p>
          </div>
          <Button variant="outline" size="sm" onClick={async () => {
            try {
              const params = new URLSearchParams({ type: 'analytics' });
              if (globalBranchId) params.set('branchId', globalBranchId);
              if (dateFrom) params.set('dateFrom', dateFrom);
              if (dateTo) params.set('dateTo', dateTo);
              const res = await fetch(`/api/crm/export?${params}`);
              if (!res.ok) { toast.error('Lỗi xuất CSV'); return; }
              const blob = await res.blob();
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `crm-analytics-${new Date().toISOString().split('T')[0]}.csv`;
              a.click();
              window.URL.revokeObjectURL(url);
              toast.success('Đã xuất CSV thành công');
            } catch { toast.error('Lỗi xuất file'); }
          }} className="gap-1"><Download className="h-4 w-4" /> Xuất CSV</Button>
        </div>

        {/* Date Filters */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex flex-wrap gap-4 items-end">
              <div><Label className="text-xs">Từ ngày</Label><Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-44" /></div>
              <div><Label className="text-xs">Đến ngày</Label><Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-44" /></div>
            </div>
          </CardContent>
        </Card>

        {/* Overall KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Card><CardContent className="pt-4 text-center">
            <Users className="h-6 w-6 mx-auto text-blue-600 mb-1" />
            <p className="text-2xl font-bold">{ov.totalLeads}</p>
            <p className="text-xs text-muted-foreground">Tổng Leads</p>
          </CardContent></Card>
          <Card><CardContent className="pt-4 text-center">
            <UserCheck className="h-6 w-6 mx-auto text-green-600 mb-1" />
            <p className="text-2xl font-bold">{ov.convertedLeads}</p>
            <p className="text-xs text-muted-foreground">Đã chuyển đổi</p>
          </CardContent></Card>
          <Card><CardContent className="pt-4 text-center">
            <UserX className="h-6 w-6 mx-auto text-red-600 mb-1" />
            <p className="text-2xl font-bold">{ov.lostLeads}</p>
            <p className="text-xs text-muted-foreground">Đã mất</p>
          </CardContent></Card>
          <Card><CardContent className="pt-4 text-center">
            <TrendingUp className="h-6 w-6 mx-auto text-amber-600 mb-1" />
            <p className="text-2xl font-bold">{ov.activeLeads}</p>
            <p className="text-xs text-muted-foreground">Đang theo dõi</p>
          </CardContent></Card>
          <Card><CardContent className="pt-4 text-center">
            <ArrowRightLeft className="h-6 w-6 mx-auto text-primary mb-1" />
            <p className="text-2xl font-bold text-green-600">{ov.conversionRate}%</p>
            <p className="text-xs text-muted-foreground">Tỷ lệ chuyển đổi</p>
          </CardContent></Card>
          <Card><CardContent className="pt-4 text-center">
            <UserX className="h-6 w-6 mx-auto text-red-400 mb-1" />
            <p className="text-2xl font-bold text-red-600">{ov.lostRate}%</p>
            <p className="text-xs text-muted-foreground">Tỷ lệ mất</p>
          </CardContent></Card>
        </div>

        {/* Pipeline */}
        {analytics?.pipeline?.length > 0 && (
          <Card>
            <CardHeader><CardTitle className="text-lg">Pipeline Leads</CardTitle></CardHeader>
            <CardContent>
              <div className="flex items-end gap-1 h-40">
                {analytics.pipeline.map((p: any) => {
                  const maxCount = Math.max(...analytics.pipeline.map((x: any) => x.count), 1);
                  const height = Math.max((p.count / maxCount) * 100, 8);
                  return (
                    <div key={p.status} className="flex-1 flex flex-col items-center gap-1">
                      <span className="text-xs font-semibold">{p.count}</span>
                      <div className={`w-full rounded-t ${STATUS_COLORS[p.status] || 'bg-gray-400'}`} style={{ height: `${height}%` }} />
                      <span className="text-[10px] text-muted-foreground text-center leading-tight">{STATUS_LABELS[p.status]}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* By Branch */}
          {analytics?.byBranch?.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Building2 className="h-5 w-5" /> Theo chi nhánh</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analytics.byBranch.map((b: any) => (
                    <div key={b.branchId} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold">{b.branchName} <span className="text-xs text-muted-foreground">({b.branchCode})</span></span>
                        <Badge className="bg-green-100 text-green-700">{b.conversionRate}% chuyển đổi</Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div><span className="text-muted-foreground">Tổng:</span> {b.totalLeads}</div>
                        <div><span className="text-muted-foreground">Converted:</span> {b.convertedLeads}</div>
                        <div><span className="text-muted-foreground">Lost:</span> {b.lostLeads}</div>
                      </div>
                      {b.avgDaysToConvert !== null && (
                        <div className="mt-1 text-xs flex items-center gap-1"><Timer className="h-3 w-3" /> TB {b.avgDaysToConvert} ngày để chuyển đổi</div>
                      )}
                      {/* Conversion bar */}
                      <div className="mt-2 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-green-500 rounded-full transition-all" style={{ width: `${b.conversionRate}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* By Source */}
          {analytics?.bySource?.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Globe className="h-5 w-5" /> Theo nguồn</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analytics.bySource.sort((a: any, b: any) => b.rate - a.rate).map((s: any) => (
                    <div key={s.source} className="flex items-center gap-3">
                      <span className="w-24 text-sm font-medium truncate">{SOURCE_LABELS[s.source] || s.source}</span>
                      <div className="flex-1">
                        <div className="h-6 bg-gray-100 rounded-full overflow-hidden relative">
                          <div className="h-full bg-primary/80 rounded-full transition-all" style={{ width: `${Math.max(s.rate, 2)}%` }} />
                          <span className="absolute inset-0 flex items-center justify-center text-xs font-medium">
                            {s.converted}/{s.total} ({s.rate}%)
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Empty state */}
        {!analytics?.pipeline?.length && !analytics?.byBranch?.length && (
          <Card>
            <CardContent className="py-16 text-center">
              <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">Chưa có dữ liệu CRM để phân tích.</p>
              <p className="text-sm text-muted-foreground mt-1">Hãy thêm leads để bắt đầu theo dõi hiệu quả.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </FadeIn>
  );
}
