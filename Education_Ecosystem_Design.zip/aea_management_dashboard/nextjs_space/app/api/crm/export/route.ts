export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { calculateConversionAnalytics } from '@/lib/crm/analytics';

const STATUS_LABELS: Record<string, string> = {
  new: 'Mới', contacted: 'Đã liên hệ', qualified: 'Đủ điều kiện',
  proposal: 'Đề xuất', negotiation: 'Đàm phán', converted: 'Đã chuyển đổi', lost: 'Đã mất',
};
const SOURCE_LABELS: Record<string, string> = {
  website: 'Website', referral: 'Giới thiệu', social_media: 'Mạng xã hội',
  walk_in: 'Đến trực tiếp', phone: 'Điện thoại', event: 'Sự kiện', campaign: 'Chiến dịch', other: 'Khác',
};

function escapeCSV(val: string | null | undefined): string {
  if (!val) return '';
  const str = String(val);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

// ── GET: Export CRM data as CSV ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền xuất dữ liệu' }, { status: 403 });
    }

    const url = new URL(request.url);
    const type = url.searchParams.get('type') || 'leads'; // leads | analytics | tasks | campaigns
    const branchId = session.user.role !== 'super_admin'
      ? session.user.primaryBranchId
      : url.searchParams.get('branchId') || undefined;
    const dateFrom = url.searchParams.get('dateFrom');
    const dateTo = url.searchParams.get('dateTo');

    let csvContent = '';
    let filename = 'export.csv';

    if (type === 'leads') {
      const where: any = {};
      if (branchId) where.branchId = branchId;
      if (dateFrom || dateTo) {
        where.createdAt = {};
        if (dateFrom) where.createdAt.gte = new Date(dateFrom);
        if (dateTo) where.createdAt.lte = new Date(dateTo);
      }

      const leads = await prisma.crmLead.findMany({
        where,
        include: {
          branch: { select: { name: true } },
          assignee: { select: { fullName: true } },
          interestCourse: { select: { name: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: 5000,
      });

      const BOM = '\uFEFF';
      const headers = ['Họ tên', 'Email', 'SĐT', 'Nguồn', 'Trạng thái', 'Điểm', 'Giá trị kỳ vọng', 'Chi nhánh', 'Người phụ trách', 'Khóa quan tâm', 'Ngày tạo', 'Liên hệ gần nhất', 'Ghi chú'];
      const rows = leads.map((l: any) => [
        escapeCSV(l.fullName),
        escapeCSV(l.email),
        escapeCSV(l.phone),
        escapeCSV(SOURCE_LABELS[l.source] || l.source),
        escapeCSV(STATUS_LABELS[l.status] || l.status),
        String(l.score || 0),
        String(l.expectedValue || 0),
        escapeCSV(l.branch?.name),
        escapeCSV(l.assignee?.fullName),
        escapeCSV(l.interestCourse?.name),
        l.createdAt?.toISOString()?.split('T')[0] || '',
        l.lastContacted?.toISOString()?.split('T')[0] || '',
        escapeCSV(l.notes),
      ].join(','));

      csvContent = BOM + headers.join(',') + '\n' + rows.join('\n');
      filename = `crm-leads-${new Date().toISOString().split('T')[0]}.csv`;

    } else if (type === 'analytics') {
      const analytics = await calculateConversionAnalytics(
        branchId || undefined,
        dateFrom ? new Date(dateFrom) : undefined,
        dateTo ? new Date(dateTo) : undefined,
      );

      const BOM = '\uFEFF';
      const lines: string[] = [];

      // Overall summary
      lines.push('=== TỔNG QUAN ===');
      lines.push('Chỉ số,Giá trị');
      lines.push(`Tổng leads,${analytics.overall.totalLeads}`);
      lines.push(`Đã chuyển đổi,${analytics.overall.convertedLeads}`);
      lines.push(`Đã mất,${analytics.overall.lostLeads}`);
      lines.push(`Đang theo dõi,${analytics.overall.activeLeads}`);
      lines.push(`Tỷ lệ chuyển đổi,${analytics.overall.conversionRate}%`);
      lines.push(`Tỷ lệ mất,${analytics.overall.lostRate}%`);
      lines.push('');

      // By Branch
      lines.push('=== THEO CHI NHÁNH ===');
      lines.push('Chi nhánh,Mã,Tổng,Đã chuyển đổi,Đã mất,Tỷ lệ chuyển đổi,TB ngày chuyển đổi');
      for (const b of analytics.byBranch) {
        lines.push(`${escapeCSV(b.branchName)},${b.branchCode},${b.totalLeads},${b.convertedLeads},${b.lostLeads},${b.conversionRate}%,${b.avgDaysToConvert ?? 'N/A'}`);
      }
      lines.push('');

      // By Source
      lines.push('=== THEO NGUỒN ===');
      lines.push('Nguồn,Tổng,Đã chuyển đổi,Tỷ lệ');
      for (const s of analytics.bySource) {
        lines.push(`${escapeCSV(SOURCE_LABELS[s.source] || s.source)},${s.total},${s.converted},${s.rate}%`);
      }
      lines.push('');

      // Pipeline
      lines.push('=== PIPELINE ===');
      lines.push('Trạng thái,Số lượng');
      for (const p of analytics.pipeline) {
        lines.push(`${escapeCSV(STATUS_LABELS[p.status] || p.status)},${p.count}`);
      }

      csvContent = BOM + lines.join('\n');
      filename = `crm-analytics-${new Date().toISOString().split('T')[0]}.csv`;

    } else if (type === 'tasks') {
      const where: any = {};
      if (branchId) where.branchId = branchId;
      const tasks = await prisma.crmTask.findMany({
        where,
        include: {
          lead: { select: { fullName: true } },
          branch: { select: { name: true } },
          assignee: { select: { fullName: true } },
        },
        orderBy: { dueDate: 'desc' },
        take: 5000,
      });

      const BOM = '\uFEFF';
      const headers = ['Tiêu đề', 'Lead', 'Chi nhánh', 'Người phụ trách', 'Loại', 'Ưu tiên', 'Trạng thái', 'Hạn chót', 'Hoàn thành', 'Mô tả'];
      const rows = tasks.map((t: any) => [
        escapeCSV(t.title),
        escapeCSV(t.lead?.fullName),
        escapeCSV(t.branch?.name),
        escapeCSV(t.assignee?.fullName),
        escapeCSV(t.taskType),
        escapeCSV(t.priority),
        escapeCSV(t.status),
        t.dueDate?.toISOString()?.split('T')[0] || '',
        t.completedAt?.toISOString()?.split('T')[0] || '',
        escapeCSV(t.description),
      ].join(','));

      csvContent = BOM + headers.join(',') + '\n' + rows.join('\n');
      filename = `crm-tasks-${new Date().toISOString().split('T')[0]}.csv`;

    } else if (type === 'campaigns') {
      const where: any = {};
      if (branchId) where.branchId = branchId;
      const campaigns = await prisma.crmCampaign.findMany({
        where,
        include: {
          branch: { select: { name: true } },
          creator: { select: { fullName: true } },
          _count: { select: { leads: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: 5000,
      });

      const BOM = '\uFEFF';
      const headers = ['Tên', 'Loại', 'Chi nhánh', 'Trạng thái', 'Ngân sách', 'Chi tiêu', 'Số leads', 'Ngày bắt đầu', 'Ngày kết thúc', 'Người tạo', 'Mô tả'];
      const rows = campaigns.map((c: any) => [
        escapeCSV(c.name),
        escapeCSV(c.type),
        escapeCSV(c.branch?.name),
        escapeCSV(c.status),
        String(c.budget || 0),
        String(c.spent || 0),
        String(c._count?.leads || 0),
        c.startDate?.toISOString()?.split('T')[0] || '',
        c.endDate?.toISOString()?.split('T')[0] || '',
        escapeCSV(c.creator?.fullName),
        escapeCSV(c.description),
      ].join(','));

      csvContent = BOM + headers.join(',') + '\n' + rows.join('\n');
      filename = `crm-campaigns-${new Date().toISOString().split('T')[0]}.csv`;

    } else {
      return NextResponse.json({ error: 'Loại export không hợp lệ (leads|analytics|tasks|campaigns)' }, { status: 400 });
    }

    return new NextResponse(csvContent, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    });
  } catch (error: any) {
    console.error('[CRM/Export GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
