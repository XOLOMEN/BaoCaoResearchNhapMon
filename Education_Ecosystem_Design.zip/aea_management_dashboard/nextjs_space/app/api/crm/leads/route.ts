export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

// ── Helper: build branch-scoped where clause ──
function buildBranchWhere(session: any, queryBranchId?: string | null) {
  const where: any = {};
  if (session.user.role !== 'super_admin') {
    where.branchId = session.user.primaryBranchId;
  } else if (queryBranchId) {
    where.branchId = queryBranchId;
  }
  return where;
}

// ── Helper: RBAC check for write operations ──
function canModifyLeads(role: string): boolean {
  return role === 'super_admin' || role === 'staff';
}

const VALID_STATUSES = ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'converted', 'lost'];
const VALID_SOURCES = ['website', 'referral', 'social_media', 'walk_in', 'phone', 'event', 'campaign', 'other'];

// ── GET: List leads with filters ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const status = url.searchParams.get('status');
    const source = url.searchParams.get('source');
    const assignedTo = url.searchParams.get('assignedTo');
    const search = url.searchParams.get('search');
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'));
    const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get('limit') || '50')));

    const where: any = buildBranchWhere(session, branchId);
    if (status) where.status = status;
    if (source) where.source = source;
    if (assignedTo) where.assignedTo = assignedTo;
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    const [leads, total] = await Promise.all([
      prisma.crmLead.findMany({
        where,
        include: {
          branch: { select: { name: true, code: true } },
          campaign: { select: { id: true, name: true } },
          interestCourse: { select: { id: true, name: true } },
          assignee: { select: { id: true, fullName: true } },
          convertedStudent: { select: { id: true, fullName: true, studentCode: true } },
          _count: { select: { interactions: true } },
        },
        orderBy: [{ createdAt: 'desc' }],
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.crmLead.count({ where }),
    ]);

    return NextResponse.json({
      leads: leads.map((l: any) => ({
        ...l,
        createdAt: l.createdAt?.toISOString(),
        updatedAt: l.updatedAt?.toISOString(),
        convertedAt: l.convertedAt?.toISOString() || null,
        lastContacted: l.lastContacted?.toISOString() || null,
        nextFollowUp: l.nextFollowUp?.toISOString() || null,
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch (error: any) {
    console.error('[CRM/Leads GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Create new lead ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLeads(session.user.role)) {
      return NextResponse.json({ error: 'Không có quyền tạo lead' }, { status: 403 });
    }

    const body = await request.json();
    const {
      branchId, fullName, email, phone, source, campaignId,
      interestCourseId, interestNotes, assignedTo, score,
      expectedValue, nextFollowUp, notes, tags,
    } = body ?? {};

    if (!branchId || !fullName || !phone || !source) {
      return NextResponse.json({ error: 'Thiếu thông tin bắt buộc (branchId, fullName, phone, source)' }, { status: 400 });
    }
    if (!VALID_SOURCES.includes(source)) {
      return NextResponse.json({ error: `Nguồn không hợp lệ. Chấp nhận: ${VALID_SOURCES.join(', ')}` }, { status: 400 });
    }

    const lead = await prisma.crmLead.create({
      data: {
        branchId,
        fullName,
        email: email || null,
        phone,
        source,
        campaignId: campaignId || null,
        interestCourseId: interestCourseId || null,
        interestNotes: interestNotes || null,
        assignedTo: assignedTo || session.user.id,
        status: 'new',
        score: score || 0,
        expectedValue: expectedValue || null,
        nextFollowUp: nextFollowUp ? new Date(nextFollowUp) : null,
        notes: notes || null,
        tags: tags || [],
      },
      include: {
        branch: { select: { name: true } },
        interestCourse: { select: { name: true } },
        assignee: { select: { fullName: true } },
      },
    });

    // EventStore: log lead creation
    await prisma.eventStore.create({
      data: {
        branchId,
        aggregateType: 'CrmLead',
        aggregateId: lead.id,
        eventType: 'LEAD_CREATED',
        payload: { fullName, source, phone, createdBy: session.user.id },
        sequenceNumber: 1,
      },
    });

    return NextResponse.json({ lead }, { status: 201 });
  } catch (error: any) {
    console.error('[CRM/Leads POST]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── PUT: Update lead ──
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLeads(session.user.role)) {
      return NextResponse.json({ error: 'Không có quyền cập nhật lead' }, { status: 403 });
    }

    const body = await request.json();
    const { id, ...updateFields } = body ?? {};
    if (!id) return NextResponse.json({ error: 'Thiếu lead ID' }, { status: 400 });

    const existing = await prisma.crmLead.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Không tìm thấy lead' }, { status: 404 });

    // Branch scope check for non-super_admin
    if (session.user.role !== 'super_admin' && existing.branchId !== session.user.primaryBranchId) {
      return NextResponse.json({ error: 'Không có quyền cập nhật lead chi nhánh khác' }, { status: 403 });
    }

    // Status transition validation
    if (updateFields.status && updateFields.status !== existing.status) {
      const validTransitions: Record<string, string[]> = {
        new: ['contacted', 'lost'],
        contacted: ['qualified', 'lost'],
        qualified: ['proposal', 'lost'],
        proposal: ['negotiation', 'lost'],
        negotiation: ['converted', 'lost'],
      };
      const allowed = validTransitions[existing.status] || [];
      if (!allowed.includes(updateFields.status)) {
        return NextResponse.json({
          error: `Không thể chuyển trạng thái từ '${existing.status}' sang '${updateFields.status}'`,
        }, { status: 400 });
      }
    }

    // Prevent direct conversion via PUT - must use /convert endpoint
    if (updateFields.status === 'converted') {
      return NextResponse.json({ error: 'Sử dụng API /api/crm/leads/convert để chuyển đổi lead' }, { status: 400 });
    }

    const data: any = {};
    if (updateFields.fullName) data.fullName = updateFields.fullName;
    if (updateFields.email !== undefined) data.email = updateFields.email || null;
    if (updateFields.phone) data.phone = updateFields.phone;
    if (updateFields.source && VALID_SOURCES.includes(updateFields.source)) data.source = updateFields.source;
    if (updateFields.campaignId !== undefined) data.campaignId = updateFields.campaignId || null;
    if (updateFields.interestCourseId !== undefined) data.interestCourseId = updateFields.interestCourseId || null;
    if (updateFields.interestNotes !== undefined) data.interestNotes = updateFields.interestNotes;
    if (updateFields.assignedTo !== undefined) data.assignedTo = updateFields.assignedTo || null;
    if (updateFields.status) data.status = updateFields.status;
    if (updateFields.score !== undefined) data.score = updateFields.score;
    if (updateFields.expectedValue !== undefined) data.expectedValue = updateFields.expectedValue;
    if (updateFields.lostReason !== undefined) data.lostReason = updateFields.lostReason;
    if (updateFields.lastContacted) data.lastContacted = new Date(updateFields.lastContacted);
    if (updateFields.nextFollowUp !== undefined) data.nextFollowUp = updateFields.nextFollowUp ? new Date(updateFields.nextFollowUp) : null;
    if (updateFields.notes !== undefined) data.notes = updateFields.notes;
    if (updateFields.tags !== undefined) data.tags = updateFields.tags;

    const lead = await prisma.crmLead.update({
      where: { id },
      data,
      include: {
        branch: { select: { name: true } },
        assignee: { select: { fullName: true } },
      },
    });

    // EventStore: log update
    await prisma.eventStore.create({
      data: {
        branchId: lead.branchId,
        aggregateType: 'CrmLead',
        aggregateId: lead.id,
        eventType: updateFields.status === 'lost' ? 'LEAD_LOST' : 'LEAD_UPDATED',
        payload: {
          changes: updateFields,
          previousStatus: existing.status,
          updatedBy: session.user.id,
        },
        sequenceNumber: 1,
      },
    });

    return NextResponse.json({ lead });
  } catch (error: any) {
    console.error('[CRM/Leads PUT]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── DELETE: Soft-delete or hard-delete a lead ──
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Chỉ Super Admin có quyền xóa lead' }, { status: 403 });
    }

    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Thiếu lead ID' }, { status: 400 });

    const existing = await prisma.crmLead.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Không tìm thấy lead' }, { status: 404 });

    // Cannot delete converted leads
    if (existing.status === 'converted') {
      return NextResponse.json({ error: 'Không thể xóa lead đã chuyển đổi' }, { status: 400 });
    }

    await prisma.crmLead.delete({ where: { id } });

    await prisma.eventStore.create({
      data: {
        branchId: existing.branchId,
        aggregateType: 'CrmLead',
        aggregateId: id,
        eventType: 'LEAD_DELETED',
        payload: { fullName: existing.fullName, deletedBy: session.user.id },
        sequenceNumber: 1,
      },
    });

    return NextResponse.json({ success: true, message: 'Đã xóa lead' });
  } catch (error: any) {
    console.error('[CRM/Leads DELETE]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
