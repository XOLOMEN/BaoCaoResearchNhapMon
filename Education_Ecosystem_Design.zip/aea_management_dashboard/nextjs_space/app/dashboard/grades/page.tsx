import { GradesContent } from './grades-content';
export default function GradesPage() { return <GradesContent />; }
