'use client';
import { useState } from 'react';
import { FlaskConical, Play, CheckCircle2, XCircle, Info, ArrowRight, RotateCcw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatCurrency } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

const STEP_ICONS: Record<string, string> = {
  success: '✅',
  error: '❌',
  info: 'ℹ️',
};

export function TestScenarioContent() {
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const runTest = async () => {
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch('/api/finance/test-scenario', { method: 'POST' });
      const data = await res?.json?.();
      if (!res?.ok) {
        toast.error(data?.error ?? 'Lỗi chạy test');
        setResult(data);
        return;
      }
      setResult(data);
      toast.success(data?.success ? 'Test thành công!' : 'Test hoàn tất (có cảnh báo)');
    } catch {
      toast.error('Đã xảy ra lỗi');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <FadeIn>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
              <FlaskConical className="w-6 h-6 text-primary" /> Kịch bản Test: Thanh toán một phần
            </h1>
            <p className="text-muted-foreground text-sm">Giả lập luồng: Ghi danh → Hóa đơn nháp → Phát hành → Đóng 50% → Kiểm tra công nợ</p>
          </div>
          <Button onClick={runTest} disabled={loading} className="gap-2">
            {loading ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            {loading ? 'Đang chạy...' : result ? 'Chạy lại' : 'Chạy Test'}
          </Button>
        </div>
      </FadeIn>

      {/* Flow Description */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Mô tả kịch bản (State Machine)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <Badge variant="outline" className="bg-slate-50">draft</Badge>
            <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
            <Badge variant="outline" className="bg-blue-50 text-blue-700">issued</Badge>
            <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
            <Badge variant="outline" className="bg-amber-50 text-amber-700">partially_paid (50%)</Badge>
            <ArrowRight className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
            <Badge variant="outline" className="bg-orange-50 text-orange-700">Kiểm tra công nợ</Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            Test tự động: tạo ghi danh → auto-invoice → phát hành → thanh toán 50% → so sánh snapshot tài chính trước/sau.
          </p>
        </CardContent>
      </Card>

      {/* Results */}
      {result && (
        <FadeIn>
          {/* Summary Card */}
          <Card className={result.success ? 'border-emerald-200 bg-emerald-50/30' : 'border-amber-200 bg-amber-50/30'}>
            <CardContent className="p-5">
              <div className="flex items-start gap-3">
                {result.success ? <CheckCircle2 className="w-6 h-6 text-emerald-600 mt-0.5" /> : <XCircle className="w-6 h-6 text-amber-600 mt-0.5" />}
                <div>
                  <p className="font-semibold text-sm">{result.summary}</p>
                  {result.invoiceNumber && (
                    <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div><span className="text-muted-foreground">Hóa đơn:</span><p className="font-mono font-medium">{result.invoiceNumber}</p></div>
                      <div><span className="text-muted-foreground">Học phí:</span><p className="font-mono font-medium">{formatCurrency(result.totalFee)}</p></div>
                      <div><span className="text-muted-foreground">Đã đóng (50%):</span><p className="font-mono font-medium text-emerald-600">{formatCurrency(result.partialPayment)}</p></div>
                      <div><span className="text-muted-foreground">Còn nợ:</span><p className="font-mono font-bold text-orange-600">{formatCurrency(result.remaining)}</p></div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Step-by-step log */}
          <Card className="mt-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Chi tiết từng bước</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {(result.steps ?? []).map((s: any, i: number) => (
                  <div key={i} className="px-4 py-3 hover:bg-muted/30 transition-colors">
                    <div className="flex items-start gap-2">
                      <span className="text-sm mt-0.5">{STEP_ICONS[s.status] || '❓'}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="secondary" className="text-[10px] font-mono">Step {s.step}</Badge>
                          <p className="text-sm font-medium">{s.title}</p>
                        </div>
                        {s.data && (
                          <div className="mt-2 p-2.5 rounded bg-muted/50 overflow-x-auto">
                            <pre className="text-[11px] text-muted-foreground whitespace-pre-wrap font-mono">
                              {JSON.stringify(s.data, null, 2)}
                            </pre>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Delta Highlight */}
          {result.steps?.find((s: any) => s.step === 7) && (
            <Card className="mt-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Info className="w-4 h-4 text-primary" /> Phân tích thay đổi trên Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(() => {
                  const deltaStep = result.steps.find((s: any) => s.step === 7);
                  const d = deltaStep?.data;
                  if (!d) return null;
                  return (
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                        <DeltaCard
                          label="Tổng doanh thu"
                          delta={d.delta?.totalRevenue}
                          expected={d.expected?.totalRevenue_increase}
                          match={d.match?.revenue}
                        />
                        <DeltaCard
                          label="Đã thu"
                          delta={d.delta?.totalCollected}
                          expected={d.expected?.totalCollected_increase}
                          match={d.match?.collected}
                        />
                        <DeltaCard
                          label="Công nợ tăng thêm"
                          delta={d.delta?.totalOutstanding}
                          expected={d.expected?.totalOutstanding_increase}
                          match={d.match?.outstanding}
                        />
                        <DeltaCard
                          label="HĐ partially_paid"
                          delta={d.delta?.partialCount}
                          expected={d.expected?.partialCount_increase}
                          match={d.match?.partialCount}
                          isCurrency={false}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        💡 Quay về <a href="/dashboard" className="text-primary underline">Dashboard</a> để xem biểu đồ Doanh thu theo tháng đã phản ánh đúng khoản thu mới.
                        Hoặc xem <a href="/dashboard/finance/invoices" className="text-primary underline">Hóa đơn</a> để thấy trạng thái partially_paid.
                      </p>
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          )}
        </FadeIn>
      )}

      {/* Instructions if no result */}
      {!result && !loading && (
        <Card>
          <CardContent className="py-12 text-center">
            <FlaskConical className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Nhấn <strong>Chạy Test</strong> để bắt đầu kịch bản giả lập</p>
            <p className="text-xs text-muted-foreground mt-1">Hệ thống sẽ tạo dữ liệu test và kiểm tra logic state machine tự động</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function DeltaCard({ label, delta, expected, match, isCurrency = true }: {
  label: string; delta: number; expected: number; match: boolean; isCurrency?: boolean;
}) {
  const fmt = (v: number) => isCurrency
    ? new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(v)
    : `+${v}`;

  return (
    <div className={`p-3 rounded-lg border ${match ? 'border-emerald-200 bg-emerald-50/50' : 'border-red-200 bg-red-50/50'}`}>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-mono font-bold mt-1">{isCurrency ? '+' : ''}{fmt(delta)}</p>
      <p className="text-[10px] text-muted-foreground mt-0.5">
        Kỳ vọng: {isCurrency ? '+' : ''}{fmt(expected)}
      </p>
      <Badge variant="secondary" className={`text-[9px] mt-1 ${match ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
        {match ? '✓ Đúng' : '✗ Sai'}
      </Badge>
    </div>
  );
}
