export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, phone, subject, message, branchId } = body ?? {};
    if (!name || !email || !message) {
      return NextResponse.json({ error: 'Vui lòng điền đầy đủ thông tin' }, { status: 400 });
    }

    await prisma.contactInquiry.create({
      data: { name, email, phone, subject, message, branchId: branchId || null, status: 'new' },
    });

    // Send notification email
    try {
      const htmlBody = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #1e40af; border-bottom: 2px solid #1e40af; padding-bottom: 10px;">Liên hệ mới từ AEA</h2>
          <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Họ tên:</strong> ${name}</p>
            <p><strong>Email:</strong> <a href="mailto:${email}">${email}</a></p>
            ${phone ? `<p><strong>SĐT:</strong> ${phone}</p>` : ''}
            ${subject ? `<p><strong>Tiêu đề:</strong> ${subject}</p>` : ''}
            <p><strong>Nội dung:</strong></p>
            <div style="background: white; padding: 15px; border-radius: 4px; border-left: 4px solid #1e40af;">${message}</div>
          </div>
        </div>
      `;
      const appUrl = process.env.NEXTAUTH_URL ?? '';
      let appName = 'AEA Education';
      try { appName = new URL(appUrl).hostname?.split?.('.')?.[0] ?? 'AEA'; } catch {}

      await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          deployment_token: process.env.ABACUSAI_API_KEY,
          app_id: process.env.WEB_APP_ID,
          notification_id: process.env.NOTIF_ID_LIN_H_YU_CU_MI,
          subject: `[AEA] Liên hệ mới từ ${name}`,
          body: htmlBody,
          is_html: true,
          recipient_email: 'aaumy2011@gmail.com',
          reply_to: email,
          sender_email: `noreply@${(() => { try { return new URL(appUrl).hostname; } catch { return 'aea.edu.vn'; } })()}`,
          sender_alias: appName,
        }),
      });
    } catch (emailErr: any) {
      console.error('Email notification failed:', emailErr);
    }

    return NextResponse.json({ success: true, message: 'Gửi thành công' });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
