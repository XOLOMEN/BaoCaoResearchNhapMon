import { CourseDetailContent } from './course-detail-content';
export default function LmsCourseDetailPage() { return <CourseDetailContent />; }
