export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { recalcEnrollmentProgress } from '@/lib/lms/helpers';

// ── GET: Get progress for an enrollment ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const enrollmentId = url.searchParams.get('enrollmentId');
    if (!enrollmentId) return NextResponse.json({ error: 'enrollmentId bắt buộc' }, { status: 400 });

    const progress = await prisma.lmsProgress.findMany({
      where: { lmsEnrollmentId: enrollmentId },
      include: {
        lesson: { select: { id: true, title: true, type: true, sortOrder: true, durationMin: true } },
      },
      orderBy: { lesson: { sortOrder: 'asc' } },
    });

    return NextResponse.json(progress);
  } catch (error: any) {
    console.error('LMS progress GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Update progress (upsert) ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { enrollmentId, lessonId, status, progressPct, timeSpentSec, lastPosition } = body;
    if (!enrollmentId || !lessonId) {
      return NextResponse.json({ error: 'enrollmentId và lessonId bắt buộc' }, { status: 400 });
    }

    const data: any = {};
    if (status) data.status = status;
    if (progressPct !== undefined) data.progressPct = parseFloat(progressPct);
    if (timeSpentSec !== undefined) data.timeSpentSec = parseInt(timeSpentSec);
    if (lastPosition !== undefined) data.lastPosition = lastPosition;
    if (status === 'completed') data.completedAt = new Date();

    const progress = await prisma.lmsProgress.upsert({
      where: {
        lmsEnrollmentId_lessonId: { lmsEnrollmentId: enrollmentId, lessonId },
      },
      update: data,
      create: {
        lmsEnrollmentId: enrollmentId,
        lessonId,
        ...data,
      },
    });

    // Recalculate enrollment overall progress
    const overallPct = await recalcEnrollmentProgress(prisma, enrollmentId);

    return NextResponse.json({ progress, overallPct });
  } catch (error: any) {
    console.error('LMS progress POST error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
