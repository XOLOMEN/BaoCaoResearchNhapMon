'use client';
import { useState, useEffect } from 'react';
import { ClipboardList, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBranch } from '@/hooks/use-branch';
import { formatDate, getStatusColor, getStatusLabel } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

export function EnrollmentsContent() {
  const { branchId } = useBranch();
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [students, setStudents] = useState<any[]>([]);
  const [classes, setClasses] = useState<any[]>([]);
  const [form, setForm] = useState<any>({});

  const load = () => {
    setLoading(true);
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/enrollments${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setEnrollments(d?.enrollments??[])).catch(()=>{}).finally(()=>setLoading(false));
  };

  useEffect(() => { load(); }, [branchId]);
  useEffect(() => {
    const sq = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/students${sq}&limit=100`).then((r:any)=>r?.json?.()).then((d:any)=>setStudents(d?.students??[])).catch(()=>{});
    fetch(`/api/classes${sq}`).then((r:any)=>r?.json?.()).then((d:any)=>setClasses(d?.classes??[])).catch(()=>{});
  }, [branchId]);

  const handleAdd = async () => {
    if (!form.studentId || !form.classId) { toast.error('Vui lòng chọn học viên và lớp'); return; }
    const cls = classes?.find?.((c:any)=>c?.id===form.classId);
    const res = await fetch('/api/enrollments', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({studentId:form.studentId,classId:form.classId,branchId:cls?.branchId||branchId}) });
    const data = await res?.json?.();
    if (!res?.ok) { toast.error(data?.error??'Lỗi'); return; }
    toast.success('Ghi danh thành công'); setShowAdd(false); setForm({}); load();
  };

  return (
    <div className="space-y-6">
      <FadeIn><div className="flex items-center justify-between">
        <div><h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><ClipboardList className="w-6 h-6 text-primary" /> Quản lý Ghi danh</h1><p className="text-muted-foreground text-sm">Ghi danh học viên vào lớp học</p></div>
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogTrigger asChild><Button size="sm" className="gap-1"><Plus className="w-4 h-4" /> Ghi danh mới</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Ghi danh học viên</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="text-xs">Học viên</Label>
                <Select value={form.studentId??''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),studentId:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn học viên" /></SelectTrigger>
                  <SelectContent>{students?.map?.((s:any)=><SelectItem key={s.id} value={s.id}>{s.fullName} ({s.studentCode})</SelectItem>)}</SelectContent>
                </Select></div>
              <div><Label className="text-xs">Lớp học</Label>
                <Select value={form.classId??''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),classId:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn lớp" /></SelectTrigger>
                  <SelectContent>{classes?.map?.((c:any)=><SelectItem key={c.id} value={c.id}>{c.name} ({c.classCode})</SelectItem>)}</SelectContent>
                </Select></div>
            </div>
            <div className="flex justify-end gap-2 mt-4"><Button variant="outline" onClick={()=>setShowAdd(false)}>Hủy</Button><Button onClick={handleAdd}>Ghi danh</Button></div>
          </DialogContent>
        </Dialog>
      </div></FadeIn>
      <Card><CardContent className="p-0"><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-muted/50"><tr>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Học viên</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Lớp học</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Khóa học</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Giáo viên</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Ngày ghi danh</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Trạng thái</th>
      </tr></thead><tbody>
        {loading ? <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Đang tải...</td></tr> :
        (enrollments??[])?.length===0 ? <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Không có dữ liệu</td></tr> :
        (enrollments??[])?.map?.((e:any)=>(
          <tr key={e?.id} className="border-t border-border hover:bg-muted/30 transition-colors">
            <td className="px-4 py-3"><span className="font-medium">{e?.student?.fullName??''}</span><br/><span className="text-[10px] text-muted-foreground font-mono">{e?.student?.studentCode??''}</span></td>
            <td className="px-4 py-3 text-xs">{e?.class?.name??''} <span className="text-muted-foreground">({e?.class?.classCode??''})</span></td>
            <td className="px-4 py-3 text-xs">{e?.class?.course?.name??''}</td>
            <td className="px-4 py-3 text-xs">{e?.class?.teacher?.fullName??''}</td>
            <td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(e?.enrolledAt)}</td>
            <td className="px-4 py-3"><Badge className={`text-[10px] ${getStatusColor(e?.status??'')}`}>{getStatusLabel(e?.status??'')}</Badge></td>
          </tr>
        ))}
      </tbody></table></div></CardContent></Card>
    </div>
  );
}
