'use client';
import { useState, useEffect } from 'react';
import { Award, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useBranch } from '@/hooks/use-branch';
import { formatDate } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

export function GradesContent() {
  const { branchId } = useBranch();
  const [grades, setGrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [form, setForm] = useState<any>({maxScore:'100',weight:'1'});

  const load = () => {
    setLoading(true);
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/grades${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setGrades(d?.grades??[])).catch(()=>{}).finally(()=>setLoading(false));
  };
  useEffect(() => { load(); }, [branchId]);
  useEffect(() => {
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/enrollments${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setEnrollments(d?.enrollments??[])).catch(()=>{});
  }, [branchId]);

  const handleAdd = async () => {
    if (!form.enrollmentId || !form.assessmentType || !form.score) { toast.error('Vui lòng điền đầy đủ'); return; }
    const res = await fetch('/api/grades', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
    if (!res?.ok) { toast.error('Lỗi nhập điểm'); return; }
    toast.success('Nhập điểm thành công'); setShowAdd(false); setForm({maxScore:'100',weight:'1'}); load();
  };

  return (
    <div className="space-y-6">
      <FadeIn><div className="flex items-center justify-between">
        <div><h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><Award className="w-6 h-6 text-primary" /> Quản lý Điểm số</h1><p className="text-muted-foreground text-sm">Nhập và theo dõi điểm học viên</p></div>
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogTrigger asChild><Button size="sm" className="gap-1"><Plus className="w-4 h-4" /> Nhập điểm</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Nhập điểm mới</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="text-xs">Học viên - Lớp</Label>
                <Select value={form.enrollmentId??''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),enrollmentId:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent>{enrollments?.map?.((e:any)=><SelectItem key={e.id} value={e.id}>{e?.student?.fullName??''} - {e?.class?.name??''}</SelectItem>)}</SelectContent>
                </Select></div>
              <div><Label className="text-xs">Loại bài</Label>
                <Select value={form.assessmentType??''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),assessmentType:v}))}>
                  <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="quiz">Quiz</SelectItem><SelectItem value="midterm">Giữa kỳ</SelectItem>
                    <SelectItem value="final">Cuối kỳ</SelectItem><SelectItem value="homework">Bài tập</SelectItem>
                    <SelectItem value="speaking">Nói</SelectItem><SelectItem value="writing">Viết</SelectItem>
                  </SelectContent>
                </Select></div>
              <div className="grid grid-cols-3 gap-2">
                <div><Label className="text-xs">Điểm</Label><Input type="number" value={form.score??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),score:e?.target?.value??''}))} /></div>
                <div><Label className="text-xs">Điểm tối đa</Label><Input type="number" value={form.maxScore??'100'} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),maxScore:e?.target?.value??'100'}))} /></div>
                <div><Label className="text-xs">Hệ số</Label><Input type="number" value={form.weight??'1'} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),weight:e?.target?.value??'1'}))} /></div>
              </div>
              <div><Label className="text-xs">Nhận xét</Label><Textarea value={form.comments??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),comments:e?.target?.value??''}))} rows={2} /></div>
            </div>
            <div className="flex justify-end gap-2 mt-4"><Button variant="outline" onClick={()=>setShowAdd(false)}>Hủy</Button><Button onClick={handleAdd}>Lưu điểm</Button></div>
          </DialogContent>
        </Dialog>
      </div></FadeIn>
      <Card><CardContent className="p-0"><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-muted/50"><tr>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Học viên</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Lớp</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Loại</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Điểm</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Hệ số</th>
        <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Ngày</th>
      </tr></thead><tbody>
        {loading ? <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Đang tải...</td></tr> :
        (grades??[])?.length===0 ? <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Không có dữ liệu</td></tr> :
        (grades??[])?.map?.((g:any)=>{
          const pct = g?.maxScore ? Math.round((g.score/g.maxScore)*100) : 0;
          return (<tr key={g?.id} className="border-t border-border hover:bg-muted/30 transition-colors">
            <td className="px-4 py-3 font-medium text-xs">{g?.enrollment?.student?.fullName??''}</td>
            <td className="px-4 py-3 text-xs">{g?.enrollment?.class?.name??''}</td>
            <td className="px-4 py-3"><Badge variant="outline" className="text-[10px]">{g?.assessmentName??g?.assessmentType??''}</Badge></td>
            <td className="px-4 py-3 font-mono text-xs"><span className={pct>=80?'text-emerald-600':pct>=60?'text-amber-600':'text-red-600'}>{g?.score??0}</span>/{g?.maxScore??100} ({pct}%)</td>
            <td className="px-4 py-3 font-mono text-xs">{g?.weight??1}</td>
            <td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(g?.gradedAt)}</td>
          </tr>);
        })}
      </tbody></table></div></CardContent></Card>
    </div>
  );
}
