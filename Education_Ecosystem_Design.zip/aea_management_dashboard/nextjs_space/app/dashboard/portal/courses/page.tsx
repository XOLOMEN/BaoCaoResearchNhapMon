import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import MyCoursesContent from './my-courses-content';

export default async function MyCoursesPage() {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== 'student') redirect('/dashboard');
  return <MyCoursesContent />;
}
