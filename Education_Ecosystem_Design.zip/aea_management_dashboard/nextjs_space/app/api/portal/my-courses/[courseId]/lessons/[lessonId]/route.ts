export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getStudentSession } from '@/lib/portal/helpers';

export async function GET(_req: NextRequest, { params }: { params: { courseId: string; lessonId: string } }) {
  const { error, session } = await getStudentSession();
  if (error) return error;
  const studentId = session!.user.studentId!;
  const { courseId, lessonId } = params;

  try {
    // Verify enrollment
    const enrollment = await prisma.lmsEnrollment.findUnique({
      where: { lmsCourseId_studentId: { lmsCourseId: courseId, studentId } },
    });
    if (!enrollment) return NextResponse.json({ error: 'Not enrolled' }, { status: 403 });

    const lesson = await prisma.lmsLesson.findUnique({
      where: { id: lessonId },
      include: {
        contents: { orderBy: { sortOrder: 'asc' } },
        quiz: true,
      },
    });
    if (!lesson || lesson.lmsCourseId !== courseId) {
      return NextResponse.json({ error: 'Lesson not found' }, { status: 404 });
    }

    // Get or create progress
    let progress = await prisma.lmsProgress.findUnique({
      where: { lmsEnrollmentId_lessonId: { lmsEnrollmentId: enrollment.id, lessonId } },
    });
    if (!progress) {
      progress = await prisma.lmsProgress.create({
        data: { lmsEnrollmentId: enrollment.id, lessonId, status: 'in_progress' },
      });
    }

    // Update last accessed
    await prisma.lmsEnrollment.update({
      where: { id: enrollment.id },
      data: { lastAccessedAt: new Date() },
    });

    // Get next/prev lessons
    const allLessons = await prisma.lmsLesson.findMany({
      where: { lmsCourseId: courseId, isPublished: true },
      orderBy: { sortOrder: 'asc' },
      select: { id: true, title: true, sortOrder: true },
    });
    const currentIdx = allLessons.findIndex((l: any) => l.id === lessonId);
    const prevLesson = currentIdx > 0 ? allLessons[currentIdx - 1] : null;
    const nextLesson = currentIdx < allLessons.length - 1 ? allLessons[currentIdx + 1] : null;

    return NextResponse.json({
      lesson,
      progress,
      prevLesson,
      nextLesson,
    });
  } catch (err: any) {
    console.error('Portal lesson detail error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Update progress
export async function POST(req: NextRequest, { params }: { params: { courseId: string; lessonId: string } }) {
  const { error, session } = await getStudentSession();
  if (error) return error;
  const studentId = session!.user.studentId!;
  const { courseId, lessonId } = params;
  const body = await req.json();

  try {
    const enrollment = await prisma.lmsEnrollment.findUnique({
      where: { lmsCourseId_studentId: { lmsCourseId: courseId, studentId } },
    });
    if (!enrollment) return NextResponse.json({ error: 'Not enrolled' }, { status: 403 });

    const updateData: any = {};
    if (body.status) updateData.status = body.status;
    if (body.progressPct !== undefined) updateData.progressPct = body.progressPct;
    if (body.timeSpentSec !== undefined) updateData.timeSpentSec = { increment: body.timeSpentSec };
    if (body.lastPosition) updateData.lastPosition = body.lastPosition;
    if (body.status === 'completed') updateData.completedAt = new Date();

    const progress = await prisma.lmsProgress.upsert({
      where: { lmsEnrollmentId_lessonId: { lmsEnrollmentId: enrollment.id, lessonId } },
      update: updateData,
      create: {
        lmsEnrollmentId: enrollment.id,
        lessonId,
        status: body.status || 'in_progress',
        progressPct: body.progressPct || 0,
        timeSpentSec: body.timeSpentSec || 0,
        lastPosition: body.lastPosition || null,
        ...(body.status === 'completed' ? { completedAt: new Date() } : {}),
      },
    });

    // Recalculate enrollment progress
    const totalLessons = await prisma.lmsLesson.count({ where: { lmsCourseId: courseId, isPublished: true } });
    const completedLessons = await prisma.lmsProgress.count({
      where: { enrollment: { id: enrollment.id }, status: 'completed' },
    });
    const newProgressPct = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100 * 10) / 10 : 0;
    await prisma.lmsEnrollment.update({
      where: { id: enrollment.id },
      data: {
        progressPct: newProgressPct,
        ...(newProgressPct >= 100 ? { status: 'completed', completedAt: new Date() } : {}),
      },
    });

    return NextResponse.json({ progress, enrollmentProgress: newProgressPct });
  } catch (err: any) {
    console.error('Portal progress update error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
