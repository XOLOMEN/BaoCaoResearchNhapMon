import { AnalyticsCrmContent } from './analytics-content';
export default function CrmAnalyticsPage() { return <AnalyticsCrmContent />; }
