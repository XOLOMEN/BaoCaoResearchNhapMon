export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

function buildBranchWhere(session: any, queryBranchId?: string | null) {
  const where: any = {};
  if (session.user.role !== 'super_admin') {
    where.branchId = session.user.primaryBranchId;
  } else if (queryBranchId) {
    where.branchId = queryBranchId;
  }
  return where;
}

const VALID_PRIORITIES = ['low', 'medium', 'high', 'urgent'];
const VALID_STATUSES = ['pending', 'in_progress', 'completed', 'cancelled'];
const VALID_TYPES = ['call', 'email', 'meeting', 'follow_up', 'demo', 'visit', 'document', 'other'];

// ── GET: List tasks ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const leadId = url.searchParams.get('leadId');
    const status = url.searchParams.get('status');
    const priority = url.searchParams.get('priority');
    const assignedTo = url.searchParams.get('assignedTo');
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'));
    const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get('limit') || '50')));

    const where: any = buildBranchWhere(session, branchId);
    if (leadId) where.leadId = leadId;
    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (assignedTo) where.assignedTo = assignedTo;

    const [tasks, total] = await Promise.all([
      prisma.crmTask.findMany({
        where,
        include: {
          lead: { select: { id: true, fullName: true, phone: true, status: true } },
          branch: { select: { name: true, code: true } },
          assignee: { select: { id: true, fullName: true } },
        },
        orderBy: [{ dueDate: 'asc' }],
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.crmTask.count({ where }),
    ]);

    return NextResponse.json({
      tasks: tasks.map((t: any) => ({
        ...t,
        dueDate: t.dueDate?.toISOString(),
        completedAt: t.completedAt?.toISOString() || null,
        createdAt: t.createdAt?.toISOString(),
        updatedAt: t.updatedAt?.toISOString(),
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch (error: any) {
    console.error('[CRM/Tasks GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Create task ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền tạo task' }, { status: 403 });
    }

    const body = await request.json();
    const { branchId, leadId, title, description, taskType, dueDate, priority, assignedTo } = body ?? {};

    if (!branchId || !title || !dueDate || !assignedTo) {
      return NextResponse.json({ error: 'Thiếu thông tin bắt buộc (branchId, title, dueDate, assignedTo)' }, { status: 400 });
    }
    if (priority && !VALID_PRIORITIES.includes(priority)) {
      return NextResponse.json({ error: 'Mức ưu tiên không hợp lệ' }, { status: 400 });
    }
    if (taskType && !VALID_TYPES.includes(taskType)) {
      return NextResponse.json({ error: 'Loại task không hợp lệ' }, { status: 400 });
    }

    const task = await prisma.crmTask.create({
      data: {
        branchId,
        leadId: leadId || null,
        title,
        description: description || null,
        taskType: taskType || 'other',
        dueDate: new Date(dueDate),
        priority: priority || 'medium',
        assignedTo,
        status: 'pending',
      },
      include: {
        lead: { select: { fullName: true } },
        branch: { select: { name: true } },
        assignee: { select: { fullName: true } },
      },
    });

    return NextResponse.json({ task }, { status: 201 });
  } catch (error: any) {
    console.error('[CRM/Tasks POST]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── PUT: Update task ──
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền cập nhật task' }, { status: 403 });
    }

    const body = await request.json();
    const { id, ...updateFields } = body ?? {};
    if (!id) return NextResponse.json({ error: 'Thiếu task ID' }, { status: 400 });

    const existing = await prisma.crmTask.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Không tìm thấy task' }, { status: 404 });

    if (session.user.role !== 'super_admin' && existing.branchId !== session.user.primaryBranchId) {
      return NextResponse.json({ error: 'Không có quyền cập nhật task chi nhánh khác' }, { status: 403 });
    }

    const data: any = {};
    if (updateFields.title) data.title = updateFields.title;
    if (updateFields.description !== undefined) data.description = updateFields.description;
    if (updateFields.taskType && VALID_TYPES.includes(updateFields.taskType)) data.taskType = updateFields.taskType;
    if (updateFields.dueDate) data.dueDate = new Date(updateFields.dueDate);
    if (updateFields.priority && VALID_PRIORITIES.includes(updateFields.priority)) data.priority = updateFields.priority;
    if (updateFields.assignedTo) data.assignedTo = updateFields.assignedTo;
    if (updateFields.status && VALID_STATUSES.includes(updateFields.status)) {
      data.status = updateFields.status;
      if (updateFields.status === 'completed') data.completedAt = new Date();
      if (updateFields.status === 'pending' || updateFields.status === 'in_progress') data.completedAt = null;
    }

    const task = await prisma.crmTask.update({
      where: { id },
      data,
      include: {
        lead: { select: { fullName: true } },
        branch: { select: { name: true } },
        assignee: { select: { fullName: true } },
      },
    });

    return NextResponse.json({ task });
  } catch (error: any) {
    console.error('[CRM/Tasks PUT]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── DELETE ──
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin') {
      return NextResponse.json({ error: 'Chỉ Super Admin có quyền xóa task' }, { status: 403 });
    }

    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Thiếu task ID' }, { status: 400 });

    await prisma.crmTask.delete({ where: { id } });
    return NextResponse.json({ success: true, message: 'Đã xóa task' });
  } catch (error: any) {
    console.error('[CRM/Tasks DELETE]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
