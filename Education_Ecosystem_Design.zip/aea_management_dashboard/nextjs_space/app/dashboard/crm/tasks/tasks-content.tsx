'use client';
import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import {
  CheckSquare, Plus, Clock, AlertTriangle, CheckCircle2,
  CalendarDays, ChevronLeft, ChevronRight, User, XCircle,
  Loader2, ListTodo, Download,
} from 'lucide-react';
import { toast } from 'sonner';
import { useBranch } from '@/hooks/use-branch';
import { formatDate } from '@/lib/helpers';
import { FadeIn } from '@/components/ui/animate';

const PRIORITY_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  low: { label: 'Thấp', color: 'bg-slate-100 text-slate-600', icon: null },
  medium: { label: 'Trung bình', color: 'bg-blue-100 text-blue-700', icon: null },
  high: { label: 'Cao', color: 'bg-orange-100 text-orange-700', icon: AlertTriangle },
  urgent: { label: 'Khẩn cấp', color: 'bg-red-100 text-red-700', icon: AlertTriangle },
};
const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: 'Chờ xử lý', color: 'bg-amber-100 text-amber-700', icon: Clock },
  in_progress: { label: 'Đang thực hiện', color: 'bg-blue-100 text-blue-700', icon: Loader2 },
  completed: { label: 'Hoàn thành', color: 'bg-green-100 text-green-700', icon: CheckCircle2 },
  cancelled: { label: 'Đã hủy', color: 'bg-gray-100 text-gray-500', icon: XCircle },
};
const TYPE_LABELS: Record<string, string> = {
  call: 'Gọi điện', email: 'Email', meeting: 'Gặp mặt', follow_up: 'Follow-up',
  demo: 'Demo', visit: 'Thăm quan', document: 'Tài liệu', other: 'Khác',
};

const INITIAL_FORM = {
  branchId: '', leadId: '', title: '', description: '', taskType: 'follow_up',
  dueDate: '', priority: 'medium', assignedTo: '',
};

export function TasksContent() {
  const { branchId: globalBranchId } = useBranch();
  const { data: session } = useSession() || {};
  const role = session?.user?.role ?? 'staff';
  const canWrite = role === 'super_admin' || role === 'staff';

  const [tasks, setTasks] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [leads, setLeads] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ total: 0, totalPages: 1 });
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(INITIAL_FORM);

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (globalBranchId) params.set('branchId', globalBranchId);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      if (priorityFilter !== 'all') params.set('priority', priorityFilter);
      params.set('page', String(page));
      params.set('limit', '20');
      const res = await fetch(`/api/crm/tasks?${params}`);
      const data = await res.json();
      setTasks(data.tasks || []);
      setPagination(data.pagination || { total: 0, totalPages: 1 });
    } catch { toast.error('Lỗi tải dữ liệu tasks'); }
    setLoading(false);
  }, [globalBranchId, statusFilter, priorityFilter, page]);

  const fetchMeta = useCallback(async () => {
    try {
      const [brRes, leadsRes] = await Promise.all([
        fetch('/api/branches'),
        fetch(`/api/crm/leads?limit=100&status=new${globalBranchId ? `&branchId=${globalBranchId}` : ''}`),
      ]);
      const [brData, leadsData] = await Promise.all([brRes.json(), leadsRes.json()]);
      setBranches(brData.branches || []);
      setLeads(leadsData.leads || []);
      // Use branches' users from session
    } catch {}
  }, [globalBranchId]);

  useEffect(() => { fetchMeta(); }, [fetchMeta]);
  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  const handleAdd = async () => {
    if (!form.branchId || !form.title || !form.dueDate) {
      toast.error('Vui lòng nhập chi nhánh, tiêu đề và hạn chót');
      return;
    }
    try {
      const res = await fetch('/api/crm/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          assignedTo: form.assignedTo || session?.user?.id,
          leadId: form.leadId || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success('Thêm task thành công');
      setShowAdd(false);
      setForm(INITIAL_FORM);
      fetchTasks();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  const handleUpdateStatus = async (taskId: string, newStatus: string) => {
    try {
      const res = await fetch('/api/crm/tasks', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: taskId, status: newStatus }),
      });
      if (!res.ok) { const d = await res.json(); toast.error(d.error); return; }
      toast.success('Cập nhật thành công');
      fetchTasks();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  const handleExportCSV = async () => {
    try {
      const params = new URLSearchParams({ type: 'tasks' });
      if (globalBranchId) params.set('branchId', globalBranchId);
      const res = await fetch(`/api/crm/export?${params}`);
      if (!res.ok) { toast.error('Lỗi xuất CSV'); return; }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `crm-tasks-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success('Đã xuất CSV thành công');
    } catch { toast.error('Lỗi xuất file'); }
  };

  // KPIs
  const pendingCount = tasks.filter(t => t.status === 'pending').length;
  const inProgressCount = tasks.filter(t => t.status === 'in_progress').length;
  const completedCount = tasks.filter(t => t.status === 'completed').length;
  const overdueCount = tasks.filter(t => t.status !== 'completed' && t.status !== 'cancelled' && new Date(t.dueDate) < new Date()).length;

  return (
    <FadeIn>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <ListTodo className="h-7 w-7 text-primary" /> Quản lý Tasks
            </h1>
            <p className="text-muted-foreground mt-1">Theo dõi công việc và follow-up leads</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1">
              <Download className="h-4 w-4" /> CSV
            </Button>
            {canWrite && (
              <Button onClick={() => setShowAdd(true)} className="gap-2">
                <Plus className="h-4 w-4" /> Thêm Task
              </Button>
            )}
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="border-l-4 border-l-amber-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-amber-600" />
                <div><p className="text-sm text-muted-foreground">Chờ xử lý</p><p className="text-2xl font-bold">{pendingCount}</p></div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-blue-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <Loader2 className="h-5 w-5 text-blue-600" />
                <div><p className="text-sm text-muted-foreground">Đang thực hiện</p><p className="text-2xl font-bold">{inProgressCount}</p></div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-green-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div><p className="text-sm text-muted-foreground">Hoàn thành</p><p className="text-2xl font-bold">{completedCount}</p></div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-red-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <div><p className="text-sm text-muted-foreground">Quá hạn</p><p className="text-2xl font-bold text-red-600">{overdueCount}</p></div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex flex-wrap gap-3 items-end">
              <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[160px]"><SelectValue placeholder="Trạng thái" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả trạng thái</SelectItem>
                  {Object.entries(STATUS_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={priorityFilter} onValueChange={(v) => { setPriorityFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[160px]"><SelectValue placeholder="Ưu tiên" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả mức ưu tiên</SelectItem>
                  {Object.entries(PRIORITY_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tasks Table */}
        <Card>
          <CardContent className="p-0">
            {loading ? (
              <div className="flex justify-center py-16"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>
            ) : tasks.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground">
                <ListTodo className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p>Chưa có task nào</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b bg-muted/50">
                    <th className="text-left p-3 font-medium">Tiêu đề</th>
                    <th className="text-left p-3 font-medium">Lead</th>
                    <th className="text-left p-3 font-medium">Loại</th>
                    <th className="text-left p-3 font-medium">Ưu tiên</th>
                    <th className="text-left p-3 font-medium">Trạng thái</th>
                    <th className="text-left p-3 font-medium">Hạn chót</th>
                    <th className="text-left p-3 font-medium">Người phụ trách</th>
                    <th className="text-right p-3 font-medium">Thao tác</th>
                  </tr></thead>
                  <tbody>
                    {tasks.map((t: any) => {
                      const isOverdue = t.status !== 'completed' && t.status !== 'cancelled' && new Date(t.dueDate) < new Date();
                      const pCfg = PRIORITY_CONFIG[t.priority] || PRIORITY_CONFIG.medium;
                      const sCfg = STATUS_CONFIG[t.status] || STATUS_CONFIG.pending;
                      return (
                        <tr key={t.id} className={`border-b transition-colors ${isOverdue ? 'bg-red-50/50' : 'hover:bg-muted/30'}`}>
                          <td className="p-3">
                            <div className="font-medium">{t.title}</div>
                            {t.description && <div className="text-xs text-muted-foreground line-clamp-1">{t.description}</div>}
                          </td>
                          <td className="p-3 text-xs">{t.lead?.fullName || <span className="text-muted-foreground">—</span>}</td>
                          <td className="p-3"><Badge variant="outline" className="text-xs">{TYPE_LABELS[t.taskType] || t.taskType}</Badge></td>
                          <td className="p-3"><Badge className={`text-xs ${pCfg.color}`}>{pCfg.label}</Badge></td>
                          <td className="p-3"><Badge className={`text-xs ${sCfg.color}`}>{sCfg.label}</Badge></td>
                          <td className="p-3">
                            <span className={`text-xs ${isOverdue ? 'text-red-600 font-semibold' : ''}`}>
                              {formatDate(t.dueDate)}
                              {isOverdue && ' ⚠'}
                            </span>
                          </td>
                          <td className="p-3 text-xs">{t.assignee?.fullName || '—'}</td>
                          <td className="p-3">
                            <div className="flex gap-1 justify-end">
                              {canWrite && t.status === 'pending' && (
                                <Button size="sm" variant="outline" className="text-xs" onClick={() => handleUpdateStatus(t.id, 'in_progress')}>Bắt đầu</Button>
                              )}
                              {canWrite && t.status === 'in_progress' && (
                                <Button size="sm" variant="outline" className="text-xs text-green-600 border-green-300" onClick={() => handleUpdateStatus(t.id, 'completed')}>
                                  <CheckCircle2 className="h-3 w-3 mr-1" />Xong
                                </Button>
                              )}
                              {canWrite && (t.status === 'pending' || t.status === 'in_progress') && (
                                <Button size="sm" variant="ghost" className="text-xs text-muted-foreground" onClick={() => handleUpdateStatus(t.id, 'cancelled')}>
                                  <XCircle className="h-3 w-3" />
                                </Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            {pagination.totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t">
                <span className="text-sm text-muted-foreground">Trang {page}/{pagination.totalPages} ({pagination.total} tasks)</span>
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
                  <Button size="sm" variant="outline" disabled={page >= pagination.totalPages} onClick={() => setPage(p => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ADD TASK DIALOG */}
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Thêm Task mới</DialogTitle></DialogHeader>
            <div className="grid gap-3">
              <div><Label>Chi nhánh *</Label>
                <Select value={form.branchId} onValueChange={(v) => setForm(f => ({ ...f, branchId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Chọn chi nhánh" /></SelectTrigger>
                  <SelectContent>{branches.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Tiêu đề *</Label><Input value={form.title} onChange={(e) => setForm(f => ({ ...f, title: e.target.value }))} /></div>
              <div><Label>Mô tả</Label><Textarea value={form.description} onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))} rows={2} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Loại task</Label>
                  <Select value={form.taskType} onValueChange={(v) => setForm(f => ({ ...f, taskType: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Ưu tiên</Label>
                  <Select value={form.priority} onValueChange={(v) => setForm(f => ({ ...f, priority: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{Object.entries(PRIORITY_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label>Hạn chót *</Label><Input type="date" value={form.dueDate} onChange={(e) => setForm(f => ({ ...f, dueDate: e.target.value }))} /></div>
              <div><Label>Lead liên quan</Label>
                <Select value={form.leadId} onValueChange={(v) => setForm(f => ({ ...f, leadId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Chọn lead (tùy chọn)" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value=" ">Không có</SelectItem>
                    {leads.map((l: any) => <SelectItem key={l.id} value={l.id}>{l.fullName} - {l.phone}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAdd(false)}>Hủy</Button>
              <Button onClick={handleAdd}>Tạo Task</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </FadeIn>
  );
}
