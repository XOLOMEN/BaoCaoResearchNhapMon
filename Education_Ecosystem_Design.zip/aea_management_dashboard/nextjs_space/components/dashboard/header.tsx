'use client';
import { useSession, signOut } from 'next-auth/react';
import { Bell, LogOut, User, ChevronDown, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { getRoleLabel } from '@/lib/helpers';
import { BranchSelector } from './branch-selector';

export function DashboardHeader() {
  const { data: session } = useSession() || {};
  const userName = session?.user?.name ?? 'Người dùng';
  const userRole = session?.user?.role ?? 'staff';

  return (
    <header className="h-14 border-b border-border bg-card/80 backdrop-blur-sm flex items-center justify-between px-6 sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <BranchSelector />
      </div>
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon-sm" className="relative">
          <Bell className="w-4 h-4" />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="w-3.5 h-3.5 text-primary" />
              </div>
              <div className="text-left hidden md:block">
                <p className="text-xs font-medium">{userName}</p>
                <p className="text-[10px] text-muted-foreground">{getRoleLabel(userRole)}</p>
              </div>
              <ChevronDown className="w-3 h-3 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem className="text-xs">
              <User className="w-3.5 h-3.5 mr-2" /> Hồ sơ cá nhân
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => signOut?.({ callbackUrl: '/login' })} className="text-xs text-destructive">
              <LogOut className="w-3.5 h-3.5 mr-2" /> Đăng xuất
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
