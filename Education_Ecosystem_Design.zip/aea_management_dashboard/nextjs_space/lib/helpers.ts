export function formatCurrency(amount: number | null | undefined): string {
  const val = amount ?? 0;
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);
}

export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function formatDateTime(date: Date | string | null | undefined): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleString('vi-VN');
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    active: 'bg-emerald-100 text-emerald-700',
    inactive: 'bg-gray-100 text-gray-700',
    graduated: 'bg-blue-100 text-blue-700',
    suspended: 'bg-red-100 text-red-700',
    withdrawn: 'bg-orange-100 text-orange-700',
    scheduled: 'bg-sky-100 text-sky-700',
    in_progress: 'bg-indigo-100 text-indigo-700',
    completed: 'bg-emerald-100 text-emerald-700',
    cancelled: 'bg-red-100 text-red-700',
    new: 'bg-purple-100 text-purple-700',
    pending: 'bg-yellow-100 text-yellow-700',
    draft: 'bg-slate-100 text-slate-600',
    issued: 'bg-blue-100 text-blue-700',
    paid: 'bg-emerald-100 text-emerald-700',
    partially_paid: 'bg-amber-100 text-amber-700',
    overdue: 'bg-red-100 text-red-700',
    on_leave: 'bg-purple-100 text-purple-700',
    terminated: 'bg-red-100 text-red-700',
    pending_review: 'bg-yellow-100 text-yellow-700',
    approved: 'bg-blue-100 text-blue-700',
    rejected: 'bg-red-100 text-red-700',
    present: 'bg-emerald-100 text-emerald-700',
    absent: 'bg-red-100 text-red-700',
    late: 'bg-amber-100 text-amber-700',
    half_day: 'bg-blue-100 text-blue-700',
    dropped: 'bg-orange-100 text-orange-700',
    expired: 'bg-gray-100 text-gray-700',
    not_started: 'bg-slate-100 text-slate-600',
    published: 'bg-emerald-100 text-emerald-700',
    unpublished: 'bg-amber-100 text-amber-700',
  };
  return colors[status] ?? 'bg-gray-100 text-gray-700';
}

export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    active: 'Đang học',
    inactive: 'Tạm nghỉ',
    graduated: 'Tốt nghiệp',
    suspended: 'Đình chỉ',
    withdrawn: 'Đã rút',
    scheduled: 'Đã lên lịch',
    in_progress: 'Đang diễn ra',
    completed: 'Hoàn thành',
    cancelled: 'Đã hủy',
    new: 'Mới',
    pending: 'Chờ xử lý',
    draft: 'Nháp',
    issued: 'Đã phát hành',
    paid: 'Đã thanh toán',
    partially_paid: 'Thanh toán một phần',
    overdue: 'Quá hạn',
    on_leave: 'Nghỉ phép',
    terminated: 'Đã nghỉ việc',
    pending_review: 'Chờ duyệt',
    approved: 'Đã duyệt',
    rejected: 'Từ chối',
    present: 'Có mặt',
    absent: 'Vắng',
    late: 'Muộn',
    half_day: 'Nửa ngày',
    dropped: 'Bỏ học',
    expired: 'Hết hạn',
    not_started: 'Chưa bắt đầu',
    published: 'Đã xuất bản',
    unpublished: 'Chưa xuất bản',
  };
  return labels[status] ?? status;
}

export function getLevelLabel(level: string | null | undefined): string {
  if (!level) return '';
  const labels: Record<string, string> = {
    beginner: 'Cơ bản',
    elementary: 'Sơ cấp',
    intermediate: 'Trung cấp',
    upper_intermediate: 'Trung cấp cao',
    advanced: 'Nâng cao',
    all: 'Tất cả trình độ',
  };
  return labels[level] ?? level;
}

export function getRoleLabel(role: string): string {
  const labels: Record<string, string> = {
    super_admin: 'Quản trị viên',
    branch_admin: 'Quản lý chi nhánh',
    manager: 'Quản lý',
    staff: 'Nhân viên',
    teacher: 'Giáo viên',
    parent: 'Phụ huynh',
    student: 'Học viên',
  };
  return labels[role] ?? role;
}
