export default function CrmTasksPage() {
  return <TasksContent />;
}
import { TasksContent } from './tasks-content';
