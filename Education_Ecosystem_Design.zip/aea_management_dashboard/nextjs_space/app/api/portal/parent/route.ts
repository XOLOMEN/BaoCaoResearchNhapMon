export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getParentSession } from '@/lib/portal/helpers';

export async function GET() {
  const { error, session } = await getParentSession();
  if (error) return error;
  const childStudentIds = session!.user.childStudentIds ?? [];

  if (childStudentIds.length === 0) {
    return NextResponse.json({ children: [] });
  }

  try {
    const children = await Promise.all(
      childStudentIds.map(async (studentId: string) => {
        const student = await prisma.student.findUnique({
          where: { id: studentId },
          select: { id: true, fullName: true, studentCode: true, level: true, status: true },
        });
        if (!student) return null;

        const enrollments = await prisma.lmsEnrollment.findMany({
          where: { studentId },
          include: {
            lmsCourse: { select: { id: true, title: true, totalLessons: true, level: true, category: true } },
            progress: {
              include: { lesson: { select: { title: true, type: true } } },
              orderBy: { updatedAt: 'desc' },
            },
          },
          orderBy: { enrolledAt: 'desc' },
        });

        const totalTimeSpent = await prisma.lmsProgress.aggregate({
          where: { enrollment: { studentId } },
          _sum: { timeSpentSec: true },
        });

        const completedLessons = await prisma.lmsProgress.count({
          where: { enrollment: { studentId }, status: 'completed' },
        });

        const certificates = await prisma.lmsCertificate.findMany({
          where: { studentId },
          include: { lmsCourse: { select: { title: true } } },
          orderBy: { issuedAt: 'desc' },
        });

        return {
          student,
          enrollments,
          stats: {
            totalCourses: enrollments.length,
            activeCourses: enrollments.filter((e: any) => e.status === 'active').length,
            completedCourses: enrollments.filter((e: any) => e.status === 'completed').length,
            avgProgress: enrollments.length > 0
              ? Math.round(enrollments.reduce((sum: number, e: any) => sum + e.progressPct, 0) / enrollments.length)
              : 0,
            totalTimeSpentMin: Math.round((totalTimeSpent._sum.timeSpentSec ?? 0) / 60),
            completedLessons,
          },
          certificates,
        };
      })
    );

    return NextResponse.json({ children: children.filter(Boolean) });
  } catch (err: any) {
    console.error('Parent portal error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
