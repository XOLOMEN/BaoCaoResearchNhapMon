'use client';
import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Building2, ChevronDown, Check } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';

interface BranchItem {
  id: string;
  name: string;
  code: string;
  city: string | null;
}

export function BranchSelector() {
  const { data: session } = useSession() || {};
  const [branches, setBranches] = useState<BranchItem[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [allBranches, setAllBranches] = useState(false);

  useEffect(() => {
    fetch('/api/branches')
      .then((r: any) => r?.json?.())
      .then((data: any) => {
        const items = data?.branches ?? [];
        setBranches(items);
        const primaryId = session?.user?.primaryBranchId;
        if (primaryId && items?.some?.((b: BranchItem) => b.id === primaryId)) {
          setSelectedId(primaryId);
        } else if (items?.[0]) {
          setSelectedId(items[0].id);
        }
      })
      .catch(() => {});
  }, [session?.user?.primaryBranchId]);

  const isSuperAdmin = session?.user?.role === 'super_admin';
  const selected = branches?.find?.((b: BranchItem) => b.id === selectedId);

  const handleSelect = (id: string) => {
    setSelectedId(id);
    setAllBranches(false);
    if (typeof window !== 'undefined') {
      window.localStorage?.setItem?.('aea_branch_id', id);
      window.dispatchEvent?.(new CustomEvent('branch-changed', { detail: { branchId: id, all: false } }));
    }
  };

  const handleAllBranches = () => {
    setAllBranches(true);
    setSelectedId('');
    if (typeof window !== 'undefined') {
      window.localStorage?.removeItem?.('aea_branch_id');
      window.dispatchEvent?.(new CustomEvent('branch-changed', { detail: { branchId: null, all: true } }));
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-2 text-xs h-8">
          <Building2 className="w-3.5 h-3.5" />
          <span>{allBranches ? 'Tất cả chi nhánh' : selected?.name ?? 'Chọn chi nhánh'}</span>
          <ChevronDown className="w-3 h-3" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-56">
        {isSuperAdmin && (
          <DropdownMenuItem onClick={handleAllBranches} className="text-xs">
            <Building2 className="w-3.5 h-3.5 mr-2" />
            Tất cả chi nhánh
            {allBranches && <Check className="w-3 h-3 ml-auto" />}
          </DropdownMenuItem>
        )}
        {branches?.map?.((b: BranchItem) => (
          <DropdownMenuItem key={b.id} onClick={() => handleSelect(b.id)} className="text-xs">
            <Building2 className="w-3.5 h-3.5 mr-2" />
            <div className="flex-1">
              <p className="font-medium">{b.name}</p>
              <p className="text-muted-foreground text-[10px]">{b.city ?? ''}</p>
            </div>
            {!allBranches && selectedId === b.id && <Check className="w-3 h-3 ml-auto" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
