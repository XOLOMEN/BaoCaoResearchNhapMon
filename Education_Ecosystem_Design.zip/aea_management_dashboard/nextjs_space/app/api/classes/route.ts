export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const where: any = {};
    if (branchId) where.branchId = branchId;

    const classes = await prisma.class.findMany({
      where,
      include: {
        course: { select: { name: true, code: true } },
        teacher: { select: { fullName: true, employeeCode: true } },
        branch: { select: { name: true, code: true } },
        _count: { select: { enrollments: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ classes });
  } catch (error: any) {
    console.error(error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const cls = await prisma.class.create({ data: {
      courseId: body.courseId,
      branchId: body.branchId,
      teacherId: body.teacherId || null,
      name: body.name,
      classCode: body.classCode,
      room: body.room,
      schedule: body.schedule ?? {},
      startDate: body.startDate ? new Date(body.startDate) : null,
      endDate: body.endDate ? new Date(body.endDate) : null,
      capacity: parseInt(body.capacity ?? '20'),
      status: body.status ?? 'scheduled',
    }});
    return NextResponse.json({ class: cls }, { status: 201 });
  } catch (error: any) {
    console.error(error);
    if (error?.code === 'P2002') return NextResponse.json({ error: 'Mã lớp đã tồn tại' }, { status: 409 });
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
