export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const status = url.searchParams.get('status');
    const studentId = url.searchParams.get('studentId');

    const where: any = {};
    if (branchId) where.branchId = branchId;
    if (status) where.status = status;
    if (studentId) where.studentId = studentId;

    const invoices = await prisma.invoice.findMany({
      where,
      include: {
        student: { select: { fullName: true, studentCode: true } },
        branch: { select: { name: true, code: true } },
        items: true,
        _count: { select: { payments: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      invoices: invoices.map((inv: any) => ({
        ...inv,
        createdAt: inv.createdAt?.toISOString(),
        updatedAt: inv.updatedAt?.toISOString(),
        dueDate: inv.dueDate?.toISOString(),
        issuedAt: inv.issuedAt?.toISOString() || null,
      })),
    });
  } catch (error: any) {
    console.error('[Finance/Invoices GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const role = session.user.role;
    if (role !== 'super_admin' && role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
    }

    const body = await request.json();
    const { branchId, studentId, type, items, dueDate, notes, discountAmount } = body;

    if (!branchId || !studentId || !items?.length) {
      return NextResponse.json({ error: 'Thiếu thông tin' }, { status: 400 });
    }

    const branch = await prisma.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const branchCode = branch?.code || 'XX';
    const now = new Date();
    const yyMM = `${String(now.getFullYear()).slice(-2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const invoiceCount = await prisma.invoice.count({
      where: { branchId, createdAt: { gte: monthStart, lt: monthEnd } },
    });
    const seq = String(invoiceCount + 1).padStart(4, '0');
    const invoiceNumber = `INV-${branchCode}-${yyMM}-${seq}`;

    const subtotal = items.reduce((sum: number, it: any) => sum + (it.amount || it.unitPrice * it.quantity), 0);
    const discount = discountAmount || 0;
    const totalAmount = subtotal - discount;

    const invoice = await prisma.invoice.create({
      data: {
        branchId,
        invoiceNumber,
        studentId,
        type: type || 'tuition',
        subtotal,
        discountAmount: discount,
        taxAmount: 0,
        totalAmount,
        paidAmount: 0,
        currency: 'VND',
        dueDate: dueDate ? new Date(dueDate) : new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000),
        status: 'draft',
        issuedBy: session.user.id,
        issuedAt: now,
        notes,
        items: {
          create: items.map((it: any) => ({
            description: it.description,
            quantity: it.quantity || 1,
            unitPrice: it.unitPrice,
            amount: it.amount || it.unitPrice * (it.quantity || 1),
          })),
        },
      },
      include: { items: true, student: { select: { fullName: true } } },
    });

    return NextResponse.json({ invoice }, { status: 201 });
  } catch (error: any) {
    console.error('[Finance/Invoices POST]', error);
    return NextResponse.json({ error: error?.message || 'Lỗi hệ thống' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const invoiceId = body?.invoiceId || body?.id;
    const newStatus = body?.status;
    if (!invoiceId || !newStatus) {
      return NextResponse.json({ error: 'Thiếu thông tin' }, { status: 400 });
    }

    const validTransitions: Record<string, string[]> = {
      draft: ['issued', 'cancelled'],
      issued: ['paid', 'partially_paid', 'overdue', 'cancelled'],
      partially_paid: ['paid', 'overdue', 'cancelled'],
      overdue: ['paid', 'partially_paid', 'cancelled'],
    };

    const current = await prisma.invoice.findUnique({ where: { id: invoiceId }, select: { status: true } });
    if (!current) return NextResponse.json({ error: 'Không tìm thấy hóa đơn' }, { status: 404 });

    const allowed = validTransitions[current.status] || [];
    if (!allowed.includes(newStatus)) {
      return NextResponse.json({ error: `Không thể chuyển từ '${current.status}' sang '${newStatus}'` }, { status: 400 });
    }

    const updateData: any = { status: newStatus };
    if (newStatus === 'issued' && current.status === 'draft') {
      updateData.issuedAt = new Date();
      updateData.issuedBy = session.user.id;
    }

    const invoice = await prisma.invoice.update({ where: { id: invoiceId }, data: updateData });
    return NextResponse.json({ invoice });
  } catch (error: any) {
    console.error('[Finance/Invoices PUT]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
