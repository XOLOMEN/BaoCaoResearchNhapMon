# TECH SPEC: Module Nhân sự (HR) — Phase 3A

> **Ngày tạo:** 02/06/2026  
> **Trạng thái:** Đề xuất — Chờ duyệt  
> **Phụ thuộc:** Module Học vụ (Academic) ✅, Module Tài chính (Finance) ✅  

---

## 1. Tổng quan & Mục tiêu

Module HR quản lý nhân sự giáo dục — tập trung vào **giáo viên** (đối tượng chính của trung tâm ngoại ngữ) với 3 chức năng cốt lõi:

| # | Chức năng | Mô tả |
|---|-----------|-------|
| 1 | **Hồ sơ nhân sự** | Quản lý thông tin giáo viên dưới dạng HrEmployee (liên kết Teacher ↔ HrEmployee) |
| 2 | **Chấm công giảng dạy** | Tự động tính giờ dạy từ ClassSession đã hoàn thành (module Học vụ) |
| 3 | **Bảng lương** | Tính lương = baseSalary + (teachingHours × hourlyRate) + phụ cấp − khấu trừ |

---

## 2. Phân tích Schema hiện tại

### 2.1 Đã có (schema only — chưa có API/UI)

```
HrEmployee      — Hồ sơ nhân sự đầy đủ (CMND, thuế, bảo hiểm, ngân hàng)
HrContract      — Hợp đồng lao động (loại, lương cơ bản, phụ cấp)
HrAttendance    — Chấm công hàng ngày (checkIn/checkOut/workHours)
HrLeaveRequest  — Đơn xin nghỉ phép
HrPayroll       — Bảng lương (gross/net, khấu trừ)
```

### 2.2 Cần liên kết từ Module Học vụ

```
Teacher         — Giáo viên (có hourlyRate, gán cho Class)
Class           — Lớp học (teacherId, schedule)
ClassSession    — Buổi học cụ thể (sessionDate, startTime, endTime, teacherId, status)
```

### 2.3 Vấn đề thiết kế: Teacher vs HrEmployee

Hiện tại tồn tại **2 bảng riêng biệt** cho cùng 1 con người:
- `Teacher` — góc nhìn học vụ (chuyên môn, lớp dạy, hourlyRate)
- `HrEmployee` — góc nhìn nhân sự (hợp đồng, CMND, bảo hiểm, lương)

**Giải pháp:** Liên kết qua trường `teacherId` mới trên `HrEmployee`:

```
HrEmployee.teacherId → Teacher.id  (nullable, unique)
```

Điều này cho phép:
- HrEmployee có thể là giáo viên (có teacherId) HOẶC nhân viên hành chính (teacherId = null)
- Khi tính lương giáo viên → truy vấn ClassSession qua teacherId → tổng giờ dạy

---

## 3. Schema Changes (DDL)

### 3.1 Thêm trường `teacherId` vào HrEmployee

```prisma
model HrEmployee {
  // ... existing fields ...
  teacherId  String?  @unique @map("teacher_id")  // NEW
  teacher    Teacher? @relation(fields: [teacherId], references: [id])  // NEW
}

model Teacher {
  // ... existing fields ...
  hrEmployee HrEmployee?  // NEW — inverse relation
}
```

### 3.2 Thêm bảng HrTeachingLog (View vật lý hóa)

Thay vì query trực tiếp ClassSession mỗi lần tính lương (phức tạp + chậm), tạo bảng trung gian **HrTeachingLog** — ghi nhận mỗi buổi dạy đã hoàn thành:

```prisma
model HrTeachingLog {
  id            String   @id @default(uuid())
  employeeId    String   @map("employee_id")
  branchId      String   @map("branch_id")
  classSessionId String  @unique @map("class_session_id")
  classId       String   @map("class_id")
  teachingDate  DateTime @map("teaching_date")
  startTime     String?  @map("start_time")
  endTime       String?  @map("end_time")
  teachingHours Float    @map("teaching_hours")  // tính từ startTime/endTime hoặc Course.durationHours/totalSessions
  hourlyRate    Float    @map("hourly_rate")      // snapshot tại thời điểm dạy
  amount        Float                              // teachingHours × hourlyRate
  status        String   @default("confirmed")    // confirmed | disputed | adjusted
  notes         String?
  metadata      Json     @default("{}")
  createdAt     DateTime @default(now()) @map("created_at")

  employee     HrEmployee   @relation(fields: [employeeId], references: [id])
  branch       Branch       @relation(fields: [branchId], references: [id])
  classSession ClassSession @relation(fields: [classSessionId], references: [id])

  @@index([employeeId])
  @@index([teachingDate])
  @@index([employeeId, teachingDate])
  @@map("hr_teaching_logs")
}
```

### 3.3 ERD Relationships (Mới)

```
┌──────────────┐         ┌──────────────┐
│   Teacher    │ 1 ─── 1 │  HrEmployee  │
│  (Academic)  │         │    (HR)      │
└──────┬───────┘         └──────┬───────┘
       │                        │
       │ 1:N                    │ 1:N
       ▼                        ▼
┌──────────────┐         ┌──────────────┐
│    Class     │         │ HrTeachingLog│
└──────┬───────┘         └──────┬───────┘
       │ 1:N                    │ N:1
       ▼                        ▼
┌──────────────┐         ┌──────────────┐
│ ClassSession │ 1 ─── 1 │ HrTeachingLog│
│  (buổi học)  │         │ (giờ dạy)    │
└──────────────┘         └──────────────┘

HrEmployee ──1:N──▶ HrContract
HrEmployee ──1:N──▶ HrAttendance  (chấm công hàng ngày)
HrEmployee ──1:N──▶ HrTeachingLog (chấm công giảng dạy — TỰ ĐỘNG)
HrEmployee ──1:N──▶ HrPayroll
HrEmployee ──1:N──▶ HrLeaveRequest
```

---

## 4. Luồng nghiệp vụ chính

### 4.1 Luồng chấm công giảng dạy (Teaching Hours Tracking)

```
ClassSession status = "completed"
       │
       ▼
┌─────────────────────────────────────────┐
│ Sync Teaching Log (API hoặc Cron)       │
│                                         │
│ 1. Tìm ClassSession.status = completed  │
│    mà chưa có HrTeachingLog             │
│ 2. Lookup Teacher → HrEmployee          │
│ 3. Tính teachingHours:                  │
│    - Nếu có startTime/endTime → parse   │
│    - Nếu không → Course.durationHours   │
│      ÷ Course.totalSessions             │
│ 4. Lấy hourlyRate từ Teacher            │
│ 5. Create HrTeachingLog                 │
└─────────────────────────────────────────┘
```

**Trigger:** Có 2 cách:
- **Cách 1 (Phase 3A — khuyên dùng):** API endpoint `POST /api/hr/teaching-logs/sync` — gọi thủ công hoặc khi cập nhật session
- **Cách 2 (Phase 3B):** Scheduled task chạy mỗi đêm

### 4.2 Luồng tính lương

```
Admin chọn kỳ lương (periodStart ↔ periodEnd)
       │
       ▼
┌─────────────────────────────────────────┐
│ Calculate Payroll                        │
│                                          │
│ Với mỗi HrEmployee (active):            │
│                                          │
│ A. Lương cơ bản (từ HrContract.baseSalary│
│    hoặc prorate theo actualDays)         │
│                                          │
│ B. Giờ dạy = SUM(HrTeachingLog.amount)  │
│    WHERE teachingDate BETWEEN period     │
│                                          │
│ C. Phụ cấp = HrContract.allowances      │
│                                          │
│ D. Gross = A + B + C + bonuses           │
│                                          │
│ E. Khấu trừ = tax + insurance + other    │
│                                          │
│ F. Net = D - E                           │
│                                          │
│ → Create HrPayroll (status: draft)       │
└─────────────────────────────────────────┘
       │
       ▼
┌──────────────────┐
│ Review & Approve │
│ draft → approved │
│ approved → paid  │
└──────────────────┘
```

**Payroll State Machine:**
```
draft ──▶ approved ──▶ paid
  │         │
  └─────────┴──▶ cancelled
```

---

## 5. API Endpoints

### 5.1 Nhân sự (HrEmployee)

| Method | Endpoint | Mô tả |
|--------|----------|--------|
| GET | `/api/hr/employees` | List + filter (branchId, department, status, search) |
| POST | `/api/hr/employees` | Tạo mới (có thể link teacherId) |
| PUT | `/api/hr/employees` | Cập nhật thông tin |

### 5.2 Chấm công giảng dạy (HrTeachingLog)

| Method | Endpoint | Mô tả |
|--------|----------|--------|
| GET | `/api/hr/teaching-logs` | List theo employeeId, period, branchId |
| POST | `/api/hr/teaching-logs/sync` | Sync ClassSession completed → HrTeachingLog |

### 5.3 Bảng lương (HrPayroll)

| Method | Endpoint | Mô tả |
|--------|----------|--------|
| GET | `/api/hr/payroll` | List bảng lương theo period, branchId |
| POST | `/api/hr/payroll/generate` | Auto-generate payroll cho 1 kỳ |
| PUT | `/api/hr/payroll` | Cập nhật status (draft→approved→paid) |

### 5.4 Thống kê HR

| Method | Endpoint | Mô tả |
|--------|----------|--------|
| GET | `/api/hr/stats` | Tổng NV, tổng giờ dạy tháng, tổng lương, by branch |

---

## 6. UI Pages

### 6.1 Danh sách Nhân sự (`/dashboard/hr/employees`)
- Table: Mã NV, Họ tên, Phòng ban, Chức vụ, Chi nhánh, Giáo viên liên kết, Trạng thái
- Filter: chi nhánh, phòng ban, trạng thái
- Dialog: Thêm/sửa nhân viên (bao gồm link Teacher)

### 6.2 Chấm công giảng dạy (`/dashboard/hr/teaching-logs`)
- Table: Ngày dạy, Giáo viên, Lớp, Buổi, Số giờ, Đơn giá, Thành tiền
- Nút "Đồng bộ buổi học" → gọi sync API
- Tổng giờ dạy tháng hiện tại

### 6.3 Bảng lương (`/dashboard/hr/payroll`)
- Chọn kỳ lương (tháng)
- Nút "Tạo bảng lương" → auto-generate
- Table: Mã NV, Họ tên, Lương CB, Giờ dạy, Tiền dạy, Phụ cấp, Gross, Khấu trừ, Net, Trạng thái
- Actions: Duyệt (draft→approved), Thanh toán (approved→paid)

### 6.4 Sidebar Navigation
```
Nhân sự
  ├─ Nhân viên       /dashboard/hr/employees
  ├─ Chấm công       /dashboard/hr/teaching-logs
  └─ Bảng lương      /dashboard/hr/payroll
```

---

## 7. Công thức tính lương chi tiết

```
┌──────────────────────────────────────────────────┐
│                 BẢNG LƯƠNG THÁNG                  │
├──────────────────────────────────────────────────┤
│                                                  │
│  A. Lương cơ bản        = HrContract.baseSalary  │
│                                                  │
│  B. Tiền giờ dạy        = Σ(HrTeachingLog.amount)│
│     = Σ(teachingHours × hourlyRate)              │
│     trong kỳ [periodStart, periodEnd]            │
│                                                  │
│  C. Phụ cấp             = HrContract.allowances  │
│     (ăn trưa, đi lại, điện thoại...)            │
│                                                  │
│  D. Thưởng              = bonuses (nhập tay)     │
│                                                  │
│  ────────────────────────────────────────         │
│  GROSS = A + B + C + D                           │
│  ────────────────────────────────────────         │
│                                                  │
│  E. Thuế TNCN           = taxDeduction           │
│  F. BHXH/BHYT/BHTN      = insuranceDeduction     │
│  G. Khấu trừ khác       = otherDeductions        │
│                                                  │
│  ────────────────────────────────────────         │
│  NET = GROSS - E - F - G                         │
│  ────────────────────────────────────────         │
└──────────────────────────────────────────────────┘
```

**Ví dụ:** Giáo viên Nguyễn Văn A, tháng 06/2026:
- Lương cơ bản: 8.000.000 đ
- Dạy 40 giờ × 150.000 đ/giờ = 6.000.000 đ
- Phụ cấp: 1.500.000 đ
- **Gross: 15.500.000 đ**
- Thuế: 750.000 đ, BHXH: 1.200.000 đ
- **Net: 13.550.000 đ**

---

## 8. Kế hoạch triển khai (Phase 3A)

| Bước | Công việc | Ước tính |
|------|-----------|----------|
| 1 | Schema migration (thêm teacherId, HrTeachingLog) | Nhỏ |
| 2 | Seed data: tạo HrEmployee cho teachers hiện có | Nhỏ |
| 3 | API: /api/hr/employees (CRUD) | Trung bình |
| 4 | API: /api/hr/teaching-logs + sync | Trung bình |
| 5 | API: /api/hr/payroll + generate | Lớn |
| 6 | API: /api/hr/stats | Nhỏ |
| 7 | UI: Nhân viên (list + form) | Trung bình |
| 8 | UI: Chấm công giảng dạy | Trung bình |
| 9 | UI: Bảng lương | Lớn |
| 10 | Activate sidebar + Dashboard HR KPIs | Nhỏ |
| 11 | Test + Checkpoint | Nhỏ |

---

## 9. Rủi ro & Giải pháp

| Rủi ro | Giải pháp |
|--------|-----------|
| ClassSession chưa có dữ liệu (chưa có buổi nào completed) | Seed data tạo sessions completed cho demo |
| Teacher chưa link HrEmployee | Auto-create HrEmployee từ Teacher data khi seed |
| Giờ dạy không chính xác (thiếu startTime/endTime) | Fallback: Course.durationHours ÷ totalSessions |
| Tính lương phức tạp (thuế lũy tiến) | Phase 3A: nhập tay khấu trừ thuế; Phase 3B: auto calc |

---

## 10. Câu hỏi chờ xác nhận

1. **Phòng ban:** Ngoài "Giảng dạy", cần quản lý phòng ban nào? (Hành chính, Tuyển sinh, Marketing...)
2. **Thuế TNCN:** Phase 3A tính thủ công hay tự động theo biểu thuế lũy tiến?
3. **Nghỉ phép:** Có triển khai HrLeaveRequest UI trong Phase 3A không?
4. **Hợp đồng:** Có cần quản lý HrContract UI không hay chỉ lưu baseSalary?
