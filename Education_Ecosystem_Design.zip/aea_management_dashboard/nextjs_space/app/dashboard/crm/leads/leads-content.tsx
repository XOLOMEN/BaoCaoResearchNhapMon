'use client';
import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import {
  Users, Plus, Search, Megaphone, ArrowRightLeft, Phone, Mail,
  Calendar, MessageSquare, TrendingUp, UserCheck, UserX, Eye,
  ChevronLeft, ChevronRight, Download,
} from 'lucide-react';
import { toast } from 'sonner';
import { useBranch } from '@/hooks/use-branch';
import { formatDate, formatCurrency, getStatusColor } from '@/lib/helpers';
import { FadeIn } from '@/components/ui/animate';

const STATUS_LABELS: Record<string, string> = {
  new: 'Mới', contacted: 'Đã liên hệ', qualified: 'Đủ điều kiện',
  proposal: 'Đề xuất', negotiation: 'Đàm phán', converted: 'Đã chuyển đổi', lost: 'Đã mất',
};
const SOURCE_LABELS: Record<string, string> = {
  website: 'Website', referral: 'Giới thiệu', social_media: 'Mạng xã hội',
  walk_in: 'Đến trực tiếp', phone: 'Điện thoại', event: 'Sự kiện', campaign: 'Chiến dịch', other: 'Khác',
};
const STATUS_COLORS: Record<string, string> = {
  new: 'bg-blue-100 text-blue-700', contacted: 'bg-cyan-100 text-cyan-700',
  qualified: 'bg-amber-100 text-amber-700', proposal: 'bg-purple-100 text-purple-700',
  negotiation: 'bg-orange-100 text-orange-700', converted: 'bg-green-100 text-green-700',
  lost: 'bg-red-100 text-red-700',
};

const INITIAL_FORM = {
  branchId: '', fullName: '', email: '', phone: '', source: 'walk_in',
  interestNotes: '', assignedTo: '', score: '0', expectedValue: '', nextFollowUp: '', notes: '',
};

export function LeadsContent() {
  const { branchId: globalBranchId } = useBranch();
  const { data: session } = useSession() || {};
  const role = session?.user?.role ?? 'staff';
  const canWrite = role === 'super_admin' || role === 'staff';

  const [leads, setLeads] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sourceFilter, setSourceFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ total: 0, totalPages: 1 });

  // Dialogs
  const [showAdd, setShowAdd] = useState(false);
  const [showDetail, setShowDetail] = useState<any>(null);
  const [showConvert, setShowConvert] = useState<any>(null);
  const [showInteraction, setShowInteraction] = useState<any>(null);
  const [form, setForm] = useState(INITIAL_FORM);
  const [convertForm, setConvertForm] = useState({ courseId: '', tuitionAmount: '', notes: '' });
  const [interactionForm, setInteractionForm] = useState({ type: 'call', direction: 'outbound', subject: '', content: '', outcome: '', nextFollowUp: '' });
  const [interactions, setInteractions] = useState<any[]>([]);

  const fetchLeads = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (globalBranchId) params.set('branchId', globalBranchId);
      if (search) params.set('search', search);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      if (sourceFilter !== 'all') params.set('source', sourceFilter);
      params.set('page', String(page));
      params.set('limit', '20');

      const res = await fetch(`/api/crm/leads?${params}`);
      const data = await res.json();
      setLeads(data.leads || []);
      setPagination(data.pagination || { total: 0, totalPages: 1 });
    } catch { toast.error('Lỗi tải dữ liệu leads'); }
    setLoading(false);
  }, [globalBranchId, search, statusFilter, sourceFilter, page]);

  const fetchMeta = useCallback(async () => {
    try {
      const [brRes, coRes] = await Promise.all([fetch('/api/branches'), fetch('/api/courses')]);
      const [brData, coData] = await Promise.all([brRes.json(), coRes.json()]);
      setBranches(brData.branches || []);
      setCourses(coData.courses || []);
    } catch {}
  }, []);

  useEffect(() => { fetchMeta(); }, [fetchMeta]);
  useEffect(() => { fetchLeads(); }, [fetchLeads]);

  // ── Add Lead ──
  const handleAddLead = async () => {
    if (!form.branchId || !form.fullName || !form.phone) {
      toast.error('Vui lòng nhập chi nhánh, họ tên và SĐT');
      return;
    }
    try {
      const res = await fetch('/api/crm/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          score: parseInt(form.score) || 0,
          expectedValue: form.expectedValue ? parseFloat(form.expectedValue) : null,
          nextFollowUp: form.nextFollowUp || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success('Thêm lead thành công');
      setShowAdd(false);
      setForm(INITIAL_FORM);
      fetchLeads();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  // ── Update Lead Status ──
  const handleUpdateStatus = async (id: string, newStatus: string, lostReason?: string) => {
    try {
      const body: any = { id, status: newStatus };
      if (lostReason) body.lostReason = lostReason;
      const res = await fetch('/api/crm/leads', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success('Cập nhật trạng thái thành công');
      fetchLeads();
      if (showDetail?.id === id) setShowDetail(null);
    } catch { toast.error('Lỗi hệ thống'); }
  };

  // ── Convert Lead ──
  const handleConvert = async () => {
    if (!showConvert?.id) return;
    try {
      const res = await fetch('/api/crm/leads/convert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leadId: showConvert.id,
          courseId: convertForm.courseId || null,
          tuitionAmount: convertForm.tuitionAmount ? parseFloat(convertForm.tuitionAmount) : null,
          notes: convertForm.notes || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success(data.message || 'Chuyển đổi thành công');
      setShowConvert(null);
      setConvertForm({ courseId: '', tuitionAmount: '', notes: '' });
      fetchLeads();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  // ── Fetch Interactions ──
  const fetchInteractions = async (leadId: string) => {
    try {
      const res = await fetch(`/api/crm/interactions?leadId=${leadId}`);
      const data = await res.json();
      setInteractions(data.interactions || []);
    } catch { setInteractions([]); }
  };

  // ── Add Interaction ──
  const handleAddInteraction = async () => {
    if (!showInteraction?.id || !interactionForm.type) return;
    try {
      const res = await fetch('/api/crm/interactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leadId: showInteraction.id, ...interactionForm, nextFollowUp: interactionForm.nextFollowUp || null }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success('Thêm tương tác thành công');
      setInteractionForm({ type: 'call', direction: 'outbound', subject: '', content: '', outcome: '', nextFollowUp: '' });
      fetchInteractions(showInteraction.id);
      fetchLeads();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  // ── Status transition helpers ──
  const getNextStatuses = (status: string): string[] => {
    const map: Record<string, string[]> = {
      new: ['contacted', 'lost'], contacted: ['qualified', 'lost'],
      qualified: ['proposal', 'lost'], proposal: ['negotiation', 'lost'],
      negotiation: ['converted', 'lost'],
    };
    return map[status] || [];
  };

  // ── KPI Summary ──
  const totalLeads = pagination.total;
  const convertedCount = leads.filter(l => l.status === 'converted').length;
  const activeCount = leads.filter(l => !['converted', 'lost'].includes(l.status)).length;

  return (
    <FadeIn>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Megaphone className="h-7 w-7 text-primary" /> Quản lý Leads
            </h1>
            <p className="text-muted-foreground mt-1">Theo dõi và chuyển đổi khách hàng tiềm năng</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={async () => {
              try {
                const params = new URLSearchParams({ type: 'leads' });
                if (globalBranchId) params.set('branchId', globalBranchId);
                const res = await fetch(`/api/crm/export?${params}`);
                if (!res.ok) { toast.error('Lỗi xuất CSV'); return; }
                const blob = await res.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `crm-leads-${new Date().toISOString().split('T')[0]}.csv`;
                a.click();
                window.URL.revokeObjectURL(url);
                toast.success('Đã xuất CSV thành công');
              } catch { toast.error('Lỗi xuất file'); }
            }} className="gap-1"><Download className="h-4 w-4" /> CSV</Button>
            {canWrite && (
              <Button onClick={() => setShowAdd(true)} className="gap-2">
                <Plus className="h-4 w-4" /> Thêm Lead
              </Button>
            )}
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card><CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg"><Users className="h-5 w-5 text-blue-600" /></div>
              <div><p className="text-sm text-muted-foreground">Tổng Leads</p><p className="text-2xl font-bold">{totalLeads}</p></div>
            </div>
          </CardContent></Card>
          <Card><CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg"><UserCheck className="h-5 w-5 text-green-600" /></div>
              <div><p className="text-sm text-muted-foreground">Đã chuyển đổi</p><p className="text-2xl font-bold">{convertedCount}</p></div>
            </div>
          </CardContent></Card>
          <Card><CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-100 rounded-lg"><TrendingUp className="h-5 w-5 text-amber-600" /></div>
              <div><p className="text-sm text-muted-foreground">Đang theo dõi</p><p className="text-2xl font-bold">{activeCount}</p></div>
            </div>
          </CardContent></Card>
          <Card><CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg"><ArrowRightLeft className="h-5 w-5 text-purple-600" /></div>
              <div><p className="text-sm text-muted-foreground">Tỷ lệ chuyển đổi</p><p className="text-2xl font-bold">{totalLeads > 0 ? Math.round((convertedCount / totalLeads) * 100) : 0}%</p></div>
            </div>
          </CardContent></Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex flex-wrap gap-3 items-end">
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Tìm tên, email, SĐT..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} className="pl-10" />
                </div>
              </div>
              <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[160px]"><SelectValue placeholder="Trạng thái" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả trạng thái</SelectItem>
                  {Object.entries(STATUS_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={sourceFilter} onValueChange={(v) => { setSourceFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[160px]"><SelectValue placeholder="Nguồn" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả nguồn</SelectItem>
                  {Object.entries(SOURCE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Leads Table */}
        <Card>
          <CardContent className="p-0">
            {loading ? (
              <div className="flex justify-center py-16"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>
            ) : leads.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground">Chưa có lead nào</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b bg-muted/50">
                    <th className="text-left p-3 font-medium">Họ tên</th>
                    <th className="text-left p-3 font-medium">Liên hệ</th>
                    <th className="text-left p-3 font-medium">Nguồn</th>
                    <th className="text-left p-3 font-medium">Trạng thái</th>
                    <th className="text-left p-3 font-medium">Điểm</th>
                    <th className="text-left p-3 font-medium">Chi nhánh</th>
                    <th className="text-left p-3 font-medium">Ngày tạo</th>
                    <th className="text-right p-3 font-medium">Thao tác</th>
                  </tr></thead>
                  <tbody>
                    {leads.map((lead: any) => (
                      <tr key={lead.id} className="border-b hover:bg-muted/30 transition-colors">
                        <td className="p-3">
                          <div className="font-medium">{lead.fullName}</div>
                          {lead.interestCourse && <div className="text-xs text-muted-foreground">Quan tâm: {lead.interestCourse.name}</div>}
                        </td>
                        <td className="p-3">
                          <div className="flex flex-col gap-0.5">
                            {lead.phone && <span className="flex items-center gap-1 text-xs"><Phone className="h-3 w-3" />{lead.phone}</span>}
                            {lead.email && <span className="flex items-center gap-1 text-xs"><Mail className="h-3 w-3" />{lead.email}</span>}
                          </div>
                        </td>
                        <td className="p-3"><Badge variant="outline" className="text-xs">{SOURCE_LABELS[lead.source] || lead.source}</Badge></td>
                        <td className="p-3"><Badge className={`text-xs ${STATUS_COLORS[lead.status] || ''}`}>{STATUS_LABELS[lead.status] || lead.status}</Badge></td>
                        <td className="p-3"><span className="font-medium">{lead.score}</span></td>
                        <td className="p-3 text-xs">{lead.branch?.name || '-'}</td>
                        <td className="p-3 text-xs">{formatDate(lead.createdAt)}</td>
                        <td className="p-3">
                          <div className="flex gap-1 justify-end">
                            <Button size="sm" variant="ghost" onClick={() => { setShowDetail(lead); fetchInteractions(lead.id); }}><Eye className="h-4 w-4" /></Button>
                            {canWrite && lead.status !== 'converted' && lead.status !== 'lost' && (
                              <Button size="sm" variant="ghost" onClick={() => { setShowInteraction(lead); fetchInteractions(lead.id); }}>
                                <MessageSquare className="h-4 w-4" />
                              </Button>
                            )}
                            {canWrite && getNextStatuses(lead.status).includes('converted') && (
                              <Button size="sm" variant="outline" className="text-green-600 border-green-300" onClick={() => setShowConvert(lead)}>
                                <ArrowRightLeft className="h-4 w-4 mr-1" /> Chuyển đổi
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t">
                <span className="text-sm text-muted-foreground">Trang {page}/{pagination.totalPages} ({pagination.total} leads)</span>
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
                  <Button size="sm" variant="outline" disabled={page >= pagination.totalPages} onClick={() => setPage(p => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ═══ ADD LEAD DIALOG ═══ */}
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Thêm Lead mới</DialogTitle></DialogHeader>
            <div className="grid gap-3">
              <div><Label>Chi nhánh *</Label>
                <Select value={form.branchId} onValueChange={(v) => setForm(f => ({ ...f, branchId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Chọn chi nhánh" /></SelectTrigger>
                  <SelectContent>{branches.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Họ tên *</Label><Input value={form.fullName} onChange={(e) => setForm(f => ({ ...f, fullName: e.target.value }))} /></div>
                <div><Label>Số điện thoại *</Label><Input value={form.phone} onChange={(e) => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
              </div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm(f => ({ ...f, email: e.target.value }))} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Nguồn *</Label>
                  <Select value={form.source} onValueChange={(v) => setForm(f => ({ ...f, source: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{Object.entries(SOURCE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Điểm lead</Label><Input type="number" value={form.score} onChange={(e) => setForm(f => ({ ...f, score: e.target.value }))} /></div>
              </div>
              <div><Label>Giá trị kỳ vọng (VND)</Label><Input type="number" value={form.expectedValue} onChange={(e) => setForm(f => ({ ...f, expectedValue: e.target.value }))} /></div>
              <div><Label>Ngày follow-up tiếp theo</Label><Input type="date" value={form.nextFollowUp} onChange={(e) => setForm(f => ({ ...f, nextFollowUp: e.target.value }))} /></div>
              <div><Label>Quan tâm / Ghi chú</Label><Textarea value={form.interestNotes} onChange={(e) => setForm(f => ({ ...f, interestNotes: e.target.value }))} rows={2} /></div>
              <div><Label>Ghi chú nội bộ</Label><Textarea value={form.notes} onChange={(e) => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAdd(false)}>Hủy</Button>
              <Button onClick={handleAddLead}>Tạo Lead</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* ═══ DETAIL DIALOG ═══ */}
        <Dialog open={!!showDetail} onOpenChange={() => setShowDetail(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Chi tiết Lead: {showDetail?.fullName}</DialogTitle></DialogHeader>
            {showDetail && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div><span className="text-muted-foreground">SĐT:</span> {showDetail.phone}</div>
                  <div><span className="text-muted-foreground">Email:</span> {showDetail.email || '-'}</div>
                  <div><span className="text-muted-foreground">Nguồn:</span> {SOURCE_LABELS[showDetail.source] || showDetail.source}</div>
                  <div><span className="text-muted-foreground">Trạng thái:</span> <Badge className={STATUS_COLORS[showDetail.status]}>{STATUS_LABELS[showDetail.status]}</Badge></div>
                  <div><span className="text-muted-foreground">Điểm:</span> {showDetail.score}</div>
                  <div><span className="text-muted-foreground">Chi nhánh:</span> {showDetail.branch?.name}</div>
                  <div><span className="text-muted-foreground">Người phụ trách:</span> {showDetail.assignee?.fullName || '-'}</div>
                  <div><span className="text-muted-foreground">Ngày tạo:</span> {formatDate(showDetail.createdAt)}</div>
                  {showDetail.expectedValue && <div><span className="text-muted-foreground">Giá trị kỳ vọng:</span> {formatCurrency(showDetail.expectedValue)}</div>}
                  {showDetail.lastContacted && <div><span className="text-muted-foreground">Liên hệ gần nhất:</span> {formatDate(showDetail.lastContacted)}</div>}
                  {showDetail.nextFollowUp && <div><span className="text-muted-foreground">Follow-up tiếp:</span> {formatDate(showDetail.nextFollowUp)}</div>}
                  {showDetail.interestCourse && <div><span className="text-muted-foreground">Khóa quan tâm:</span> {showDetail.interestCourse.name}</div>}
                </div>
                {showDetail.notes && <div className="text-sm"><span className="text-muted-foreground">Ghi chú:</span> {showDetail.notes}</div>}
                {showDetail.convertedStudent && (
                  <div className="p-3 bg-green-50 rounded-lg border border-green-200 text-sm">
                    <strong>Đã chuyển đổi:</strong> {showDetail.convertedStudent.fullName} ({showDetail.convertedStudent.studentCode}) - {formatDate(showDetail.convertedAt)}
                  </div>
                )}

                {/* Status Actions */}
                {canWrite && showDetail.status !== 'converted' && showDetail.status !== 'lost' && (
                  <div className="flex gap-2 flex-wrap">
                    <span className="text-sm text-muted-foreground self-center">Chuyển trạng thái:</span>
                    {getNextStatuses(showDetail.status).filter(s => s !== 'converted').map(ns => (
                      <Button key={ns} size="sm" variant="outline" onClick={() => handleUpdateStatus(showDetail.id, ns)}>
                        {STATUS_LABELS[ns]}
                      </Button>
                    ))}
                    {getNextStatuses(showDetail.status).includes('converted') && (
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => { setShowDetail(null); setShowConvert(showDetail); }}>
                        <ArrowRightLeft className="h-4 w-4 mr-1" /> Chuyển đổi
                      </Button>
                    )}
                    <Button size="sm" variant="destructive" onClick={() => handleUpdateStatus(showDetail.id, 'lost')}>
                      <UserX className="h-4 w-4 mr-1" /> Đánh dấu mất
                    </Button>
                  </div>
                )}

                {/* Interactions History */}
                <div>
                  <h4 className="font-semibold mb-2 flex items-center gap-1"><MessageSquare className="h-4 w-4" /> Lịch sử tương tác ({interactions.length})</h4>
                  {interactions.length === 0 ? (
                    <p className="text-sm text-muted-foreground">Chưa có tương tác nào</p>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {interactions.map((i: any) => (
                        <div key={i.id} className="p-2 border rounded text-sm">
                          <div className="flex justify-between">
                            <Badge variant="outline" className="text-xs">{i.type} {i.direction ? `(${i.direction})` : ''}</Badge>
                            <span className="text-xs text-muted-foreground">{formatDate(i.createdAt)}</span>
                          </div>
                          {i.subject && <div className="font-medium mt-1">{i.subject}</div>}
                          {i.content && <div className="text-muted-foreground mt-0.5">{i.content}</div>}
                          {i.outcome && <div className="mt-1"><span className="text-muted-foreground">Kết quả:</span> {i.outcome}</div>}
                          {i.contactor && <div className="text-xs text-muted-foreground mt-1">Bởi: {i.contactor.fullName}</div>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* ═══ CONVERT DIALOG ═══ */}
        <Dialog open={!!showConvert} onOpenChange={() => setShowConvert(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Chuyển đổi Lead thành Học viên</DialogTitle></DialogHeader>
            {showConvert && (
              <div className="space-y-3">
                <div className="p-3 bg-muted rounded-lg text-sm">
                  <strong>{showConvert.fullName}</strong> - {showConvert.phone}
                  {showConvert.interestCourse && <div className="text-muted-foreground">Quan tâm: {showConvert.interestCourse.name}</div>}
                </div>
                <div><Label>Khóa học đăng ký</Label>
                  <Select value={convertForm.courseId} onValueChange={(v) => {
                    const course = courses.find((c: any) => c.id === v);
                    setConvertForm(f => ({ ...f, courseId: v, tuitionAmount: course?.tuitionFee?.toString() || f.tuitionAmount }));
                  }}>
                    <SelectTrigger><SelectValue placeholder="Chọn khóa học (tùy chọn)" /></SelectTrigger>
                    <SelectContent>{courses.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name} - {formatCurrency(c.tuitionFee)}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Học phí (VND)</Label><Input type="number" value={convertForm.tuitionAmount} onChange={(e) => setConvertForm(f => ({ ...f, tuitionAmount: e.target.value }))} /></div>
                <div><Label>Ghi chú</Label><Textarea value={convertForm.notes} onChange={(e) => setConvertForm(f => ({ ...f, notes: e.target.value }))} rows={2} /></div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowConvert(null)}>Hủy</Button>
              <Button className="bg-green-600 hover:bg-green-700" onClick={handleConvert}>
                <ArrowRightLeft className="h-4 w-4 mr-1" /> Xác nhận chuyển đổi
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* ═══ INTERACTION DIALOG ═══ */}
        <Dialog open={!!showInteraction} onOpenChange={() => setShowInteraction(null)}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Tương tác với Lead: {showInteraction?.fullName}</DialogTitle></DialogHeader>
            {showInteraction && (
              <div className="space-y-4">
                {/* Interaction form */}
                <div className="grid gap-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div><Label>Loại tương tác *</Label>
                      <Select value={interactionForm.type} onValueChange={(v) => setInteractionForm(f => ({ ...f, type: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="call">Cuộc gọi</SelectItem>
                          <SelectItem value="email">Email</SelectItem>
                          <SelectItem value="meeting">Gặp mặt</SelectItem>
                          <SelectItem value="sms">SMS</SelectItem>
                          <SelectItem value="visit">Thăm quan</SelectItem>
                          <SelectItem value="demo">Demo</SelectItem>
                          <SelectItem value="note">Ghi chú</SelectItem>
                          <SelectItem value="other">Khác</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div><Label>Chiều</Label>
                      <Select value={interactionForm.direction} onValueChange={(v) => setInteractionForm(f => ({ ...f, direction: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="outbound">Gửi đi</SelectItem>
                          <SelectItem value="inbound">Nhận vào</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div><Label>Tiêu đề</Label><Input value={interactionForm.subject} onChange={(e) => setInteractionForm(f => ({ ...f, subject: e.target.value }))} /></div>
                  <div><Label>Nội dung</Label><Textarea value={interactionForm.content} onChange={(e) => setInteractionForm(f => ({ ...f, content: e.target.value }))} rows={3} /></div>
                  <div><Label>Kết quả</Label><Input value={interactionForm.outcome} onChange={(e) => setInteractionForm(f => ({ ...f, outcome: e.target.value }))} /></div>
                  <div><Label>Follow-up tiếp theo</Label><Input type="date" value={interactionForm.nextFollowUp} onChange={(e) => setInteractionForm(f => ({ ...f, nextFollowUp: e.target.value }))} /></div>
                </div>
                <Button onClick={handleAddInteraction} className="w-full">Lưu tương tác</Button>

                {/* History */}
                <div>
                  <h4 className="font-semibold mb-2 text-sm">Lịch sử ({interactions.length})</h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {interactions.map((i: any) => (
                      <div key={i.id} className="p-2 border rounded text-xs">
                        <div className="flex justify-between">
                          <Badge variant="outline">{i.type}</Badge>
                          <span className="text-muted-foreground">{formatDate(i.createdAt)}</span>
                        </div>
                        {i.subject && <div className="font-medium mt-1">{i.subject}</div>}
                        {i.content && <div className="text-muted-foreground">{i.content}</div>}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </FadeIn>
  );
}
