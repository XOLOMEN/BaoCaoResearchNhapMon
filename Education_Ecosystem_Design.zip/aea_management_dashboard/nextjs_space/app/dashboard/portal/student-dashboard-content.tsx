'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FadeIn } from '@/components/ui/animate';
import { BookOpen, Clock, Trophy, TrendingUp, PlayCircle, CheckCircle2, BarChart3 } from 'lucide-react';

export default function StudentDashboardContent() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/portal/dashboard')
      .then(r => r.json())
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-28 bg-muted animate-pulse rounded-lg" />)}
        </div>
      </div>
    );
  }

  const stats = data?.stats;
  const enrollments = data?.enrollments ?? [];
  const recentActivity = data?.recentActivity ?? [];

  const kpis = [
    { label: 'Khóa học', value: stats?.totalCourses ?? 0, icon: BookOpen, color: 'text-blue-600 bg-blue-50' },
    { label: 'Đang học', value: stats?.activeCourses ?? 0, icon: TrendingUp, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'Hoàn thành', value: stats?.completedCourses ?? 0, icon: Trophy, color: 'text-amber-600 bg-amber-50' },
    { label: 'Thời gian học', value: `${stats?.totalTimeSpentMin ?? 0} phút`, icon: Clock, color: 'text-purple-600 bg-purple-50' },
  ];

  return (
    <FadeIn>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Bảng điều khiển</h2>
          <p className="text-muted-foreground">Xin chào! Đây là tổng quan học tập của bạn.</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((kpi, idx) => (
            <Card key={idx} className="border-0 shadow-sm">
              <CardContent className="flex items-center gap-4 p-5">
                <div className={`p-3 rounded-xl ${kpi.color}`}>
                  <kpi.icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{kpi.label}</p>
                  <p className="text-2xl font-bold">{kpi.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Average Progress */}
        {stats?.avgProgress > 0 && (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Tiến độ trung bình</span>
                <span className="text-sm font-bold text-primary">{stats.avgProgress}%</span>
              </div>
              <Progress value={stats.avgProgress} className="h-2" />
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* My Courses */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Khóa học của tôi</CardTitle>
                <Link href="/dashboard/portal/courses" className="text-sm text-primary hover:underline">Xem tất cả</Link>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {enrollments.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">Chưa ghi danh khóa học nào</p>
              ) : (
                enrollments.map((e: any) => (
                  <Link key={e.id} href={`/dashboard/portal/courses/${e.lmsCourseId}`} className="block">
                    <div className="flex items-center gap-4 p-3 rounded-lg hover:bg-accent/50 transition-colors">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <BookOpen className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{e.lmsCourse?.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Progress value={e.progressPct} className="h-1.5 flex-1" />
                          <span className="text-xs text-muted-foreground whitespace-nowrap">{Math.round(e.progressPct)}%</span>
                        </div>
                      </div>
                      <Badge variant={e.status === 'completed' ? 'default' : 'secondary'} className="shrink-0">
                        {e.status === 'completed' ? 'Hoàn thành' : 'Đang học'}
                      </Badge>
                    </div>
                  </Link>
                ))
              )}
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Hoạt động gần đây</CardTitle>
                <Link href="/dashboard/portal/progress" className="text-sm text-primary hover:underline">Xem chi tiết</Link>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentActivity.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">Chưa có hoạt động nào</p>
              ) : (
                recentActivity.map((a: any) => (
                  <div key={a.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent/50 transition-colors">
                    {a.status === 'completed' ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                    ) : (
                      <PlayCircle className="w-5 h-5 text-blue-500 shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{a.lesson?.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{a.enrollment?.lmsCourse?.title}</p>
                    </div>
                    <Badge variant="outline" className="text-xs shrink-0">
                      {a.status === 'completed' ? 'Xong' : `${Math.round(a.progressPct)}%`}
                    </Badge>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </FadeIn>
  );
}
