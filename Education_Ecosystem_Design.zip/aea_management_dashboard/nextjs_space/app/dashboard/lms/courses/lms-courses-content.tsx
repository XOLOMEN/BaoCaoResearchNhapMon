'use client';

import { useState, useEffect, useCallback } from 'react';
import { useBranch } from '@/hooks/use-branch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FadeIn } from '@/components/ui/animate';
import { BookOpen, Plus, Search, Users, Award, GraduationCap, Eye, Pencil, Globe } from 'lucide-react';
import { toast } from 'sonner';
import { formatCurrency, getStatusColor, getLevelLabel, formatDate } from '@/lib/helpers';
import Link from 'next/link';

export function LmsCoursesContent() {
  const { branchId: selectedBranch } = useBranch();
  const [courses, setCourses] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [levelFilter, setLevelFilter] = useState('');
  const [publishedFilter, setPublishedFilter] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ branchId: '', title: '', description: '', level: 'all', category: '', price: '' });

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedBranch) params.set('branchId', selectedBranch);
      if (search) params.set('search', search);
      if (levelFilter) params.set('level', levelFilter);
      if (publishedFilter) params.set('published', publishedFilter);

      const [coursesRes, branchesRes, statsRes] = await Promise.all([
        fetch(`/api/lms/courses?${params}`),
        fetch('/api/branches'),
        fetch(`/api/lms/stats?${selectedBranch ? `branchId=${selectedBranch}` : ''}`),
      ]);
      const coursesData = await coursesRes.json();
      setCourses(coursesData.courses || []);
      setBranches(await branchesRes.json());
      setStats(await statsRes.json());
    } catch { toast.error('Lỗi tải dữ liệu'); }
    setLoading(false);
  }, [selectedBranch, search, levelFilter, publishedFilter]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleCreate = async () => {
    if (!form.branchId || !form.title) { toast.error('Vui lòng nhập chi nhánh và tên khóa học'); return; }
    try {
      const res = await fetch('/api/lms/courses', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      if (!res.ok) { const e = await res.json(); toast.error(e.error); return; }
      toast.success('Tạo khóa học thành công');
      setDialogOpen(false);
      setForm({ branchId: '', title: '', description: '', level: 'all', category: '', price: '' });
      fetchData();
    } catch { toast.error('Lỗi tạo khóa học'); }
  };

  const togglePublish = async (id: string, current: boolean) => {
    try {
      await fetch(`/api/lms/courses/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isPublished: !current }) });
      toast.success(current ? 'Đã ẩn khóa học' : 'Đã xuất bản khóa học');
      fetchData();
    } catch { toast.error('Lỗi cập nhật'); }
  };

  return (
    <FadeIn>
      <div className="space-y-6">
        {/* KPI Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card><CardContent className="pt-6"><div className="flex items-center gap-3"><BookOpen className="h-8 w-8 text-blue-500" /><div><p className="text-sm text-muted-foreground">Tổng khóa học</p><p className="text-2xl font-bold">{stats.totalCourses}</p></div></div></CardContent></Card>
            <Card><CardContent className="pt-6"><div className="flex items-center gap-3"><Globe className="h-8 w-8 text-emerald-500" /><div><p className="text-sm text-muted-foreground">Đã xuất bản</p><p className="text-2xl font-bold">{stats.publishedCourses}</p></div></div></CardContent></Card>
            <Card><CardContent className="pt-6"><div className="flex items-center gap-3"><Users className="h-8 w-8 text-purple-500" /><div><p className="text-sm text-muted-foreground">Đang học</p><p className="text-2xl font-bold">{stats.activeEnrollments}</p></div></div></CardContent></Card>
            <Card><CardContent className="pt-6"><div className="flex items-center gap-3"><Award className="h-8 w-8 text-amber-500" /><div><p className="text-sm text-muted-foreground">Chứng chỉ</p><p className="text-2xl font-bold">{stats.totalCertificates}</p></div></div></CardContent></Card>
          </div>
        )}

        {/* Toolbar */}
        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <CardTitle className="flex items-center gap-2"><GraduationCap className="h-5 w-5" /> Khóa học trực tuyến (LMS)</CardTitle>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-1" /> Thêm khóa học</Button></DialogTrigger>
                <DialogContent className="max-w-lg">
                  <DialogHeader><DialogTitle>Tạo khóa học LMS mới</DialogTitle></DialogHeader>
                  <div className="space-y-4 py-4">
                    <div><Label>Chi nhánh *</Label>
                      <Select value={form.branchId} onValueChange={v => setForm(p => ({...p, branchId: v}))}>
                        <SelectTrigger><SelectValue placeholder="Chọn chi nhánh" /></SelectTrigger>
                        <SelectContent>{branches.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div><Label>Tên khóa học *</Label><Input value={form.title} onChange={e => setForm(p => ({...p, title: e.target.value}))} placeholder="Nhập tên khóa học" /></div>
                    <div><Label>Mô tả</Label><Input value={form.description} onChange={e => setForm(p => ({...p, description: e.target.value}))} placeholder="Mô tả ngắn" /></div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><Label>Trình độ</Label>
                        <Select value={form.level} onValueChange={v => setForm(p => ({...p, level: v}))}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Tất cả</SelectItem>
                            <SelectItem value="beginner">Cơ bản</SelectItem>
                            <SelectItem value="intermediate">Trung cấp</SelectItem>
                            <SelectItem value="advanced">Nâng cao</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div><Label>Học phí (VND)</Label><Input type="number" value={form.price} onChange={e => setForm(p => ({...p, price: e.target.value}))} placeholder="0 = Miễn phí" /></div>
                    </div>
                    <div><Label>Danh mục</Label><Input value={form.category} onChange={e => setForm(p => ({...p, category: e.target.value}))} placeholder="Ví dụ: english, math" /></div>
                  </div>
                  <DialogFooter>
                    <DialogClose asChild><Button variant="outline">Hủy</Button></DialogClose>
                    <Button onClick={handleCreate}>Tạo khóa học</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-3 mb-4">
              <div className="relative flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input className="pl-9" placeholder="Tìm khóa học..." value={search} onChange={e => setSearch(e.target.value)} /></div>
              <Select value={levelFilter} onValueChange={setLevelFilter}><SelectTrigger className="w-40"><SelectValue placeholder="Trình độ" /></SelectTrigger>
                <SelectContent><SelectItem value="all_levels">Tất cả</SelectItem><SelectItem value="beginner">Cơ bản</SelectItem><SelectItem value="intermediate">Trung cấp</SelectItem><SelectItem value="advanced">Nâng cao</SelectItem></SelectContent>
              </Select>
              <Select value={publishedFilter} onValueChange={setPublishedFilter}><SelectTrigger className="w-40"><SelectValue placeholder="Trạng thái" /></SelectTrigger>
                <SelectContent><SelectItem value="all_status">Tất cả</SelectItem><SelectItem value="true">Đã xuất bản</SelectItem><SelectItem value="false">Nháp</SelectItem></SelectContent>
              </Select>
            </div>

            {loading ? <p className="text-muted-foreground text-center py-8">Đang tải...</p> : courses.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">Chưa có khóa học nào</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {courses.map((c: any) => (
                  <Card key={c.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-lg truncate">{c.title}</h3>
                          <p className="text-sm text-muted-foreground truncate">{c.description || 'Chưa có mô tả'}</p>
                        </div>
                        <Badge className={c.isPublished ? getStatusColor('published') : getStatusColor('draft')}>
                          {c.isPublished ? 'Xuất bản' : 'Nháp'}
                        </Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-muted-foreground">Trình độ</span><span>{getLevelLabel(c.level)}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Bài học</span><span>{c._count?.lessons || 0}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Học viên</span><span>{c._count?.enrollments || 0}</span></div>
                        <div className="flex justify-between"><span className="text-muted-foreground">Học phí</span><span className="font-medium">{c.price > 0 ? formatCurrency(c.price) : 'Miễn phí'}</span></div>
                        {c.instructorUser && <div className="flex justify-between"><span className="text-muted-foreground">Giáo viên</span><span>{c.instructorUser.fullName}</span></div>}
                        <div className="flex justify-between"><span className="text-muted-foreground">Chi nhánh</span><span>{c.branch?.name}</span></div>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Link href={`/dashboard/lms/courses/${c.id}`} className="flex-1">
                          <Button variant="outline" size="sm" className="w-full"><Eye className="h-3 w-3 mr-1" /> Chi tiết</Button>
                        </Link>
                        <Button variant="outline" size="sm" onClick={() => togglePublish(c.id, c.isPublished)}>
                          {c.isPublished ? 'Ẩn' : 'Xuất bản'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </FadeIn>
  );
}
