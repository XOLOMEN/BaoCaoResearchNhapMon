export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getStudentSession } from '@/lib/portal/helpers';

export async function GET() {
  const { error, session } = await getStudentSession();
  if (error) return error;
  const studentId = session!.user.studentId!;

  try {
    const enrollments = await prisma.lmsEnrollment.findMany({
      where: { studentId },
      include: {
        lmsCourse: { select: { id: true, title: true, totalLessons: true, level: true, category: true } },
        progress: {
          include: { lesson: { select: { id: true, title: true, type: true, durationMin: true } } },
          orderBy: { updatedAt: 'desc' },
        },
      },
      orderBy: { enrolledAt: 'desc' },
    });

    const totalTimeSpent = await prisma.lmsProgress.aggregate({
      where: { enrollment: { studentId } },
      _sum: { timeSpentSec: true },
    });

    const completedLessons = await prisma.lmsProgress.count({
      where: { enrollment: { studentId }, status: 'completed' },
    });

    const totalLessons = await prisma.lmsProgress.count({
      where: { enrollment: { studentId } },
    });

    // Quiz attempts
    const quizAttempts = await prisma.lmsQuizAttempt.findMany({
      where: { studentId },
      include: { quiz: { select: { title: true, lesson: { select: { title: true } } } } },
      orderBy: { startedAt: 'desc' },
      take: 10,
    });

    // Certificates
    const certificates = await prisma.lmsCertificate.findMany({
      where: { studentId },
      include: { lmsCourse: { select: { title: true } } },
      orderBy: { issuedAt: 'desc' },
    });

    return NextResponse.json({
      enrollments,
      summary: {
        totalTimeSpentMin: Math.round((totalTimeSpent._sum.timeSpentSec ?? 0) / 60),
        completedLessons,
        totalLessons,
        completionRate: totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0,
      },
      quizAttempts,
      certificates,
    });
  } catch (err: any) {
    console.error('Portal progress error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
