'use client';
import { useState, useEffect } from 'react';
import { BarChart3, Users, School, TrendingUp, Award } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useBranch } from '@/hooks/use-branch';
import { FadeIn } from '@/components/ui/animate';
import dynamic from 'next/dynamic';

const EnrollmentChart = dynamic(() => import('../charts/enrollment-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải...</div> });
const ClassUtilChart = dynamic(() => import('../charts/class-util-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải...</div> });
const BranchChart = dynamic(() => import('../charts/branch-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải...</div> });
const PerformanceChart = dynamic(() => import('./performance-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải...</div> });

export function AnalyticsContent() {
  const { branchId } = useBranch();
  const [stats, setStats] = useState<any>(null);
  const [grades, setGrades] = useState<any[]>([]);

  useEffect(() => {
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/dashboard/stats${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setStats(d)).catch(()=>{});
    fetch(`/api/grades${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setGrades(d?.grades??[])).catch(()=>{});
  }, [branchId]);

  // Aggregate grade performance
  const perfData = (() => {
    const types: Record<string, {total:number,count:number}> = {};
    for (const g of grades ?? []) {
      const t = g?.assessmentType ?? 'other';
      if (!types[t]) types[t] = {total:0,count:0};
      types[t].total += (g?.maxScore ? (g.score/g.maxScore)*100 : 0);
      types[t].count += 1;
    }
    return Object.entries(types).map(([type,d]:any) => ({ type, avg: Math.round(d.total/Math.max(d.count,1)) }));
  })();

  return (
    <div className="space-y-6">
      <FadeIn>
        <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><BarChart3 className="w-6 h-6 text-primary" /> Phân tích Học vụ</h1>
        <p className="text-muted-foreground text-sm">Biểu đồ và thống kê chi tiết về hoạt động học vụ</p>
      </FadeIn>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <FadeIn delay={0.1}><Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="w-4 h-4 text-primary" /> Xu hướng ghi danh</CardTitle></CardHeader>
          <CardContent><div className="h-64"><EnrollmentChart data={stats?.enrollmentTrend ?? []} /></div></CardContent></Card></FadeIn>

        <FadeIn delay={0.2}><Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><School className="w-4 h-4 text-primary" /> Tỷ lệ lấp đầy</CardTitle></CardHeader>
          <CardContent><div className="h-64"><ClassUtilChart data={stats?.classUtilization ?? []} /></div></CardContent></Card></FadeIn>

        <FadeIn delay={0.3}><Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Users className="w-4 h-4 text-primary" /> So sánh chi nhánh</CardTitle></CardHeader>
          <CardContent><div className="h-64"><BranchChart data={stats?.branchStats ?? []} /></div></CardContent></Card></FadeIn>

        <FadeIn delay={0.4}><Card><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Award className="w-4 h-4 text-primary" /> Học lực trung bình</CardTitle></CardHeader>
          <CardContent><div className="h-64"><PerformanceChart data={perfData} /></div></CardContent></Card></FadeIn>
      </div>
    </div>
  );
}
