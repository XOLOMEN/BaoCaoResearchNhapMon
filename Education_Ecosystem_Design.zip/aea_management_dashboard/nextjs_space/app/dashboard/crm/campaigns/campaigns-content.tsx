'use client';
import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import {
  Megaphone, Plus, Target, TrendingUp, DollarSign, Users,
  ChevronLeft, ChevronRight, Play, Pause, CheckCircle2,
  Download, BarChart3, Calendar,
} from 'lucide-react';
import { toast } from 'sonner';
import { useBranch } from '@/hooks/use-branch';
import { formatDate, formatCurrency } from '@/lib/helpers';
import { FadeIn } from '@/components/ui/animate';

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  draft: { label: 'Nháp', color: 'bg-gray-100 text-gray-600' },
  active: { label: 'Đang chạy', color: 'bg-green-100 text-green-700' },
  paused: { label: 'Tạm dừng', color: 'bg-amber-100 text-amber-700' },
  completed: { label: 'Hoàn thành', color: 'bg-blue-100 text-blue-700' },
  cancelled: { label: 'Đã hủy', color: 'bg-red-100 text-red-600' },
};
const TYPE_LABELS: Record<string, string> = {
  email: 'Email', social_media: 'Mạng xã hội', event: 'Sự kiện',
  referral: 'Giới thiệu', ads: 'Quảng cáo', content: 'Nội dung',
  outbound: 'Outbound', other: 'Khác',
};

const INITIAL_FORM = {
  branchId: '', name: '', type: 'other', description: '', startDate: '', endDate: '', budget: '',
};

export function CampaignsContent() {
  const { branchId: globalBranchId } = useBranch();
  const { data: session } = useSession() || {};
  const role = session?.user?.role ?? 'staff';
  const canWrite = role === 'super_admin' || role === 'staff';

  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ total: 0, totalPages: 1 });
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(INITIAL_FORM);

  const fetchCampaigns = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (globalBranchId) params.set('branchId', globalBranchId);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      params.set('page', String(page));
      params.set('limit', '20');
      const res = await fetch(`/api/crm/campaigns?${params}`);
      const data = await res.json();
      setCampaigns(data.campaigns || []);
      setPagination(data.pagination || { total: 0, totalPages: 1 });
    } catch { toast.error('Lỗi tải dữ liệu chiến dịch'); }
    setLoading(false);
  }, [globalBranchId, statusFilter, page]);

  const fetchBranches = useCallback(async () => {
    try {
      const res = await fetch('/api/branches');
      const data = await res.json();
      setBranches(data.branches || []);
    } catch {}
  }, []);

  useEffect(() => { fetchBranches(); }, [fetchBranches]);
  useEffect(() => { fetchCampaigns(); }, [fetchCampaigns]);

  const handleAdd = async () => {
    if (!form.branchId || !form.name) {
      toast.error('Vui lòng nhập chi nhánh và tên chiến dịch');
      return;
    }
    try {
      const res = await fetch('/api/crm/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          budget: form.budget ? parseFloat(form.budget) : null,
        }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success('Thêm chiến dịch thành công');
      setShowAdd(false);
      setForm(INITIAL_FORM);
      fetchCampaigns();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  const handleUpdateStatus = async (campaignId: string, newStatus: string) => {
    try {
      const res = await fetch('/api/crm/campaigns', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: campaignId, status: newStatus }),
      });
      if (!res.ok) { const d = await res.json(); toast.error(d.error); return; }
      toast.success('Cập nhật trạng thái thành công');
      fetchCampaigns();
    } catch { toast.error('Lỗi hệ thống'); }
  };

  const handleExportCSV = async () => {
    try {
      const params = new URLSearchParams({ type: 'campaigns' });
      if (globalBranchId) params.set('branchId', globalBranchId);
      const res = await fetch(`/api/crm/export?${params}`);
      if (!res.ok) { toast.error('Lỗi xuất CSV'); return; }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `crm-campaigns-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success('Đã xuất CSV thành công');
    } catch { toast.error('Lỗi xuất file'); }
  };

  // KPIs
  const totalBudget = campaigns.reduce((s, c) => s + (c.budget || 0), 0);
  const totalSpent = campaigns.reduce((s, c) => s + (c.spent || 0), 0);
  const totalLeads = campaigns.reduce((s, c) => s + (c.stats?.totalLeads || 0), 0);
  const totalConverted = campaigns.reduce((s, c) => s + (c.stats?.converted || 0), 0);

  return (
    <FadeIn>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Target className="h-7 w-7 text-primary" /> Chiến dịch Marketing
            </h1>
            <p className="text-muted-foreground mt-1">Quản lý và theo dõi hiệu quả chiến dịch</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1">
              <Download className="h-4 w-4" /> CSV
            </Button>
            {canWrite && (
              <Button onClick={() => setShowAdd(true)} className="gap-2">
                <Plus className="h-4 w-4" /> Thêm Chiến dịch
              </Button>
            )}
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="border-l-4 border-l-purple-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <Megaphone className="h-5 w-5 text-purple-600" />
                <div><p className="text-sm text-muted-foreground">Tổng chiến dịch</p><p className="text-2xl font-bold">{pagination.total}</p></div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-green-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <DollarSign className="h-5 w-5 text-green-600" />
                <div><p className="text-sm text-muted-foreground">Ngân sách</p><p className="text-lg font-bold">{formatCurrency(totalBudget)}</p></div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-blue-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <Users className="h-5 w-5 text-blue-600" />
                <div><p className="text-sm text-muted-foreground">Tổng Leads</p><p className="text-2xl font-bold">{totalLeads}</p></div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-amber-400">
            <CardContent className="pt-4">
              <div className="flex items-center gap-3">
                <TrendingUp className="h-5 w-5 text-amber-600" />
                <div><p className="text-sm text-muted-foreground">Đã chuyển đổi</p><p className="text-2xl font-bold">{totalConverted}</p></div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex flex-wrap gap-3">
              <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[180px]"><SelectValue placeholder="Trạng thái" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả trạng thái</SelectItem>
                  {Object.entries(STATUS_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Cards */}
        {loading ? (
          <div className="flex justify-center py-16"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>
        ) : campaigns.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <Target className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="text-muted-foreground">Chưa có chiến dịch nào</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {campaigns.map((c: any) => {
              const sCfg = STATUS_CONFIG[c.status] || STATUS_CONFIG.draft;
              const budgetUsed = c.budget ? Math.round((c.spent / c.budget) * 100) : 0;
              return (
                <Card key={c.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-base">{c.name}</CardTitle>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">{TYPE_LABELS[c.type] || c.type}</Badge>
                          <Badge className={`text-xs ${sCfg.color}`}>{sCfg.label}</Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {c.description && <p className="text-sm text-muted-foreground line-clamp-2">{c.description}</p>}

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div><span className="text-muted-foreground">Leads:</span> <strong>{c.stats?.totalLeads || 0}</strong></div>
                      <div><span className="text-muted-foreground">Converted:</span> <strong className="text-green-600">{c.stats?.converted || 0}</strong></div>
                      <div><span className="text-muted-foreground">Tỷ lệ:</span> <strong>{c.stats?.conversionRate || 0}%</strong></div>
                      <div><span className="text-muted-foreground">Chi nhánh:</span> {c.branch?.name}</div>
                    </div>

                    {c.budget && c.budget > 0 && (
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Ngân sách</span>
                          <span>{formatCurrency(c.spent || 0)} / {formatCurrency(c.budget)}</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${Math.min(budgetUsed, 100)}%` }} />
                        </div>
                      </div>
                    )}

                    {(c.startDate || c.endDate) && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        {c.startDate && formatDate(c.startDate)}
                        {c.startDate && c.endDate && ' → '}
                        {c.endDate && formatDate(c.endDate)}
                      </div>
                    )}

                    {/* Actions */}
                    {canWrite && (
                      <div className="flex gap-1 pt-1">
                        {c.status === 'draft' && (
                          <Button size="sm" variant="outline" className="text-xs flex-1" onClick={() => handleUpdateStatus(c.id, 'active')}>
                            <Play className="h-3 w-3 mr-1" />Bắt đầu
                          </Button>
                        )}
                        {c.status === 'active' && (
                          <>
                            <Button size="sm" variant="outline" className="text-xs flex-1" onClick={() => handleUpdateStatus(c.id, 'paused')}>
                              <Pause className="h-3 w-3 mr-1" />Tạm dừng
                            </Button>
                            <Button size="sm" variant="outline" className="text-xs flex-1 text-green-600 border-green-300" onClick={() => handleUpdateStatus(c.id, 'completed')}>
                              <CheckCircle2 className="h-3 w-3 mr-1" />Hoàn thành
                            </Button>
                          </>
                        )}
                        {c.status === 'paused' && (
                          <Button size="sm" variant="outline" className="text-xs flex-1" onClick={() => handleUpdateStatus(c.id, 'active')}>
                            <Play className="h-3 w-3 mr-1" />Tiếp tục
                          </Button>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Trang {page}/{pagination.totalPages}</span>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
              <Button size="sm" variant="outline" disabled={page >= pagination.totalPages} onClick={() => setPage(p => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
            </div>
          </div>
        )}

        {/* ADD CAMPAIGN DIALOG */}
        <Dialog open={showAdd} onOpenChange={setShowAdd}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Thêm Chiến dịch mới</DialogTitle></DialogHeader>
            <div className="grid gap-3">
              <div><Label>Chi nhánh *</Label>
                <Select value={form.branchId} onValueChange={(v) => setForm(f => ({ ...f, branchId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Chọn chi nhánh" /></SelectTrigger>
                  <SelectContent>{branches.map((b: any) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Tên chiến dịch *</Label><Input value={form.name} onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))} /></div>
              <div><Label>Loại</Label>
                <Select value={form.type} onValueChange={(v) => setForm(f => ({ ...f, type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Mô tả</Label><Textarea value={form.description} onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))} rows={2} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Ngày bắt đầu</Label><Input type="date" value={form.startDate} onChange={(e) => setForm(f => ({ ...f, startDate: e.target.value }))} /></div>
                <div><Label>Ngày kết thúc</Label><Input type="date" value={form.endDate} onChange={(e) => setForm(f => ({ ...f, endDate: e.target.value }))} /></div>
              </div>
              <div><Label>Ngân sách (VND)</Label><Input type="number" value={form.budget} onChange={(e) => setForm(f => ({ ...f, budget: e.target.value }))} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAdd(false)}>Hủy</Button>
              <Button onClick={handleAdd}>Tạo Chiến dịch</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </FadeIn>
  );
}
