export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { buildBranchWhere, canModifyLms, slugify } from '@/lib/lms/helpers';

// ── GET: List LMS courses ──
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const search = url.searchParams.get('search');
    const level = url.searchParams.get('level');
    const published = url.searchParams.get('published');
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'));
    const limit = Math.min(100, parseInt(url.searchParams.get('limit') || '50'));

    const where: any = buildBranchWhere(session, branchId);
    if (level) where.level = level;
    if (published === 'true') where.isPublished = true;
    if (published === 'false') where.isPublished = false;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [courses, total] = await Promise.all([
      prisma.lmsCourse.findMany({
        where,
        include: {
          branch: { select: { id: true, name: true, code: true } },
          course: { select: { id: true, name: true, code: true } },
          instructorUser: { select: { id: true, fullName: true } },
          _count: { select: { enrollments: true, lessons: true } },
        },
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.lmsCourse.count({ where }),
    ]);

    return NextResponse.json({ courses, total, page, limit });
  } catch (error: any) {
    console.error('LMS courses GET error:', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

// ── POST: Create LMS course ──
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (!canModifyLms(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const body = await request.json();
    const { branchId, title, description, courseId, level, category, price, instructor, tags, thumbnail } = body;
    if (!branchId || !title) return NextResponse.json({ error: 'branchId và title bắt buộc' }, { status: 400 });

    // Auto-generate slug from title
    let slug = slugify(title);
    const existing = await prisma.lmsCourse.findUnique({ where: { slug } });
    if (existing) slug = `${slug}-${Date.now().toString(36)}`;

    const course = await prisma.lmsCourse.create({
      data: {
        branchId,
        title,
        slug,
        description: description || null,
        courseId: courseId || null,
        level: level || 'all',
        category: category || null,
        price: price ? parseFloat(price) : 0,
        instructor: instructor || null,
        tags: tags || [],
        thumbnail: thumbnail || null,
      },
      include: {
        branch: { select: { id: true, name: true, code: true } },
        _count: { select: { enrollments: true, lessons: true } },
      },
    });

    return NextResponse.json(course, { status: 201 });
  } catch (error: any) {
    console.error('LMS courses POST error:', error);
    if (error.code === 'P2002') return NextResponse.json({ error: 'Slug đã tồn tại' }, { status: 409 });
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
