export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

// =============================================================================
// POST /api/academic/ai-submission
// Prototype API to test AI data storage in the AEA ecosystem
//
// Actions:
//   - 'start'  : Create a new submission (student begins an exercise)
//   - 'submit' : Submit answers for AI grading
//   - 'grade'  : (Internal) Store AI grading results
// =============================================================================

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Chưa đăng nhập' }, { status: 401 });
    }

    const body = await request.json();
    const { action } = body;

    // -----------------------------------------------------------------------
    // ACTION: START - Create a new submission attempt
    // -----------------------------------------------------------------------
    if (action === 'start') {
      const { moduleId, studentId, enrollmentId } = body;

      if (!moduleId || !studentId) {
        return NextResponse.json(
          { error: 'moduleId và studentId là bắt buộc' },
          { status: 400 }
        );
      }

      // Verify module exists and is published
      const module = await prisma.aiLearningModule.findUnique({
        where: { id: moduleId },
        select: { id: true, title: true, type: true, maxScore: true, isPublished: true },
      });

      if (!module) {
        return NextResponse.json({ error: 'Module không tồn tại' }, { status: 404 });
      }

      if (!module.isPublished) {
        return NextResponse.json({ error: 'Module chưa được công bố' }, { status: 403 });
      }

      // Count existing attempts to determine attemptNumber
      const existingAttempts = await prisma.aiSubmission.count({
        where: { moduleId, studentId },
      });

      const submission = await prisma.aiSubmission.create({
        data: {
          moduleId,
          studentId,
          enrollmentId: enrollmentId || null,
          attemptNumber: existingAttempts + 1,
          status: 'in_progress',
          startedAt: new Date(),
          deviceInfo: body.deviceInfo || {},
        },
        include: {
          module: { select: { title: true, type: true, content: true, maxScore: true, timeLimitSec: true } },
        },
      });

      return NextResponse.json({
        success: true,
        submission: {
          id: submission.id,
          attemptNumber: submission.attemptNumber,
          status: submission.status,
          startedAt: submission.startedAt.toISOString(),
          module: submission.module,
        },
      });
    }

    // -----------------------------------------------------------------------
    // ACTION: SUBMIT - Student submits answers
    // -----------------------------------------------------------------------
    if (action === 'submit') {
      const { submissionId, submittedData } = body;

      if (!submissionId || !submittedData) {
        return NextResponse.json(
          { error: 'submissionId và submittedData là bắt buộc' },
          { status: 400 }
        );
      }

      // Verify submission exists and is in_progress
      const existing = await prisma.aiSubmission.findUnique({
        where: { id: submissionId },
        include: { module: true },
      });

      if (!existing) {
        return NextResponse.json({ error: 'Submission không tồn tại' }, { status: 404 });
      }

      if (existing.status !== 'in_progress') {
        return NextResponse.json(
          { error: `Submission đã ở trạng thái: ${existing.status}` },
          { status: 400 }
        );
      }

      // Calculate duration
      const durationSec = Math.floor(
        (Date.now() - existing.startedAt.getTime()) / 1000
      );

      // Update submission to 'submitted'
      const updated = await prisma.aiSubmission.update({
        where: { id: submissionId },
        data: {
          submittedData,
          status: 'submitted',
          submittedAt: new Date(),
          durationSec,
        },
      });

      // In production, this would trigger async AI grading.
      // For prototype, we simulate a simple grading result.
      const gradeResult = simulateAiGrading(
        existing.module.type,
        submittedData,
        existing.module.maxScore,
        existing.module.content as Record<string, unknown>
      );

      // Store AI result in a transaction
      const [result] = await prisma.$transaction([
        // 1. Create AI grading result
        prisma.aiSubmissionResult.create({
          data: {
            submissionId,
            totalScore: gradeResult.totalScore,
            maxScore: gradeResult.maxScore,
            percentageScore: gradeResult.percentageScore,
            breakdown: gradeResult.breakdown,
            aiModelUsed: gradeResult.aiModelUsed,
            aiRawResponse: gradeResult.aiRawResponse,
            feedback: gradeResult.feedback,
            strengths: gradeResult.strengths,
            improvements: gradeResult.improvements,
            processingTimeMs: gradeResult.processingTimeMs,
          },
        }),

        // 2. Update submission status to 'graded'
        prisma.aiSubmission.update({
          where: { id: submissionId },
          data: { status: 'graded' },
        }),

        // 3. Update gamification (upsert XP)
        prisma.aiGamificationScore.upsert({
          where: { studentId: existing.studentId },
          create: {
            studentId: existing.studentId,
            totalXp: calculateXp(gradeResult.percentageScore),
            currentStreak: 1,
            longestStreak: 1,
            lastActivityAt: new Date(),
            weeklyProgress: 1,
          },
          update: {
            totalXp: { increment: calculateXp(gradeResult.percentageScore) },
            weeklyProgress: { increment: 1 },
            lastActivityAt: new Date(),
          },
        }),

        // 4. Log event for analytics
        prisma.eventStore.create({
          data: {
            aggregateType: 'ai_submission',
            aggregateId: submissionId,
            eventType: 'ai.submission.graded',
            payload: {
              studentId: existing.studentId,
              moduleId: existing.moduleId,
              moduleType: existing.module.type,
              score: gradeResult.totalScore,
              maxScore: gradeResult.maxScore,
              percentage: gradeResult.percentageScore,
            },
            sequenceNumber: 1,
          },
        }),
      ]);

      return NextResponse.json({
        success: true,
        submission: {
          id: updated.id,
          status: 'graded',
          durationSec,
          submittedAt: updated.submittedAt?.toISOString(),
        },
        result: {
          id: result.id,
          totalScore: result.totalScore,
          maxScore: result.maxScore,
          percentageScore: result.percentageScore,
          breakdown: result.breakdown,
          feedback: result.feedback,
          strengths: result.strengths,
          improvements: result.improvements,
          aiModelUsed: result.aiModelUsed,
          processingTimeMs: result.processingTimeMs,
        },
        gamification: {
          xpEarned: calculateXp(gradeResult.percentageScore),
        },
      });
    }

    return NextResponse.json({ error: 'Action không hợp lệ. Sử dụng: start | submit' }, { status: 400 });
  } catch (error: any) {
    console.error('[AI-Submission API Error]', error);
    return NextResponse.json(
      { error: error?.message || 'Lỗi hệ thống' },
      { status: 500 }
    );
  }
}

// =============================================================================
// GET /api/academic/ai-submission
// Get submissions for a student or module
// =============================================================================

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Chưa đăng nhập' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get('studentId');
    const moduleId = searchParams.get('moduleId');
    const status = searchParams.get('status');

    const where: any = {};
    if (studentId) where.studentId = studentId;
    if (moduleId) where.moduleId = moduleId;
    if (status) where.status = status;

    const submissions = await prisma.aiSubmission.findMany({
      where,
      include: {
        module: { select: { title: true, type: true, maxScore: true } },
        result: {
          select: {
            totalScore: true,
            maxScore: true,
            percentageScore: true,
            feedback: true,
            strengths: true,
            improvements: true,
            gradedAt: true,
          },
        },
        student: { select: { fullName: true, studentCode: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return NextResponse.json({
      submissions: submissions.map((s) => ({
        ...s,
        startedAt: s.startedAt.toISOString(),
        submittedAt: s.submittedAt?.toISOString() || null,
        createdAt: s.createdAt.toISOString(),
        updatedAt: s.updatedAt.toISOString(),
        result: s.result
          ? { ...s.result, gradedAt: s.result.gradedAt.toISOString() }
          : null,
      })),
    });
  } catch (error: any) {
    console.error('[AI-Submission GET Error]', error);
    return NextResponse.json(
      { error: error?.message || 'Lỗi hệ thống' },
      { status: 500 }
    );
  }
}

// =============================================================================
// HELPER: Simulate AI Grading (Prototype)
// In production, this will be replaced by actual AI API calls
// =============================================================================

function simulateAiGrading(
  moduleType: string,
  submittedData: any,
  maxScore: number,
  moduleContent: Record<string, unknown>
) {
  const startTime = Date.now();

  // Simple scoring logic for prototype
  let totalScore = 0;
  const breakdown: Record<string, number> = {};
  const strengths: string[] = [];
  const improvements: string[] = [];

  if (moduleType === 'quiz' || moduleType === 'grammar' || moduleType === 'vocabulary') {
    // For quiz: compare answers with correct answers
    const answers = submittedData?.answers || [];
    const correctAnswers = (moduleContent as any)?.correctAnswers || [];
    let correct = 0;

    answers.forEach((answer: string, idx: number) => {
      const isCorrect = correctAnswers[idx] && answer === correctAnswers[idx];
      if (isCorrect) correct++;
      breakdown[`question_${idx + 1}`] = isCorrect ? maxScore / Math.max(answers.length, 1) : 0;
    });

    totalScore = Math.round((correct / Math.max(answers.length, 1)) * maxScore);

    if (correct / Math.max(answers.length, 1) >= 0.8) {
      strengths.push('Nắm vững kiến thức cơ bản');
    }
    if (correct / Math.max(answers.length, 1) < 0.6) {
      improvements.push('Cần ôn lại ngữ pháp cơ bản');
    }
  } else if (moduleType === 'speaking') {
    // Simulated speaking assessment
    totalScore = Math.round(maxScore * (0.6 + Math.random() * 0.35));
    breakdown['pronunciation'] = Math.round(30 * (0.5 + Math.random() * 0.5));
    breakdown['fluency'] = Math.round(25 * (0.5 + Math.random() * 0.5));
    breakdown['grammar'] = Math.round(25 * (0.5 + Math.random() * 0.5));
    breakdown['vocabulary'] = Math.round(20 * (0.5 + Math.random() * 0.5));
    strengths.push('Phát âm rõ ràng');
    improvements.push('Cần cải thiện ngữ điệu tự nhiên');
  } else if (moduleType === 'writing') {
    totalScore = Math.round(maxScore * (0.5 + Math.random() * 0.45));
    breakdown['structure'] = Math.round(25 * (0.5 + Math.random() * 0.5));
    breakdown['grammar'] = Math.round(25 * (0.5 + Math.random() * 0.5));
    breakdown['vocabulary'] = Math.round(25 * (0.5 + Math.random() * 0.5));
    breakdown['coherence'] = Math.round(25 * (0.5 + Math.random() * 0.5));
    strengths.push('Cấu trúc bài viết logic');
    improvements.push('Mở rộng vốn từ vựng academic');
  } else {
    // Default scoring
    totalScore = Math.round(maxScore * (0.5 + Math.random() * 0.45));
    breakdown['overall'] = totalScore;
  }

  const percentageScore = Math.round((totalScore / maxScore) * 100);
  const processingTimeMs = Date.now() - startTime;

  return {
    totalScore,
    maxScore,
    percentageScore,
    breakdown,
    aiModelUsed: 'prototype-simulator',
    aiRawResponse: { simulatedAt: new Date().toISOString(), note: 'This is a prototype simulation. Production will use GPT-4o/Whisper via RouteLLM API.' },
    feedback: {
      general: percentageScore >= 80
        ? 'Xuất sắc! Bạn đã nắm vững nội dung bài học.'
        : percentageScore >= 60
          ? 'Khá tốt! Cần luyện tập thêm một số phần.'
          : 'Cần cố gắng hơn. Hãy xem lại bài học và thử lại.',
      detail: `Bạn đạt ${totalScore}/${maxScore} điểm (${percentageScore}%).`,
    },
    strengths,
    improvements,
    processingTimeMs,
  };
}

function calculateXp(percentageScore: number): number {
  if (percentageScore >= 90) return 100;
  if (percentageScore >= 80) return 75;
  if (percentageScore >= 60) return 50;
  if (percentageScore >= 40) return 25;
  return 10;
}
