export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = new URL(request.url);
    const branchId = url.searchParams.get('branchId');
    const employeeId = url.searchParams.get('employeeId');
    const month = url.searchParams.get('month'); // YYYY-MM

    const where: any = {};
    if (session.user.role !== 'super_admin') {
      where.branchId = session.user.primaryBranchId;
    } else if (branchId) {
      where.branchId = branchId;
    }
    if (employeeId) where.employeeId = employeeId;
    if (month) {
      const [y, m] = month.split('-').map(Number);
      where.workDate = { gte: new Date(y, m - 1, 1), lt: new Date(y, m, 1) };
    }

    const records = await prisma.hrAttendance.findMany({
      where,
      include: {
        employee: { select: { fullName: true, employeeCode: true, position: true } },
        branch: { select: { name: true } },
      },
      orderBy: [{ workDate: 'desc' }],
      take: 500,
    });

    return NextResponse.json({
      attendance: records.map((r: any) => ({
        ...r,
        workDate: r.workDate?.toISOString(),
        checkIn: r.checkIn?.toISOString(),
        checkOut: r.checkOut?.toISOString(),
        createdAt: r.createdAt?.toISOString(),
      })),
    });
  } catch (error: any) {
    console.error('[HR/Attendance GET]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (session.user.role !== 'super_admin' && session.user.role !== 'staff') {
      return NextResponse.json({ error: 'Không có quyền' }, { status: 403 });
    }

    const body = await request.json();
    const { employeeId, branchId, workDate, checkIn, checkOut, status: attendanceStatus, notes } = body ?? {};

    if (!employeeId || !branchId || !workDate) {
      return NextResponse.json({ error: 'Thiếu thông tin bắt buộc' }, { status: 400 });
    }

    // Calculate work hours if check-in and check-out provided
    let workHours: number | null = null;
    if (checkIn && checkOut) {
      const diff = new Date(checkOut).getTime() - new Date(checkIn).getTime();
      workHours = Math.round((diff / (1000 * 60 * 60)) * 100) / 100;
    }

    const record = await prisma.hrAttendance.upsert({
      where: {
        employeeId_workDate: { employeeId, workDate: new Date(workDate) },
      },
      create: {
        employeeId,
        branchId,
        workDate: new Date(workDate),
        checkIn: checkIn ? new Date(checkIn) : null,
        checkOut: checkOut ? new Date(checkOut) : null,
        workHours,
        status: attendanceStatus || 'present',
        notes: notes || null,
      },
      update: {
        checkIn: checkIn ? new Date(checkIn) : undefined,
        checkOut: checkOut ? new Date(checkOut) : undefined,
        workHours: workHours ?? undefined,
        status: attendanceStatus || undefined,
        notes: notes || undefined,
      },
    });

    return NextResponse.json({ attendance: record }, { status: 201 });
  } catch (error: any) {
    console.error('[HR/Attendance POST]', error);
    return NextResponse.json({ error: 'Lỗi hệ thống' }, { status: 500 });
  }
}
