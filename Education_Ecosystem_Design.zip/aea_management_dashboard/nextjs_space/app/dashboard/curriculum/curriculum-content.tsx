'use client';
import { useState, useEffect } from 'react';
import { BookOpenCheck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useBranch } from '@/hooks/use-branch';
import { getLevelLabel, formatCurrency } from '@/lib/helpers';
import { FadeIn, Stagger, StaggerItem } from '@/components/ui/animate';

export function CurriculumContent() {
  const { branchId } = useBranch();
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/courses${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setCourses(d?.courses??[])).catch(()=>{}).finally(()=>setLoading(false));
  }, [branchId]);

  return (
    <div className="space-y-6">
      <FadeIn><div>
        <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><BookOpenCheck className="w-6 h-6 text-primary" /> Chương trình học</h1>
        <p className="text-muted-foreground text-sm">Tổng quan chương trình giảng dạy và giáo trình</p>
      </div></FadeIn>
      {loading ? <p className="text-muted-foreground text-center py-12">Đang tải...</p> :
      <Stagger className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(courses ?? [])?.map?.((c: any) => (
          <StaggerItem key={c?.id}>
            <Card className="hover:shadow-md transition-shadow h-full">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-[10px] font-mono">{c?.code ?? ''}</Badge>
                  <Badge className="text-[10px]">{getLevelLabel(c?.level)}</Badge>
                </div>
                <CardTitle className="text-sm mt-2">{c?.name ?? ''}</CardTitle>
              </CardHeader>
              <CardContent className="text-xs space-y-2">
                <p className="text-muted-foreground">{c?.description ?? 'Chưa có mô tả'}</p>
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border">
                  <div><span className="text-muted-foreground">Thời lượng:</span> <span className="font-mono">{c?.durationHours ?? 0}h</span></div>
                  <div><span className="text-muted-foreground">Số buổi:</span> <span className="font-mono">{c?.totalSessions ?? 0}</span></div>
                  <div><span className="text-muted-foreground">Sĩ số tối đa:</span> <span className="font-mono">{c?.maxStudents ?? 0}</span></div>
                  <div><span className="text-muted-foreground">Số lớp:</span> <span className="font-mono">{c?._count?.classes ?? 0}</span></div>
                </div>
                <div className="pt-2 border-t border-border">
                  <span className="text-muted-foreground">Học phí:</span> <span className="font-medium text-primary">{formatCurrency(c?.tuitionFee)}</span>
                </div>
              </CardContent>
            </Card>
          </StaggerItem>
        ))}
      </Stagger>}
    </div>
  );
}
