'use client';
import { useState, useEffect, useCallback } from 'react';
import { Users, Plus, Search, Filter, Eye, Edit2, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useBranch } from '@/hooks/use-branch';
import { formatDate, getStatusColor, getStatusLabel, getLevelLabel } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn, Stagger, StaggerItem } from '@/components/ui/animate';

export function StudentsContent() {
  const { branchId } = useBranch();
  const [students, setStudents] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterLevel, setFilterLevel] = useState('');
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [showView, setShowView] = useState<any>(null);
  const [showEdit, setShowEdit] = useState<any>(null);
  const [branches, setBranches] = useState<any[]>([]);
  const [form, setForm] = useState<any>({ branchId: '', studentCode: '', fullName: '', dateOfBirth: '', gender: '', phone: '', email: '', address: '', level: '', source: '', notes: '' });

  useEffect(() => {
    fetch('/api/branches').then((r: any) => r?.json?.()).then((d: any) => setBranches(d?.branches ?? [])).catch(() => {});
  }, []);

  const loadStudents = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (branchId) params.set('branchId', branchId);
    if (search) params.set('search', search);
    if (filterStatus) params.set('status', filterStatus);
    if (filterLevel) params.set('level', filterLevel);
    params.set('page', String(page));
    fetch(`/api/students?${params}`)
      .then((r: any) => r?.json?.())
      .then((d: any) => { setStudents(d?.students ?? []); setTotal(d?.total ?? 0); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [branchId, search, filterStatus, filterLevel, page]);

  useEffect(() => { loadStudents(); }, [loadStudents]);

  const handleAdd = async () => {
    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, branchId: form.branchId || branchId }),
      });
      const data = await res?.json?.();
      if (!res?.ok) { toast.error(data?.error ?? 'Lỗi'); return; }
      toast.success('Thêm học viên thành công');
      setShowAdd(false);
      setForm({ branchId: '', studentCode: '', fullName: '', dateOfBirth: '', gender: '', phone: '', email: '', address: '', level: '', source: '', notes: '' });
      loadStudents();
    } catch { toast.error('Đã xảy ra lỗi'); }
  };

  const handleEdit = async () => {
    try {
      const res = await fetch(`/api/students/${showEdit?.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (!res?.ok) { toast.error('Lỗi cập nhật'); return; }
      toast.success('Cập nhật thành công');
      setShowEdit(null);
      loadStudents();
    } catch { toast.error('Đã xảy ra lỗi'); }
  };

  const startEdit = (s: any) => {
    setForm({
      fullName: s?.fullName ?? '',
      dateOfBirth: s?.dateOfBirth ? new Date(s.dateOfBirth).toISOString().split('T')[0] : '',
      gender: s?.gender ?? '',
      phone: s?.phone ?? '',
      email: s?.email ?? '',
      address: s?.address ?? '',
      level: s?.level ?? '',
      status: s?.status ?? '',
      source: s?.source ?? '',
      notes: s?.notes ?? '',
    });
    setShowEdit(s);
  };

  const viewStudent = async (id: string) => {
    try {
      const res = await fetch(`/api/students/${id}`);
      const data = await res?.json?.();
      setShowView(data?.student ?? null);
    } catch { toast.error('Lỗi tải dữ liệu'); }
  };

  return (
    <div className="space-y-6">
      <FadeIn>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2">
              <Users className="w-6 h-6 text-primary" /> Quản lý Học viên
            </h1>
            <p className="text-muted-foreground text-sm">Quản lý thông tin và hồ sơ học viên</p>
          </div>
          <Dialog open={showAdd} onOpenChange={setShowAdd}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1"><Plus className="w-4 h-4" /> Thêm học viên</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>Thêm học viên mới</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label className="text-xs">Chi nhánh</Label>
                  <Select value={form.branchId || branchId || ''} onValueChange={(v: string) => setForm((p: any) => ({...(p ?? {}), branchId: v}))}>
                    <SelectTrigger><SelectValue placeholder="Chọn chi nhánh" /></SelectTrigger>
                    <SelectContent>{branches?.map?.((b: any) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">Mã HV</Label><Input value={form.studentCode ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), studentCode: e?.target?.value ?? ''}))} placeholder="SV-XXX" /></div>
                <div><Label className="text-xs">Họ tên</Label><Input value={form.fullName ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), fullName: e?.target?.value ?? ''}))} /></div>
                <div><Label className="text-xs">Ngày sinh</Label><Input type="date" value={form.dateOfBirth ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), dateOfBirth: e?.target?.value ?? ''}))} /></div>
                <div><Label className="text-xs">Giới tính</Label>
                  <Select value={form.gender ?? ''} onValueChange={(v: string) => setForm((p: any) => ({...(p ?? {}), gender: v}))}>
                    <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                    <SelectContent><SelectItem value="male">Nam</SelectItem><SelectItem value="female">Nữ</SelectItem><SelectItem value="other">Khác</SelectItem></SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">Điện thoại</Label><Input value={form.phone ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), phone: e?.target?.value ?? ''}))} /></div>
                <div><Label className="text-xs">Email</Label><Input value={form.email ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), email: e?.target?.value ?? ''}))} /></div>
                <div><Label className="text-xs">Trình độ</Label>
                  <Select value={form.level ?? ''} onValueChange={(v: string) => setForm((p: any) => ({...(p ?? {}), level: v}))}>
                    <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Cơ bản</SelectItem>
                      <SelectItem value="intermediate">Trung cấp</SelectItem>
                      <SelectItem value="advanced">Nâng cao</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">Nguồn</Label><Input value={form.source ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), source: e?.target?.value ?? ''}))} placeholder="website, referral..." /></div>
                <div className="col-span-2"><Label className="text-xs">Địa chỉ</Label><Input value={form.address ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), address: e?.target?.value ?? ''}))} /></div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setShowAdd(false)}>Hủy</Button>
                <Button onClick={handleAdd}>Lưu</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </FadeIn>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Tìm kiếm học viên..." value={search} onChange={(e: any) => { setSearch(e?.target?.value ?? ''); setPage(1); }} className="pl-10 h-9 text-sm" />
            </div>
            <Select value={filterStatus} onValueChange={(v: string) => { setFilterStatus(v === 'all' ? '' : v); setPage(1); }}>
              <SelectTrigger className="w-40 h-9 text-xs"><SelectValue placeholder="Trạng thái" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả</SelectItem>
                <SelectItem value="active">Đang học</SelectItem>
                <SelectItem value="inactive">Tạm nghỉ</SelectItem>
                <SelectItem value="graduated">Tốt nghiệp</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterLevel} onValueChange={(v: string) => { setFilterLevel(v === 'all' ? '' : v); setPage(1); }}>
              <SelectTrigger className="w-36 h-9 text-xs"><SelectValue placeholder="Trình độ" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả</SelectItem>
                <SelectItem value="beginner">Cơ bản</SelectItem>
                <SelectItem value="intermediate">Trung cấp</SelectItem>
                <SelectItem value="advanced">Nâng cao</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="secondary" className="text-xs">{total} học viên</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Mã HV</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Họ tên</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Điện thoại</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Trình độ</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Chi nhánh</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Trạng thái</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Đang tải...</td></tr>
                ) : (students ?? [])?.length === 0 ? (
                  <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Không có dữ liệu</td></tr>
                ) : (
                  (students ?? [])?.map?.((s: any) => (
                    <tr key={s?.id} className="border-t border-border hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs">{s?.studentCode ?? ''}</td>
                      <td className="px-4 py-3 font-medium">{s?.fullName ?? ''}</td>
                      <td className="px-4 py-3 text-muted-foreground">{s?.phone ?? ''}</td>
                      <td className="px-4 py-3"><Badge variant="outline" className="text-[10px]">{getLevelLabel(s?.level)}</Badge></td>
                      <td className="px-4 py-3 text-muted-foreground text-xs">{s?.branch?.name ?? ''}</td>
                      <td className="px-4 py-3"><Badge className={`text-[10px] ${getStatusColor(s?.status ?? '')}`}>{getStatusLabel(s?.status ?? '')}</Badge></td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon-sm" onClick={() => viewStudent(s?.id)}><Eye className="w-3.5 h-3.5" /></Button>
                          <Button variant="ghost" size="icon-sm" onClick={() => startEdit(s)}><Edit2 className="w-3.5 h-3.5" /></Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {total > 20 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <p className="text-xs text-muted-foreground">Trang {page} / {Math.ceil(total / 20)}</p>
              <div className="flex gap-1">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Trước</Button>
                <Button variant="outline" size="sm" disabled={page >= Math.ceil(total / 20)} onClick={() => setPage(page + 1)}>Sau</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Dialog */}
      <Dialog open={!!showView} onOpenChange={() => setShowView(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Thông tin học viên</DialogTitle></DialogHeader>
          {showView && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground">Mã HV:</span> <span className="font-mono">{showView?.studentCode ?? ''}</span></div>
                <div><span className="text-muted-foreground">Họ tên:</span> <span className="font-medium">{showView?.fullName ?? ''}</span></div>
                <div><span className="text-muted-foreground">Ngày sinh:</span> {formatDate(showView?.dateOfBirth)}</div>
                <div><span className="text-muted-foreground">Giới tính:</span> {showView?.gender === 'male' ? 'Nam' : showView?.gender === 'female' ? 'Nữ' : showView?.gender ?? ''}</div>
                <div><span className="text-muted-foreground">ĐT:</span> {showView?.phone ?? ''}</div>
                <div><span className="text-muted-foreground">Email:</span> {showView?.email ?? ''}</div>
                <div><span className="text-muted-foreground">Trình độ:</span> {getLevelLabel(showView?.level)}</div>
                <div><span className="text-muted-foreground">Trạng thái:</span> <Badge className={getStatusColor(showView?.status ?? '')}>{getStatusLabel(showView?.status ?? '')}</Badge></div>
              </div>
              {(showView?.enrollments?.length ?? 0) > 0 && (
                <div>
                  <h3 className="font-medium text-sm mb-2">Lớp đang học</h3>
                  <div className="space-y-2">
                    {showView?.enrollments?.map?.((e: any) => (
                      <div key={e?.id} className="p-2 bg-muted/30 rounded-lg text-xs">
                        <p className="font-medium">{e?.class?.name ?? ''} ({e?.class?.classCode ?? ''})</p>
                        <p className="text-muted-foreground">Trạng thái: {getStatusLabel(e?.status ?? '')}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!showEdit} onOpenChange={() => setShowEdit(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Sửa thông tin học viên</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2"><Label className="text-xs">Họ tên</Label><Input value={form.fullName ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), fullName: e?.target?.value ?? ''}))} /></div>
            <div><Label className="text-xs">Ngày sinh</Label><Input type="date" value={form.dateOfBirth ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), dateOfBirth: e?.target?.value ?? ''}))} /></div>
            <div><Label className="text-xs">Điện thoại</Label><Input value={form.phone ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), phone: e?.target?.value ?? ''}))} /></div>
            <div><Label className="text-xs">Email</Label><Input value={form.email ?? ''} onChange={(e: any) => setForm((p: any) => ({...(p ?? {}), email: e?.target?.value ?? ''}))} /></div>
            <div><Label className="text-xs">Trạng thái</Label>
              <Select value={form.status ?? ''} onValueChange={(v: string) => setForm((p: any) => ({...(p ?? {}), status: v}))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Đang học</SelectItem>
                  <SelectItem value="inactive">Tạm nghỉ</SelectItem>
                  <SelectItem value="graduated">Tốt nghiệp</SelectItem>
                  <SelectItem value="suspended">Đình chỉ</SelectItem>
                  <SelectItem value="withdrawn">Đã rút</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setShowEdit(null)}>Hủy</Button>
            <Button onClick={handleEdit}>Cập nhật</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
