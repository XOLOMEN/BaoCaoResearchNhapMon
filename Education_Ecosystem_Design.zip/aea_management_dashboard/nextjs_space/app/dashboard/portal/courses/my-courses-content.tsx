'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { FadeIn } from '@/components/ui/animate';
import { BookOpen, Clock, User, ArrowRight } from 'lucide-react';

const levelLabels: Record<string, string> = { beginner: 'Sơ cấp', intermediate: 'Trung cấp', advanced: 'Nâng cao', all: 'Tất cả' };
const statusLabels: Record<string, string> = { active: 'Đang học', completed: 'Hoàn thành', dropped: 'Bỏ dở', expired: 'Hết hạn' };

export default function MyCoursesContent() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    fetch('/api/portal/my-courses')
      .then(r => r.json())
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => <div key={i} className="h-64 bg-muted animate-pulse rounded-xl" />)}
        </div>
      </div>
    );
  }

  const allEnrollments = data?.enrollments ?? [];
  const enrollments = filter === 'all' ? allEnrollments : allEnrollments.filter((e: any) => e.status === filter);

  const filters = [
    { key: 'all', label: 'Tất cả', count: allEnrollments.length },
    { key: 'active', label: 'Đang học', count: allEnrollments.filter((e: any) => e.status === 'active').length },
    { key: 'completed', label: 'Hoàn thành', count: allEnrollments.filter((e: any) => e.status === 'completed').length },
  ];

  return (
    <FadeIn>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Khóa học của tôi</h2>
          <p className="text-muted-foreground">Quản lý và theo dõi các khóa học đã ghi danh.</p>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2">
          {filters.map(f => (
            <Button
              key={f.key}
              variant={filter === f.key ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(f.key)}
              className="gap-1"
            >
              {f.label}
              <Badge variant="secondary" className="ml-1 text-xs">{f.count}</Badge>
            </Button>
          ))}
        </div>

        {/* Course Grid */}
        {enrollments.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <BookOpen className="w-12 h-12 text-muted-foreground/30 mb-4" />
              <p className="text-lg font-medium text-muted-foreground">Chưa có khóa học nào</p>
              <p className="text-sm text-muted-foreground/70">Bạn chưa ghi danh vào khóa học nào trong danh mục này.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {enrollments.map((e: any) => {
              const course = e.lmsCourse;
              return (
                <Link key={e.id} href={`/dashboard/portal/courses/${e.lmsCourseId}`}>
                  <Card className="border-0 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden group cursor-pointer h-full">
                    {/* Thumbnail */}
                    <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-primary/40 group-hover:scale-110 transition-transform" />
                    </div>
                    <CardContent className="p-5 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-semibold text-base line-clamp-2">{course?.title}</h3>
                        <Badge variant={e.status === 'completed' ? 'default' : 'secondary'} className="shrink-0 text-xs">
                          {statusLabels[e.status] || e.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">{course?.description}</p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <BookOpen className="w-3.5 h-3.5" />
                          {course?.totalLessons} bài
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {course?.totalDuration} phút
                        </span>
                        {course?.level && (
                          <Badge variant="outline" className="text-xs">{levelLabels[course.level] || course.level}</Badge>
                        )}
                      </div>
                      {course?.instructorUser && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <User className="w-3.5 h-3.5" />
                          {course.instructorUser.fullName}
                        </div>
                      )}
                      <div className="pt-2">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-muted-foreground">Tiến độ</span>
                          <span className="text-xs font-medium">{Math.round(e.progressPct)}%</span>
                        </div>
                        <Progress value={e.progressPct} className="h-1.5" />
                      </div>
                      <div className="flex justify-end pt-1">
                        <span className="text-xs text-primary font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                          Tiếp tục học <ArrowRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </FadeIn>
  );
}
