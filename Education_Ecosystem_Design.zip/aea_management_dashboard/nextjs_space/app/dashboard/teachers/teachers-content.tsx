'use client';
import { useState, useEffect } from 'react';
import { UserCog, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBranch } from '@/hooks/use-branch';
import { getStatusColor, getStatusLabel } from '@/lib/helpers';
import { toast } from 'sonner';
import { FadeIn } from '@/components/ui/animate';

export function TeachersContent() {
  const { branchId } = useBranch();
  const [teachers, setTeachers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [branches, setBranches] = useState<any[]>([]);
  const [form, setForm] = useState<any>({});

  useEffect(() => { fetch('/api/branches').then((r:any)=>r?.json?.()).then((d:any)=>setBranches(d?.branches??[])).catch(()=>{}); }, []);

  useEffect(() => {
    setLoading(true);
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/teachers${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setTeachers(d?.teachers??[])).catch(()=>{}).finally(()=>setLoading(false));
  }, [branchId]);

  const handleAdd = async () => {
    const res = await fetch('/api/teachers', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({...form, branchId: form.branchId||branchId}) });
    const data = await res?.json?.();
    if (!res?.ok) { toast.error(data?.error??'Lỗi'); return; }
    toast.success('Thêm giáo viên thành công');
    setShowAdd(false); setForm({});
    const q = branchId ? `?branchId=${branchId}` : '';
    fetch(`/api/teachers${q}`).then((r:any)=>r?.json?.()).then((d:any)=>setTeachers(d?.teachers??[]));
  };

  return (
    <div className="space-y-6">
      <FadeIn>
        <div className="flex items-center justify-between">
          <div><h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><UserCog className="w-6 h-6 text-primary" /> Quản lý Giáo viên</h1>
          <p className="text-muted-foreground text-sm">Quản lý thông tin giáo viên và phân công</p></div>
          <Dialog open={showAdd} onOpenChange={setShowAdd}>
            <DialogTrigger asChild><Button size="sm" className="gap-1"><Plus className="w-4 h-4" /> Thêm GV</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Thêm giáo viên</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label className="text-xs">Chi nhánh</Label>
                  <Select value={form.branchId||branchId||''} onValueChange={(v:string)=>setForm((p:any)=>({...(p??{}),branchId:v}))}>
                    <SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger>
                    <SelectContent>{branches?.map?.((b:any)=><SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">Mã GV</Label><Input value={form.employeeCode??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),employeeCode:e?.target?.value??''}))} /></div>
                <div><Label className="text-xs">Họ tên</Label><Input value={form.fullName??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),fullName:e?.target?.value??''}))} /></div>
                <div><Label className="text-xs">Email</Label><Input value={form.email??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),email:e?.target?.value??''}))} /></div>
                <div><Label className="text-xs">ĐT</Label><Input value={form.phone??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),phone:e?.target?.value??''}))} /></div>
                <div><Label className="text-xs">Lương/giờ</Label><Input type="number" value={form.hourlyRate??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),hourlyRate:parseFloat(e?.target?.value??'0')}))} /></div>
                <div><Label className="text-xs">Ngày vào</Label><Input type="date" value={form.hireDate??''} onChange={(e:any)=>setForm((p:any)=>({...(p??{}),hireDate:e?.target?.value??''}))} /></div>
              </div>
              <div className="flex justify-end gap-2 mt-4"><Button variant="outline" onClick={()=>setShowAdd(false)}>Hủy</Button><Button onClick={handleAdd}>Lưu</Button></div>
            </DialogContent>
          </Dialog>
        </div>
      </FadeIn>
      <Card><CardContent className="p-0">
        <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-muted/50"><tr>
          <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Mã GV</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Họ tên</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Email</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Chuyên môn</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Số lớp</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Chi nhánh</th>
          <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Trạng thái</th>
        </tr></thead><tbody>
          {loading ? <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Đang tải...</td></tr> :
          (teachers??[])?.length===0 ? <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Không có dữ liệu</td></tr> :
          (teachers??[])?.map?.((t:any)=>(
            <tr key={t?.id} className="border-t border-border hover:bg-muted/30 transition-colors">
              <td className="px-4 py-3 font-mono text-xs">{t?.employeeCode??''}</td>
              <td className="px-4 py-3 font-medium">{t?.fullName??''}</td>
              <td className="px-4 py-3 text-muted-foreground text-xs">{t?.email??''}</td>
              <td className="px-4 py-3">{(t?.specializations??[])?.map?.((s:string,i:number)=><Badge key={i} variant="outline" className="text-[10px] mr-1">{s}</Badge>)}</td>
              <td className="px-4 py-3 text-center font-mono">{t?._count?.classes??0}</td>
              <td className="px-4 py-3 text-xs text-muted-foreground">{t?.branch?.name??''}</td>
              <td className="px-4 py-3"><Badge className={`text-[10px] ${getStatusColor(t?.status??'')}`}>{getStatusLabel(t?.status??'')}</Badge></td>
            </tr>
          ))}
        </tbody></table></div>
      </CardContent></Card>
    </div>
  );
}
