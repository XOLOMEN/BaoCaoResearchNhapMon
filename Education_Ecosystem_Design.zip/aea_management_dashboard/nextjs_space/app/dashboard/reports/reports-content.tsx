'use client';
import { FileText, Download, BarChart3, Users, School, Award } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FadeIn, Stagger, StaggerItem } from '@/components/ui/animate';
import { toast } from 'sonner';

const reportTypes = [
  { title: 'Báo cáo học viên', desc: 'Danh sách và thống kê học viên theo chi nhánh', icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
  { title: 'Báo cáo lớp học', desc: 'Tình trạng và tỷ lệ sử dụng lớp học', icon: School, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { title: 'Báo cáo điểm số', desc: 'Tổng hợp kết quả học tập của học viên', icon: Award, color: 'text-purple-600', bg: 'bg-purple-50' },
  { title: 'Báo cáo ghi danh', desc: 'Xu hướng ghi danh và tỷ lệ chuyển đổi', icon: BarChart3, color: 'text-orange-600', bg: 'bg-orange-50' },
];

export function ReportsContent() {
  const handleExport = (reportTitle: string) => {
    toast.success(`Đang chuẩn bị xuất: ${reportTitle}`);
  };

  return (
    <div className="space-y-6">
      <FadeIn><div>
        <h1 className="font-display text-2xl font-bold tracking-tight flex items-center gap-2"><FileText className="w-6 h-6 text-primary" /> Báo cáo</h1>
        <p className="text-muted-foreground text-sm">Tạo và xuất báo cáo học vụ</p>
      </div></FadeIn>
      <Stagger className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reportTypes?.map?.((r: any) => (
          <StaggerItem key={r.title}>
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg ${r.bg} flex items-center justify-center`}>
                    <r.icon className={`w-5 h-5 ${r.color}`} />
                  </div>
                  <div>
                    <CardTitle className="text-sm">{r.title}</CardTitle>
                    <CardDescription className="text-xs">{r.desc}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Button variant="outline" size="sm" className="gap-1" onClick={() => handleExport(r.title)}>
                  <Download className="w-3.5 h-3.5" /> Xuất báo cáo
                </Button>
              </CardContent>
            </Card>
          </StaggerItem>
        ))}
      </Stagger>
    </div>
  );
}
