'use client';
import { useState, useEffect } from 'react';
import { Users, School, GraduationCap, BookOpen, TrendingUp, Clock, UserCheck, Award, DollarSign, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useBranch } from '@/hooks/use-branch';
import { formatCurrency, formatDate, getStatusColor, getStatusLabel } from '@/lib/helpers';
import { FadeIn, SlideIn } from '@/components/ui/animate';
import dynamic from 'next/dynamic';

const EnrollmentChart = dynamic(() => import('./charts/enrollment-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải biểu đồ...</div> });
const ClassUtilChart = dynamic(() => import('./charts/class-util-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải biểu đồ...</div> });
const BranchChart = dynamic(() => import('./charts/branch-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải biểu đồ...</div> });
const RevenueChart = dynamic(() => import('./charts/revenue-chart'), { ssr: false, loading: () => <div className="h-64 flex items-center justify-center text-sm text-muted-foreground">Đang tải biểu đồ...</div> });

interface Stats {
  totalStudents: number;
  activeStudents: number;
  totalTeachers: number;
  totalClasses: number;
  activeClasses: number;
  totalEnrollments: number;
  totalCourses: number;
  recentEnrollments: any[];
  classUtilization: any[];
  enrollmentTrend: any[];
  branchStats: any[];
}

interface FinanceStats {
  totalRevenue: number;
  totalCollected: number;
  totalOutstanding: number;
  monthlyRevenue: any[];
}

export function DashboardContent() {
  const { branchId } = useBranch();
  const [stats, setStats] = useState<Stats | null>(null);
  const [finStats, setFinStats] = useState<FinanceStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const q = branchId ? `?branchId=${branchId}` : '';
    Promise.all([
      fetch(`/api/dashboard/stats${q}`).then((r: any) => r?.json?.()),
      fetch(`/api/finance/stats${q}`).then((r: any) => r?.json?.()).catch(() => null),
    ])
      .then(([d, f]: any) => { setStats(d ?? null); setFinStats(f ?? null); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [branchId]);

  if (loading) return <div className="flex items-center justify-center h-64 text-muted-foreground">Đang tải dữ liệu...</div>;

  const kpis = [
    { label: 'Tổng học viên', value: stats?.totalStudents ?? 0, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Lớp đang học', value: stats?.activeClasses ?? 0, icon: School, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Giáo viên', value: stats?.totalTeachers ?? 0, icon: GraduationCap, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Khóa học', value: stats?.totalCourses ?? 0, icon: BookOpen, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Tổng doanh thu', value: formatCurrency(finStats?.totalRevenue ?? 0), icon: DollarSign, color: 'text-violet-600', bg: 'bg-violet-50', isCurrency: true },
    { label: 'Công nợ', value: formatCurrency(finStats?.totalOutstanding ?? 0), icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50', isCurrency: true },
  ];

  return (
    <div className="space-y-6">
      <FadeIn>
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Tổng quan</h1>
          <p className="text-muted-foreground text-sm">Thống kê hoạt động học vụ và quản lý</p>
        </div>
      </FadeIn>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {kpis?.map?.((kpi: any, i: number) => (
          <SlideIn key={kpi.label} from="bottom" delay={i * 0.08}>
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">{kpi.label}</p>
                    <p className={`${kpi.isCurrency ? 'text-lg' : 'text-2xl'} font-bold mt-1 font-mono`}>{kpi.value}</p>
                  </div>
                  <div className={`w-10 h-10 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                    <kpi.icon className={`w-5 h-5 ${kpi.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </SlideIn>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <FadeIn delay={0.2}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" /> Xu hướng ghi danh
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <EnrollmentChart data={stats?.enrollmentTrend ?? []} />
              </div>
            </CardContent>
          </Card>
        </FadeIn>

        <FadeIn delay={0.3}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <School className="w-4 h-4 text-primary" /> Sử dụng lớp học
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ClassUtilChart data={stats?.classUtilization ?? []} />
              </div>
            </CardContent>
          </Card>
        </FadeIn>
      </div>

      {/* Revenue Chart */}
      <FadeIn delay={0.35}>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-primary" /> Doanh thu theo tháng
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <RevenueChart data={finStats?.monthlyRevenue ?? []} />
            </div>
          </CardContent>
        </Card>
      </FadeIn>

      {/* Branch Overview + Recent */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <FadeIn delay={0.4}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Award className="w-4 h-4 text-primary" /> Tổng quan chi nhánh
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <BranchChart data={stats?.branchStats ?? []} />
              </div>
            </CardContent>
          </Card>
        </FadeIn>

        <FadeIn delay={0.5}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" /> Ghi danh gần đây
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {(stats?.recentEnrollments ?? [])?.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">Chưa có dữ liệu</p>
                ) : (
                  (stats?.recentEnrollments ?? [])?.map?.((e: any) => (
                    <div key={e?.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                      <div>
                        <p className="text-sm font-medium">{e?.studentName ?? ''}</p>
                        <p className="text-xs text-muted-foreground">{e?.className ?? ''}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="secondary" className={`text-[10px] ${getStatusColor(e?.status ?? '')}`}>
                          {getStatusLabel(e?.status ?? '')}
                        </Badge>
                        <p className="text-[10px] text-muted-foreground mt-1">{formatDate(e?.enrolledAt)}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </FadeIn>
      </div>
    </div>
  );
}
