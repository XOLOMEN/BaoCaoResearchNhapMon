# AEA Integrated Ecosystem Architecture
# Kiến trúc Hệ sinh thái tích hợp AEA (All-in-one Platform)

> **Version:** 2.0  
> **Author:** AEA Architecture Team  
> **Status:** Draft – Pending Review  
> **Date:** June 2026  
> **Scope:** Monolithic-Modular Architecture, Super App Design, AI-Learning Integration, Finance Parent Portal, LMS Module  
> **Related Documents:** `TECH_SPEC_FINANCE_MODULE.md`, `aea_system_design.md`, `aea_database_ddl.sql`

---

## Mục lục

1. [Tổng quan kiến trúc Hệ sinh thái tích hợp](#1-tổng-quan-kiến-trúc)
2. [Phần 1: Hợp nhất kiến trúc Monolithic-Modular](#2-hợp-nhất-kiến-trúc)
3. [Phần 2: Thiết kế Super App – User Flow 3 vai trò](#3-super-app-design)
4. [Phần 3: AI-Learning Integration – Công nghệ & Kiến trúc](#4-ai-learning-integration)
5. [Phần 4: Finance Portal cho Phụ huynh](#5-finance-parent-portal)
6. [Phần 5: Chiến lược mở rộng bền vững](#6-scaling-strategy)
7. [Phần 6: Roadmap ưu tiên phát triển](#7-roadmap)

---

## 1. Tổng quan kiến trúc Hệ sinh thái tích hợp

### 1.1 Tầm nhìn

AEA chuyển đổi từ mô hình **2 ứng dụng riêng biệt** (Management Dashboard + Student Portal) sang mô hình **1 nền tảng duy nhất** (All-in-one Platform) với kiến trúc Monolithic-Modular.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        AEA ALL-IN-ONE PLATFORM                             │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                      SHARED DATA LAYER                              │   │
│  │  PostgreSQL + Prisma ORM                                            │   │
│  │  ┌──────────┬──────────┬──────────┬──────────┬──────────┬──────────┐ │   │
│  │  │   core   │ academic │ finance  │    hr    │   crm    │   lms    │ │   │
│  │  │          │+ai_learn │          │          │          │          │ │   │
│  │  └──────────┴──────────┴──────────┴──────────┴──────────┴──────────┘ │   │
│  │  ┌──────────┬──────────────────────────────────────────┐            │   │
│  │  │  system  │ audit_logs, events, notifications, files │            │   │
│  │  └──────────┴──────────────────────────────────────────┘            │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌────────────────────┐  ┌────────────────────┐  ┌──────────────────────┐   │
│  │  WEB APP (Next.js)  │  │ MOBILE APP (Future)│  │  AI SERVICE LAYER   │   │
│  │  Admin/Staff/Teacher│  │ Student/Parent     │  │  Whisper, GPT-4o    │   │
│  │  Full ERP Dashboard │  │ Learning + Payment │  │  Pronunciation AI   │   │
│  └────────────────────┘  └────────────────────┘  └──────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Nguyên tắc thiết kế

| # | Nguyên tắc | Mô tả |
|---|-----------|-------|
| P1 | **Single Source of Truth** | Tất cả dữ liệu nằm trên 1 database duy nhất |
| P2 | **Role-Based Views** | Cùng 1 data, hiển thị khác nhau theo vai trò (Admin vs Student vs Parent) |
| P3 | **Module Isolation** | Mỗi module hoạt động độc lập, giao tiếp qua API/Event |
| P4 | **Progressive Enhancement** | Core features load trước, AI features lazy-load sau |
| P5 | **AI-Ready by Design** | Mọi bảng đều có `metadata JSONB` cho AI enrichment |
| P6 | **Branch-Scoped** | RLS đảm bảo data isolation theo chi nhánh |

---

## 2. Phần 1: Hợp nhất kiến trúc Monolithic-Modular

### 2.1 Schema Namespaces – Tổ chức lại

Mở rộng namespace `academic` để bao gồm AI-Learning, nhưng tách biệt logic bằng **prefix naming convention**:

```
academic (namespace mở rộng)
├── Traditional ERP (giữ nguyên)
│   ├── students
│   ├── teachers
│   ├── courses
│   ├── classes
│   ├── class_sessions
│   ├── enrollments
│   ├── attendance
│   ├── grade_records
│   ├── parents
│   └── student_parents
│
├── AI-Learning Bridge (MỚI)
│   ├── ai_learning_modules      → Bài học AI (quiz, speaking, writing)
│   ├── ai_submissions           → Bài nộp của học viên
│   ├── ai_submission_results    → Kết quả chấm từ AI
│   ├── ai_learning_paths        → Lộ trình học cá nhân hóa
│   └── ai_gamification_scores   → Điểm game, streak, badges
│
└── Content Management (MỚI)
    ├── learning_materials        → Tài liệu học tập
    └── material_assignments      → Gán tài liệu vào lớp/khóa học
```

```
lms (namespace riêng — tách biệt khỏi academic)
├── LMS Core
│   ├── lms_courses               → Khóa học trực tuyến (title, description, thumbnail)
│   ├── lms_lessons               → Bài học theo thứ tự (orderIndex)
│   └── lms_contents              → Nội dung đa phương tiện (VIDEO, DOCUMENT, AUDIO, INTERACTIVE)
│
├── Student Progress
│   ├── lms_enrollments           → Ghi danh: User ↔ LmsCourse (ACTIVE/COMPLETED/DROPPED)
│   └── lms_progress              → Theo dõi tiến độ từng lesson (watchedSeconds, completedAt)
│
├── Assessment
│   ├── lms_quizzes               → Bài kiểm tra gắn với lesson
│   └── lms_quiz_attempts         → Lịch sử làm bài (score, answers JSON)
│
└── Certification
    └── lms_certificates          → Chứng chỉ tự động khi hoàn thành khóa học
```

### 2.2 Tại sao giữ trong `academic` thay vì tạo namespace riêng?

| Tiêu chí | Namespace riêng `ai_learning` | Mở rộng `academic` |
|----------|------------------------------|--------------------|
| FK đến `students`, `classes` | Cross-schema joins (chậm) | Same-schema joins (nhanh) |
| Prisma relations | Phức tạp, cần type cast | Tự nhiên, type-safe |
| Code organization | Sạch sẽ nhưng over-engineering | Đơn giản, pragmatic |
| Grade integration | Cần sync/duplicate | Trực tiếp reference |
| **Kết luận** | ❌ Không phù hợp giai đoạn này | ✅ **Chọn phương án này** |

### 2.3 Prisma Models mới cho AI-Learning

```prisma
// ============================================================================
// ACADEMIC (AI-LEARNING EXTENSION): AI Modules, Submissions, Results
// ============================================================================

model AiLearningModule {
  id           String   @id @default(uuid())
  courseId     String?  @map("course_id")
  classId      String?  @map("class_id")
  title        String
  type         String   // 'quiz' | 'speaking' | 'writing' | 'listening' | 'vocabulary' | 'grammar'
  difficulty   String   @default("intermediate") // 'beginner' | 'intermediate' | 'advanced'
  content      Json     // Nội dung bài tập (câu hỏi, audio prompts, etc.)
  config       Json     @default("{}")  // AI model config, scoring rubric
  maxScore     Float    @default(100) @map("max_score")
  timeLimitSec Int?     @map("time_limit_sec")
  isPublished  Boolean  @default(false) @map("is_published")
  sortOrder    Int      @default(0)  @map("sort_order")
  metadata     Json     @default("{}")  // AI-ready: tags, analytics hints
  createdBy    String?  @map("created_by")
  createdAt    DateTime @default(now()) @map("created_at")
  updatedAt    DateTime @updatedAt @map("updated_at")

  course      Course?        @relation(fields: [courseId], references: [id])
  class       Class?         @relation(fields: [classId], references: [id])
  submissions AiSubmission[]

  @@index([courseId])
  @@index([classId])
  @@index([type])
  @@map("ai_learning_modules")
}

model AiSubmission {
  id              String    @id @default(uuid())
  moduleId        String    @map("module_id")
  studentId       String    @map("student_id")
  enrollmentId    String?   @map("enrollment_id")
  attemptNumber   Int       @default(1)  @map("attempt_number")
  status          String    @default("in_progress")  // 'in_progress' | 'submitted' | 'grading' | 'graded' | 'error'
  submittedData   Json      @default("{}")  @map("submitted_data")  // Câu trả lời, audio URL, text
  startedAt       DateTime  @default(now()) @map("started_at")
  submittedAt     DateTime? @map("submitted_at")
  durationSec     Int?      @map("duration_sec")
  deviceInfo      Json      @default("{}")  @map("device_info")  // mobile/web, OS, browser
  metadata        Json      @default("{}")  // AI-ready extensible
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @updatedAt @map("updated_at")

  module     AiLearningModule   @relation(fields: [moduleId], references: [id])
  student    Student            @relation(fields: [studentId], references: [id])
  enrollment Enrollment?        @relation(fields: [enrollmentId], references: [id])
  result     AiSubmissionResult?

  @@index([moduleId])
  @@index([studentId])
  @@index([status])
  @@unique([moduleId, studentId, attemptNumber])
  @@map("ai_submissions")
}

model AiSubmissionResult {
  id               String   @id @default(uuid())
  submissionId     String   @unique @map("submission_id")
  totalScore       Float    @map("total_score")
  maxScore         Float    @map("max_score")
  percentageScore  Float    @map("percentage_score")
  breakdown        Json     @default("{}")  // Chi tiết điểm từng phần
  aiModelUsed      String?  @map("ai_model_used")  // 'gpt-4o' | 'whisper' | 'pronunciation-ai'
  aiRawResponse    Json     @default("{}")  @map("ai_raw_response")  // Raw AI output for audit
  feedback         Json     @default("{}")  // Nhận xét chi tiết từ AI
  strengths        Json     @default("[]")  // Điểm mạnh
  improvements     Json     @default("[]")  // Cần cải thiện
  gradedAt         DateTime @default(now()) @map("graded_at")
  processingTimeMs Int?     @map("processing_time_ms")
  metadata         Json     @default("{}")  // AI-ready
  createdAt        DateTime @default(now()) @map("created_at")

  submission AiSubmission @relation(fields: [submissionId], references: [id], onDelete: Cascade)

  @@map("ai_submission_results")
}

model AiLearningPath {
  id              String   @id @default(uuid())
  studentId       String   @map("student_id")
  courseId        String?  @map("course_id")
  pathData        Json     @default("{}")  @map("path_data")  // Recommended modules, order, weights
  currentLevel    String   @default("beginner") @map("current_level")
  completionPct   Float    @default(0) @map("completion_pct")
  lastActivityAt  DateTime? @map("last_activity_at")
  generatedBy     String   @default("system") @map("generated_by")  // 'system' | 'ai' | 'teacher'
  metadata        Json     @default("{}")  
  createdAt       DateTime @default(now()) @map("created_at")
  updatedAt       DateTime @updatedAt @map("updated_at")

  student Student @relation(fields: [studentId], references: [id])
  course  Course? @relation(fields: [courseId], references: [id])

  @@unique([studentId, courseId])
  @@map("ai_learning_paths")
}

model AiGamificationScore {
  id              String    @id @default(uuid())
  studentId       String    @map("student_id")
  totalXp         Int       @default(0) @map("total_xp")
  currentLevel    Int       @default(1) @map("current_level")
  currentStreak   Int       @default(0) @map("current_streak")
  longestStreak   Int       @default(0) @map("longest_streak")
  lastActivityAt  DateTime? @map("last_activity_at")
  badges          Json      @default("[]")  // [{name, earnedAt, icon}]
  achievements    Json      @default("[]")  // [{type, value, earnedAt}]
  weeklyGoal      Int       @default(5) @map("weekly_goal")
  weeklyProgress  Int       @default(0) @map("weekly_progress")
  metadata        Json      @default("{}")  
  createdAt       DateTime  @default(now()) @map("created_at")
  updatedAt       DateTime  @updatedAt @map("updated_at")

  student Student @relation(fields: [studentId], references: [id])

  @@unique([studentId])
  @@map("ai_gamification_scores")
}
```

### 2.4 Cầu nối Academic ↔ AI-Learning

AI-Learning data **chảy ngược** vào hệ thống ERP qua 2 cơ chế:

```
┌─────────────────────────────────────────────────────────────────┐
│                   DATA FLOW: AI → ERP                          │
│                                                                 │
│  ┌──────────────┐     ┌──────────────┐     ┌────────────────┐  │
│  │ AI Submission │────►│ AI Result    │────►│ GradeRecord    │  │
│  │ (student      │     │ (score,      │     │ (auto-sync     │  │
│  │  does quiz)   │     │  feedback)   │     │  assessment)   │  │
│  └──────────────┘     └──────────────┘     └────────────────┘  │
│                                                                 │
│  Mechanism 1: DIRECT GRADE SYNC                                 │
│  - When AI grades a submission, auto-create GradeRecord         │
│  - assessmentType = 'ai_quiz' | 'ai_speaking' | 'ai_writing'   │
│  - Teacher sees AI grades alongside manual grades               │
│                                                                 │
│  Mechanism 2: EVENT SOURCING                                    │
│  - Every AI action → EventStore entry                           │
│  - Event types: 'ai.submission.created',                        │
│    'ai.submission.graded', 'ai.streak.updated'                  │
│  - Dashboard analytics can aggregate from EventStore            │
│                                                                 │
│  Mechanism 3: NOTIFICATION BRIDGE                               │
│  - AI grading complete → Notification to student + parent       │
│  - Low score alert → Notification to teacher                    │
│  - Streak milestone → Gamification notification                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.5 Quản trị không bị phức tạp hóa

Để Admin/Staff **không bị overwhelm** bởi AI data:

| Chiến lược | Cách triển khai |
|-----------|----------------|
| **Aggregated Views** | Dashboard chỉ hiển thị KPI tổng hợp (avg AI score, completion rate), không hiển thị từng submission |
| **Drill-down on demand** | Click vào KPI → mới xem chi tiết AI submissions |
| **Separate nav section** | Sidebar: "Học vụ" (truyền thống) vs "AI Learning" (riêng) |
| **Read-only for Admin** | Admin xem báo cáo AI, không cần can thiệp vào AI grading |
| **Teacher controls** | Teacher tạo/quản lý AI modules cho lớp mình dạy |

---

## 3. Phần 2: Thiết kế Super App – User Flow 3 vai trò

### 3.1 Role-Based Navigation Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        SUPER APP NAVIGATION                            │
│                                                                         │
│  ┌─────────────────────────┐                                           │
│  │ LOGIN / AUTHENTICATION  │ ← Single entry point, role detection      │
│  └────────────┬────────────┘                                           │
│               │                                                         │
│      ┌────────┼────────┐                                               │
│      ▼        ▼        ▼                                               │
│  ┌────────┐ ┌───────┐ ┌──────────┐                                     │
│  │ ADMIN  │ │STUDENT│ │  PARENT  │                                     │
│  │ /STAFF │ │       │ │          │                                     │
│  └───┬────┘ └───┬───┘ └────┬─────┘                                     │
│      │          │          │                                            │
│      ▼          ▼          ▼                                            │
│  ┌────────────────────────────────────────────────────────────────┐     │
│  │                    FEATURE MODULES                             │     │
│  │                                                                │     │
│  │  ADMIN/STAFF sees:          STUDENT sees:    PARENT sees:      │     │
│  │  ✅ Dashboard (KPI)          ✅ My Schedule    ✅ Child Progress  │     │
│  │  ✅ Students CRUD            ✅ AI Practice    ✅ AI Report Card  │     │
│  │  ✅ Teachers CRUD            ✅ My Grades      ✅ Invoices       │     │
│  │  ✅ Courses/Classes          ✅ Gamification   ✅ Payment        │     │
│  │  ✅ Enrollments              ✅ Materials      ✅ Notifications  │     │
│  │  ✅ Grades                   ✅ Notifications  ✅ Contact Teacher│     │
│  │  ✅ Finance (invoices)       ✅ Profile        ✅ Schedule       │     │
│  │  ✅ HR (employees)           ❌ NO admin data  ❌ NO admin data  │     │
│  │  ✅ CRM (leads)                                                │     │
│  │  ✅ AI Analytics (aggregate)                                   │     │
│  │  ✅ Reports                                                    │     │
│  └────────────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.2 User Flow – Admin/Staff (Giữ nguyên + Mở rộng)

```
Admin Login → Dashboard Overview
├── Academic Management (như hiện tại)
│   ├── Students → CRUD + AI Progress Summary
│   ├── Teachers → CRUD + AI Module Assignment Stats
│   ├── Courses → CRUD + AI Module Count per Course
│   ├── Classes → CRUD + AI Completion Rates
│   ├── Enrollments → CRUD (auto-invoice unchanged)
│   └── Grades → Manual + AI Grades (merged view)
│
├── AI Learning Analytics (MỚI - read-only dashboard)
│   ├── Overview: Total submissions, avg scores, active learners
│   ├── Module Performance: Which modules are most/least effective
│   ├── Student Engagement: Daily active, streak stats
│   └── AI Model Usage: Cost tracking, accuracy metrics
│
├── Finance (Phase 2)
│   ├── Invoices → List + filter by status/branch
│   ├── Payments → Record + reconcile
│   └── Reports → Revenue by branch/month
│
├── HR (Phase 3)
└── CRM (Phase 3)
```

### 3.3 User Flow – Học sinh (Student)

```
┌────────────────────────────────────────────────────────────────────────┐
│                    STUDENT USER JOURNEY                                │
│                                                                        │
│  ① MỞ APP                                                             │
│  └──► Home Screen: Today's schedule + Streak counter + Quick actions   │
│                                                                        │
│  ② CHỌN HOẠT ĐỘNG                                                     │
│  ├──► [Luyện tập AI] → Chọn loại bài:                                 │
│  │    ├── 🎯 Quiz (Ngữ pháp, từ vựng)                                 │
│  │    ├── 🎤 Luyện nói (Pronunciation practice)                       │
│  │    ├── ✍️  Luyện viết (Writing practice)                            │
│  │    └── 👂 Luyện nghe (Listening comprehension)                     │
│  │                                                                     │
│  ├──► [Lịch học] → Xem lịch lớp, phòng, giáo viên                    │
│  ├──► [Kết quả] → Xem điểm, feedback từ AI + giáo viên               │
│  ├──► [Thành tích] → XP, Level, Badges, Leaderboard                  │
│  └──► [Tài liệu] → Download bài giảng, slide                         │
│                                                                        │
│  ③ LÀM BÀI TẬP AI                                                     │
│  └──► Chọn module → Bắt đầu → Làm bài → Submit                       │
│       └──► AI chấm điểm (async, 2-15 giây)                            │
│            └──► Hiển thị kết quả + feedback                            │
│                 ├── Điểm tổng + breakdown                              │
│                 ├── Điểm mạnh (strengths)                              │
│                 ├── Cần cải thiện (improvements)                       │
│                 └── Gợi ý bài tập tiếp theo                           │
│                                                                        │
│  ④ GAMIFICATION                                                        │
│  └──► Hoàn thành bài → +XP → Check level up → Check badge unlock      │
│       └──► Streak update → Weekly goal progress                        │
│            └──► Leaderboard position update                            │
└────────────────────────────────────────────────────────────────────────┘
```

### 3.4 User Journey chi tiết: Học sinh luyện tập AI

```
┌─────────────────────────────────────────────────────────────────────────┐
│  SEQUENCE DIAGRAM: Student AI Practice → Parent Notification           │
│                                                                         │
│  Student App         API Server         AI Service       Parent App    │
│  ──────────          ──────────         ──────────       ──────────    │
│      │                   │                  │                │         │
│      │ 1. GET /api/academic                 │                │         │
│      │    /ai-modules?classId=X             │                │         │
│      │──────────────────►│                  │                │         │
│      │◄──────────────────│                  │                │         │
│      │   [list of modules]                  │                │         │
│      │                   │                  │                │         │
│      │ 2. Select module, start attempt      │                │         │
│      │ POST /api/academic/ai-submission     │                │         │
│      │  {moduleId, action: 'start'}         │                │         │
│      │──────────────────►│                  │                │         │
│      │◄──────────────────│                  │                │         │
│      │   {submissionId, status: 'in_progress'}              │         │
│      │                   │                  │                │         │
│      │ 3. Student completes, submits answers                │         │
│      │ PUT /api/academic/ai-submission      │                │         │
│      │  {submissionId, submittedData, action: 'submit'}     │         │
│      │──────────────────►│                  │                │         │
│      │                   │ 4. Send to AI    │                │         │
│      │                   │──────────────────►│               │         │
│      │                   │                  │                │         │
│      │                   │ 5. AI returns result              │         │
│      │                   │◄──────────────────│               │         │
│      │                   │                  │                │         │
│      │                   │ 6. Save AiSubmissionResult       │         │
│      │                   │    Update GradeRecord            │         │
│      │                   │    Update Gamification           │         │
│      │                   │    Create EventStore entry       │         │
│      │                   │                  │                │         │
│      │                   │ 7. Create Notification           │         │
│      │                   │    for Student + Parent          │         │
│      │                   │──────────────────────────────────►│         │
│      │                   │                  │                │         │
│      │◄──────────────────│                  │   Push notif   │         │
│      │ 8. {result, score, feedback}         │   "Con bạn     │         │
│      │                   │                  │    vừa hoàn    │         │
│      │                   │                  │    thành bài   │         │
│      │                   │                  │    Speaking:   │         │
│      │                   │                  │    85/100"     │         │
│      │                   │                  │                │         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.5 User Flow – Phụ huynh (Parent)

```
Parent Login → Parent Dashboard
├── Con tôi (My Children)
│   ├── Chọn con → Student Profile Summary
│   ├── Tiến độ học tập (Learning Progress)
│   │   ├── Điểm truyền thống (GradeRecords from teacher)
│   │   ├── Điểm AI (AiSubmissionResults aggregated)
│   │   ├── Xu hướng tiến bộ (Trend chart: weekly/monthly)
│   │   └── So sánh với trung bình lớp (optional)
│   ├── Hoạt động gần đây (Recent AI submissions)
│   └── Lịch học tuần (Weekly schedule)
│
├── Tài chính (Finance)
│   ├── Hóa đơn chờ thanh toán (Pending invoices)
│   ├── Lịch sử thanh toán (Payment history)
│   ├── Gói trả góp (Payment plans)
│   └── Thanh toán online (Pay now → Payment Gateway)
│
├── Thông báo (Notifications)
│   ├── Kết quả AI mới (AI grading results)
│   ├── Nhắc đóng học phí (Payment reminders)
│   ├── Thông báo từ giáo viên (Teacher announcements)
│   └── Thành tích con (Gamification milestones)
│
└── Liên hệ (Contact)
    ├── Nhắn tin giáo viên (Direct message)
    └── Gửi yêu cầu hỗ trợ (Support request)
```

---

## 4. Phần 3: AI-Learning Integration – Công nghệ & Kiến trúc

### 4.1 Chọn Công nghệ AI

| Tính năng | AI Model đề xuất | Lý do | Độ chính xác | Chi phí ước tính |
|-----------|------------------|-------|-------------|------------------|
| **Quiz/Grammar Grading** | GPT-4o (via RouteLLM) | Rule-based + AI fallback, fast | ~98% | Thấp (text only) |
| **Speaking/Pronunciation** | Whisper (STT) + GPT-4o (analysis) | Whisper chuyển audio→text, GPT-4o đánh giá ngữ pháp/fluency | ~85-90% | Trung bình (audio) |
| **Writing Assessment** | GPT-4o (via RouteLLM) | Đánh giá structure, grammar, vocabulary, coherence | ~90% | Thấp-Trung bình |
| **Listening Comprehension** | GPT-4o (generate questions) + Rule-based scoring | AI tạo câu hỏi, scoring theo đáp án | ~95% | Thấp |
| **Vocabulary/Flashcard** | Spaced Repetition Algorithm (SM-2) + GPT-4o | SM-2 cho scheduling, AI cho ví dụ context | ~95% | Rất thấp |
| **Pronunciation Scoring** | Azure Speech SDK hoặc Whisper + custom model | Chuyên biệt cho phát âm, phoneme-level feedback | ~80-85% | Trung bình-Cao |

### 4.2 Kiến trúc AI Service Layer

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      AI SERVICE ARCHITECTURE                           │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │                    API ROUTES (Next.js)                           │   │
│  │  POST /api/academic/ai-submission  ← Entry point                │   │
│  │  GET  /api/academic/ai-modules     ← List available modules     │   │
│  │  GET  /api/academic/ai-results     ← Get results for student    │   │
│  │  GET  /api/academic/ai-analytics   ← Aggregate stats for admin  │   │
│  └───────────────────────────┬──────────────────────────────────────┘   │
│                              │                                          │
│                              ▼                                          │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │                   AI GRADING SERVICE                              │   │
│  │  (Internal module, not external microservice)                    │   │
│  │                                                                  │   │
│  │  lib/ai/grading-service.ts                                       │   │
│  │  ├── gradeQuiz(submission)      → GPT-4o (rule + AI)            │   │
│  │  ├── gradeSpeaking(submission)  → Whisper → GPT-4o              │   │
│  │  ├── gradeWriting(submission)   → GPT-4o (rubric-based)         │   │
│  │  ├── gradeListening(submission) → Rule-based                    │   │
│  │  └── gradeVocabulary(submission)→ Rule-based + SM-2             │   │
│  │                                                                  │   │
│  │  Each grading function returns:                                  │   │
│  │  {                                                               │   │
│  │    totalScore: number,                                           │   │
│  │    maxScore: number,                                             │   │
│  │    breakdown: { section: score }[],                              │   │
│  │    feedback: { general: string, perQuestion?: string[] },        │   │
│  │    strengths: string[],                                          │   │
│  │    improvements: string[],                                       │   │
│  │    aiModelUsed: string,                                          │   │
│  │    processingTimeMs: number                                      │   │
│  │  }                                                               │   │
│  └──────────────────────────────────────────────────────────────────┘   │
│                              │                                          │
│                              ▼                                          │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │                   EXTERNAL AI PROVIDERS                          │   │
│  │  RouteLLM API (GPT-4o, Claude)  ← Via ABACUSAI_API_KEY         │   │
│  │  - Text analysis, grading, feedback generation                  │   │
│  │  - Audio transcription (Whisper via RouteLLM)                   │   │
│  │  - Image analysis (for handwriting recognition - future)        │   │
│  └──────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
```

### 4.3 Prompt Engineering cho Chấm điểm AI

#### Quiz/Grammar Grading Prompt
```
You are an expert English language teacher grading a quiz.
Student level: {difficulty}
Quiz content: {module.content}
Student answers: {submittedData.answers}

Score each answer and provide:
1. Total score (0-{maxScore})
2. Per-question breakdown with explanation
3. 2-3 strengths the student showed
4. 2-3 specific areas for improvement
5. Suggested next topic to study

Respond in JSON format with Vietnamese feedback for the student.
```

#### Speaking Assessment Prompt
```
You are an English pronunciation and speaking coach.
The student was asked to: {module.content.prompt}
Student's transcribed speech: {transcribedText}
Expected pronunciation guide: {module.content.expected}

Evaluate:
1. Pronunciation accuracy (0-30)
2. Fluency and rhythm (0-25)
3. Grammar correctness (0-25)
4. Vocabulary usage (0-20)

Provide specific phoneme-level feedback where pronunciation was incorrect.
Give encouraging feedback in Vietnamese.
```

---

## 5. Phần 4: Finance Portal cho Phụ huynh

### 5.1 Kiến trúc luồng thanh toán

```
┌────────────────────────────────────────────────────────────────────────────┐
│                  PARENT PAYMENT FLOW ARCHITECTURE                         │
│                                                                            │
│  ┌─────────────┐    ┌──────────────┐    ┌───────────────┐                  │
│  │  Enrollment  │───►│ Auto-Invoice │───►│  Notification │                  │
│  │  Created     │    │  (DRAFT)     │    │  to Parent    │                  │
│  └─────────────┘    └──────┬───────┘    │  "Hóa đơn mới"│                  │
│                            │            └───────┬───────┘                  │
│                            │                    │                          │
│                            ▼                    ▼                          │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    PARENT APP - FINANCE TAB                          │  │
│  │                                                                      │  │
│  │  ┌──────────────────┐                                                │  │
│  │  │ Hóa đơn chờ TT   │ ← GET /api/parent/invoices?status=pending     │  │
│  │  │ INV-HCM-Q1-2506  │                                                │  │
│  │  │ 5,000,000 VND    │                                                │  │
│  │  │ Hạn: 30/06/2026  │                                                │  │
│  │  │ [Thanh toán ngay] │                                                │  │
│  │  └────────┬─────────┘                                                │  │
│  │           │                                                          │  │
│  │           ▼                                                          │  │
│  │  ┌──────────────────┐    ┌────────────────┐                          │  │
│  │  │ Chọn phương thức  │───►│ Payment Gateway│                          │  │
│  │  │ ☐ Chuyển khoản    │    │ (Stripe/VNPay) │                          │  │
│  │  │ ☐ Thẻ tín dụng   │    │                │                          │  │
│  │  │ ☐ Ví điện tử     │    │ PCI DSS Level 1│                          │  │
│  │  └──────────────────┘    └───────┬────────┘                          │  │
│  │                                  │                                    │  │
│  └──────────────────────────────────│────────────────────────────────────┘  │
│                                     │                                      │
│                                     ▼                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    PAYMENT WEBHOOK HANDLER                           │  │
│  │  POST /api/webhooks/payment                                         │  │
│  │                                                                      │  │
│  │  1. Verify webhook signature (HMAC-SHA256)                          │  │
│  │  2. BEGIN TRANSACTION                                                │  │
│  │     a. Create Payment record (status: 'completed')                  │  │
│  │     b. Update Invoice (paidAmount += payment.amount)                 │  │
│  │     c. If fully paid → Invoice status = 'paid'                      │  │
│  │     d. If payment_plan → Update installment status                  │  │
│  │     e. Create EventStore entry (type: 'payment.completed')          │  │
│  │  3. COMMIT                                                           │  │
│  │                                                                      │  │
│  │  4. POST-COMMIT (async, non-blocking):                              │  │
│  │     a. Send Notification to Parent ("Thanh toán thành công")        │  │
│  │     b. Send Notification to Admin ("Nhận thanh toán mới")           │  │
│  │     c. Invalidate revenue cache for branch                          │  │
│  │     d. Send confirmation email                                      │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│                                     │                                      │
│                                     ▼                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    ADMIN DASHBOARD (real-time sync)                  │  │
│  │                                                                      │
│  │  Revenue chart auto-updates because:                                │  │
│  │  - Payment webhook creates Payment record                          │  │
│  │  - GET /api/dashboard/finance-stats queries Payment table directly  │  │
│  │  - No separate sync needed — single source of truth                 │  │
│  │  - Optional: WebSocket for instant dashboard refresh                │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Parent Finance APIs

```typescript
// API cho Parent Portal

// 1. Xem hóa đơn của con
GET /api/parent/invoices
  Query: ?studentId=xxx&status=pending|paid|overdue
  Response: {
    invoices: [
      {
        id, invoiceNumber, totalAmount, paidAmount,
        remainingAmount, dueDate, status,
        items: [{ description, amount }],
        paymentPlan: [{ installmentNo, amount, dueDate, status }]
      }
    ]
  }
  Auth: Parent role only, filtered by parent→student relationship

// 2. Xem lịch sử thanh toán
GET /api/parent/payments
  Query: ?studentId=xxx&from=2026-01-01&to=2026-12-31
  Response: {
    payments: [
      {
        id, amount, paymentMethod, paymentDate,
        receiptNumber, invoiceNumber, status
      }
    ],
    totalPaid: number
  }

// 3. Tạo phiên thanh toán
POST /api/parent/payments/create-session
  Body: { invoiceId, amount, paymentMethod, paymentPlanId? }
  Response: {
    sessionId: string,
    redirectUrl: string  // Stripe Checkout / VNPay redirect
  }
  Security: Verify parent→student→invoice ownership chain

// 4. Webhook từ Payment Gateway
POST /api/webhooks/payment
  Headers: { 'stripe-signature': signature }
  Body: Stripe/VNPay webhook payload
  Security: Verify HMAC signature, idempotency key
```

### 5.3 Parent Payment User Journey (Chi tiết)

```
┌────────────────────────────────────────────────────────────────────┐
│          PARENT PAYMENT USER JOURNEY (End-to-End)                 │
│                                                                    │
│  BƯỚC 1: NHẬN THÔNG BÁO                                          │
│  ─────────────────────────                                         │
│  • Hệ thống tạo enrollment → auto-create Invoice (DRAFT)          │
│  • Staff review → change status to ISSUED                         │
│  • System creates Notification:                                    │
│    {                                                               │
│      type: 'invoice.issued',                                       │
│      title: 'Hóa đơn học phí mới',                                │
│      body: 'Khóa IELTS Intensive - 5,000,000 VND. Hạn: 30/06',   │
│      data: { invoiceId, amount, dueDate }                          │
│    }                                                               │
│  • Push notification → Parent's phone                              │
│                                                                    │
│  BƯỚC 2: XEM HÓA ĐƠN                                             │
│  ──────────────────                                                │
│  • Parent opens app → Thông báo tab → Click thông báo              │
│  • Navigate to Finance → Invoice detail                            │
│  • Screen shows:                                                   │
│    ┌──────────────────────────────────────┐                        │
│    │  📄 Hóa đơn #INV-HCM-Q1-2506-0001  │                        │
│    │                                      │                        │
│    │  Học viên: Nguyễn Văn A              │                        │
│    │  Khóa: IELTS Intensive (3 tháng)     │                        │
│    │                                      │                        │
│    │  Học phí:        5,000,000 VND       │                        │
│    │  Giảm giá:        -500,000 VND       │                        │
│    │  ──────────────────────────           │                        │
│    │  Tổng cộng:      4,500,000 VND       │                        │
│    │  Đã thanh toán:          0 VND       │                        │
│    │  Còn lại:        4,500,000 VND       │                        │
│    │                                      │                        │
│    │  Hạn thanh toán: 30/06/2026          │                        │
│    │                                      │                        │
│    │  [💳 Thanh toán ngay]                │                        │
│    │  [📅 Chọn trả góp]                  │                        │
│    └──────────────────────────────────────┘                        │
│                                                                    │
│  BƯỚC 3: CHỌN PHƯƠNG THỨC THANH TOÁN                             │
│  ────────────────────────────────────                              │
│  • Option A: Thanh toán toàn bộ                                   │
│    → Select payment method (card/bank/e-wallet)                    │
│    → Redirect to Payment Gateway                                  │
│  • Option B: Trả góp (Payment Plan)                               │
│    → Choose plan: 2 kỳ × 2,250,000 or 3 kỳ × 1,500,000          │
│    → Pay first installment now                                     │
│                                                                    │
│  BƯỚC 4: XỬ LÝ THANH TOÁN                                        │
│  ────────────────────────                                          │
│  • Payment Gateway processes payment                               │
│  • Webhook callback → /api/webhooks/payment                       │
│  • System executes (in transaction):                               │
│    1. ✅ Create Payment record                                    │
│    2. ✅ Update Invoice.paidAmount                                 │
│    3. ✅ Update Invoice.status → 'paid' (if fully paid)           │
│    4. ✅ Update PaymentPlan installment → 'paid'                  │
│    5. ✅ Create EventStore entry                                   │
│    6. ✅ Send Notification → Parent: "Thanh toán thành công"      │
│    7. ✅ Send Notification → Admin: "Nhận thanh toán mới"         │
│    8. ✅ Dashboard revenue auto-updated (same DB)                  │
│                                                                    │
│  BƯỚC 5: XÁC NHẬN & BÁO CÁO                                     │
│  ─────────────────────────                                         │
│  • Parent sees payment confirmation screen                         │
│  • Receipt available for download                                  │
│  • Payment history updated                                         │
│  • Admin dashboard: Revenue chart reflects new payment             │
│  • Branch report: Revenue by branch auto-aggregated                │
└────────────────────────────────────────────────────────────────────┘
```

### 5.4 Bảo mật giao dịch (Transaction Security)

```
┌────────────────────────────────────────────────────────────────────┐
│              SECURITY LAYERS FOR PAYMENT INTEGRATION               │
│                                                                    │
│  Layer 1: AUTHENTICATION & AUTHORIZATION (RBAC)                   │
│  ─────────────────────────────────────────────                     │
│  • Parent can ONLY see invoices linked to their children           │
│  • Ownership chain: Parent → StudentParent → Student → Invoice    │
│  • API validates: session.user.role === 'parent'                   │
│    AND student.parentLinks.some(p => p.parentId === session.userId)│
│  • Admin/Staff: Full invoice access (read + write)                 │
│  • Teacher: No finance access                                     │
│  • Student: Read-only own invoices                                 │
│                                                                    │
│  Layer 2: PAYMENT GATEWAY SECURITY                                 │
│  ────────────────────────────────                                  │
│  • PCI DSS Level 1 compliance (Stripe/VNPay handles card data)    │
│  • App NEVER stores card numbers, CVV, or raw payment credentials │
│  • Tokenization: Payment gateway returns tokens, not card data    │
│  • 3D Secure (3DS2) authentication for card payments              │
│  • Webhook signature verification (HMAC-SHA256)                   │
│                                                                    │
│  Layer 3: DATA ENCRYPTION                                          │
│  ─────────────────────                                             │
│  • TLS 1.3 for all API communication (in-transit)                  │
│  • Database encryption at rest (PostgreSQL)                        │
│  • Sensitive fields (transactionRef) encrypted in application      │
│  • JSONB metadata fields: NO payment credentials stored            │
│                                                                    │
│  Layer 4: TRANSACTION INTEGRITY                                    │
│  ─────────────────────────────                                     │
│  • Idempotency keys: Prevent duplicate payments                   │
│  • Database transactions: ACID compliance for payment recording   │
│  • Webhook retry handling: Same payment not processed twice       │
│  • Audit trail: Every payment action logged to AuditLog table     │
│                                                                    │
│  Layer 5: RATE LIMITING & FRAUD PREVENTION                         │
│  ──────────────────────────────────────                             │
│  • Rate limiting on payment creation API (5 req/min per user)      │
│  • Amount validation: Cannot pay more than invoice balance         │
│  • IP-based suspicious activity detection                          │
│  • Admin notification for payments > threshold amount              │
│                                                                    │
│  Layer 6: TWO-FACTOR AUTHENTICATION (2FA) - Phase 2               │
│  ─────────────────────────────────────────────                     │
│  • OTP via SMS/Email before high-value payments                    │
│  • Biometric authentication on mobile (fingerprint/face)          │
│  • Session timeout: 15 minutes for payment flows                  │
└────────────────────────────────────────────────────────────────────┘
```

### 5.5 API cho đồng bộ thời gian thực

```typescript
// =====================================================
// REAL-TIME SYNC: Payment → Dashboard Revenue
// =====================================================

// Option A: Polling (Simple, Phase 1)
// Dashboard polls /api/dashboard/finance-stats every 30 seconds
// Revenue data always fresh because queries Payment table directly

// Option B: Server-Sent Events (Recommended, Phase 2)
// GET /api/dashboard/revenue-stream
// Server pushes updates when new payment is recorded

// API: GET /api/dashboard/finance-stats
// (as specified in TECH_SPEC_FINANCE_MODULE.md)
// This endpoint queries:
//   - Invoice table for revenue by branch/month
//   - Payment table for actual cash received
//   - Aggregates in real-time, no separate sync needed

// POST /api/webhooks/payment (Webhook handler)
// After recording payment:
async function onPaymentCompleted(payment: Payment, invoice: Invoice) {
  // 1. Already updated in same transaction:
  //    - Payment record created
  //    - Invoice.paidAmount updated
  //    - Invoice.status updated
  
  // 2. Async post-commit actions:
  await Promise.all([
    // Notify parent
    createNotification({
      userId: parentUserId,
      type: 'payment.confirmed',
      title: 'Thanh toán thành công',
      body: `Đã thanh toán ${formatCurrency(payment.amount)} cho hóa đơn ${invoice.invoiceNumber}`,
      data: { paymentId: payment.id, invoiceId: invoice.id }
    }),
    
    // Notify admin
    createNotification({
      userId: adminUserId,
      type: 'payment.received',
      title: 'Nhận thanh toán mới',
      body: `${formatCurrency(payment.amount)} - ${invoice.invoiceNumber} - Chi nhánh ${branch.name}`,
      data: { paymentId: payment.id, branchId: invoice.branchId }
    }),
    
    // Event sourcing
    createEvent({
      aggregateType: 'payment',
      aggregateId: payment.id,
      eventType: 'payment.completed',
      payload: { amount: payment.amount, invoiceId: invoice.id, branchId: invoice.branchId }
    }),
    
    // Send email confirmation
    sendPaymentConfirmationEmail(payment, invoice)
  ]);
}
```

### 5.6 UX Design cho Parent Finance

Giao diện đơn giản, tập trung vào 3 hành động chính:

```
┌──────────────────────────────────────────────────────────────┐
│                    PARENT FINANCE TAB                        │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  📊 Tổng quan                                           │ │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐              │ │
│  │  │ Cần TT   │  │ Đã TT    │  │ Quá hạn  │              │ │
│  │  │4,500,000 │  │12,000,000│  │    0     │              │ │
│  │  │   VND    │  │   VND    │  │   VND    │              │ │
│  │  └──────────┘  └──────────┘  └──────────┘              │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  📄 Hóa đơn chờ thanh toán                (Tab 1)      │ │
│  │  ┌─────────────────────────────────────────────────┐    │ │
│  │  │ INV-HCM-Q1-2506-0001                           │    │ │
│  │  │ IELTS Intensive · Nguyễn Văn A                 │    │ │
│  │  │ 4,500,000 VND · Hạn 30/06/2026                │    │ │
│  │  │                          [Thanh toán ▶]        │    │ │
│  │  └─────────────────────────────────────────────────┘    │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  🕐 Lịch sử thanh toán                    (Tab 2)      │ │
│  │  ┌─────────────────────────────────────────────────┐    │ │
│  │  │ 15/05/2026 · 5,000,000 VND · Thẻ tín dụng     │    │ │
│  │  │ INV-HCM-Q1-2505-0003 · ✅ Thành công           │    │ │
│  │  └─────────────────────────────────────────────────┘    │ │
│  │  ┌─────────────────────────────────────────────────┐    │ │
│  │  │ 01/04/2026 · 3,000,000 VND · Chuyển khoản      │    │ │
│  │  │ INV-HCM-Q1-2504-0001 · ✅ Thành công           │    │ │
│  │  └─────────────────────────────────────────────────┘    │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  📅 Gói trả góp                           (Tab 3)      │ │
│  │  ┌─────────────────────────────────────────────────┐    │ │
│  │  │ INV-HCM-Q1-2506-0001 · Trả góp 3 kỳ           │    │ │
│  │  │ ┌─────┬───────────┬──────────┬──────────┐      │    │ │
│  │  │ │ Kỳ  │ Số tiền   │ Hạn      │ Trạng thái│     │    │ │
│  │  │ ├─────┼───────────┼──────────┼──────────┤      │    │ │
│  │  │ │  1  │ 1,500,000 │ 15/06   │ ✅ Đã TT │      │    │ │
│  │  │ │  2  │ 1,500,000 │ 15/07   │ ⏳ Chờ TT │     │    │ │
│  │  │ │  3  │ 1,500,000 │ 15/08   │ ⏳ Chờ TT │     │    │ │
│  │  │ └─────┴───────────┴──────────┴──────────┘      │    │ │
│  │  │                          [Thanh toán kỳ 2 ▶]   │    │ │
│  │  └─────────────────────────────────────────────────┘    │ │
│  └─────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

---

## 6. Phần 5: Chiến lược mở rộng bền vững (Sustainable Scaling)

### 6.1 Lazy Loading cho Module AI-Learning

```
┌─────────────────────────────────────────────────────────────────────┐
│               LAZY LOADING STRATEGY                                │
│                                                                     │
│  Level 1: CODE SPLITTING (Next.js built-in)                        │
│  ───────────────────────────────────────────                        │
│  • Mỗi module = 1 dynamic import chunk                             │
│  • AI-Learning components: next/dynamic with { ssr: false }        │
│  • Chỉ load AI module JS khi user navigate vào trang AI            │
│  • Bundle size: Core app ~150KB, AI module +~80KB (on-demand)      │
│                                                                     │
│  // Example:                                                        │
│  const AiPractice = dynamic(                                        │
│    () => import('@/components/ai-learning/practice'),               │
│    { loading: () => <PracticePageSkeleton />, ssr: false }          │
│  );                                                                 │
│                                                                     │
│  Level 2: DATA PAGINATION & VIRTUAL SCROLLING                      │
│  ──────────────────────────────────────────                         │
│  • API pagination: 20 items/page default, cursor-based             │
│  • AI submissions list: Virtual scroll (react-window)              │
│  • Grade history: Paginated with date range filter                 │
│  • Leaderboard: Top 50 cached, rest on-demand                      │
│                                                                     │
│  Level 3: DATABASE OPTIMIZATION                                     │
│  ─────────────────────────────                                     │
│  • Indexes on frequently queried columns:                          │
│    - ai_submissions: (student_id, module_id, status)               │
│    - ai_submission_results: (submission_id) — unique               │
│    - ai_gamification_scores: (student_id) — unique                 │
│  • Materialized views for analytics dashboards                     │
│  • BRIN index on created_at for time-series queries                │
│  • Connection pooling: PgBouncer (if needed at scale)              │
│                                                                     │
│  Level 4: CACHING STRATEGY                                          │
│  ────────────────────────                                          │
│  • Static content (modules, course materials): CDN cache 1h        │
│  • Dashboard KPIs: Server-side cache 30s, stale-while-revalidate  │
│  • AI results: Cached after grading (immutable data)               │
│  • Gamification scores: Cache 5min, invalidate on new submission   │
│                                                                     │
│  Level 5: PROGRESSIVE DATA LOADING                                  │
│  ─────────────────────────────                                     │
│  • Dashboard: Load KPI cards first (fast query)                    │
│  • Charts: Load asynchronously (parallel fetch)                    │
│  • AI analytics: Load only when tab is active                      │
│  • Historical data: Load on scroll/pagination                      │
│                                                                     │
│  Performance Targets:                                               │
│  ┌───────────────────┬────────────────┬───────────────────┐        │
│  │ Metric            │ Target         │ At 10K students   │        │
│  ├───────────────────┼────────────────┼───────────────────┤        │
│  │ Initial page load │ < 2s           │ < 2.5s            │        │
│  │ AI module load    │ < 1s (lazy)    │ < 1.5s            │        │
│  │ API response      │ < 200ms        │ < 500ms           │        │
│  │ AI grading        │ < 15s          │ < 15s (async)     │        │
│  │ Dashboard refresh │ < 1s           │ < 2s              │        │
│  └───────────────────┴────────────────┴───────────────────┘        │
└─────────────────────────────────────────────────────────────────────┘
```

### 6.2 Kiến trúc chống cồng kềnh (Anti-Bloat Architecture)

| Chiến lược | Cách áp dụng |
|-----------|-------------|
| **Feature Flags** | Mỗi module có flag on/off. Chi nhánh A bật AI, chi nhánh B chưa → không load AI code cho B |
| **Module Registry** | `lib/modules/registry.ts` — khai báo tất cả modules, lazy import |
| **API Route Groups** | `/api/academic/...`, `/api/finance/...`, `/api/ai/...` — clear separation |
| **Shared Component Library** | `components/ui/` — reuse, không duplicate |
| **Database Query Optimization** | Select chỉ fields cần thiết, không `select: *` |
| **Event-Driven Side Effects** | Payment → EventStore → async notification. Main flow không bị block |
| **LMS Lazy Loading** | LMS video player + quiz engine chỉ load khi user truy cập LMS routes |

---

## 7. Phần 6: Roadmap ưu tiên phát triển

### 7.1 Từ Dashboard hiện tại → All-in-one Platform

```
┌─────────────────────────────────────────────────────────────────────┐
│                    DEVELOPMENT ROADMAP                              │
│                                                                     │
│  ════════════════════════════════════════════════════════════       │
│  PHASE 1: FOUNDATION (✅ DONE)                                     │
│  ════════════════════════════════════════════════════════════       │
│  ✅ Core schema (all 6 namespaces)                                 │
│  ✅ Academic Module (full CRUD + charts)                           │
│  ✅ Auth (3 roles: admin, staff, teacher)                          │
│  ✅ Multi-branch with branch selector                              │
│  ✅ Dashboard with enrollment/utilization/branch charts            │
│  ✅ System design documentation                                    │
│  ✅ Finance Tech Spec                                              │
│  ✅ Integrated Ecosystem Architecture (this document)              │
│                                                                     │
│  ════════════════════════════════════════════════════════════       │
│  PHASE 2A: FINANCE MODULE (Next Priority)                          │
│  ════════════════════════════════════════════════════════════       │
│  🔲 Enrollment → Auto-invoice (transaction)                       │
│  🔲 Invoice CRUD API + UI pages                                   │
│  🔲 Payment recording API + UI                                    │
│  🔲 Dashboard revenue charts integration                          │
│  🔲 Finance sidebar activation                                    │
│  Estimated: 2-3 sprints                                            │
│                                                                     │
│  ════════════════════════════════════════════════════════════       │
│  PHASE 2B: AI-LEARNING FOUNDATION (Parallel)                       │
│  ════════════════════════════════════════════════════════════       │
│  🔲 AI-Learning schema migration (Prisma models)                  │
│  🔲 AI Submission API (prototype → production)                    │
│  🔲 Quiz grading with GPT-4o                                      │
│  🔲 Basic gamification (XP, streak)                                │
│  🔲 AI results → GradeRecord sync                                 │
│  Estimated: 2-3 sprints                                            │
│                                                                     │
│  ════════════════════════════════════════════════════════════       │
│  PHASE 3: PARENT & STUDENT PORTALS                                 │
│  ════════════════════════════════════════════════════════════       │
│  🔲 Parent role + auth flow                                       │
│  🔲 Parent dashboard (child progress, AI results)                  │
│  🔲 Student role + learning interface                              │
│  🔲 Parent finance portal (view invoices, payment history)         │
│  🔲 Notification system (in-app + push)                            │
│  Estimated: 3-4 sprints                                            │
│                                                                     │
│  ════════════════════════════════════════════════════════════       │
│  PHASE 4: ADVANCED AI + PAYMENT                                    │
│  ════════════════════════════════════════════════════════════       │
│  🔲 Speaking practice (Whisper integration)                        │
│  🔲 Writing assessment (rubric-based AI grading)                   │
│  🔲 Payment gateway integration (Stripe/VNPay)                    │
│  🔲 Payment plans (installments)                                   │
│  🔲 AI Learning Paths (personalized)                               │
│  🔲 2FA for payment flows                                          │
│  Estimated: 4-5 sprints                                            │
│                                                                     │
│  ════════════════════════════════════════════════════════════       │
│  PHASE 5: LMS & STUDENT PORTAL                                     │
│  ════════════════════════════════════════════════════════════       │
│  🔲 LMS schema migration (LmsCourse, LmsLesson, LmsContent...)    │
│  🔲 Course management UI (admin/teacher)                           │
│  🔲 Student self-study portal (video streaming + progress)         │
│  🔲 Quiz system + auto-grading                                     │
│  🔲 Certificate generation                                         │
│  🔲 LMS ↔ Academic grade sync (GradeRecord bridge)                │
│  Estimated: 3-4 sprints                                            │
│                                                                     │
│  ════════════════════════════════════════════════════════════       │
│  PHASE 6: HR + CRM + MOBILE                                        │
│  ════════════════════════════════════════════════════════════       │
│  🔲 HR Module (employee management, payroll)                       │
│  🔲 CRM Module (lead tracking, campaigns)                          │
│  🔲 Mobile app (React Native - Super App)                          │
│  🔲 Advanced gamification (badges, leaderboard)                    │
│  🔲 Advanced reporting & analytics                                 │
│  Estimated: 5-6 sprints                                            │
└─────────────────────────────────────────────────────────────────────┘
```

### 7.2 Ưu tiên tiếp theo (Immediate Next Steps)

| # | Task | Ưu tiên | Lý do |
|---|------|---------|-------|
| 1 | **Thêm AI-Learning Prisma models** | 🔴 Cao | Foundation cho toàn bộ AI features |
| 2 | **API prototype `/api/academic/ai-submission`** | 🔴 Cao | Validate kiến trúc AI |
| 3 | **Enrollment → Auto-invoice transaction** | 🔴 Cao | Finance module core feature |
| 4 | **Invoice CRUD API + UI** | 🟡 Trung bình | User-facing finance |
| 5 | **Parent role trong auth** | 🟡 Trung bình | Unlock parent portal |
| 6 | **Revenue chart on Dashboard** | 🟢 Thấp | Visualization (sau khi có data) |
| 7 | **LMS schema + Prisma models** | 🟡 Trung bình | Foundation cho Student Portal |
| 8 | **LMS Course CRUD API + UI** | 🟡 Trung bình | Admin quản lý khóa học online |

---

## Phụ lục A: Prototype API Reference

Xem file: `app/api/academic/ai-submission/route.ts` (đã triển khai)

## Phụ lục B: Tài liệu liên quan

- `docs/TECH_SPEC_FINANCE_MODULE.md` — Chi tiết Finance Module
- `docs/AEA_ARCHITECTURAL_SPECIFICATION.md#7` — LMS Module Schema & Functional Spec
- `docs/aea_database_ddl.sql` — Full DDL script
- `prisma/schema.prisma` — Source of truth cho data models
- `.project_instructions.md` — Project context & decisions