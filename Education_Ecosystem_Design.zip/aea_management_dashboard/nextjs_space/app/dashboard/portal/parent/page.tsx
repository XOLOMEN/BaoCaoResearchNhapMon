import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import ParentDashboardContent from './parent-dashboard-content';

export default async function ParentPortalPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/login');
  if (session.user.role !== 'parent') redirect('/dashboard');
  return <ParentDashboardContent />;
}
