'use client';
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FadeIn } from '@/components/ui/animate';
import {
  Users, BookOpen, Clock, Trophy, TrendingUp,
  CheckCircle2, Award, GraduationCap
} from 'lucide-react';

export default function ParentDashboardContent() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/portal/parent')
      .then(r => r.json())
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="h-64 bg-muted animate-pulse rounded-xl" />
      </div>
    );
  }

  const children = data?.children ?? [];

  return (
    <FadeIn>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Phụ huynh Dashboard</h2>
          <p className="text-muted-foreground">Theo dõi tiến độ học tập của con bạn.</p>
        </div>

        {children.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Users className="w-12 h-12 text-muted-foreground/30 mb-4" />
              <p className="text-lg font-medium text-muted-foreground">Chưa liên kết với học viên nào</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Vui lòng liên hệ nhà trường để liên kết tài khoản.</p>
            </CardContent>
          </Card>
        ) : (
          children.map((child: any) => {
            const student = child.student;
            const stats = child.stats;
            const enrollments = child.enrollments ?? [];
            const certificates = child.certificates ?? [];

            return (
              <div key={student.id} className="space-y-4">
                {/* Student header */}
                <Card className="border-0 shadow-sm bg-gradient-to-r from-primary/5 to-primary/10">
                  <CardContent className="p-5">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
                        <GraduationCap className="w-7 h-7 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-bold">{student.fullName}</h3>
                        <p className="text-sm text-muted-foreground">Mã HV: {student.studentCode} • Trình độ: {student.level || 'Chưa xác định'}</p>
                      </div>
                      <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                        {student.status === 'active' ? 'Đang học' : student.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Stats */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                  {[
                    { label: 'Khóa học', value: stats.totalCourses, icon: BookOpen, color: 'text-blue-600 bg-blue-50' },
                    { label: 'Đang học', value: stats.activeCourses, icon: TrendingUp, color: 'text-emerald-600 bg-emerald-50' },
                    { label: 'Hoàn thành', value: stats.completedCourses, icon: Trophy, color: 'text-amber-600 bg-amber-50' },
                    { label: 'Tiến độ TB', value: `${stats.avgProgress}%`, icon: CheckCircle2, color: 'text-indigo-600 bg-indigo-50' },
                    { label: 'Thời gian', value: `${stats.totalTimeSpentMin}p`, icon: Clock, color: 'text-purple-600 bg-purple-50' },
                  ].map((kpi, idx) => (
                    <Card key={idx} className="border-0 shadow-sm">
                      <CardContent className="flex items-center gap-3 p-4">
                        <div className={`p-2 rounded-lg ${kpi.color}`}>
                          <kpi.icon className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">{kpi.label}</p>
                          <p className="text-lg font-bold">{kpi.value}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Course Progress */}
                <Card className="border-0 shadow-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Tiến độ khóa học</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {enrollments.length === 0 ? (
                      <p className="text-sm text-muted-foreground py-4 text-center">Chưa ghi danh khóa học nào</p>
                    ) : (
                      enrollments.map((e: any) => {
                        const course = e.lmsCourse;
                        const completedLessons = e.progress?.filter((p: any) => p.status === 'completed').length ?? 0;
                        const totalLessons = e.progress?.length ?? 0;

                        return (
                          <div key={e.id} className="p-4 border rounded-lg space-y-2">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-sm">{course?.title}</p>
                                <p className="text-xs text-muted-foreground">{completedLessons}/{totalLessons} bài hoàn thành</p>
                              </div>
                              <Badge variant={e.status === 'completed' ? 'default' : 'secondary'} className="text-xs">
                                {e.status === 'completed' ? 'Hoàn thành' : 'Đang học'}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-3">
                              <Progress value={e.progressPct} className="h-2 flex-1" />
                              <span className="text-xs font-medium text-primary">{Math.round(e.progressPct)}%</span>
                            </div>
                            {/* Recent lesson progress */}
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {e.progress?.slice(0, 4).map((p: any) => (
                                <div key={p.id} className="flex items-center gap-1 text-[11px]">
                                  {p.status === 'completed' ? (
                                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                                  ) : (
                                    <div className="w-3 h-3 rounded-full border border-muted-foreground/30" />
                                  )}
                                  <span className="text-muted-foreground truncate max-w-[100px]">{p.lesson?.title}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </CardContent>
                </Card>

                {/* Certificates */}
                {certificates.length > 0 && (
                  <Card className="border-0 shadow-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Chứng chỉ</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {certificates.map((cert: any) => (
                          <div key={cert.id} className="flex items-center gap-3 p-3 rounded-lg border bg-gradient-to-r from-amber-50/50 to-yellow-50/50">
                            <Award className="w-8 h-8 text-amber-500 shrink-0" />
                            <div>
                              <p className="text-sm font-medium">{cert.lmsCourse?.title}</p>
                              <p className="text-xs text-muted-foreground">Ngày cấp: {new Date(cert.issuedAt).toLocaleDateString('vi-VN')}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            );
          })
        )}
      </div>
    </FadeIn>
  );
}
